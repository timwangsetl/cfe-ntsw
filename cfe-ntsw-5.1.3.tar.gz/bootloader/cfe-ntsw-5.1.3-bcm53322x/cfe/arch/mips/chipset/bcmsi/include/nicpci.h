/*
 * BCM43XX PCI/E core sw API definitions.
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: nicpci.h,v 1.2 2009/02/25 02:36:28 kliao Exp $
 */

#ifndef	_NICPCI_H
#define	_NICPCI_H

struct sbpcieregs;
extern uint8 pcicore_find_pci_capability(osl_t *osh, uint8 req_cap_id,
                                         uchar *buf, uint32 *buflen);
extern uint pcie_readreg(osl_t *osh, struct sbpcieregs *pcieregs, uint addrtype, uint offset);
extern uint pcie_writereg(osl_t *osh, struct sbpcieregs *pcieregs, uint addrtype, uint offset,
                          uint val);

extern uint8 pcie_clkreq(void *pch, uint32 mask, uint32 val);

extern void *pcicore_init(si_t *sih, osl_t *osh, void *regs);
extern void pcicore_deinit(void *pch);
extern void pcicore_attach(void *pch, char *pvars, int state);
extern void pcicore_hwup(void *pch);

#endif	/* _NICPCI_H */

