/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *
    *  Broadcom Silicon Backplane PCI support   File: sb_pci_machdep.c
    *  
    *  Author:  Ed Satterthwaite
    *  
    *********************************************************************  
    *
    *  Copyright 2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

/*
 * AXI machine-specific functions for PCI autoconfiguration.
 */

#include "cfe.h"
#include "pcivar.h"
#include "pci_internal.h"
#include "siutils.h"
#include "hndsoc.h"
#include "hndpci.h"
#include "pcireg.h"

/* default PCI mem regions in PCI space */
#define PCI_MEM_SPACE_BASE  SI_PCI_MEM
#define PCI1_MEM_SPACE_BASE  SI_PCI1_MEM
#define PCI_MEM_SPACE_SIZE  SI_PCI_MEM_SZ

const cons_t pci_optnames[] = {
    {"verbose",PCI_FLG_VERBOSE},
    {NULL,0}
};

static const struct pci_bus init_pci_bus = {
    0,      /* minimum grant */
    255,        /* maximum latency */
    0,      /* devsel time = fast */
    0,      /* we don't support fast back-to-back */
    0,      /* we don't support prefetch */
    0,      /* we don't support 66 MHz */
    0,      /* we don't support 64 bits */
    4000000,    /* bandwidth: in 0.25us cycles / sec */
    1       /* initially one device on bus (i.e. us) */
};
#define MAXBUS	16
static struct pci_bus _pci_bus[MAXBUS];
static int _pci_nbus = 0;
/* PCIe port 1 */
static struct pci_bus _pci1_bus[MAXBUS];
static int _pci1_nbus = 0;


static si_t *sih = NULL;

extern int _pciverbose;

/* The following functions provide for device-specific setup required
   during configuration.  There is nothing host-specific about them,
   and it would be better to do the packaging and registration in a
   more modular way. */

/* The following should return the index of the last usable bus port. */
int
pci_maxport (void)
{
    return PCI_HOST_PORTS - 1;
}


int
pci_nextbus(int port)
{
    int bus = 0;

    if (port == 0) {
        bus = _pci_nbus;
    } else {
        bus = _pci1_nbus;
    }
    if (bus >= MAXBUS)
	return -1;
    if (port == 0) {
        _pci_nbus++;
    } else {
        _pci1_nbus++;
    }
    return bus;
}
  
int
pci_maxbus(int port)
{
    return ((port == 0)?_pci_nbus - 1:_pci1_nbus - 1);
}

struct pci_bus *
pci_businfo(int port, int bus)
{
    if (port == 0) {
        if (bus < _pci_nbus)
            return &_pci_bus[bus];
    } else {
        if (bus < _pci1_nbus)
            return &_pci1_bus[bus];
    }
    return NULL;
}

pcireg_t
pci_minmemaddr(int port)
{
    if (port == 1) {
        return PCI1_MEM_SPACE_BASE;
    }

    return PCI_MEM_SPACE_BASE;
}

pcireg_t
pci_maxmemaddr(int port)
{
    return pci_minmemaddr(port) + PCI_MEM_SPACE_SIZE;
}

pcireg_t
pci_minioaddr(int port)
{
    return 0;
}

pcireg_t
pci_maxioaddr(int port)
{
    return 0;
}

/*
 * Called to initialise the bridge at the beginning of time
 */
int
pci_hwinit(int port, pci_flags_t flags)
{
    int i, status = 0;
    
    if (port == 0) {
        memcpy(&_pci_bus[_pci_nbus], &init_pci_bus, sizeof(struct pci_bus));
        _pci_bus[_pci_nbus].port = port;
        _pci_nbus++;
        for (i = _pci_nbus; i < MAXBUS; i++)
	    memcpy(&_pci_bus[i], &init_pci_bus, sizeof(struct pci_bus));
    } else {
        memcpy(&_pci1_bus[_pci1_nbus], &init_pci_bus, sizeof(struct pci_bus));
        _pci1_bus[_pci1_nbus].port = port;
        _pci1_nbus++;
        for (i = _pci1_nbus; i < MAXBUS; i++)
            memcpy(&_pci1_bus[i], &init_pci_bus, sizeof(struct pci_bus));
    }

    /* attach to backplane */
    if (!(sih = si_kattach(SI_OSH)))
        return -1;

    status = hndpci_init_pci(sih, port);
    /* emulate PCI devices */
    hndpci_init_cores(sih);
    return status;
}


/*
 * Called to reinitialise the bridge after we've scanned each PCI device
 * and know what is possible.
 */
void
pci_hwreinit(int port, pci_flags_t flags)
{
}

void
pci_flush(void)
{
}

pcitag_t
pci_make_tag(int port, int bus, int device, int function)
{
    return (port << 24) | (bus << 16) | (device << 11) | (function << 8);
}

void
pci_break_tag(pcitag_t tag, int *portp, int *busp, int *devicep, int *functionp)
{
    if (portp) *portp = (tag >> 24) & 0xff;
    if (busp) *busp = (tag >> 16) & 0xff;
    if (devicep) *devicep = (tag >> 11) & 0x1f;
    if (functionp) *functionp = (tag >> 8) & 0x07;
}

int
pci_canscan(pcitag_t tag)
{
    int bus, device, function;
    
    pci_break_tag(tag, NULL, &bus, &device, &function); 
    if (bus > PCI_BUSMAX || device > PCI_DEVMAX || function > PCI_FUNCMAX)
		return 0;

    return (bus != 0 || (device >= 0 && device < 16));
}

pcireg_t
pci_conf_read(pcitag_t tag, int reg)
{
    int bus, device, function, port;
    pcireg_t data;

    pci_break_tag(tag, &port, &bus, &device, &function); 

	/* The bus number 0 means internal SI bus in hndpci.c */
	/* We need to increase the bus number for external bus */
    if (hndpci_read_config(sih, (uint32_t)port, (uint32_t)(bus + 1), (uint32_t)device, 
                           (uint32_t)function, (uint32_t)reg,
                           (void *)&data, sizeof(pcireg_t)))
        data = 0xffffffff;

    return data;
}


void
pci_conf_write(pcitag_t tag, int reg, pcireg_t data)
{
    int bus, device, function, port;

    pci_break_tag(tag, &port, &bus, &device, &function);

	/* The bus number 0 means internal SI bus in hndpci.c */
	/* We need to increase the bus number for external bus */
    hndpci_write_config(sih, (uint32_t)port, (uint32_t)(bus + 1), (uint32_t)device, 
                        (uint32_t)function, (uint32_t)reg,
                        (void *)&data, sizeof(pcireg_t));
}

int
pci_conf_write_acked(pcitag_t tag, int reg, pcireg_t data)
{
    pci_conf_write(tag, reg, data);
    return 1;
}

pcireg_t
pci_conf_read16(pcitag_t tag, int reg)
{
    int bus, device, function, port;
    uint16_t data;

    pci_break_tag(tag, &port, &bus, &device, &function); 

	/* The bus number 0 means internal SI bus in hndpci.c */
	/* We need to increase the bus number for external bus */
    if (hndpci_read_config(sih, (uint32_t)port, (uint32_t)(bus + 1), (uint32_t)device, 
                           (uint32_t)function, (uint32_t)reg,
                           (void *)&data, sizeof(data)))
        data = 0xffff;

    return data;
}

void
pci_conf_write16(pcitag_t tag, int reg, pcireg_t data)
{
    int bus, device, function, port;
    uint16_t tmp = (uint16_t)data;

    pci_break_tag(tag, &port, &bus, &device, &function);

	/* The bus number 0 means internal SI bus in hndpci.c */
	/* We need to increase the bus number for external bus */  
    hndpci_write_config(sih, (uint32_t)port, (uint32_t)(bus + 1), (uint32_t)device, 
                        (uint32_t)function, (uint32_t)reg,
                        (void *)&tmp, sizeof(tmp));
}

int
pci_map_io(pcitag_t tag, int reg, pci_endian_t endian, phys_addr_t *pap)
{
    return -1;
}

int
pci_map_mem(pcitag_t tag, int reg, pci_endian_t endian, phys_addr_t *pap)
{
    pcireg_t address;
    phys_addr_t pa;

    if (reg == PCI_MAPREG_ROM) {
        /* expansion ROM */
        address = pci_conf_read(tag, reg);
        if (!(address & PCI_MAPREG_ROM)) {
            pci_tagprintf(tag, "pci_map_mem: attempt to map missing rom\n");
            return -1;
        }
        pa = address & PCI_MAPREG_ROM_ADDR_MASK;
    }
    else {
        if (reg < PCI_MAPREG_START || reg >= PCI_MAPREG_END || (reg & 3)) {
            if (_pciverbose >= 1)
                pci_tagprintf(tag, "pci_map_mem: bad request\n");
            return -1;
        }
    
        address = pci_conf_read(tag, reg);
        if ((address & PCI_MAPREG_TYPE_IO) != 0) {
            if (_pciverbose >= 1)
                pci_tagprintf(tag, "pci_map_mem: attempt to memory map an I/O region\n");
            return -1;
        }
    
        switch (address & PCI_MAPREG_MEM_TYPE_MASK) {
        case PCI_MAPREG_MEM_TYPE_32BIT:
        case PCI_MAPREG_MEM_TYPE_32BIT_1M:
            break;
        case PCI_MAPREG_MEM_TYPE_64BIT:
            if (_pciverbose >= 1)
                pci_tagprintf (tag, "pci_map_mem: attempt to map 64-bit region tag=0x%X @ addr=%X\n", tag, address);
            break;
        default:
            if (_pciverbose >= 1)
                pci_tagprintf (tag, "pci_map_mem: reserved mapping type\n");
            return -1;
        }
        pa = address & PCI_MAPREG_MEM_ADDR_MASK;
    }

    if (_pciverbose >= 1)
        pci_tagprintf (tag, "pci_map_mem: addr=0x%X pa=0x%X\n", address, pa);

    *pap = pa;
    return 0;
}

int
pci_probe_tag(pcitag_t tag)
{
    pcireg_t data;

    if (!pci_canscan(tag))
        return 0;

    data = pci_conf_read(tag,PCI_ID_REG);
    if ((data == 0) || (data == 0xffffffff))
        return 0;

    return 1;
}

int
pci_map_window(phys_addr_t va,
           unsigned int offset, unsigned int len,
           int l2ca, int endian)
{
    return -1;
}

int
pci_unmap_window(unsigned int offset, unsigned int len)
{
    return -1;
}

/* Called for each hostbridge, to discover and scan secondary buses */
void
pci_businit_hostbridge (pcitag_t tag, pci_flags_t flags)
{
}

int
pci_device_preset(pcitag_t tag)
{
    return -1;
}

void
pci_device_setup(pcitag_t tag)
{
}

/* Called for each bridge after configuring the secondary bus, to allow
   device-specific initialization. */
void
pci_bridge_setup(pcitag_t tag, pci_flags_t flags)
{
}

/* The base shift of a slot or device on the motherboard. */
uint8_t
pci_int_shift_0(pcitag_t tag)
{
    return 0;
}

uint8_t
pci_int_map_0(pcitag_t tag)
{
    return 0;
}

uint8_t
pci_int_line(uint8_t pci_int)
{
    return 0;
}

