/*
 * Misc utility routines for accessing PMU corerev specific features
 * of the SiliconBackplane-based Broadcom chips.
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: hndpmu.c,v 1.5 2010/05/11 10:25:28 alai Exp $
 */

#include "cfe.h"
#include "typedefs.h"
#include "osl.h"
#include "bcmutils.h"
#include "siutils.h"
#include "bcmdevs.h"
#include "hndsoc.h"
#include "sbchipc.h"
#include "hndpmu.h"

/* debug/trace */
#ifdef BCMDBG_ERR
#define PMU_ERROR(args) printf args
#else
#define PMU_ERROR(args)
#endif  /* BCMDBG_ERR */

#ifdef BCMDBG
#define PMU_MSG(args)   printf args
#else
#define PMU_MSG(args)
#endif  /* BCMDBG */


/* initialize PMU */
void
si_pmu_init(si_t *sih, osl_t *osh)
{
    chipcregs_t *cc;
    uint origidx;
    uint cid;

    ASSERT(sih->cccaps & CC_CAP_PMU);

    /* Remember original core before switch to chipc */
    origidx = si_coreidx(sih);
    cc = si_setcoreidx(sih, SI_CC_IDX);
    ASSERT(cc != NULL);

    /* XXX Feature is added in PMU rev. 1 but doesn't work until rev. 2 */
    if (sih->pmurev == 1)
        AND_REG(osh, &cc->pmucontrol, ~PCTL_NOILP_ON_WAIT);
    else if (sih->pmurev >= 2)
        OR_REG(osh, &cc->pmucontrol, PCTL_NOILP_ON_WAIT);
        
    /* 
     * Workaround for MIPS "wait" instruction on bcm5300x: 
     *    set ForceHT (in one core) to avoid entering ALP mode.
     */
    OR_REG(osh, &cc->clk_ctl_st, CLK_CTL_FORCEHT);

    /* Return to original core */
    si_setcoreidx(sih, origidx);


    /* Power down analog parts according to bondings */
    cid = (R_REG(sii->osh, &cc->chipid) & CID_PKG_MASK) >> CID_PKG_SHIFT;
    if (cid == 1) {
        /* BCM53001 */
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_DDR2, 2, \
                                             POWER_SWITCH_STATE_OFF);
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_DDR2, 3, \
                                             POWER_SWITCH_STATE_OFF);
        
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_SGMII, 0, \
                                             POWER_SWITCH_STATE_OFF);
    }
    if (cid == 2) {
        /* BCM53002 */
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_DDR2, 2, \
                                             POWER_SWITCH_STATE_OFF);
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_DDR2, 3, \
                                             POWER_SWITCH_STATE_OFF);
        
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_PCIE, \
                      POWER_SWITCH_ID_PCIE_1, POWER_SWITCH_STATE_OFF);
    }
}


/* initialize PLL */
void
si_pmu_pll_init(si_t *sih, osl_t *osh, uint xtalfreq)
{
    chipcregs_t *cc;
    uint origidx;

    ASSERT(sih->cccaps & CC_CAP_PMU);

    /* Remember original core before switch to chipc */
    origidx = si_coreidx(sih);
    cc = si_setcoreidx(sih, SI_CC_IDX);
    ASSERT(cc != NULL);

    switch (CHIPID(sih->chip)) {
#ifdef UNRELEASEDCHIP
    case BCM4329_CHIP_ID:
        si_pmu1_pllinit0(sih, osh, cc, xtalfreq);
        break;
    case BCM4315_CHIP_ID:
        si_pmu1_pllinit0(sih, osh, cc, xtalfreq);
        break;
    case BCM4319_CHIP_ID:
        si_pmu1_pllinit0(sih, osh, cc, xtalfreq);
        break;

    case BCM43222_CHIP_ID:
    case BCM43224_CHIP_ID:
    case BCM43226_CHIP_ID:
        break;
#endif  /* UNRELEASEDCHIP */

    default:
        PMU_MSG(("No PLL init done for chip %x rev %d pmurev %d\n",
                 sih->chip, sih->chiprev, sih->pmurev));
        break;
    }

    /* Return to original core */
    si_setcoreidx(sih, origidx);
}


/* Setup resource up/down timers */
typedef struct {
    uint8 resnum;
    uint16 updown;
} pmu_res_updown_t;

/* Change resource dependancies masks */
typedef struct {
    uint32 res_mask;        /* resources (chip specific) */
    int8 action;            /* action */
    uint32 depend_mask;     /* changes to the dependancies mask */
    bool (*filter)(si_t *sih);  /* action is taken when filter is NULL or return TRUE */
} pmu_res_depend_t;

/* Resource dependancies mask change action */
#define RES_DEPEND_SET      0   /* Override the dependancies mask */
#define RES_DEPEND_ADD      1   /* Add to the  dependancies mask */
#define RES_DEPEND_REMOVE   -1  /* Remove from the dependancies mask */


/* Determine min/max rsrc masks. Value 0 leaves hardware at default. */
static void
si_pmu_res_masks(si_t *sih, uint32 *pmin, uint32 *pmax)
{
    uint32 min_mask = 0, max_mask = 0;
    uint rsrcs;
    char *val;

    /* # resources */
    rsrcs = (sih->pmucaps & PCAP_RC_MASK) >> PCAP_RC_SHIFT;

    /* determine min/max rsrc masks */
    switch (CHIPID(sih->chip)) {

#ifdef UNRELEASEDCHIP
    case BCM4329_CHIP_ID:
         /* min_mask = 0x2fe63e; */
        min_mask =
         PMURES_BIT(RES4329_CBUCK_LPOM) |
         PMURES_BIT(RES4329_CBUCK_BURST) |
         PMURES_BIT(RES4329_CBUCK_PWM) |
         PMURES_BIT(RES4329_CLDO_PU) |
         PMURES_BIT(RES4329_PALDO_PU) |
         PMURES_BIT(RES4329_LNLDO1_PU) |
         PMURES_BIT(RES4329_OTP_PU) |
         PMURES_BIT(RES4329_XTAL_PU) |
         PMURES_BIT(RES4329_ALP_AVAIL) |
         PMURES_BIT(RES4329_RX_PWRSW_PU) |
         PMURES_BIT(RES4329_TX_PWRSW_PU) |
         PMURES_BIT(RES4329_RFPLL_PWRSW_PU) |
         PMURES_BIT(RES4329_LOGEN_PWRSW_PU) |
         PMURES_BIT(RES4329_AFE_PWRSW_PU) |
         PMURES_BIT(RES4329_HT_AVAIL);
        /* Allow (but don't require) PLL to turn on */
        max_mask = 0x3fffff;
        break;
    case BCM4315_CHIP_ID:
        /* We only need a few resources to be kept on all the time */
        if (!(sih->boardflags & BFL_NOCBUCK))
            min_mask = PMURES_BIT(RES4315_CBUCK_LPOM);
        min_mask |= PMURES_BIT(RES4315_CLDO_PU);
        /* Allow everything else to be turned on upon requests */
        max_mask = ~(~0 << rsrcs);
        break;
    case BCM4319_CHIP_ID:
        /* We only need a few resources to be kept on all the time */
        min_mask = PMURES_BIT(RES4319_CBUCK_LPOM);
        min_mask |= PMURES_BIT(RES4319_CLDO_PU);
        min_mask |= PMURES_BIT(RES4319_PALDO_PU);
        /* Allow everything else to be turned on upon requests */
        max_mask = ~(~0 << rsrcs);
        break;

    case BCM43222_CHIP_ID:
    case BCM43224_CHIP_ID:
    case BCM43226_CHIP_ID:
        /* ?? */
        break;
#endif  /* UNRELEASEDCHIP */

    default:
        break;
    }

    /* Apply nvram override to min mask */
    if ((val = getvar(NULL, "rmin")) != NULL) {
        PMU_MSG(("Applying rmin=%s to min_mask\n", val));
        min_mask = (uint32)bcm_strtoul(val, NULL, 0);
    }
    /* Apply nvram override to max mask */
    if ((val = getvar(NULL, "rmax")) != NULL) {
        PMU_MSG(("Applying rmax=%s to max_mask\n", val));
        max_mask = (uint32)bcm_strtoul(val, NULL, 0);
    }

    *pmin = min_mask;
    *pmax = max_mask;
}


/* initialize PMU resources */
void
si_pmu_res_init(si_t *sih, osl_t *osh)
{
    chipcregs_t *cc;
    uint origidx;
    const pmu_res_updown_t *pmu_res_updown_table = NULL;
    uint pmu_res_updown_table_sz = 0;
    const pmu_res_depend_t *pmu_res_depend_table = NULL;
    uint pmu_res_depend_table_sz = 0;
    uint32 min_mask = 0, max_mask = 0;
    char name[8], *val;
    uint i, rsrcs;

    ASSERT(sih->cccaps & CC_CAP_PMU);

    /* Remember original core before switch to chipc */
    origidx = si_coreidx(sih);
    cc = si_setcoreidx(sih, SI_CC_IDX);
    ASSERT(cc != NULL);

    switch (CHIPID(sih->chip)) {
#ifdef UNRELEASEDCHIP
    case BCM4315_CHIP_ID:
        /* Optimize resources up/down timers */
        if (ISSIM_ENAB(sih)) {
            pmu_res_updown_table = bcm4315a0_res_updown_qt;
            pmu_res_updown_table_sz = ARRAYSIZE(bcm4315a0_res_updown_qt);
        }
        else {
            pmu_res_updown_table = bcm4315a0_res_updown;
            pmu_res_updown_table_sz = ARRAYSIZE(bcm4315a0_res_updown);
        }
        /* Optimize resources dependancies masks */
        pmu_res_depend_table = bcm4315a0_res_depend;
        pmu_res_depend_table_sz = ARRAYSIZE(bcm4315a0_res_depend);
        break;
    case BCM4319_CHIP_ID:
        /* Optimize resources up/down timers */
        if (ISSIM_ENAB(sih)) {
            pmu_res_updown_table = bcm4319a0_res_updown_qt;
            pmu_res_updown_table_sz = ARRAYSIZE(bcm4319a0_res_updown_qt);
        }
        else {
            pmu_res_updown_table = NULL;
            pmu_res_updown_table_sz = 0;
        }
        /* Optimize resources dependancies masks */
        pmu_res_depend_table = bcm4319a0_res_depend;
        pmu_res_depend_table_sz = ARRAYSIZE(bcm4319a0_res_depend);
        break;
#endif  /* UNRELEASEDCHIP */

    default:
        break;
    }

    /* # resources */
    rsrcs = (sih->pmucaps & PCAP_RC_MASK) >> PCAP_RC_SHIFT;

    /* Program up/down timers */
    while (pmu_res_updown_table_sz--) {
        ASSERT(pmu_res_updown_table != NULL);
        PMU_MSG(("Changing rsrc %d res_updn_timer to 0x%x\n",
                 pmu_res_updown_table[pmu_res_updown_table_sz].resnum,
                 pmu_res_updown_table[pmu_res_updown_table_sz].updown));
        W_REG(osh, &cc->res_table_sel,
              pmu_res_updown_table[pmu_res_updown_table_sz].resnum);
        W_REG(osh, &cc->res_updn_timer,
              pmu_res_updown_table[pmu_res_updown_table_sz].updown);
    }
    /* Apply nvram overrides to up/down timers */
    for (i = 0; i < rsrcs; i ++) {
        if ((val = getvar(NULL, name)) == NULL)
            continue;
        PMU_MSG(("Applying %s=%s to rsrc %d res_updn_timer\n", name, val, i));
        W_REG(osh, &cc->res_table_sel, (uint32)i);
        W_REG(osh, &cc->res_updn_timer, (uint32)bcm_strtoul(val, NULL, 0));
    }

    /* Program resource dependencies table */
    while (pmu_res_depend_table_sz--) {
        ASSERT(pmu_res_depend_table != NULL);
        if (pmu_res_depend_table[pmu_res_depend_table_sz].filter != NULL &&
            !(pmu_res_depend_table[pmu_res_depend_table_sz].filter)(sih))
            continue;
        for (i = 0; i < rsrcs; i ++) {
            if ((pmu_res_depend_table[pmu_res_depend_table_sz].res_mask &
                 PMURES_BIT(i)) == 0)
                continue;
            W_REG(osh, &cc->res_table_sel, i);
            switch (pmu_res_depend_table[pmu_res_depend_table_sz].action) {
            case RES_DEPEND_SET:
                PMU_MSG(("Changing rsrc %d res_dep_mask to 0x%x\n", i,
                    pmu_res_depend_table[pmu_res_depend_table_sz].depend_mask));
                W_REG(osh, &cc->res_dep_mask,
                      pmu_res_depend_table[pmu_res_depend_table_sz].depend_mask);
                break;
            case RES_DEPEND_ADD:
                PMU_MSG(("Adding 0x%x to rsrc %d res_dep_mask\n",
                    pmu_res_depend_table[pmu_res_depend_table_sz].depend_mask, i));
                OR_REG(osh, &cc->res_dep_mask,
                       pmu_res_depend_table[pmu_res_depend_table_sz].depend_mask);
                break;
            case RES_DEPEND_REMOVE:
                PMU_MSG(("Removing 0x%x from rsrc %d res_dep_mask\n",
                    pmu_res_depend_table[pmu_res_depend_table_sz].depend_mask, i));
                AND_REG(osh, &cc->res_dep_mask,
                        ~pmu_res_depend_table[pmu_res_depend_table_sz].depend_mask);
                break;
            default:
                ASSERT(0);
                break;
            }
        }
    }
    /* Apply nvram overrides to dependancies masks */
    for (i = 0; i < rsrcs; i ++) {
        if ((val = getvar(NULL, name)) == NULL)
            continue;
        PMU_MSG(("Applying %s=%s to rsrc %d res_dep_mask\n", name, val, i));
        W_REG(osh, &cc->res_table_sel, (uint32)i);
        W_REG(osh, &cc->res_dep_mask, (uint32)bcm_strtoul(val, NULL, 0));
    }

    if (CHIPID(sih->chip) != BCM53000_CHIP_ID) {

        /* Determine min/max rsrc masks */
        si_pmu_res_masks(sih, &min_mask, &max_mask);
    
        /* Program min resource mask */
        if (min_mask) {
            PMU_MSG(("Changing min_res_mask to 0x%x\n", min_mask));
            W_REG(osh, &cc->min_res_mask, min_mask);
        }
        /* Program max resource mask */
        if (max_mask) {
            PMU_MSG(("Changing max_res_mask to 0x%x\n", max_mask));
            W_REG(osh, &cc->max_res_mask, max_mask);
        }
    }

    /* Return to original core */
    si_setcoreidx(sih, origidx);
}


/* query alp/xtal clock frequency */
uint32
si_pmu_alp_clock(si_t *sih, osl_t *osh)
{
    chipcregs_t *cc;
    uint origidx;
    uint32 clock = ALP_CLOCK;

    ASSERT(sih->cccaps & CC_CAP_PMU);

    /* Remember original core before switch to chipc */
    origidx = si_coreidx(sih);
    cc = si_setcoreidx(sih, SI_CC_IDX);
    ASSERT(cc != NULL);

    switch (sih->chip) {
    case BCM4716_CHIP_ID:
        /* always 20Mhz */
        clock = 20000 * 1000;
        break;
    default:
        PMU_MSG(("No ALP clock specified "
            "for chip %x rev %d pmurev %d, using default %d Hz\n",
            sih->chip, sih->chiprev, sih->pmurev, clock));
        break;
    }

    /* Return to original core */
    si_setcoreidx(sih, origidx);
    return clock;
}

/* query backplane clock frequency */
/* For designs that feed the same clock to both backplane
 * and CPU just return the CPU clock speed.
 */
uint32
si_pmu_si_clock(si_t *sih, osl_t *osh)
{
    chipcregs_t *cc;
    uint origidx;
    uint32 clock = HT_CLOCK;

    ASSERT(sih->cccaps & CC_CAP_PMU);

    /* Remember original core before switch to chipc */
    origidx = si_coreidx(sih);
    cc = si_setcoreidx(sih, SI_CC_IDX);
    ASSERT(cc != NULL);

    switch (CHIPID(sih->chip)) {
    case BCM4716_CHIP_ID:
        /* XXX: Fix */
        clock = 133000000;
        break;
    case BCM53000_CHIP_ID:
        clock = si_clock();
        break;

    default:
        PMU_MSG(("No backplane clock specified "
            "for chip %x rev %d pmurev %d, using default %d Hz\n",
            sih->chip, sih->chiprev, sih->pmurev, clock));
        break;
    }

    /* Return to original core */
    si_setcoreidx(sih, origidx);
    return clock;
}

/* query CPU clock frequency */
/* XXX For now just simply call si_pmu_si_clock() to return the backplane
 * clock speed instead since all current CPU chips are feeding the same
 * clock to both backplane and CPU.
 */
uint32
si_pmu_cpu_clock(si_t *sih, osl_t *osh)
{
    return si_cpu_clock();
}

/* query ILP clock frequency */
/* XXX The variable ilpcycles_per_sec is used to store the ILP clock speed. The value
 * is calculated when the function is called the first time using PMU.timer ellapsed
 * during the time defined by ILP_CALC_DUR and then cached. Before first time calling
 * the function one must make sure the HT clock is turned on and used to feed the CPU
 * and OSL_DELAY() is calibrated and available.
 */
#define ILP_CALC_DUR    10  /* ms, make sure 1000 can be divided by it. */
uint32
si_pmu_ilp_clock(si_t *sih, osl_t *osh)
{
    static uint32 ilpcycles_per_sec = 0;

    if (ISSIM_ENAB(sih))
        return ILP_CLOCK;

    if (ilpcycles_per_sec == 0) {
        uint32 start, end, delta;
        uint32 origidx = si_coreidx(sih);
        chipcregs_t *cc = si_setcoreidx(sih, SI_CC_IDX);
        ASSERT(cc != NULL);
        start = R_REG(osh, &cc->pmutimer);
        OSL_DELAY(ILP_CALC_DUR * 1000);
        end = R_REG(osh, &cc->pmutimer);
        delta = end >= start ? end - start : ~0 - start + 1 + end;
        ilpcycles_per_sec = delta * (1000 / ILP_CALC_DUR);
        si_setcoreidx(sih, origidx);
    }

    return ilpcycles_per_sec;
}

void
si_pmu_sprom_enable(si_t *sih, osl_t *osh, bool enable)
{
    chipcregs_t *cc;
    uint origidx;

    /* Remember original core before switch to chipc */
    origidx = si_coreidx(sih);
    cc = si_setcoreidx(sih, SI_CC_IDX);
    ASSERT(cc != NULL);

    switch (CHIPID(sih->chip)) {
#ifdef UNRELEASEDCHIP
    case BCM4315_CHIP_ID:
        if (sih->chiprev < 1)
            break;
        if (sih->chipst & CST4315_SPROM_SEL) {
            uint32 val;
            W_REG(osh, &cc->chipcontrol_addr, 0);
            val = R_REG(osh, &cc->chipcontrol_data);
            if (enable)
                val &= ~0x80000000;
            else
                val |= 0x80000000;
            W_REG(osh, &cc->chipcontrol_data, val);
        }
        break;
#endif /* UNRELEASEDCHIP */
    default:
        break;
    }

    /* Return to original core */
    si_setcoreidx(sih, origidx);
}

bool
si_pmu_is_sprom_enabled(si_t *sih, osl_t *osh)
{
    chipcregs_t *cc;
    uint origidx;
    bool enable = TRUE;

    /* Remember original core before switch to chipc */
    origidx = si_coreidx(sih);
    cc = si_setcoreidx(sih, SI_CC_IDX);
    ASSERT(cc != NULL);

    switch (CHIPID(sih->chip)) {
#ifdef UNRELEASEDCHIP
    case BCM4315_CHIP_ID:
        if (sih->chiprev < 1)
            break;
        if (!(sih->chipst & CST4315_SPROM_SEL))
            break;
        W_REG(osh, &cc->chipcontrol_addr, 0);
        if (R_REG(osh, &cc->chipcontrol_data) & 0x80000000)
            enable = FALSE;
        break;
#endif /* UNRELEASEDCHIP */
    default:
        break;
    }

    /* Return to original core */
    si_setcoreidx(sih, origidx);
    return enable;
}


/* initialize PMU chip controls and other chip level stuff */
void
si_pmu_chip_init(si_t *sih, osl_t *osh)
{
    uint origidx;

    ASSERT(sih->cccaps & CC_CAP_PMU);

#ifndef CONFIG_XIP
    /* Gate off SPROM clock and chip select signals */
    si_pmu_sprom_enable(sih, osh, FALSE);
#endif

    /* Remember original core */
    origidx = si_coreidx(sih);

    /* Misc. chip control, has nothing to do with PMU */
    switch (CHIPID(sih->chip)) {
#ifdef UNRELEASEDCHIP
    case BCM4315_CHIP_ID:
#ifdef BCMUSBDEV
        si_setcore(sih, PCMCIA_CORE_ID, 0);
        si_core_disable(sih, 0);
#endif
        break;
#endif /* UNRELEASEDCHIP */
    default:
        break;
    }

    /* Return to original core */
    si_setcoreidx(sih, origidx);
}

/* initialize PMU switch/regulators */
void
si_pmu_swreg_init(si_t *sih, osl_t *osh)
{
    ASSERT(sih->cccaps & CC_CAP_PMU);

    switch (CHIPID(sih->chip)) {
    default:
        break;
    }
}

int
si_pmu_power_switch(si_t *sih, int func, int id, int state)
{
    uint32 old_setting = 0;

    if (state != POWER_SWITCH_STATE_OFF) {
        PMU_MSG(("Power on command is not supported currently.\n"));
        return -1;
    }

    switch(func) {
        case POWER_SWITCH_FUNC_DDR2:
            if ((id < 2) || (id > 3)) {
                PMU_MSG(("Incorrect DDR2 PHY byte lane\n"));
                return -1;
            }
             if (id == 2) {
                *(volatile uint32 *)(0xb800f33c) = 0x800fffff;
            } else {
                /* lane 3 */
                *(volatile uint32 *)(0xb800f43c) = 0x800fffff;
            }
           break;
        case POWER_SWITCH_FUNC_SGMII:
            old_setting = *(volatile uint32 *)(0xb8001104);
            *(volatile uint32 *)(0xb8001104) = 0x02840000;
            *(volatile uint32 *)(0xb8001100) = 0x60011940;
            cfe_usleep(10);
            *(volatile uint32 *)(0xb8200800) = 0x1;
            *(volatile uint32 *)(0xb8200408) = 0x0;
            *(volatile uint32 *)(0xb8001104) = old_setting;
            break;
        case POWER_SWITCH_FUNC_PCIE:
            if (id == POWER_SWITCH_ID_PCIE_0) {
                PMU_MSG(("PCIE %d not supports power switching\n", id));
                return -1;
            }
            *(volatile uint32 *)(0xb8105408) = 0x1;
            *(volatile uint32 *)(0xb8105800) = 0x0;
            *(volatile uint32 *)(0xb8005000) = 0x3;
            *(volatile uint32 *)(0xb8005128) = 0x84;
            *(volatile uint32 *)(0xb800512c) = 0x507e8020;
            cfe_usleep(5);
            if (id == POWER_SWITCH_ID_PCIE_ALL_LOW_LEAK_MODE) {
                *(volatile uint32 *)(0xb800512c) = 0x50424180;
            } else {
                *(volatile uint32 *)(0xb800512c) = 0x50424080;
            }
            cfe_usleep(5);
            if ((id == POWER_SWITCH_ID_PCIE_ALL) ||
                 (id == POWER_SWITCH_ID_PCIE_ALL_LOW_LEAK_MODE)) {
                *(volatile uint32 *)(0xb800512c) = 0x5072000f;
                cfe_usleep(5);
                *(volatile uint32 *)(0xb8105800) = 0x1;
                *(volatile uint32 *)(0xb8201800) = 0x1;
                *(volatile uint32 *)(0xb8105408) = 0x0;
                *(volatile uint32 *)(0xb8201408) = 0x0;
            } else {
                *(volatile uint32 *)(0xb800512c) = 0x5072000c;
                cfe_usleep(5);
                *(volatile uint32 *)(0xb8201800) = 0x1;
                *(volatile uint32 *)(0xb8201408) = 0x0;
            }
            break;
        case POWER_SWITCH_FUNC_USB:
            *(volatile uint32 *)(0xb8104408) = 0x1;
            *(volatile uint32 *)(0xb8104800) = 0x0;
            *(volatile uint32 *)(0xb8004200) = 0x0;
            *(volatile uint32 *)(0xb8104408) = 0x0;
            break;
        default:
            PMU_MSG(("Incorrect functionality\n"));
            return -1;
    }
    return 0; 
}


