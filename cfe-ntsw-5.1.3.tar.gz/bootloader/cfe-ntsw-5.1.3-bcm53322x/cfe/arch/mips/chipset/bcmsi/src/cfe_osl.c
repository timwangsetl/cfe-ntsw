/*
 * CFE OS Independent Layer
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: cfe_osl.c,v 1.2 2009/02/25 02:38:33 kliao Exp $
 */
#include "cfe.h"
#include "lib_try.h"
#include "typedefs.h"
#include "osl.h"

struct osl_info {
	void *pdev;
	pktfree_cb_fn_t tx_fn;
	void *tx_ctx;
};

void *
osl_attach(void *pdev)
{
    osl_t *osh;

    osh = (osl_t *)KMALLOC(sizeof(osl_t), 0);
    ASSERT(osh);

    bzero(osh, sizeof(osl_t));
    osh->pdev = pdev;
    return osh;
}

void
osl_detach(osl_t *osh)
{
    if (osh == NULL)
        return;
    KFREE((void*) KERNADDR(PHYSADDR((ulong)osh)));
}

struct lbuf *
osl_pktget(uint len, uint memtype)
{
    uchar *buf;
    struct lbuf *lb;

    ASSERT(len <= LBDATASZ);

    switch (memtype) {
        case MEMORY_DDRRAM:
            if (!(buf = ((KMALLOC(LBUFSZ, 0)))))
                return NULL;
            break;
        case MEMORY_SOCRAM:
            if (!(buf = ((SOCRAMMALLOC(LBUFSZ, 0)))))
                return NULL;
            break;
        case MEMORY_PCIMEM:
            if (!(buf = ((PCIMALLOC(LBUFSZ, 0)))))
                return NULL;
            break;
        default:
            return NULL;
    }

    cfe_flushcache(CFE_CACHE_FLUSH_D);
    buf = (void *) UNCADDR((ulong) buf);
    lb = (struct lbuf *) &buf[LBDATASZ];
    bzero(lb, sizeof(struct lbuf));
    lb->head = lb->data = buf;
    lb->end = buf + len;
    lb->len = len;
    lb->tail = lb->data + len;
    return lb;
}

void
osl_pktfree(osl_t *osh, struct lbuf *lb, bool send, uint memtype)
{
    struct lbuf *next;

    if (send && osh->tx_fn)
        osh->tx_fn(osh->tx_ctx, lb, 0);

    for (; lb; lb = next) {
        ASSERT(!lb->link);
        next = lb->next;
        switch (memtype) {
            case MEMORY_DDRRAM:
                KFREE((void *) KERNADDR(PHYSADDR((ulong) lb->head)));
                break;
            case MEMORY_SOCRAM:
                SOCRAMFREE((void *) lb->head);
                break;
            case MEMORY_PCIMEM:
                PCIFREE((void *) lb->head);
                break;
        }
    }
}



void
osl_pktsetlen(struct lbuf *lb, uint len)
{
    ASSERT((lb->data + len) <= lb->end);

    lb->len = len;
    lb->tail = lb->data + len;
}

uchar *
osl_pktpush(struct lbuf *lb, uint bytes)
{
    ASSERT((lb->data - bytes) >= lb->head);

    lb->data -= bytes;
    lb->len += bytes;

    return lb->data;
}

uchar *
osl_pktpull(struct lbuf *lb, uint bytes)
{
    ASSERT((lb->data + bytes) <= lb->end);
    ASSERT(lb->len >= bytes);

    lb->data += bytes;
    lb->len -= bytes;

    return lb->data;
}

void *
osl_dma_alloc_consistent(uint size, ulong *pap)
{
    void *buf;

    if (!(buf = KMALLOC(size, DMA_CONSISTENT_ALIGN)))
        return NULL;

    *((ulong *) pap) = PHYSADDR((ulong) buf);

    cfe_flushcache(CFE_CACHE_FLUSH_D);

    return (void *) UNCADDR((ulong) buf);
}

void
osl_dma_free_consistent(void *va)
{
    KFREE((void *) KERNADDR(PHYSADDR((ulong) va)));
}

int
osl_busprobe(uint32 *val, uint32 addr)
{
    jmpbuf_t *jb;

    jb = exc_initialize_block();
    if (jb == NULL)
	return -1;
    if (exc_try(jb) == 0) {
        /* XXX Support bus probing */
        *val = R_REG(NULL, (volatile uint32 *) addr);
    } else {
        /* Bus error */
        return -1;
    }

    exc_cleanup_block(jb);
    return 0;
}

