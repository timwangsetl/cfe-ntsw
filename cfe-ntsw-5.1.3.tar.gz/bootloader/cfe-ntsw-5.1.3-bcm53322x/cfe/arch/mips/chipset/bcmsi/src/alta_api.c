/*
 * $Id: alta_api.c,v 1.3 2009/07/16 08:50:35 cchao Exp $
 * $Copyright: (c) 2009 Broadcom Corp.
 * All Rights Reserved.$
 *
 */
#include "typedefs.h"
#include "alta_osl.h"
#include "alta_mdc.h"
#include "alta_api.h"

int
alta_init(void)
{
    return alta_mdc_init();
}

int
alta_get_number_of_units(void)
{
    return alta_mdc_get_number_of_units();
}

int
alta_attach(int unit)
{
    return alta_mdc_attach(unit);
}

int
alta_detach(int unit)
{
    return alta_mdc_detach(unit);
}

int
alta_interrupt_connect(int unit, uint32 nsec, ALTA_ISR_FUNC isr, void *param)
{
    return alta_mdc_interrupt_connect(unit, nsec, isr, param);
}

int
alta_init_audio_dma_set(int unit, AV_DMA_SET *pset)
{
    return alta_mdc_init_audio_dma_set(unit, pset);
}

int
alta_start_audio_dma_set(int unit, AV_DMA_SET *pset)
{
    return alta_mdc_start_audio_dma_set(unit, pset);
}

int
alta_stop_audio_dma_set(int unit, AV_DMA_SET *pset)
{
    return alta_mdc_stop_audio_dma_set(unit, pset);
}

int
alta_configure_audio_port(int unit, AVPORT_CONFIG *pparam)
{
    return alta_mdc_configure_audio_port(unit, pparam);
}

int
alta_start_audio_port(int unit, AVPORT_CONFIG *pparam)
{
    return alta_mdc_start_audio_port(unit, pparam);
}

int
alta_stop_audio_port(int unit, AVPORT_CONFIG *pparam)
{
    return alta_mdc_stop_audio_port(unit, pparam);
}

int
alta_schedule_av_time_event(int unit, uint32 lt_ns)
{
    return alta_mdc_schedule_av_time_event(unit, lt_ns);
}

int
alta_get_localtime(int unit, uint32 *pltime)
{
    return alta_mdc_get_localtime(unit, pltime);
}

int
alta_set_localtime(int unit, uint32 ltime)
{
    return alta_mdc_set_localtime(unit, ltime);
}

int
alta_get_localtime_increment(int unit, uint32 *pval)
{
    return alta_mdc_get_localtime_increment(unit, pval);
}

int
alta_set_localtime_increment(int unit, uint32 val)
{
    return alta_mdc_set_localtime_increment(unit, val);
}

int
alta_locatime_to_nanosecond(uint32 ltime, uint32 *pnsec)
{
    return alta_mdc_locatime_to_nanosecond(ltime, pnsec);
}

int
alta_locatime_to_picosecond(uint32 ltime, uint32 *ppsec)
{
    return alta_mdc_locatime_to_picosecond(ltime, ppsec);
}

int
alta_timestamp_status(int unit, E_TSFIFO_STATUS *pstatus)
{
    return alta_mdc_timestamp_status(unit, pstatus);
}

int
alta_retrieve_timestamp(int unit, uint32 *pts, uint32 *pmask)
{
    return alta_mdc_retrieve_timestamp(unit, pts, pmask);
}

int
alta_reset_timestamp(int unit)
{
    return alta_mdc_reset_timestamp(unit);
}

int
alta_dma_get_totsz(int unit, uint32 channel, uint32 *ptotsz)
{
    return alta_mdc_dma_get_totsz(unit, channel, ptotsz);
}
