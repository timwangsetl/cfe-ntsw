/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5836 MII driver                               File: si_mii.c
    *  
    *  Basic operations for BCM53003 MII managment interface.
    *  
    *********************************************************************  
    *
    *  Copyright 2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"

#include "ui_command.h"

#include "lib_physio.h"
#include "mii.h"

#include "cfe_mii.h"


#define PHY_READCSR(sc,csr) (phys_read32((sc)->membase + (csr)))
#define PHY_WRITECSR(sc,csr,val) (phys_write32((sc)->membase + (csr), (val)))


#define GMAC_COMMON_PHY_ACCESS_REG  0x100

#define 	PHY_ACCESS_TRIGGER_SHIFT	30
#define 	PHY_ACCESS_TRIGGER_MASK	0x40000000
#define 	PHY_ACCESS_WR_CMD_SHIFT	29
#define 	PHY_ACCESS_WR_CMD_MASK	0x20000000
#define 	PHY_ACCESS_CPU_REG_ADDR_SHIFT	24
#define 	PHY_ACCESS_CPU_REG_ADDR_MASK	0x1f000000
#define 	PHY_ACCESS_CPU_PHY_ADDR_SHIFT	16
#define 	PHY_ACCESS_CPU_PHY_ADDR_MASK	0x1f0000  
#define 	PHY_ACCESS_ACC_DATA_SHIFT	0
#define 	PHY_ACCESS_ACC_DATA_MASK	0xffff    

typedef uint32_t phys_addr_t;
#define PHY_PORT(x) PHYS_TO_K1(x)

typedef struct si_mii_softc_s {
    unsigned long base;
    int default_phyaddr;
    phys_addr_t membase;
} si_mii_softc_t;


/*  *********************************************************************
    *  Forward declarations
    ********************************************************************* */

static cfe_mii_channel_t *si_mii_attach(cfe_mii_t *ops,uint64_t probe_a,uint64_t probe_b);
static int si_mii_init(cfe_mii_channel_t *chan);
static int si_mii_default_addr(cfe_mii_channel_t *chan);
static void si_mii_write(cfe_mii_channel_t *chan,int addr,int regidx,unsigned int regval);
static unsigned int si_mii_read(cfe_mii_channel_t *chan,int addr,int regidx);


/*  *********************************************************************
    *  MII operations
    ********************************************************************* */

cfe_mii_t si_mii = {
    si_mii_attach,
    si_mii_init,
    si_mii_default_addr,
    si_mii_write,
    si_mii_read
};


static cfe_mii_channel_t *si_mii_attach(cfe_mii_t *ops,uint64_t probe_a,uint64_t probe_b)
{
    cfe_mii_channel_t *chan;	
    si_mii_softc_t *softc;

    chan = KMALLOC(sizeof(cfe_mii_channel_t)+sizeof(si_mii_softc_t),0);

    if (!chan) return NULL;

    chan->ops = ops;
    chan->softc = (void *) (chan+1);

    softc = chan->softc;
    softc->base = probe_a;
    softc->default_phyaddr = probe_b;
    softc->membase = PHY_PORT(softc->base);

    return chan;
}

static int si_mii_init(cfe_mii_channel_t *chan)
{
    return 0;
}

static int si_mii_default_addr(cfe_mii_channel_t *chan)
{
    si_mii_softc_t *s = chan->softc;

    return s->default_phyaddr;
}


static unsigned int si_mii_read(cfe_mii_channel_t *chan,int phyaddr,int regidx)
{
    si_mii_softc_t *s = chan->softc;
    uint32_t data;
    int timeout;

    if (phyaddr < 0) phyaddr = s->default_phyaddr;

    data = (PHY_ACCESS_TRIGGER_MASK | 
        (phyaddr << PHY_ACCESS_CPU_PHY_ADDR_SHIFT) | 
          (regidx << PHY_ACCESS_CPU_REG_ADDR_SHIFT));
    /* set phyaccess for read/write */
    PHY_WRITECSR(s, GMAC_COMMON_PHY_ACCESS_REG, data);

    for (timeout = 1000; timeout > 0; timeout -= 100) {
	data = PHY_READCSR(s, GMAC_COMMON_PHY_ACCESS_REG);
	if ((data & PHY_ACCESS_TRIGGER_MASK) == 0)
	    break;
	cfe_usleep(100);
	}

    if (timeout <= 0) {
	return 0xFFFF;
    }

    data &= PHY_ACCESS_ACC_DATA_MASK;
    return data;
}


static void si_mii_write(cfe_mii_channel_t *chan,int phyaddr,int regidx,
                         unsigned int regval)
{
    si_mii_softc_t *s = chan->softc;
    uint32_t data;
    int timeout;

    if (phyaddr < 0) phyaddr = s->default_phyaddr;

    /* set phyaccess for read/write */
    data = (PHY_ACCESS_TRIGGER_MASK | PHY_ACCESS_WR_CMD_MASK | 
          (phyaddr << PHY_ACCESS_CPU_PHY_ADDR_SHIFT) | 
          (regidx << PHY_ACCESS_CPU_REG_ADDR_SHIFT) | 
          (regval & PHY_ACCESS_ACC_DATA_MASK));
    PHY_WRITECSR(s, GMAC_COMMON_PHY_ACCESS_REG, data);

    for (timeout = 1000; timeout > 0; timeout -= 100) {
	data = PHY_READCSR(s, GMAC_COMMON_PHY_ACCESS_REG);
	if ((data & PHY_ACCESS_TRIGGER_MASK) == 0)
	    break;
	cfe_usleep(100);
    }
}
