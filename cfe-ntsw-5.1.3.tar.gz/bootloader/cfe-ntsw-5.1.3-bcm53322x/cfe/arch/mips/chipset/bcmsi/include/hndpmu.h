/*
 * HND SiliconBackplane PMU support.
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: hndpmu.h,v 1.3 2010/05/05 08:18:53 alai Exp $
 */

#ifndef _hndpmu_h_
#define _hndpmu_h_

/* Power switching on/off */
#define POWER_SWITCH_STATE_OFF 0
#define POWER_SWITCH_STATE_ON 1

/* Functions that support power switching */
#define POWER_SWITCH_FUNC_DDR2 0
#define POWER_SWITCH_FUNC_SGMII 1
#define POWER_SWITCH_FUNC_PCIE 2
#define POWER_SWITCH_FUNC_USB 3

#define POWER_SWITCH_ID_PCIE_0 0        
#define POWER_SWITCH_ID_PCIE_1 1        
#define POWER_SWITCH_ID_PCIE_ALL 2        
#define POWER_SWITCH_ID_PCIE_ALL_LOW_LEAK_MODE 3

extern void si_pmu_init(si_t *sih, osl_t *osh);
extern void si_pmu_chip_init(si_t *sih, osl_t *osh);
extern void si_pmu_pll_init(si_t *sih, osl_t *osh, uint32 xtalfreq);
extern void si_pmu_res_init(si_t *sih, osl_t *osh);
extern void si_pmu_swreg_init(si_t *sih, osl_t *osh);

extern uint32 si_pmu_si_clock(si_t *sih, osl_t *osh);
extern uint32 si_pmu_cpu_clock(si_t *sih, osl_t *osh);
extern uint32 si_pmu_alp_clock(si_t *sih, osl_t *osh);
extern uint32 si_pmu_ilp_clock(si_t *sih, osl_t *osh);

extern bool si_pmu_is_sprom_enabled(si_t *sih, osl_t *osh);
extern void si_pmu_sprom_enable(si_t *sih, osl_t *osh, bool enable);
extern int si_pmu_power_switch(si_t *sih, int func, int id, int state);


#endif /* _hndpmu_h_ */

