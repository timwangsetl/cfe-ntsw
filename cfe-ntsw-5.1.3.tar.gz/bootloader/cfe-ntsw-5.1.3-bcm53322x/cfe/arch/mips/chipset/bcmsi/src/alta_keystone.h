/*
 * $Id: alta_keystone.h,v 1.3 2009/07/16 08:50:35 cchao Exp $
 * $Copyright: (c) 2009 Broadcom Corp.
 * All Rights Reserved.$
 *
 */

#ifndef _ALTA_KEYSTONE_H
#define _ALTA_KEYSTONE_H

#ifndef PAD
#define _PADLINE(line)  pad ## line
#define _XSTR(line)     _PADLINE(line)
#define PAD             _XSTR(__LINE__)
#endif /* PAD */


/*
 * Chipset specific constants
 */

#define TOTAL_NUMBER_OF_AV_PORT         (2)
#define TOTAL_NUMBER_OF_AUDIO_PORT      (2)
#define AV_MAX_CHANNELS_PER_PORT        (8)
#define AV_MAX_CHANNELS_PER_CHIP        \
    ((TOTAL_NUMBER_OF_AUDIO_PORT * AV_MAX_CHANNELS_PER_PORT) + \
     (TOTAL_NUMBER_OF_AV_PORT - TOTAL_NUMBER_OF_AUDIO_PORT))
#define AVDMA_MAX_CBUF_SIZE             (8192)
     
     
/* 
 * Register offset
 */
#define ALTA_GET_AV_REG_ADDR(base)  ((void *)(base))
#define ALTA_GET_DMA_REG_ADDR(base) ((void *)((uint32)(base) + 0x300))
#define ALTA_GET_DTE_REG_ADDR(base) ((void *)((uint32)(base) + 0x600))


/*
 * Registers
 */

typedef struct _avport_regs_t {
    uint32 csr;
    uint32 ocd_csr;
    uint32 fifo_stat;
    uint32 mute_val;
    uint32 PAD[1];
    uint32 io_mask;
    uint32 PAD[2];
    uint32 N_reg;
    uint32 F_reg;
    uint32 W_reg;
    uint32 PAD[1];
    uint32 B_reg;
    uint32 T_reg;
    uint32 PAD[2];
    
    /* Shouldn't be accessed directly */
    uint32 fifo[AV_MAX_CHANNELS_PER_PORT];
    
    uint32 PAD[40];
} avport_regs_t;

typedef struct _avregs_t {
    
    uint32 te;
    uint32 glbl_ctrl;
    uint32 glbl_dbg_data;
    uint32 PAD[61];
    
    avport_regs_t avport[TOTAL_NUMBER_OF_AV_PORT];
    
} avregs_t;

typedef struct _dmachregs_t {
    uint32 csr;
    uint32 sz;
    uint32 src_addr;
    uint32 src_enc_mask;
    uint32 dst_addr;
    uint32 dst_enc_mask;
    uint32 PAD[2];
} dmachregs_t;

typedef struct _avdmaregs_t {
    uint32 main_csr;
    uint32 int_mask0A;
    uint32 PAD[7];
    uint32 int_src0A;
    uint32 PAD[54];
    
    dmachregs_t ch[AV_MAX_CHANNELS_PER_CHIP];
    
} dmaregs_t;

typedef struct _dteregs_t {
    uint32 sdm_ctrl;
    uint32 PAD[3];
    uint32 iig0_next_soi;
    uint32 iig0_int_len;
    uint32 PAD[10];
    uint32 lts_fifo_out;
    uint32 lts_status;
    uint32 PAD[2];
    uint32 ltnco_sum1;
    uint32 ltnco_sum2;
    uint32 ltnco_sum3;
    uint32 ltnco_inc;
    uint32 lts_div10;
    uint32 PAD[2];
    uint32 sdm_fract[TOTAL_NUMBER_OF_AV_PORT];
    uint32 PAD[101 - TOTAL_NUMBER_OF_AV_PORT];
    uint32 sdm_quant[TOTAL_NUMBER_OF_AV_PORT][64];
} dteregs_t;

/*
 * Register fields
 */
#define AV_CSR_SW_RST(x)             ((x) << 31)   /* 1:Reset */
#define AV_CSR_IO_MODE(x)            ((x) << 30)   /* 1:Inoput, 0:Output */
#define AV_CSR_SAMP_SHFT(x)          ((x) << 27) 
#define AV_CSR_INV_ICLK(x)           ((x) << 26)
#define AV_CSR_INV_WCLK(x)           ((x) << 25)
#define AV_CSR_WCLK_SEL(x)           ((x) << 24)  /* 1:External WCLK, 0: Internal WCLK */
#define AV_CSR_ICLK_SEL(x)           ((x) << 23)  /* 1:External ICLK, 0:Internal ICLK */
#define AV_CSR_FB_POS(x)             ((x) << 21)
#define AV_CSR_SER_OE(x)             ((x) << 20)
#define AV_CSR_ICLK_OE(x)            ((x) << 19)
#define AV_CSR_WCLK_OE(x)            ((x) << 18)
#define AV_CSR_DVB_IXS_SEL(x)        ((x) << 17)   /* 1:DVB, 0:IxS */
#define AV_CSR_MODE(x)               ((x) << 14)
#define AV_CSR_MUTE_ALL(x)           ((x) << 13)
#define AV_CSR_LSB_MSB(x)            ((x) << 12) /* 1:First bit LSB, 0:First bit MSB */
#define AV_CSR_CH_ACT_MASK(x)        ((x) << 4)
#define AV_CSR_NUM_CHAN(x)           (((x) - 1) << 0)

#define AV_OCG_CSR_WCLK_NE_SEL(x)    ((x) << 14) 
#define AV_OCG_CSR_SAMP_SHFT_DIR(x)  ((x) << 13)
#define AV_OCG_CSR_LTE_SEL(x)        ((x) << 10)
#define AV_OCG_CSR_PLLFB_DC(x)       ((x) << 9)
#define AV_OCG_CSR_INV_WCLK(x)       ((x) << 8)
#define AV_OCG_CSR_INV_ICLK(x)       ((x) << 7)
#define AV_OCG_CSR_ICLK_SRC_SEL(x)   ((x) << 6)
#define AV_OCG_CSR_SYNC_SEL(x)       ((x) << 3)
#define AV_OCG_CSR_APLL_SEL(x)       ((x) << 0)

#define AV_GLBL_CTRL_STAT_DBG_SEL(x) ((x) << 8)

#define DTE_SDM_CTRL_INTR(x)         ((x) << 16)
#define DTE_SDM_CTRL_INTR_ERR(x)     ((x) << 17)

#define AV_DMA_SZ_TOTSZ_MASK         (0x0000fff)


/*
 * FIFO access
 */
#define AV_FIFO(port,ch)    ((uint32)0x18000140 + (port) * 0x100 + (ch) * 4)


/*
 * Bits of timestamp FIFO status
 */
#define TSFIFO_STATUS_LEVEL_MASK    (0x3)
#define TSFIFO_STATUS_UNDERFLOW     (1 << 2)
#define TSFIFO_STATUS_OVERFLOW      (1 << 3)
#define TSFIFO_STATUS_EMPTY         (1 << 4)
#define TSFIFO_STATUS_FULL          (1 << 5)


/*
 * Register access
 */ 

#define ALTA_REG_READ(a)   (*(volatile unsigned int *)(a))
#define ALTA_REG_WRITE(a,d) ({  \
    volatile unsigned int _t;   \
    ALTA_REG_READ(a) = (d);     \
    _t = ALTA_REG_READ(a);      \
})


/*
 * Local time resolution
 */
#define LTIME_FROM_NSEC(ns)         (((uint32)(ns)) << 3)
#define LTIME_TO_NSEC(lt)           (((uint32)(lt)) >> 3)
#define LTIME_TO_PSEC(lt)           (((uint32)(lt)) * 125)
#define LTIME_TO_SUM1(lt)           (((uint32)(lt)) << 25)
#define LTIME_TO_SUM2(lt)           (((uint32)(lt)) >> 7)
#define LTIME_ADD_NSEC(lt, ns)      ((uint32)(lt) + ((uint32)(ns) << 3))


/*
 * Utilities for AV DMA
 */
#define AVDMA_ITER(bmp, ch) \
    for((ch)=0; (ch)<AV_MAX_CHANNELS_PER_CHIP; (ch)++) \
        if ((bmp) & (1 << (ch)))



     

#endif /* _ALTA_KEYSTONE_H */
