/*
 * $Id: alta_osl.h,v 1.2 2009/02/25 02:36:28 kliao Exp $
 * $Copyright: (c) 2009 Broadcom Corp.
 * All Rights Reserved.$
 *
 */

#ifndef _ALTA_OSL_H
#define _ALTA_OSL_H

#include "cfe.h"
#include "osl.h"

typedef bool (*DEV_MATCH_FUNC)(uint16, uint16, uint32);
extern int alta_osl_find_chip(DEV_MATCH_FUNC func);

typedef void (*ALTA_OSL_ISR)(int);
extern int alta_osl_interrupt_connect(int irq, ALTA_OSL_ISR isr);
extern void alta_osl_interrupt_mask(int irq);
extern void alta_osl_interrupt_unmask(int irq);
extern void alta_osl_interrupt_acknowledge(int irq);



#endif /* _ALTA_OSL_H */
