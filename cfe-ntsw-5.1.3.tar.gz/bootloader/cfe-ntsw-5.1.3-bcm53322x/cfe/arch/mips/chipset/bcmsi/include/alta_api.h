/*
 * $Id: alta_api.h,v 1.3 2009/07/16 08:50:34 cchao Exp $
 * $Copyright: (c) 2009 Broadcom Corp.
 * All Rights Reserved.$
 *
 */

#ifndef _ALTA_API_H
#define _ALTA_API_H

#include "typedefs.h"

/*
 * Set of interleaved AV/DMA channels
 */
typedef struct _AV_DMA_SET {
    bool    avout;          /* Direction: AV out */
    uint32  channels;       /* Channel bitmap */
    uint32  bufaddr;        /* Buffer address (physical) */
    uint32  bufsize;        /* Buffer size (in bytes) */
} AV_DMA_SET;

/* Sample rate; the enum value is meaningful */
typedef enum 
{        
    SAMPLERATE_8000     = 8000,
    SAMPLERATE_44100    = 44100,
    SAMPLERATE_48000    = 48000,
    SAMPLERATE_88200    = 88200,
    SAMPLERATE_96000    = 96000,
    SAMPLERATE_192000   = 192000,
} E_AUDIO_SAMPLERATE_TYPE;

/* Sample size; the enum value is meaningful */
typedef enum 
{        
    SAMPLEBITS_8     = 8,
    SAMPLEBITS_16    = 16,
    SAMPLEBITS_20    = 20,
    SAMPLEBITS_24    = 24,
    SAMPLEBITS_32    = 32,
} E_AUDIO_SAMPLEBITS_TYPE;


/* Clock per sample; it is dependent on external codec; the enum value is meaningful */
typedef enum 
{        
    SAMPLECLOCKS_8 = 0,
    SAMPLECLOCKS_16,
    SAMPLECLOCKS_20,
    SAMPLECLOCKS_24,
    SAMPLECLOCKS_32,
} E_AUDIO_SAMPLECLOCKS_TYPE;

/* Sample shift bits; the enum value is meaningful */
typedef enum
{
    SHIFT_0 = 0,
    SHIFT_4 ,
    SHIFT_8 ,
    SHIFT_12,
    SHIFT_16,
    SHIFT_20,
    SHIFT_24,
    SHIFT_28,
        
} E_IXS_SAMP_SHFT;

/* IxS IN/OUT Mode */
typedef enum
{
    IXS_OUTPUT,               /* Incoming AVB (Alta view), Egress Mode (IxS view) */
    IXS_INPUT,                  /* Outging AVB (Alta view), Ingress Mode (IxS view) & clocked by external */
    IXS_INPUT_INTERNAL  /* Outging AVB (Alta view), Ingress Mode (IxS view) & clocked by internal (Alta) */
    
} E_IXS_TYPE;

/* AV port's mode; the enum value is meaningful */
typedef enum
{
    AUDIO_IXS_MODE = 0,
    AUDIO_CIRRUS_NORMAL_MODE,
    AUDIO_CIRRUS_FORMAT0_MODE,
    AUDIO_CIRRUS_TDM_MODE,
  
    VIDEO_MPEG188_MODE,
    VIDEO_MPEG188_PLUS16_MODE,
    VIDEO_MPEG204_MODE,
    RESERVED, /* Dummy */
    VIDEO_BT656_3X10BITS_MODE,
    VIDEO_BT656_4X8BITS_MODE,
    VIDEO_BT656_16X10BITS_MODE,
    
} E_IXS_MODE;

typedef enum
{
    CIRRUS_4385_FORMAT0_POS = 1,
    STANDARD_IXS_POS = 2,

}  E_FIRST_BIT_POS;



/* Word Clock Negative Edge Select; the enum value is meaningful
 *  1 - Output word clock from register that is clocked on negative edge of internal ICLK.
 *  0 - Output word clock from register that is clocked on positive edge of internal ICLK.
 */
typedef enum
{
    POSITIVE_EDGE = 0,
    NEGATIVE_EDGE,

}  E_WCLK_NE_SEL;

/* Sample Shift Direction; the enum value is meaningful
 *  1 - SAMP_SHFT in AV CSR Register specifies right shift.
 *  0 - SAMP_SHFT in AV CSR Register specifies left shift.
 */
typedef enum
{
    LEFT_SHIFT = 0,
    RIGHT_SHIFT,

}  E_SAMP_SHFT_DIR;


/* PLL Feedback select; the enum value is meaningful
 * 1 - Divide by two to create a 50% duty cycle
 * 0 - Single Pulse
 */
typedef enum
{
    SINGLE_PULSE = 0,
    DIVIDE_BY_2,

}  E_PLLFB_DC;


/* ICLK select; the enum value is meaningful
 *  1 - APLL Clock
 *  0 - Internal ICLK Divider
 *  Default value = 1 (APLL Clock selected). This was done as part of effort to guarantee an APLL clock is present on Alta reset.
 */
typedef enum
{
    INTERNAL_ICLK_DIVIDER = 0,
    APLL_CLOCK,

}  E_ICLK_SRC_SEL;


/* Output Clock Generator */
typedef struct _OCG_PARAMS
{
    /* This value should generally only be set to 1 in the case where Alta is in input mode, but is sourcing the clocks. 
     *  In this case, it needs to "launch" word clock on negative edge of ICLK, but then "capture" input data on positive edge.
     */
    E_WCLK_NE_SEL eWclkSel;

    /* This value should be set based on external codec spec
     *
     *  Refer to ALTA_AV_EDS 1.7, 5.1.3 for further information
     */
    E_SAMP_SHFT_DIR eSampShftDir;

    /* Local Time event select
     *  Selects from which port the synchronized local time event is used.  
     *  In general, this field should be set to the same value as SYNC_SEL below.
     */
    uint32 eLteSel;
    
    E_PLLFB_DC ePllFbDc;

    
    /* Sync Input Select
     *  Selects the master port for synchronization purposes.  
     *  If a port is not slaved to another port, then it is its own master and the port should select itself.
     */
    uint32 eSyncSel;

    /*
     * ACLK: Used as ICLK (w/ or w/o divider) if CSR.ICLK_SEL is internal.
     *  - True: use PL301b backplane clock 150Mhz.
     *  - False: use APLL clock.
     */
    bool is_ACLK_from_PL301b;

    /*
     * APLL clock speed (in Hz) if using APLL clock
     */
    uint32 APLL_clock_speed;

    /*
     *   - If APLL_CLOCK, then ICLK = ACLK
     *   - If INTERNAL_ICLK_DIVIDER, then ICLK = ACLK / (2 * (N + 1));
     */
    E_ICLK_SRC_SEL eIclkSrcSel;

    bool isInvertedOutputWclk;
    bool isInvertedOutputIclk;
} S_OCG_PARAMS;


typedef struct _AVPORT_CONFIG
{                                    
    /* "eAudioSampleRate", "eBitsPerSample", and "eClocksPerSample" 
     *  are valid only when "E_IXS_MODE" is belong to audio mode; 
     *  for video stream, they are dependent on the video mode (ex. BT565 3*10bits is 27MHz, 30bits)
     *
     *  Refer to ALTA_AV_EDS 1.7, 5.1.3 for further information
     */
    E_AUDIO_SAMPLERATE_TYPE eAudioSampleRate;
    E_AUDIO_SAMPLEBITS_TYPE eBitsPerSample;
    E_AUDIO_SAMPLECLOCKS_TYPE eClocksPerSample;    

    /* AV Port index  */
    uint32 eIdx;

    /* Client code should set this field based on the AVB stream talker/listener role
     *  IXS_OUTPUT              -> Incoming AVB (Alta view), Egress Mode (IxS view) 
     *  IXS_INPUT                 -> Outging AVB (Alta view), Ingress Mode (IxS view) & clocked by external
     *  IXS_INPUT_INTERNAL  -> Outging AVB (Alta view), Ingress Mode (IxS view) & clocked by internal (Alta)
     */
    E_IXS_TYPE eIxS_Type;

    /* Driver uses IxsParams.eIxS_Mode < VIDEO_MPEG188_MODE to determine if the port is set as audio (DvbIxsSel=0) */
    E_IXS_MODE eIxS_Mode;


    /* If eClocksPerSample > eBitsPerSample, we have to set eSampleShift & OCG.eSampShftDir to determine
     *  the real sample size and what it looks like before/after the output/input 32bits shift register
     *
     *  Refer to ALTA_AV_EDS 1.7, 5.1.3 for further information
     */
    E_IXS_SAMP_SHFT eSampleShift;

    /* Channel bitmap to indicated enabled channels */
    uint8 ChannelMask;

    /* Control where the first bit position is relative the word clock edge
     *  Refer to ALTA_AV_EDS 1.7, 5.1.3 for further information
     */
    E_FIRST_BIT_POS eFirstBitPos;

    /* Input mode only; invert incoming ICLK */
    bool isInvertedIclk;

    /* Input mode only; invert incoming WCLK */
    bool isInvertedWclk;

    /* Enable ICLK output - Alta as master (IXS_OUTPUT only) */
    bool isAvIclkOe;

    /* Enable WCLK output Alta as master (IXS_OUTPUT only) */
    bool isAvWclkOe;

    /* Is fisrt bis LSB*/
    bool isFirstBitLSB;

    /* Output clock generator */
    S_OCG_PARAMS OCG;

    /* 
     * For output mode: mute value, this value is driven to the serial IO bus when the channels are not enabled, muted or FIFO empty.
     * For input mode: audio label,  this value is ORed to the received samples before they are stored in the FIFO
     */
    uint32 MuteLableVal;

    /* 
     * For output mode: out mask, this mask is ANDed with the audio data read from memory in order to remove the label; default: 0xFFFFFFFF
     * For input mode: in mask, this mask is ANDed with the audio input data (after shifting left/right is done) in order to 
     * clear a spot for any label that may need to be ORed in; default: 0xFFFFFFFF
     */
    uint32 AudioMask;
    
    /*
     * Samples (per channel) for generating one timestamp
     * Note: For time interval, you will need to convert into samples.
     *       Eg. If you want timestamp generated every 10ms with 48kHz/32bits,
     *           then the samples = (TimeInterval / (1sec / SamplingRate));
     *                            = (48000 * ms / 1000)
     *                            = (48000 * 10 / 1000) = 480 samples
     */
    uint32 SamplePerTimestamp;
    
} AVPORT_CONFIG;

/*
 * Timestamp fifo status
 */
typedef enum {
    TSFIFO_EMPTY = 0,
    TSFIFO_AVAIL = 2,
    TSFIFO_FULL = 2,
    TSFIFO_OVERFLOW_ERR = -1,
    TSFIFO_UNDERFLOW_ERR = -2,
} E_TSFIFO_STATUS;

/*
 * Mask of timestamp
 */
#define TSMASK_INPUT(port)      (1 << (11 + port))
#define TSMASK_OUTPUT(port)     (1 << (6 + port))

typedef void (*ALTA_ISR_FUNC)(int, void *);

/* Global initialization; must be called before anything else. */
extern int alta_init(void);

/* Get number fo Alta chips in the system */
extern int alta_get_number_of_units(void);


/* Chip attach; must be called before doing anything to the chip */
extern int alta_attach(int unit);

/* Chip detach */
extern int alta_detach(int unit);


/* Start interrupt with user supplied handler and interval */
extern int alta_interrupt_connect(int unit, uint32 nsec, ALTA_ISR_FUNC isr, void *param);


/* Initialize a set of DMA channels which share the same buffer */
extern int alta_init_audio_dma_set(int unit, AV_DMA_SET *pset);

/* Start the set of DMA channels (should be called after audio port started) */
extern int alta_start_audio_dma_set(int unit, AV_DMA_SET *pset);

/* Stop the set of DMA channels */
extern int alta_stop_audio_dma_set(int unit, AV_DMA_SET *pset);


/* Configure audio port using the supplied parameters */
extern int alta_configure_audio_port(int unit, AVPORT_CONFIG *pparam);

/* Start this audio port */
extern int alta_start_audio_port(int unit, AVPORT_CONFIG *pparam);

/* Stop this audio port */
extern int alta_stop_audio_port(int unit, AVPORT_CONFIG *pparam);


/* Set time to really activate audio input/output (after audio/DMA started) */
extern int alta_schedule_av_time_event(int unit, uint32 ltime);


/* Get current local time */
extern int alta_get_localtime(int unit, uint32 *pltime);

/* Set current local time */
extern int alta_set_localtime(int unit, uint32 ltime);

/* Get local time increment */
extern int alta_get_localtime_increment(int unit, uint32 *pval);

/* Set local time increment */
extern int alta_set_localtime_increment(int unit, uint32 val);

/* Convert local time to nanoseconds */
extern int alta_locatime_to_nanosecond(uint32 ltime, uint32 *pnsec);

/* Convert local time to picoseconds */
extern int alta_locatime_to_picosecond(uint32 ltime, uint32 *ppsec);


/* Get current status of timestamp fifo */
extern int alta_timestamp_status(int unit, E_TSFIFO_STATUS *pstatus);

/* Retrieve timestamp (not available if *pmask == 0) */
extern int alta_retrieve_timestamp(int unit, uint32 *pts, uint32 *pmask);

/* Reset timestamp FIFO (if TSFIFO_OVERFLOW_ERR/TSFIFO_UNDERFLOW_ERR happens) */
extern int alta_reset_timestamp(int unit);


/* Get remaining total size of DMA circular buffer (in DWORDs) */
extern int alta_dma_get_totsz(int unit, uint32 channel, uint32 *ptotsz);

#endif /* _ALTA_API_H */

