/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  MEMC definitions             File: aimemc.h
    *
    *  Constants and macros pertaining to SiliconBackplane 
    *  based MEMC cores
    *  
    *********************************************************************  
    *
    *  Copyright 2008,2009
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#ifndef _AIMEMC_H
#define _AIMEMC_H

/*
 * PL341 Specific Parameters
 */
#define MEMC_BURST_LENGTH       (4)


/*
 * PLL clock configuration
 */
#ifndef CFG_DDR_PLL_CLOCK
#define CFG_DDR_PLL_CLOCK   (300000) /* KHz */
#endif /* !CFG_DDR_PLL_CLOCK */
#define PLL_NDIV_INT_VAL    (16 * (CFG_DDR_PLL_CLOCK) / 100000)


/*
 * Convenient macros (forced carry)
 */
#define MEMCYCLES(psec)   (((psec) * (CFG_DDR_PLL_CLOCK) + 999999999) / 1000000000)

/*
 * Convenient macros (minimum requirement and truncated decimal)
 */
#define MEMCYCLES_MIN(psec)   ((psec) * (CFG_DDR_PLL_CLOCK) / 1000000000)

/*
 * DDR23PHY registers
 */
#define DDR23PHY_PLL_STATUS             0x010
#define DDR23PHY_PLL_CONFIG             0x014
#define DDR23PHY_PLL_PRE_DIVIDER        0x018
#define DDR23PHY_PLL_DIVIDER            0x01c
#define DDR23PHY_STATIC_VDL_OVERRIDE    0x030
#define DDR23PHY_ZQ_PVT_COMP_CTL        0x03c
#define DDR23PHY_BL3_VDL_CALIBRATE      0x104
#define DDR23PHY_BL3_VDL_STATUS         0x108
#define DDR23PHY_BL3_READ_CONTROL       0x130
#define DDR23PHY_BL3_WR_PREAMBLE_MODE   0x148
#define DDR23PHY_BL2_VDL_CALIBRATE      0x204
#define DDR23PHY_BL2_VDL_STATUS         0x208
#define DDR23PHY_BL2_READ_CONTROL       0x230
#define DDR23PHY_BL2_WR_PREAMBLE_MODE   0x248
#define DDR23PHY_BL1_VDL_CALIBRATE      0x304
#define DDR23PHY_BL1_VDL_STATUS         0x308
#define DDR23PHY_BL1_READ_CONTROL       0x330
#define DDR23PHY_BL1_WR_PREAMBLE_MODE   0x348
#define DDR23PHY_BL0_VDL_CALIBRATE      0x404
#define DDR23PHY_BL0_VDL_STATUS         0x408
#define DDR23PHY_BL0_READ_CONTROL       0x430
#define DDR23PHY_BL0_WR_PREAMBLE_MODE   0x448

/*
 * PL341 registers
 */
#define PL341_memc_status               0x000
#define PL341_memc_cmd                  0x004
#define PL341_direct_cmd                0x008
#define PL341_memory_cfg                0x00c
#define PL341_refresh_prd               0x010
#define PL341_cas_latency               0x014
#define PL341_write_latency             0x018
#define PL341_t_mrd                     0x01c
#define PL341_t_ras                     0x020
#define PL341_t_rc                      0x024
#define PL341_t_rcd                     0x028
#define PL341_t_rfc                     0x02c
#define PL341_t_rp                      0x030
#define PL341_t_rrd                     0x034
#define PL341_t_wr                      0x038
#define PL341_t_wtr                     0x03c
#define PL341_t_xp                      0x040
#define PL341_t_xsr                     0x044
#define PL341_t_esr                     0x048
#define PL341_memory_cfg2               0x04c
#define PL341_memory_cfg3               0x050
#define PL341_t_faw                     0x054
#define PL341_chip_0_cfg                0x200
#define PL341_user_config0              0x304


/*
 * Values for PL341 Direct Command Register
 */
#define MCHIP_CMD_PRECHARGE_ALL         (0x0 << 18)
#define MCHIP_CMD_AUTO_REFRESH          (0x1 << 18)
#define MCHIP_CMD_MODE_REG              (0x2 << 18)
#define MCHIP_CMD_NOP                   (0x3 << 18)
#define MCHIP_MODEREG_SEL(x)            ((x) << 16)
#define MCHIP_MR_WRITE_RECOVERY(x)      (((x) - 1) << 9)
#define MCHIP_MR_DLL_RESET(x)           ((x) << 8)
#define MCHIP_MR_CAS_LATENCY(x)         ((x) << 4)
#if MEMC_BURST_LENGTH == 4
#define MCHIP_MR_BURST_LENGTH           (2)
#else
#define MCHIP_MR_BURST_LENGTH           (3)
#endif
#define MCHIP_EMR1_DLL_DISABLE(x)       ((x) << 0)
#define MCHIP_EMR1_RTT_ODT_DISABLED     (0)
#define MCHIP_EMR1_RTT_75_OHM           (1 << 2)
#define MCHIP_EMR1_RTT_150_OHM          (1 << 6)
#define MCHIP_EMR1_RTT_50_OHM           ((1 << 6) | (1 << 2))
#define MCHIP_EMR1_OCD_CALI_EXIT        (0x0 << 7)
#define MCHIP_EMR1_OCD_CALI_DEFAULT     (0x3 << 7)


#endif  /* _AIMEMC_H */
