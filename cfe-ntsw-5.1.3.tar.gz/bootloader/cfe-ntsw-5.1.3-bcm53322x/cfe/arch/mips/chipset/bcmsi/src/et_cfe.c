/*
 * CFE polled-mode device driver for
 * Broadcom BCM47XX 10/100 Mbps Ethernet Controller
 *
 * $Copyright (C) 2003 Broadcom Corporation$
 *
 * $Id: et_cfe.c,v 1.12 2009/09/23 10:16:46 hchang Exp $
 */

#include "cfe.h"
#include "ui_command.h"

#include <typedefs.h>
#include <osl.h>
#include <bcmendian.h>
#include <ethernet.h>
#include <bcmdevs.h>
#include <bcmenetrxh.h>
#include <bcmutils.h>
#include <et_dbg.h>
#include <hndsoc.h>
#include <bcmgmacrxh.h>
#include <etc.h>
#include <etcgmac.h>
#include <gmac_common.h>
#include <bcmenetphy.h>
#include <et_cfe.h>

typedef struct et_info {
    etc_info_t *etc;        /* pointer to common os-independent data */
    cfe_devctx_t *ctx;      /* backpoint to device */
    int64_t timer;          /* one second watchdog timer */
    osl_t *osh;
    struct et_info *next;       /* pointer to next et_info_t in chain */
} et_info_t;

#if CFG_SOCDIAG
extern int socdiag_addcmd(
               char *command,
               int (*func)(ui_cmdline_t *,int argc,char *argv[]),
               void *ref,
               char *help,
               char *usage,
               char *switches
               );

extern int ui_cmd_etdiag(
    etc_info_t * etc, ui_cmdline_t *cmdline, int argc, char *argv[]);
#endif

static et_info_t *et_list = NULL;

void et_init(et_info_t *et, uint options);
void et_reset(et_info_t *et);
void et_link_up(et_info_t *et);
void et_link_down(et_info_t *et);
int et_up(et_info_t *et);
int et_down(et_info_t *et, int reset);
void et_dump(et_info_t *et, struct bcmstrbuf *b);
void et_addcmd(void);
void et_socdiag_addcmd(void);
void et_intrson(et_info_t *et);

static void ui_rx_callback_dump(void *x);

void
et_init(et_info_t *et, uint options)
{
    ET_TRACE(("et%d: et_init\n", et->etc->unit));

    etc_reset(et->etc);
    etc_init(et->etc, options);
}

void
et_reset(et_info_t *et)
{
    ET_TRACE(("et%d: et_reset\n", et->etc->unit));

    etc_reset(et->etc);
}

void
et_link_up(et_info_t *et)
{
    ET_ERROR(("et%d: link up (%d%s)\n",
        et->etc->unit, et->etc->speed, (et->etc->duplex? "FD" : "HD")));
}

void
et_link_down(et_info_t *et)
{
    ET_ERROR(("et%d: link down\n", et->etc->unit));
}

int
et_up(et_info_t *et)
{
    if (et->etc->up)
        return 0;

    ET_TRACE(("et%d: et_up\n", et->etc->unit));

    etc_up(et->etc);

    /* schedule one second watchdog timer */
    TIMER_SET(et->timer, CFE_HZ / 2);

    return 0;
}

int
et_down(et_info_t *et, int reset)
{
    ET_TRACE(("et%d: et_down\n", et->etc->unit));

    /* stop watchdog timer */
    TIMER_CLEAR(et->timer);

    etc_down(et->etc, reset);

    return 0;
}

void
et_dump(et_info_t *et, struct bcmstrbuf *b)
{
#ifdef BCMDBG
    etc_dump(et->etc, b);
#endif
}

#ifdef BCM47XX_CHOPS

et_info_t *et_phyfind(et_info_t *et, uint coreunit);
uint16 et_phyrd(et_info_t *et, uint phyaddr, uint reg);
void et_phywr(et_info_t *et, uint reg, uint phyaddr, uint16 val);

/*
 * 47XX-specific shared mdc/mdio contortion:
 * Find the et associated with the same chip as <et>
 * and coreunit matching <coreunit>.
 */
et_info_t *
et_phyfind(et_info_t *et, uint coreunit)
{
    et_info_t *tmp;

    /* walk the list et's */
    for (tmp = et_list; tmp; tmp = tmp->next) {
        if (et->etc == NULL)
            continue;
        if (tmp->etc->coreunit != coreunit)
            continue;
        break;
    }
    return (tmp);
}

/* shared phy read entry point */
uint16
et_phyrd(et_info_t *et, uint phyaddr, uint reg)
{
    return et->etc->chops->phyrd(et->etc->ch, phyaddr, reg);
}

/* shared phy write entry point */
void
et_phywr(et_info_t *et, uint phyaddr, uint reg, uint16 val)
{
    et->etc->chops->phywr(et->etc->ch, phyaddr, reg, val);
}

#endif  /* BCM47XX_CHOPS */

/*  *********************************************************************
    *  ETHER_PROBE(drv,probe_a,probe_b,probe_ptr)
    *  
    *  Probe and install driver.
    *  Create a context structure and attach to the
    *  specified network device.
    *  
    *  Input parameters: 
    *      drv - driver descriptor
    *      probe_a - device ID
    *      probe_b - unit number
    *      probe_ptr - mapped registers
    *      
    *  Return value:
    *      nothing
    ********************************************************************* */

static void
et_probe(cfe_driver_t *drv,
     unsigned long probe_a, unsigned long probe_b, 
     void *probe_ptr)
{
    et_info_t *et;
    uint16 device;
    uint unit;
    char name[128];

    device = (uint16) probe_a;
    unit = (uint) probe_b;

    if (!(et = (et_info_t *) KMALLOC(sizeof(et_info_t), 0))) {
        ET_ERROR(("et%d: KMALLOC failed\n", unit));
        return;
    }
    bzero(et, sizeof(et_info_t));

    et->osh = osl_attach(et);
    ASSERT(et->osh);

    /* common load-time initialization */
    if ((et->etc = etc_attach(et, VENDOR_BROADCOM, device, unit, et->osh, probe_ptr)) == NULL) {
        ET_ERROR(("et%d: etc_attach failed\n", unit));
        KFREE(et);
        return;
    }

    /* this is a polling driver - the chip intmask stays zero */
    et->etc->chops->intrsoff(et->etc->ch);

    /* add us to the global linked list */
    et->next = et_list;
    et_list = et;

    /* print hello string */
    et->etc->chops->longname(et->etc->ch, name, sizeof (name));

    cfe_attach(drv, et, NULL, name);
}

/*  *********************************************************************
    *  ETHER_OPEN(ctx)
    *  
    *  Open the Ethernet device.  The MAC is reset, initialized, and
    *  prepared to receive and send packets.
    *  
    *  Input parameters: 
    *      ctx - device context (includes ptr to our softc)
    *      
    *  Return value:
    *      status, 0 = ok
    ********************************************************************* */

static int
et_open(cfe_devctx_t *ctx)
{
    et_info_t *et = (et_info_t *) ctx->dev_softc;

    ET_TRACE(("et%d: et_open\n", et->etc->unit));

    return et_up(et);
}

/*  *********************************************************************
    *  ETHER_READ(ctx,buffer)
    *  
    *  Read a packet from the Ethernet device.  If no packets are
    *  available, the read will succeed but return 0 bytes.
    *  
    *  Input parameters: 
    *      ctx - device context (includes ptr to our softc)
    *      buffer - pointer to buffer descriptor.  
    *      
    *  Return value:
    *      status, 0 = ok
    ********************************************************************* */

static int
et_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    et_info_t *et = (et_info_t *) ctx->dev_softc;
    int events;
    void *p;
    bcmenetrxh_t *rxh;
    uint16 flags;
#ifdef BCMDBG     
    char eabuf[32];
#endif
    int hdrlen;
    void *ptr_payload;

    ET_TRACE(("et%d: et_read\n", et->etc->unit));

    /* assume no packets */
    buffer->buf_retlen = 0;

    /* poll for packet */
    events = et->etc->chops->getintrevents(et->etc->ch, FALSE);
    if ((events & INTR_RX) == 0)
        return 0;

    /* get packet */
    if (!(p = et->etc->chops->rx(et->etc->ch)))
        goto done;
    
    /*
     * Since currently the upper protocol didn't support multi-block packets
     * It combine the separate header and payload into a complete packet 
     */
    if ((ptr_payload = PKTNEXT(NULL, p)) != NULL) {
        hdrlen= PKTLEN(NULL, p);
        /* The payload has reserved extra header room */
        PKTPUSH(NULL, ptr_payload, hdrlen);
        bcopy(PKTDATA(NULL, p), PKTDATA(NULL, ptr_payload), 
                hdrlen);
        PKTNEXT(NULL, p) = NULL;
        /* The memory type should be changed */
        PKTFREE(NULL, p, FALSE, et->etc->pkthdr_mem); 
        p = ptr_payload;
    }

    /* packet buffer starts with rxhdr */
    rxh = (bcmenetrxh_t *) PKTDATA(NULL, p);

    /* strip off rxhdr */
    PKTPULL(NULL, p, HWRXOFF);

    /* check for reported frame errors */
    flags = RXH_FLAGS(et->etc, rxh);
    if (flags) {
#ifdef BCMDBG     
        bcm_ether_ntoa((struct ether_addr *)
              (((struct ether_header *) PKTDATA(NULL, p))->ether_shost), eabuf);
#endif
        if (RXH_OVERSIZE(et->etc, rxh)) {
            ET_ERROR(("et%d: rx: over size packet from %s\n", et->etc->unit, eabuf));
        }
        if (RXH_CRC(et->etc, rxh)) {
            ET_ERROR(("et%d: rx: crc error from %s\n", et->etc->unit, eabuf));
        }
        if (RXH_OVF(et->etc, rxh)) {
            ET_ERROR(("et%d: rx: fifo overflow\n", et->etc->unit));
        }
        if (RXH_NO(et->etc, rxh)) {
            ET_ERROR(("et%d: rx: crc error (odd nibbles) from %s\n",
                      et->etc->unit, eabuf));
        }
        if (RXH_RXER(et->etc, rxh)) {
            ET_ERROR(("et%d: rx: symbol error from %s\n", et->etc->unit, eabuf));
        }
    } else {
        bcopy(PKTDATA(NULL, p), HSADDR2PTR(buffer->buf_ptr), PKTLEN(NULL, p));
        buffer->buf_retlen = PKTLEN(NULL, p);
        ET_PRHDR("rx", (struct ether_header *) HSADDR2PTR(buffer->buf_ptr),
                 buffer->buf_retlen, et->etc->unit);
        ET_PRPKT("rxpkt", HSADDR2PTR(buffer->buf_ptr), buffer->buf_retlen, et->etc->unit);
    }

    /* free packet */
    PKTFREE(et->osh, p, FALSE, et->etc->pkt_mem);

done:
    /* post more rx bufs */
    et->etc->chops->rxfill(et->etc->ch);

    return 0;
}

/*  *********************************************************************
    *  ETHER_INPSTAT(ctx,inpstat)
    *  
    *  Check for received packets on the Ethernet device
    *  
    *  Input parameters: 
    *      ctx - device context (includes ptr to our softc)
    *      inpstat - pointer to input status structure
    *      
    *  Return value:
    *      status, 0 = ok
    ********************************************************************* */

static int
et_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    et_info_t *et = (et_info_t *) ctx->dev_softc;
    int events;

    events = et->etc->chops->getintrevents(et->etc->ch, FALSE);
    inpstat->inp_status = ((events & INTR_RX) ? 1 : 0);

    return 0;
}

/*  *********************************************************************
    *  ETHER_WRITE(ctx,buffer)
    *  
    *  Write a packet to the Ethernet device.
    *  
    *  Input parameters: 
    *      ctx - device context (includes ptr to our softc)
    *      buffer - pointer to buffer descriptor.  
    *      
    *  Return value:
    *      status, 0 = ok
    ********************************************************************* */

static int
et_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    et_info_t *et = ctx->dev_softc;
    void *p;
    int blen;

    if (!(p = PKTGET(NULL, buffer->buf_length, TRUE, et->etc->pkt_mem))) {
        ET_ERROR(("et%d: PKTGET failed\n", et->etc->unit));
        return CFE_ERR_NOMEM;
    }
    blen = buffer->buf_length;
    bcopy(HSADDR2PTR(buffer->buf_ptr), PKTDATA(NULL, p), buffer->buf_length);

    ET_PRHDR("tx", (struct ether_header *) PKTDATA(NULL, p), PKTLEN(NULL, p), et->etc->unit);
    ET_PRPKT("txpkt", PKTDATA(NULL, p), PKTLEN(NULL, p), et->etc->unit);

    ASSERT(*et->etc->txavail[TX_Q0] > 0);

    /* transmit the frame */
    et->etc->chops->tx(et->etc->ch, p);

    /* wait for frame to complete */
    while (!(et->etc->chops->getintrevents(et->etc->ch, FALSE) & INTR_TX));

    /* reclaim any completed tx frames */
    et->etc->chops->txreclaim(et->etc->ch, FALSE);

    buffer->buf_retlen = blen;

    return 0;
}

/*  *********************************************************************
    *  ETHER_IOCTL(ctx,buffer)
    *  
    *  Do device-specific I/O control operations for the device
    *  
    *  Input parameters: 
    *      ctx - device context (includes ptr to our softc)
    *      buffer - pointer to buffer descriptor.  
    *      
    *  Return value:
    *      status, 0 = ok
    ********************************************************************* */
static int
et_ioctl(cfe_devctx_t *ctx,iocb_buffer_t *buffer) 
{
    et_info_t *et = (et_info_t *) ctx->dev_softc;
    int val;

    ET_TRACE(("et%d: et_ioctl: cmd 0x%x\n", et->etc->unit, buffer->buf_ioctlcmd));

    switch (buffer->buf_ioctlcmd) {

    case IOCTL_ETHER_GETHWADDR:
        bcopy(&et->etc->cur_etheraddr, HSADDR2PTR(buffer->buf_ptr), ETHER_ADDR_LEN);
        break;

    case IOCTL_ETHER_SETHWADDR:
        bcopy(HSADDR2PTR(buffer->buf_ptr), &et->etc->cur_etheraddr, ETHER_ADDR_LEN);
        et_init(et, ET_INIT_DEF_OPTIONS);
        break;

    case IOCTL_ETHER_GETSPEED:
        val = ETHER_SPEED_UNKNOWN;
        if (et->etc->linkstate) {
            if (et->etc->speed == 10)
                val = et->etc->duplex ? ETHER_SPEED_10FDX : ETHER_SPEED_10HDX;
            else if (et->etc->speed == 100)
                val = et->etc->duplex ? ETHER_SPEED_100FDX : ETHER_SPEED_100HDX;
            else if (et->etc->speed == 1000)
                val = ETHER_SPEED_1000FDX;
        }
        *((int *) HSADDR2PTR(buffer->buf_ptr)) = val;
        break;

    case IOCTL_ETHER_SETSPEED:
        val = *((int *) HSADDR2PTR(buffer->buf_ptr));
        if (val == ETHER_SPEED_AUTO)
            val = ET_AUTO;
        else if (val == ETHER_SPEED_10HDX)
            val = ET_10HALF;
        else if (val == ETHER_SPEED_10FDX)
            val = ET_10FULL;
        else if (val == ETHER_SPEED_100HDX)
            val = ET_100HALF;
        else if (val == ETHER_SPEED_100FDX)
            val = ET_100FULL;
        else if (val == ETHER_SPEED_1000FDX)
            val = ET_1000FULL;
        else
            return CFE_ERR_UNSUPPORTED;
        return etc_ioctl(et->etc, ETCSPEED, &val);

    case IOCTL_ETHER_GETLINK:
        *((int *) HSADDR2PTR(buffer->buf_ptr)) = (int) et->etc->linkstate;
        break;

    case IOCTL_ETHER_GETLOOPBACK:
        *((int *) HSADDR2PTR(buffer->buf_ptr)) = et->etc->loopbk;
        break;

    case IOCTL_ETHER_SETLOOPBACK:
        val = *((int *) HSADDR2PTR(buffer->buf_ptr));
        if (val == ETHER_LOOPBACK_OFF)
            val = (int) FALSE;
        else
            val = (int) TRUE;
        return etc_ioctl(et->etc, ETCLOOP, &val);

    case IOCTL_ETHER_GETCFPENTRY:
        return etc_ioctl(et->etc, ETCCFPRD, HSADDR2PTR(buffer->buf_ptr));

    case IOCTL_ETHER_SETCFPENTRY:
        return etc_ioctl(et->etc, ETCCFPWR, HSADDR2PTR(buffer->buf_ptr));

    case IOCTL_ETHER_GETCFPFIELD:
        return etc_ioctl(et->etc, ETCCFPFIELDRD, HSADDR2PTR(buffer->buf_ptr));

    case IOCTL_ETHER_SETCFPFIELD:
        return etc_ioctl(et->etc, ETCCFPFIELDWR, HSADDR2PTR(buffer->buf_ptr));
    case IOCTL_ETHER_CFP_GETUDF:
        return etc_ioctl(et->etc, ETCCFPUDFRD, HSADDR2PTR(buffer->buf_ptr));

    case IOCTL_ETHER_CFP_SETUDF:
        return etc_ioctl(et->etc, ETCCFPUDFWR, HSADDR2PTR(buffer->buf_ptr));

    case IOCTL_ETHER_SET_PKT_MEM:
        val = *((uint *) HSADDR2PTR(buffer->buf_ptr));
        return etc_ioctl(et->etc, ETCPKTMEMSET, &val);
        
    case IOCTL_ETHER_SET_PKTHDR_MEM:
        val = *((uint *) HSADDR2PTR(buffer->buf_ptr));
        return etc_ioctl(et->etc, ETCPKTHDRMEMSET, &val); 

    /* rate control */
    case IOCTL_ETHER_SET_RXRATE:
        return etc_ioctl(et->etc, ETCRXRATE, HSADDR2PTR(buffer->buf_ptr));
    case IOCTL_ETHER_SET_TXRATE:
        return etc_ioctl(et->etc, ETCTXRATE, HSADDR2PTR(buffer->buf_ptr));

    /* flow control */
    case IOCTL_ETHER_SET_FLOWCTRL_MODE:
        val = *((uint *) HSADDR2PTR(buffer->buf_ptr));
        return etc_ioctl(et->etc, ETCFLOWCTRLMODE, &val);
    case IOCTL_ETHER_SET_FLOWCTRL_AUTO:
        return etc_ioctl(et->etc, ETCFLOWCTRLAUTOSET, HSADDR2PTR(buffer->buf_ptr));
    case IOCTL_ETHER_SET_FLOWCTRL_CPU:
        val = *((uint *) HSADDR2PTR(buffer->buf_ptr));
        return etc_ioctl(et->etc, ETCFLOWCTRLCPUSET, &val);
    case IOCTL_ETHER_SET_FLOWCTRL_RX_CHANNEL:
        return etc_ioctl(et->etc, ETCFLOWCTRLRXCHANSET, HSADDR2PTR(buffer->buf_ptr));
    /* TPID */
    case IOCTL_ETHER_SET_TPID:
        return etc_ioctl(et->etc, ETCTPID, HSADDR2PTR(buffer->buf_ptr));

    /* Private tag */
    case IOCTL_ETHER_SET_PV_TAG:
        val = *((uint *) HSADDR2PTR(buffer->buf_ptr));
        return etc_ioctl(et->etc, ETCPVTAG, &val);

    /* RX Separate header */
    case IOCTL_ETHER_SET_RX_SEPHDR:
        val = *((uint *) HSADDR2PTR(buffer->buf_ptr));
        return etc_ioctl(et->etc, ETCRXSEPHDR, &val);

    /* Tx qos */
    case IOCTL_ETHER_SET_TXQOS_MODE:
        val = *((uint *) HSADDR2PTR(buffer->buf_ptr));
        return etc_ioctl(et->etc, ETCTXQOSMODE, &val);
    case IOCTL_ETHER_SET_TXQOS_WEIGHT:
        return etc_ioctl(et->etc, ETCTXQOSWEIGHTSET, HSADDR2PTR(buffer->buf_ptr));

    default:
        return CFE_ERR_UNSUPPORTED;

    }

    return 0;
}

/*  *********************************************************************
    *  ETHER_CLOSE(ctx)
    *  
    *  Close the Ethernet device.
    *  
    *  Input parameters: 
    *      ctx - device context (includes ptr to our softc)
    *      
    *  Return value:
    *      status, 0 = ok
    ********************************************************************* */

static int
et_close(cfe_devctx_t *ctx)
{
    et_info_t *et = (et_info_t *) ctx->dev_softc;

    ET_TRACE(("et%d: et_close\n", et->etc->unit));

    return et_down(et, 1);
}

void
et_intrson(et_info_t *et)
{
    /* this is a polling driver - the chip intmask stays zero */
    ET_TRACE(("et%d: et_intrson\n", et->etc->unit));
}

/*  *********************************************************************
    *  ETHER_POLL(ctx,ticks)
    *  
    *  Check for changes in the PHY, so we can track speed changes.
    *  
    *  Input parameters: 
    *      ctx - device context (includes ptr to our softc)
    *      ticks- current time in ticks
    *      
    *  Return value:
    *      nothing
    ********************************************************************* */

static void
et_poll(cfe_devctx_t *ctx, int64_t ticks)
{
    et_info_t *et = (et_info_t *) ctx->dev_softc;

    if (TIMER_RUNNING(et->timer) &&
        TIMER_EXPIRED(et->timer)) {
        etc_watchdog(et->etc);
        TIMER_SET(et->timer, CFE_HZ / 2);
    }
}

const static cfe_devdisp_t et_dispatch = {
    et_open,
    et_read,
    et_inpstat,
    et_write,
    et_ioctl,
    et_close,
    et_poll,
    NULL
};

const cfe_driver_t bcmet = {
    "Broadcom Ethernet",
    "eth",
    CFE_DEV_NETWORK,
    &et_dispatch,
    et_probe
};


static int
ui_cmd_et_flowctrl(et_info_t * et, ui_cmdline_t *cmdline, int argc, char *argv[])
{
    char *subcmd, *x, *arg;
    uint tmp[3];
    int cmd, i;
    
    if (!(subcmd = cmd_getarg(cmdline, 1)))
        return CFE_ERR_INV_PARAM;

     if (!strcmp(subcmd, "mode")) {
        /* flowctrl mode <mode> */ 
        cmd = ETCFLOWCTRLMODE;
        x = cmd_getarg(cmdline, 2);
        if (x == NULL) {
            printf("et fl mode <mode>\n");
            return CFE_ERR_INV_PARAM;
        }
        tmp[0] = xtoi(x);
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
     }
     else if (!strcmp(subcmd, "autoset")) { 
        /* flowctrl autoset <on_threshold> <off_threshold> */ 
        cmd = ETCFLOWCTRLAUTOSET;
        for (i = 0; i < 2; i++) {
            x = cmd_getarg(cmdline, (i+2));
            if (x == NULL) {
                printf("et fl autoset <on_threshold> <off_threshold>\n");
                return CFE_ERR_INV_PARAM;
            }
            tmp[i] = xtoi(x);
        }
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
     }
     else if (!strcmp(subcmd, "cpuset")) {
        /* flowctrl cpuset <pause_on> */
        cmd = ETCFLOWCTRLCPUSET;
        x = cmd_getarg(cmdline, 2);
        if (x == NULL) {
            printf("et fl cpuset <1/0>\n");
            return CFE_ERR_INV_PARAM;
        }
        tmp[0] = xtoi(x);
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
     }
     else if (!strcmp(subcmd, "rxchanset")) { 
        /* flowctrl rxchanset <channel> <on_threshold> <off_threshold> */ 
        cmd = ETCFLOWCTRLRXCHANSET;
        for (i = 0; i < 3; i++) {
            x = cmd_getarg(cmdline, (i+2));
            if (x == NULL) {
                printf("et fl rxchanset <rx queue> <on_threshold> <off_threshold>\n");
                return CFE_ERR_INV_PARAM;
            }
            tmp[i] = xtoi(x);
        }
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
     }
     else {
        return CFE_ERR_INV_PARAM;
     }

     return CFE_OK;
}

static int
ui_cmd_et_txqos(et_info_t * et, ui_cmdline_t *cmdline, int argc, char *argv[])
{
    char *subcmd, *x, *arg;
    uint tmp[3];
    int cmd, i;
    
    if (!(subcmd = cmd_getarg(cmdline, 1)))
        return CFE_ERR_INV_PARAM;

     if (!strcmp(subcmd, "mode")) {
        /* txqos mode <mode> */ 
        cmd = ETCTXQOSMODE;
        x = cmd_getarg(cmdline, 2);
        if (x == NULL) {
            printf("et txqos mode <mode>\n");
            return CFE_ERR_INV_PARAM;
        }
        tmp[0] = xtoi(x);
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
     }
     else if (!strcmp(subcmd, "weight")) { 
        /* flowctrl rxchanset <channel> <on_threshold> <off_threshold> */ 
        cmd = ETCTXQOSWEIGHTSET;
        for (i = 0; i < 2; i++) {
            x = cmd_getarg(cmdline, (i+2));
            if (x == NULL) {
                printf("et txqos weight <tx queue> <weight>\n");
                return CFE_ERR_INV_PARAM;
            }
            tmp[i] = xtoi(x);
        }
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
     }
     else {
        return CFE_ERR_INV_PARAM;
     }

     return CFE_OK;
}


static int
ui_cmd_tx(et_info_t * et, ui_cmdline_t *cmdline, int argc, char *argv[])
{
    void *p;
    char *x;
    uchar *data_p;
    int length, i;
    uint prio;

    if(!et->etc->up) {
        ET_ERROR(("et%d: is not up now!\n", et->etc->unit));
        return CFE_ERR;
    }

     x = cmd_getarg(cmdline, 1);
     if (x == NULL) {
        printf("et tx <length> <prority>\n");
        return CFE_ERR_INV_PARAM;
     }
     length = atoi(x);

     x = cmd_getarg(cmdline, 2);
     if (x == NULL) {
        printf("et tx <length> <prority>\n");
        return CFE_ERR_INV_PARAM;
     }
     prio = atoi(x);
     printf("ui_cmd_tx : length = %d, priority = %d\n",
     	length, prio);

    /* reclaim any completed tx frames */
    et->etc->chops->txreclaim(et->etc->ch, FALSE);

    if (!(p = PKTGET(NULL, length, TRUE, et->etc->pkt_mem))) {
        ET_ERROR(("et%d: PKTGET failed\n", et->etc->unit));
        return CFE_ERR_NOMEM;
    }

    et->etc->qos = 1;

    PKTFLAGTS(NULL, p) = 1;
    PKTSETPRIO(p, prio);

    data_p = (uchar *)PKTDATA(NULL, p);
    /* Fix the MAC DA */
    for (i = 0; i < length; i++) {
        *(data_p + i) = i;
    }
    

    ET_PRHDR("tx", (struct ether_header *) PKTDATA(NULL, p), PKTLEN(NULL, p), et->etc->unit);
    ET_PRPKT("txpkt", PKTDATA(NULL, p), PKTLEN(NULL, p), et->etc->unit);

    ASSERT(*et->etc->txavail[etc_up2tc(prio)] > 0);

    /* transmit the frame */
    et->etc->chops->tx(et->etc->ch, p);




    return 0;
}

static void
ui_rx_callback_dump(void *x)
{
    int i, len;
    et_info_t *et, *et1;
    void *p, *p0, *next;
    int events;
    uchar *data_ptr;
    uchar tx_buf[2048];
    int tx_len;
    
    for (et = et_list; et; et = et->next) {
        if (!et->etc->up) {
            continue;
        }

        /* reclaim any completed tx frames */
        et->etc->chops->txreclaim(et->etc->ch, FALSE);

        /* refill the rx buffer */
        et->etc->chops->rxfill(et->etc->ch);
        events = et->etc->chops->getintrevents(et->etc->ch, FALSE);
        if (events & INTR_RX) {
            /* get packet */
            if (!(p = et->etc->chops->rx(et->etc->ch))) {
                /* post more rx bufs */
                et->etc->chops->rxfill(et->etc->ch);
                return;
            }

            /* strip off rxhdr */
            PKTPULL(et->osh, p, HWRXOFF);

            /* tx */
            tx_len = 0;
            xprintf("Receive packets : et%d\n",et->etc->unit);

            for (p0 = p; p0; p0 = next) {
                len = PKTLEN(et->osh, p0) - 4; /* strip off CRC */
                data_ptr = (uchar *)PKTDATA(et->osh, p0);
                bcopy(data_ptr, &tx_buf[tx_len], len);
                tx_len += len;
                next = PKTNEXT(et->osh, p0);
                for (i=0; i<len; i++) {
                    xprintf("0x%02x ", *(data_ptr + i));
                    if ((i % 16) ==  15) {
                        xprintf("\n");
                    }
                }
                xprintf("\n");
                /* free packet */
                PKTFREE(et->osh, p0, FALSE, et->etc->pkt_mem);
            }

            /* Send the packet to another port */
            if (et == et_list) {
                et1 = et_list->next;
            } else {
                et1 = et_list;
            }
            if (!et1->etc->up) {
                continue;
            }
            if (!(p = PKTGET(NULL, tx_len, TRUE, et1->etc->pkt_mem))) {
                ET_ERROR(("et%d: PKTGET failed\n", et1->etc->unit));
            } else {
                bcopy(&tx_buf[0], PKTDATA(et1->osh, p), tx_len);
                xprintf("Transmit packets to et%d\n",et1->etc->unit);
                et1->etc->chops->tx(et1->etc->ch, p);
            }

        }
    }
}


static int
ui_cmd_et(ui_cmdline_t *cmdline, int argc, char *argv[])
{
    char *command, *name;
    et_info_t *et;
    cfe_device_t *dev;
    int cmd, val, ret, i;
    char *arg = (char *) &val;

    if (!(command = cmd_getarg(cmdline, 0)))
        return CFE_ERR_INV_PARAM;

    if (!cmd_sw_value(cmdline, "-i", &name) || !name)
        name = "eth0";
    if (!(dev = cfe_finddev(name)) ||
        !dev->dev_softc) {
        return CFE_ERR_DEVNOTFOUND;
       }
    for (et = et_list; et; et = et->next)
        if (et == dev->dev_softc)
            break;
    if (!et && !(et = et_list)) {
        return CFE_ERR_DEVNOTFOUND;
       }

    if (!strcmp(command, "up"))
        cmd = ETCUP;
    else if (!strcmp(command, "down"))
        cmd = ETCDOWN;
    else if (!strcmp(command, "loop")) {
        cmd = ETCLOOP;
        arg = cmd_getarg(cmdline, 1);
    } 
    
#ifdef QT_TEST /* ---- Debug section, Must be removed for formal release */
    /* internal debug command to set phy address 
     *  - phy address is HW decided on a real paltform.
     */
    else if  (!strcmp(command, "phyaddr")) {
        
        arg = cmd_getarg(cmdline, 1);   /* get new phyaddr */
        val = atoi(arg);
        
        if (arg != NULL){
            if ((val & (~EPHY_MASK)) || (val == EPHY_NONE) || 
                    (val == EPHY_NOREG)) {
                ET_ERROR(("Invalid PHY-addr=%0x%02x !\n", val));
                return 0;
            }
            et->etc->phyaddr = val;
        } else {
            printf("ET working PHY-Addr=0x%02x\n",et->etc->phyaddr);
        }
        
        return 0;        
    }
    /* internal debug command to set mdc/mdio cycle th 
     *  - the mdc_cycle_th is used to generate mdc/mdio clock.
     *      >> axi_clk * (2 * mdc_cycle_th + 1 ) = mdc_clock.
     */
    else if  (!strcmp(command, "mdioclkth")) {
        
        arg = cmd_getarg(cmdline, 1);   /* get new mdioclkth */
        val = atoi(arg);
        
        val &= ~(PHYCONTROL_MDC_CYCLE_TH_MASK >> 
                PHYCONTROL_MDC_CYCLE_TH_SHIFT);
        
        if (arg != NULL){
            printf("Not Implemented!\n");
        } else {
            printf("Not Implemented!\n");
        }
        
        return 0;        
    }
#endif  /* if QT_TEST */
    else if (!strcmp(command, "dump")) {
        if (!(arg = KMALLOC(4096, 0)))
            return CFE_ERR_NOMEM;
        bzero(arg, 4096);       
        if ((ret = etc_ioctl(et->etc, ETCDUMP, arg))) {
            KFREE(arg);
            return ret;
        }
        puts(arg);
        KFREE(arg);
        return 0;
    }
    else if (!strcmp(command, "msglevel")) {
        cmd = ETCSETMSGLEVEL;
        arg = cmd_getarg(cmdline, 1);
    }
    else if (!strcmp(command, "promisc")) {
        cmd = ETCPROMISC;
        arg = cmd_getarg(cmdline, 1);
    }
    else if  (!strcmp(command, "phyr")) {
        int phy_arg[] = {0,0};    /* mii_reg,mii_val */
        char *x;
        
        cmd = ETCPHYRD;
        x = cmd_getarg(cmdline, 1);
        if (x == NULL) {
             return CFE_ERR_INV_PARAM;
        }
        phy_arg[0] = atoi(x);
        
        if (!(arg = KMALLOC(sizeof(uint16), 0)))
                return CFE_ERR_NOMEM;
        bzero(arg, sizeof(uint16));
        
        if ((ret = etc_ioctl(et->etc, cmd, phy_arg))) {
            KFREE(arg);
            return ret;
        }
        
        printf("ET PHY-Read reg=0x%02x >> value=0x%04x\n",
                phy_arg[0], phy_arg[1]);
        puts(arg);
        KFREE(arg);
        return 0;
    }
    else if  (!strcmp(command, "phyw")) {
        int phy_arg[] = {0,0};    /* mii_reg,mii_val */
        char *x;

        x = cmd_getarg(cmdline, 1);
        if (x == NULL) {
            return CFE_ERR_INV_PARAM;
        }
        phy_arg[0] = atoi(x);
        x = cmd_getarg(cmdline, 2);
        if (x == NULL) {
            return CFE_ERR_INV_PARAM;
        }

        phy_arg[1] = atoi(x);

        printf("ET PHY-Write reg=0x%02x >> value=0x%04x\n",
                phy_arg[0], phy_arg[1]);
        cmd = ETCPHYWR;
        if ((ret = etc_ioctl(et->etc, cmd, phy_arg))) {
            return ret;
        }
        return 0;
    }
    else if (!strcmp(command, "tx")) {
        return ui_cmd_tx(et, cmdline, argc, argv);
    }
     else if (!strcmp(command, "rxmon")) {
        if (!(command = cmd_getarg(cmdline, 1))) {
            printf("et rxmon <start/stop>\n");
            return CFE_ERR_INV_PARAM;
        }

        if (!strcmp(command, "start")) {
            cfe_bg_add(ui_rx_callback_dump, NULL);
        } else if (!strcmp(command, "stop")) {
            cfe_bg_remove(ui_rx_callback_dump);
        } else {
            printf("et rxmon <start/stop>\n");
            return CFE_ERR_INV_PARAM;
        }
        
        return 0;
    }
    else if (!strcmp(command, "pktmem")) {
        cmd = ETCPKTMEMSET;
        arg = cmd_getarg(cmdline, 1);
    }
    else if (!strcmp(command, "pkthdr")) {
        cmd = ETCPKTHDRMEMSET;
        arg = cmd_getarg(cmdline, 1);
    }
    else if (!strcmp(command, "rxrate")) {
        uint tmp[2];
        char *x;
        cmd = ETCRXRATE;
        for (i = 0; i < 2; i++) {
            x = cmd_getarg(cmdline, (i+1));
            if (x == NULL) {
                printf("et rxrate <queue> <pps>\n");
                return CFE_ERR_INV_PARAM;
            }
            tmp[i] = xtoi(x);
        }
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
    }
    else if (!strcmp(command, "txrate")) {
        uint tmp[3];
        char *x;
        cmd = ETCTXRATE;
        for (i = 0; i < 3; i++) {
            x = cmd_getarg(cmdline, (i+1));
            if (x == NULL) {
                printf("et txrate <queue> <rate> <burst>\n");
                return CFE_ERR_INV_PARAM;
            }
            tmp[i] = xtoi(x);
        }
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
    }
    else if (!strcmp(command, "fl")) {
        return ui_cmd_et_flowctrl(et, cmdline, argc, argv);
    }
    else if (!strcmp(command, "tpid")) {
        uint tmp[2];
        char *x;
        cmd = ETCTPID;
        for (i = 0; i < 2; i++) {
            x = cmd_getarg(cmdline, (i+1));
            if (x == NULL) {
                return CFE_ERR_INV_PARAM;
            }
            tmp[i] = xtoi(x);
        }
        arg = (char *)&tmp[0];
        return etc_ioctl(et->etc, cmd, arg);
    }
    else if (!strcmp(command, "ptag")) {
        cmd = ETCPVTAG;
        arg = cmd_getarg(cmdline, 1);
    }
    else if (!strcmp(command, "sephdr")) {
        cmd = ETCRXSEPHDR;
        arg = cmd_getarg(cmdline, 1);
    }
    else if (!strcmp(command, "txqos")) {
        return ui_cmd_et_txqos(et, cmdline, argc, argv);
    }
#ifdef CFG_SOCDIAG   
    else if (!strcmp(command, "diag")) {
        return ui_cmd_etdiag(et->etc, cmdline, argc, argv);
    }
#endif    
    else
        return CFE_ERR_INV_PARAM;

    if (!arg)
        return CFE_ERR_INV_PARAM;
    else if (arg != (char *) &val) {
        val = bcm_strtoul(arg, NULL, 0);
        arg = (char *) &val;
    }

    return etc_ioctl(et->etc, cmd, arg);
}

void
et_addcmd(void)
{
    cmd_addcmd("et",
           ui_cmd_et,
           NULL,
           "Broadcom Ethernet utility.",
           "et command [args..]\n\n"
           "Configures the specified Broadcom Ethernet interface.",
           "-i=*;Specifies the interface|"
           "up;Activate the specified interface|"
           "down;Deactivate the specified interface|"
           "loop;Sets the loopback mode (0,1)|"
#ifdef BCMDBG           
           "dump;Dump driver information|"
#endif /* BCMDBG */           
           "phyr;PHY read |"
           "phyw;PHY write |"
           "msglevel;Sets the driver message level|"
           "promisc;Sets promiscuous mode|"
           "tx;Transmit a packet to the specified interface|"
           "rxmon;Enable the rx callback to switch the receiced packet to another ports|"
           "pktmem; Sets the target memory of packet buffer|"
           ";(0:main memory, 1: socram, 2: pci memory)|"
           "pkthdr; Sets the target memory of packet header buffer|"
           "rxrate; Set the ingress rate of RX queue|"
           "txrate; Set the egress rate of TX queue|"
           "fl mode; Set the flow control mode (0: disable, 1: auto, 2: cpu, 3: mix) |"
           "fl autoset; Set the ON/OFF threshold of auto mode|"
           "fl cpuset; Enable/disable the PAUSE frame send out of cpu mode|"
           "fl rxchanset; Set the threshold value of RX queue|"
           "tpid; Set the value of S-TAG TPID |"
           "ptag; Set private tag value |"
           "sephdr; Enable/Disable RX separate header. (0: disable, 1: enable) |"
           "txqos mode; Set the txqos mode (0: 1SP_3WRR, 1: 2SP_3WRR, 2: 3SP_1WRR, 3: ALL_SP) |"
           "txqos weight; Set the weight value of TX queue|"
           "diag; diagnostic tests (txrx, cfp, rate, flowctrl, tpid, ptag, all |"
           "");
}

#if CFG_SOCDIAG
void
et_socdiag_addcmd(void)
{
    socdiag_addcmd("et",
           ui_cmd_et,
           NULL,
           "Broadcom Ethernet utility.",
           "et command [args..]\n\n"
           "Configures the specified Broadcom Ethernet interface.",
           "-i=*;Specifies the interface|"
           "up;Activate the specified interface|"
           "down;Deactivate the specified interface|"
           "loop;Sets the loopback mode (0,1)|"
#ifdef BCMDBG           
           "dump;Dump driver information|"
#endif /* BCMDBG */           
           "phyr;PHY read |"
           "phyw;PHY write |"
           "msglevel;Sets the driver message level|"
           "promisc;Sets promiscuous mode|"
           "tx;Transmit a packet to the specified interface|"
           "rxmon;Enable the rx callback to switch the receiced packet to another ports|"
           "pktmem; Sets the target memory of packet buffer|"
           ";(0:main memory, 1: socram, 2: pci memory)|"
           "pkthdr; Sets the target memory of packet header buffer|"
           "rxrate; Set the ingress rate of RX queue|"
           "txrate; Set the egress rate of TX queue|"
           "fl mode; Set the flow control mode (0: disable, 1: auto, 2: cpu, 3: mix) |"
           "fl autoset; Set the ON/OFF threshold of auto mode|"
           "fl cpuset; Enable/disable the PAUSE frame send out of cpu mode|"
           "fl rxchanset; Set the threshold value of RX queue|"
           "tpid; Set the value of S-TAG TPID |"
           "ptag; Set private tag value |"
           "sephdr; Enable/Disable RX separate header. (0: disable, 1: enable) |"
           "txqos mode; Set the txqos mode (0: 1SP_3WRR, 1: 2SP_3WRR, 2: 3SP_1WRR, 3: ALL_SP) |"
           "txqos weight; Set the weight value of TX queue|"
           "diag; diagnostic tests (txrx, cfp, rate, flowctrl, tpid, ptag, all |"
           "");
}
#endif /* CFG_SOCDIAG */
