/*
 * CFE device driver tunables for
 * Broadcom BCM47XX 10/100Mbps Ethernet Device Driver

 * $Copyright (C) 2003 Broadcom Corporation$
 *
 * $Id: et_cfe.h,v 1.2 2009/02/25 02:36:28 kliao Exp $
 */

#ifndef _et_cfe_h_
#define _et_cfe_h_

#define NTXD	        16
#define NRXD	        16
#define NRXBUFPOST	8   

#define NBUFS		(NRXBUFPOST + 8)

/* common tunables */
#define	RXBUFSZ		LBDATASZ	/* rx packet buffer size */
#define	MAXMULTILIST	32		/* max # multicast addresses */

#endif /* _et_cfe_h_ */
