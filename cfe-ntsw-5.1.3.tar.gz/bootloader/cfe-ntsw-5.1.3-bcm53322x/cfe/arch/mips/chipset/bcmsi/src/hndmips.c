/*
 * BCM53000 Sonics SiliconBackplane MIPS core routines
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: hndmips.c,v 1.4 2009/08/06 09:11:16 cchao Exp $
 */

#include "cfe.h"
#include "typedefs.h"
#include "osl.h"
#include "bcmutils.h"
#include "siutils.h"
#include "bcmdevs.h"
#include "hndsoc.h"
#include "sbchipc.h"
#include "sbmemc.h"
#include <mipsinc.h>
#include "mips74k_core.h"
#include <hndmips.h>


/* sbipsflag register format, indexed by irq. */
static const uint32 sbips_int_mask[] = {
    0,  /* placeholder */
    SBIPS_INT1_MASK,
    SBIPS_INT2_MASK,
    SBIPS_INT3_MASK,
    SBIPS_INT4_MASK
};

static const uint32 sbips_int_shift[] = {
    0,  /* placeholder */
    SBIPS_INT1_SHIFT,
    SBIPS_INT2_SHIFT,
    SBIPS_INT3_SHIFT,
    SBIPS_INT4_SHIFT
};


/*
 * Map SB cores sharing the MIPS hardware IRQ0 to virtual dedicated OS IRQs.
 * Per-port BSP code is required to provide necessary translations between
 * the shared MIPS IRQ and the virtual OS IRQs based on SB core flag.
 *
 * See si_irq() for the mapping.
 */
static uint shirq_map_base = 0;


/*
 * Returns the MIPS IRQ assignment of the current core. If unassigned,
 * 0 is returned.
 */
static uint
si_getirq(si_t *sih)
{
    osl_t *osh;
    uint idx;
    void *regs;
    sbconfig_t *sb;
    uint32 flag, sbipsflag;
    uint irq = 0;

    osh = si_osh(sih);
    flag = si_flag(sih);

    idx = si_coreidx(sih);

    if ((regs = si_setcore(sih, MIPS74K_CORE_ID, 0)) != NULL) {
        /* IntMask1,2,3,4 regs are configured to enable propagation of
         * backplane interrupts 0,1,2,3 to mips hw interrupts 1,2,3,4.
         */
        for (irq = 1; irq <= 4; irq++) {
            if (R_REG(osh, &((mips74kregs_t *)regs)->intmask[irq]) &
                      (1 << flag))
                break;
        }
    } else if ((regs = si_setcore(sih, MIPS33_CORE_ID, 0)) != NULL) {
        sb = (sbconfig_t *)((ulong) regs + SBCONFIGOFF);

        /* sbipsflag specifies which core is routed to interrupts 1 to 4 */
        sbipsflag = R_REG(osh, &sb->sbipsflag);
        for (irq = 1; irq <= 4; irq++) {
            if (((sbipsflag & sbips_int_mask[irq]) >>
                 sbips_int_shift[irq]) == flag)
                break;
        }
    } else {
        ASSERT("Unknown processor core" == NULL);
        return 1000;    /* An invalid value */
    }

    if (irq == 5)
        irq = 0;

    si_setcoreidx(sih, idx);

    return irq;
}
/*
 * Return the MIPS IRQ assignment of the current core. If necessary
 * map cores sharing the MIPS hw IRQ0 to virtual dedicated OS IRQs.
 */
uint
si_irq(si_t *sih)
{
    uint irq = si_getirq(sih);
    if (irq == 0 && shirq_map_base)
        irq = si_flag(sih) + shirq_map_base;
    return irq;
}

/* Clears the specified MIPS IRQ. */
static void
si_clearirq(si_t *sih, uint irq)
{
    osl_t *osh;
    void *regs;
    sbconfig_t *sb;

    osh = si_osh(sih);

    if ((regs = si_setcore(sih, MIPS74K_CORE_ID, 0)) != NULL) {
        W_REG(osh, &((mips74kregs_t *)regs)->intmask[irq], 0);
    } else if ((regs = si_setcore(sih, MIPS33_CORE_ID, 0)) != NULL) {
        sb = (sbconfig_t *)((ulong) regs + SBCONFIGOFF);
        if (irq == 0)
            W_REG(osh, &sb->sbintvec, 0);
        else
            OR_REG(osh, &sb->sbipsflag, sbips_int_mask[irq]);
    } else
        ASSERT("Unknown processor core" == NULL);
}

#if CFG_INTERRUPTS
/*
 * Assigns the specified MIPS IRQ to the specified core. Shared MIPS
 * IRQ 0 may be assigned more than once.
 *
 * The old assignment to the specified core is removed first.
 */
static void
si_setirq(si_t *sih, uint irq, uint coreid, uint coreunit)
{
    osl_t *osh;
    void *regs;
    sbconfig_t *sb;
    uint32 flag;
    uint oldirq;

    osh = si_osh(sih);

    regs = si_setcore(sih, coreid, coreunit);
    ASSERT(regs);
    flag = si_flag(sih);
    oldirq = si_getirq(sih);
    if (oldirq)
        si_clearirq(sih, oldirq);

    if ((regs = si_setcore(sih, MIPS74K_CORE_ID, 0)) != NULL) {
        if (!oldirq)
            AND_REG(osh, &((mips74kregs_t *)regs)->intmask[0], ~(1 << flag));

        if (irq == 0)
            OR_REG(osh, &((mips74kregs_t *)regs)->intmask[0], 1 << flag);
        else {
            W_REG(osh, &((mips74kregs_t *)regs)->intmask[irq], 1 << flag);
        }
    } else if ((regs = si_setcore(sih, MIPS33_CORE_ID, 0)) != NULL) {
        sb = (sbconfig_t *)((ulong) regs + SBCONFIGOFF);

        if (!oldirq)
            AND_REG(osh, &sb->sbintvec, ~(1 << flag));

        if (irq == 0)
            OR_REG(osh, &sb->sbintvec, 1 << flag);
        else {
            flag <<= sbips_int_shift[irq];
            ASSERT(!(flag & ~sbips_int_mask[irq]));
            flag |= R_REG(osh, &sb->sbipsflag) & ~sbips_int_mask[irq];
            W_REG(osh, &sb->sbipsflag, flag);
        }
    } else
        ASSERT("Unknown processor core" == NULL);
}
#endif

/*
 * Initializes clocks and interrupts. SB and NVRAM access must be
 * initialized prior to calling.
 *
 * 'shirqmap' enables virtual dedicated OS IRQ mapping if non-zero.
 */
void
si_mips_init(si_t *sih, uint shirqmap)
{
    osl_t *osh;
    uint32 c0reg;
    uint irq;

    osh = si_osh(sih);

    /* Disable interrupts */
    c0reg = MFC0(C0_STATUS, 0);
    c0reg &= ~ST0_IE;
    MTC0(C0_STATUS, 0, c0reg);

	/* Enable ExternalSync for sync instruction to take effect */
	c0reg = MFC0(C0_CONFIG, 7);
	c0reg |= CONF7_ES;
	MTC0(C0_CONFIG, 7, c0reg);

    /* Save shared IRQ mapping base */
    shirq_map_base = shirqmap;

    /* Chip specific initialization */
    switch (sih->chip) {
    case BCM4716_CHIP_ID:
    case BCM53000_CHIP_ID:
        /* Clear interrupt map */
        for (irq = 0; irq <6; irq++)
            si_clearirq(sih, irq);
            
#ifdef CFG_ALTA
        si_setirq(sih, 3, ALTA_CORE_ID, 0);
#endif /* CFG_ALTA */

        break;
    }
}


