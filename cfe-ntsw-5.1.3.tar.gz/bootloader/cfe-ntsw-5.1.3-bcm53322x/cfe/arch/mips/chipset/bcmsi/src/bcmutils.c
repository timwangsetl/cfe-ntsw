/*
 * Driver O/S-independent utility routines
 *
 * $Copyright Open Broadcom Corporation$
 * $Id: bcmutils.c,v 1.4 2009/04/17 02:33:29 kliao Exp $
 */

#include "cfe.h"
#include "typedefs.h"
#include "bcmutils.h"
#include "osl.h"
#include "siutils.h"
#include "env_subr.h"
#include "ethernet.h"
#include "disasm.h"


const unsigned char bcm_ctype[] = {
    _BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,           /* 0-7 */
    _BCM_C, _BCM_C|_BCM_S, _BCM_C|_BCM_S, _BCM_C|_BCM_S, _BCM_C|_BCM_S, _BCM_C|_BCM_S, _BCM_C,
    _BCM_C, /* 8-15 */
    _BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,         /* 16-23 */
    _BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,_BCM_C,       /* 24-31 */
    _BCM_S|_BCM_SP,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P, /* 32-39 */
    _BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,         /* 40-47 */
    _BCM_D,_BCM_D,_BCM_D,_BCM_D,_BCM_D,_BCM_D,_BCM_D,_BCM_D,         /* 48-55 */
    _BCM_D,_BCM_D,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,         /* 56-63 */
    _BCM_P, _BCM_U|_BCM_X, _BCM_U|_BCM_X, _BCM_U|_BCM_X, _BCM_U|_BCM_X, _BCM_U|_BCM_X,
    _BCM_U|_BCM_X, _BCM_U, /* 64-71 */
    _BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,         /* 72-79 */
    _BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,_BCM_U,         /* 80-87 */
    _BCM_U,_BCM_U,_BCM_U,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_P,         /* 88-95 */
    _BCM_P, _BCM_L|_BCM_X, _BCM_L|_BCM_X, _BCM_L|_BCM_X, _BCM_L|_BCM_X, _BCM_L|_BCM_X,
    _BCM_L|_BCM_X, _BCM_L, /* 96-103 */
    _BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L, /* 104-111 */
    _BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L,_BCM_L, /* 112-119 */
    _BCM_L,_BCM_L,_BCM_L,_BCM_P,_BCM_P,_BCM_P,_BCM_P,_BCM_C, /* 120-127 */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 128-143 */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,     /* 144-159 */
    _BCM_S|_BCM_SP, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P,
    _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, /* 160-175 */
    _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P,
    _BCM_P, _BCM_P, _BCM_P, _BCM_P, _BCM_P, /* 176-191 */
    _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U,
    _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, /* 192-207 */
    _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_P, _BCM_U, _BCM_U, _BCM_U,
    _BCM_U, _BCM_U, _BCM_U, _BCM_U, _BCM_L, /* 208-223 */
    _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L,
    _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, /* 224-239 */
    _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_P, _BCM_L, _BCM_L, _BCM_L,
    _BCM_L, _BCM_L, _BCM_L, _BCM_L, _BCM_L /* 240-255 */
};


/*
 * Search the name=value vars for a specific one and return its value.
 * Returns NULL if not found.
 */

ulong
bcm_strtoul(char *cp, char **endp, uint base)
{
    ulong result, last_result = 0, value;
    bool minus;

    minus = FALSE;

    while (bcm_isspace(*cp))
        cp++;

    if (cp[0] == '+')
        cp++;
    else if (cp[0] == '-') {
        minus = TRUE;
        cp++;
    }

    if (base == 0) {
        if (cp[0] == '0') {
            if ((cp[1] == 'x') || (cp[1] == 'X')) {
                base = 16;
                cp = &cp[2];
            } else {
                base = 8;
                cp = &cp[1];
            }
        } else
            base = 10;
    } else if (base == 16 && (cp[0] == '0') && ((cp[1] == 'x') || (cp[1] == 'X'))) {
        cp = &cp[2];
    }

    result = 0;

    while (bcm_isxdigit(*cp) &&
           (value = bcm_isdigit(*cp) ? *cp-'0' : bcm_toupper(*cp)-'A'+10) < base) {
        result = result*base + value;
        /* Detected overflow */
        if (result < last_result && !minus)
            return ((unsigned long) -1);
        last_result = result;
        cp++;
    }

    if (minus)
        result = (ulong)(result * -1);

    if (endp)
        *endp = (char *)cp;

    return (result);
}

int
bcm_atoi(char *s)
{
    return (int)bcm_strtoul(s, NULL, 10);
}

/* parse a xx:xx:xx:xx:xx:xx format ethernet address */
int
bcm_ether_atoe(char *p, struct ether_addr *ea)
{
    int i = 0;

    for (;;) {
        ea->octet[i++] = (char)bcm_strtoul(p, &p, 16);
        if (!*p++ || i == 6)
            break;
    }

    return (i == 6);
}

char *
bcm_ether_ntoa(const struct ether_addr *ea, char *buf)
{
    static const char template[] = "%02x:%02x:%02x:%02x:%02x:%02x";
    snprintf(buf, 18, template,
        ea->octet[0]&0xff, ea->octet[1]&0xff, ea->octet[2]&0xff,
        ea->octet[3]&0xff, ea->octet[4]&0xff, ea->octet[5]&0xff);
    return (buf);
}

 
char *
getvar(char *vars, const char *name)
{
#ifdef  _MINOSL_
    return NULL;
#else
    char *s;
    int len;

    if (!name)
        return NULL;

    len = strlen(name);
    if (len == 0)
        return NULL;

    /* first look in vars[] */
    for (s = vars; s && *s;) {
        if ((bcmp(s, name, len) == 0) && (s[len] == '='))
            return (&s[len+1]);

        while (*s++)
            ;
    }

    /* then query env device */
    return (char *)(env_getenv(name));
#endif  /* _MINOSL_ */
}

/*
 * Search the vars for a specific one and return its value as
 * an integer. Returns 0 if not found.
 */
int
getintvar(char *vars, const char *name)
{
#ifdef  _MINOSL_
    return 0;
#else
    char *val;

    if ((val = getvar(vars, name)) == NULL)
        return (0);

    return (bcm_strtoul(val, NULL, 0));
#endif  /* _MINOSL_ */
}

#if defined(BCMDBG)
/* pretty hex print a contiguous buffer */
void
prhex(const char *msg, uchar *buf, uint nbytes)
{
    char line[128], *p;
    uint i;

    if (msg && (msg[0] != '\0'))
        printf("%s:\n", msg);

    p = line;
    for (i = 0; i < nbytes; i++) {
        if (i % 16 == 0) {
            p += sprintf(p, "  %04d: ", i); /* line prefix */
        }
        p += sprintf(p, "%02x ", buf[i]);
        if (i % 16 == 15) {
            printf("%s\n", line);       /* flush line */
            p = line;
        }
    }

    /* flush last partial line */
    if (p != line)
        printf("%s\n", line);
}
#endif

/* Initialization of bcmstrbuf structure */
void
bcm_binit(struct bcmstrbuf *b, char *buf, uint size)
{
    b->origsize = b->size = size;
    b->origbuf = b->buf = buf;
}

