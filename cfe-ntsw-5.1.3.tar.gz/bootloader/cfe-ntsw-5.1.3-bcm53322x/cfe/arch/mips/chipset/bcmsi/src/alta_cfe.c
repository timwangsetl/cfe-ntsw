/*
 * $Id: alta_cfe.c,v 1.2 2009/02/25 02:38:33 kliao Exp $
 * $Copyright: (c) 2009 Broadcom Corp.
 * All Rights Reserved.$
 *
 */
#include "cfe.h"
#include "typedefs.h"
#include "alta_osl.h"
#include "bcmdevs.h"
#include "hndsoc.h"
#include "cpu_config.h"
#include "sbmips32.h"
#include "exception.h"
#include "cfe_irq.h"

static ALTA_OSL_ISR alta_osl_user_isr[6] = {
    NULL, NULL, NULL, NULL, NULL, NULL, 
};

#define HAL_INTERRUPT_ACKNOWLEDGE( _vector_ )   \
{                                               \
    uint32 __vector = _vector_;                 \
    if (__vector >= 6) {                        \
        __vector = 0;                           \
    }                                           \
    asm volatile (                              \
        "mfc0   $3,$13\n"                       \
        "la     $2,0x00000400\n"                \
        "sllv   $2,$2,%0\n"                     \
        "nor    $2,$2,$0\n"                     \
        "and    $3,$3,$2\n"                     \
        "mtc0   $3,$13\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        "nop; nop; nop\n"                       \
        :                                       \
        : "r"(__vector)                         \
        : "$2", "$3"                            \
        );                                      \
}

int
alta_osl_find_chip(DEV_MATCH_FUNC func)
{
    if (func == NULL) {
        return -1;
    }
    
    /* XXX: scan PCI */
    (*func)(VENDOR_BROADCOM, ALTA_CORE_ID, AI_ALTA_BASE);
    
    return 0;
}

static void
alta_osl_isr(int ip)
{
    if (ip < 2 || ip > 7) {
        return;
    }
    ip -= 2;
    if (alta_osl_user_isr[ip]) {
        (*alta_osl_user_isr[ip])(ip);
    }
}

int
alta_osl_interrupt_connect(int irq, ALTA_OSL_ISR isr)
{
    if (irq < 0 || irq > 5) {
        return -1;
    }
    
    alta_osl_user_isr[irq] = isr;
    cfe_irq_setvector(irq + 2, alta_osl_isr);
	return 0;
}

void
alta_osl_interrupt_mask(int irq)
{
	uint32_t sr;

	sr = cfe_irq_disable();
	sr &= ~_MM_MAKEMASK1(S_SR_IMMASK + irq + 2);
	cfe_irq_enable(sr);
}

void
alta_osl_interrupt_unmask(int irq)
{
	uint32_t sr;

	sr = cfe_irq_disable();
	sr |= _MM_MAKEMASK1(S_SR_IMMASK + irq + 2);
	cfe_irq_enable(sr);
}

void
alta_osl_interrupt_acknowledge(int irq)
{
    HAL_INTERRUPT_ACKNOWLEDGE(irq);
}

