/*
 * HND SiliconBackplane MIPS core software interface.
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: hndmips.h,v 1.2 2009/02/25 02:36:28 kliao Exp $
 */

#ifndef _hndmips_h_
#define _hndmips_h_

extern void si_mips_init(si_t *sih, uint shirq_map_base);

#endif /* _hndmips_h_ */

