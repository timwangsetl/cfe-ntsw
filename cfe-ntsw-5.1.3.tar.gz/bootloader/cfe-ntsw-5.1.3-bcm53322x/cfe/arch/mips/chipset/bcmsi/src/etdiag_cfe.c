/*
 * CFE polled-mode device driver for
 * Broadcom BCM47XX 10/100 Mbps Ethernet Controller
 *
 * $Copyright (C) 2003 Broadcom Corporation$
 *
 * $Id: etdiag_cfe.c,v 1.7 2009/04/15 12:52:46 kliao Exp $
 */

#include "cfe.h"
#include "ui_command.h"
#include <typedefs.h>
#include <osl.h>
#include <ethernet.h>
#include <bcmenetrxh.h>
#include <et_dbg.h>
#include <etc.h>
#include <etcgmac.h>

extern int socdiag_addcmd(
               char *command,
               int (*func)(ui_cmdline_t *,int argc,char *argv[]),
               void *ref,
               char *help,
               char *usage,
               char *switches
               );

int ui_cmd_etdiag(etc_info_t * etc, ui_cmdline_t *cmdline, int argc, char *argv[]);
static void cfp_entry_init(etc_info_t * etc, uint l3_fram, uint slice_id, void *arg);
static int cfp_check_result(etc_info_t * etc, int expect);
static void etdiag_send_packet(etc_info_t * etc, uchar *tx_buf, int len);


#define ET_DIAG_TEST_PACKET_LEN 72

#define PACKET_TYPE_IPV4_NONE_TAG    0
#define PACKET_TYPE_IPV4_SINGLE_TAG    1
#define PACKET_TYPE_IPV4_DOUBLE_TAG    2
#define PACKET_TYPE_IPV6_NONE_TAG    3
#define PACKET_TYPE_IPV6_SINGLE_TAG    4
#define PACKET_TYPE_IPV6_DOUBLE_TAG    5
#define PACKET_TYPE_NONIP_NONE_TAG    6
#define PACKET_TYPE_NONIP_SINGLE_TAG    7
#define PACKET_TYPE_NONIP_DOUBLE_TAG    8
#define PACKET_TYPE_IPV4_UDP    9
#define PACKET_TYPE_IPV6_UDP    10
#define PACKET_TYPE_COUNT   11


/* Construct IPv4 packet */
uint8 pkt_pattern[PACKET_TYPE_COUNT][ET_DIAG_TEST_PACKET_LEN] = 
    {  /* IPV4 non-tagged packet pattern */
    {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x08, 0x00, 0x45, 0x00,
        0x00, 0x3a, 0x00, 0x00, 0x00, 0x00, 0x40, 0xff,
        0x79, 0xc6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* IPV4 single-tagged packet pattern */
      {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x81, 0x00, 0x00, 0x01,
        0x08, 0x00, 0x45, 0x00, 0x00, 0x3a, 0x00, 0x00,
        0x00, 0x00, 0x40, 0xff, 0x79, 0xc6, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* IPV4 double-tagged packet pattern */
      {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x88, 0xa8, 0x00, 0x02,
        0x81, 0x00, 0x00, 0x01, 0x08, 0x00, 0x45, 0x00,
        0x00, 0x3a, 0x00, 0x00, 0x00, 0x00, 0x40, 0xff,
        0x79, 0xc6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* IPV6 non-tagged packet pattern */
      {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x86, 0xdd, 0x60, 0x30,
        0x00, 0x00, 0x00, 0x12, 0x3b, 0xff, 0xfe, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x10,
        0x18, 0xff, 0xfe, 0x53, 0x00, 0x05, 0x35, 0x55,
        0x55, 0x55, 0x66, 0x66, 0x66, 0x66, 0x77, 0x77,
        0x77, 0x77, 0x88, 0x88, 0x88, 0x88, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* IPV6 single-tagged packet pattern */
      {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x81, 0x00, 0x00, 0x01,
        0x86, 0xdd, 0x60, 0x30, 0x00, 0x00, 0x00, 0x12,
        0x3b, 0xff, 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x02, 0x10, 0x18, 0xff, 0xfe, 0x53,
        0x00, 0x05, 0x35, 0x55, 0x55, 0x55, 0x66, 0x66,
        0x66, 0x66, 0x77, 0x77, 0x77, 0x77, 0x88, 0x88,
        0x88, 0x88, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* IPV6 double-tagged packet pattern */
      {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x88, 0xa8, 0x00, 0x02,
        0x81, 0x00, 0x00, 0x01, 0x86, 0xdd, 0x60, 0x30, 
        0x00, 0x00, 0x00, 0x12, 0x3b, 0xff, 0xfe, 0x80, 
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x10, 
        0x18, 0xff, 0xfe, 0x53, 0x00, 0x05, 0x35, 0x55, 
        0x55, 0x55, 0x66, 0x66, 0x66, 0x66, 0x77, 0x77, 
        0x77, 0x77, 0x88, 0x88, 0x88, 0x88, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* NONIP non-tagged packet pattern */
    {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x08, 0x01, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* NONIP single-tagged packet pattern */
    {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x81, 0x00, 0x00, 0x01, 
        0x08, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* NONIP double-tagged packet pattern */
    {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x88, 0xa8, 0x00, 0x02, 
        0x81, 0x00, 0x00, 0x01, 0x08, 0x01, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* IPV4 UDP packet pattern*/
     {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x08, 0x00, 0x45, 0x00,
        0x00, 0x3a, 0x00, 0x00, 0x00, 0x00, 0x40, 0x11,
        0x64, 0xaf, 0x0a, 0x01, 0x01, 0x02, 0x0a, 0x01,
        0x01, 0x01, 0x00, 0x3f, 0x00, 0x3f, 0x00, 0x26,
        0xe9, 0x1f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        /* IPV6 UDP packet pattern */
      {0x00, 0x01, 0x02, 0x03, 0x04, 0x5, 0x00, 0x10, 
        0x18, 0x53, 0x00, 0x05, 0x86, 0xdd, 0x60, 0x30,
        0x00, 0x00, 0x00, 0x12, 0x11, 0xff, 0xfe, 0x80,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x10,
        0x18, 0xff, 0xfe, 0x53, 0x00, 0x05, 0x35, 0x55,
        0x55, 0x55, 0x66, 0x66, 0x66, 0x66, 0x77, 0x77,
        0x77, 0x77, 0x88, 0x88, 0x88, 0x88, 0x00, 0x3f,
        0x00, 0x3f, 0x00, 0x12, 0x8f, 0xec, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
    };

static uchar txbuf[ET_DIAG_TEST_PACKET_LEN];
/* Constrcut IPv6 packet */


/* Construct NonIP packet */


#define SET_CFP_FIELD_PARAM(fld_idx, fld_val, ram, l3_fram, s_id, buf_ptr) { \
    buf_ptr->field_idx = fld_idx; buf_ptr->field_value = fld_val; \
    buf_ptr->ram_type = ram; buf_ptr->l3_framing = l3_fram; \
    buf_ptr->slice_id = s_id;}

static int
etdiag_txrx(etc_info_t * etc)
{
    void *p;
    char *x;
    int i, len;

    /* Set environment, loopback, initialized, up */
    etc->loopbk = 1;
    etc_up(etc);


    /* 1. transmit packets with length 64*/
    if (!(p = PKTGET(NULL, 64, TRUE, etc->pkt_mem))) {
        ET_ERROR(("et%d: PKTGET failed\n", etc->unit));
        return CFE_ERR_NOMEM;
    }

    x = (char *)PKTDATA(NULL, p);
    /* Fix the MAC DA */
    for (i = 0; i < 64; i++) {
        *(x + i) = i;
    }
    

    ET_PRHDR("tx", (struct ether_header *) PKTDATA(NULL, p), PKTLEN(NULL, p), etc->unit);
    ET_PRPKT("txpkt", PKTDATA(NULL, p), PKTLEN(NULL, p), etc->unit);

    ASSERT(*etc->txavail[TX_Q0] > 0);

    /* transmit the frame */
    etc->chops->tx(etc->ch, p);

    /* wait for frame to complete */
    while (!(etc->chops->getintrevents(etc->ch, FALSE) & INTR_TX));

    /* reclaim any completed tx frames */
    etc->chops->txreclaim(etc->ch, FALSE);

    /* Check rx packets */
    if (!(p = etc->chops->rx(etc->ch))) {
        /* post more rx bufs */
        etc->chops->rxfill(etc->ch);
        etc->loopbk = 0;
        etc_up(etc);
        return 1;
    }


    /* strip off rxhdr */
    PKTPULL(NULL, p, HWRXOFF);

    len = PKTLEN(NULL, p) - 4; /* strip off CRC */
    x = (char *)PKTDATA(NULL, p);
    xprintf("Received packets :\n");
    for (i=0; i<len; i++) {
        xprintf("0x%02x ", *(x + i));
        if ((i % 16) ==  15) {
            xprintf("\n");
        }
    }

    /* free packet */
    PKTFREE(NULL, p, FALSE, etc->pkt_mem);

    etc->loopbk = 0;
    etc_up(etc);
    return 0;
}

static int
cfp_check_result(etc_info_t * etc, int expect)
{
    int len;
    int i, events;
    void *p;
    uchar *data_ptr;
    int pass = 0;

    /* Delay */
    for (i=0; i < 10000; i++) {
        ;
    }
    
    events = etc->chops->getintrevents(etc->ch, FALSE);
    if (events & INTR_RX) {
        /* get packet */
        if (!(p = etc->chops->rx(etc->ch))) {
            /* post more rx bufs */
            etc->chops->rxfill(etc->ch);
            if (!expect) {
                pass = 1;
            }
            goto result;
        }

        /* strip off rxhdr */
        PKTPULL(NULL, p, HWRXOFF);

        len = PKTLEN(NULL, p) - 4; /* strip off CRC */
        data_ptr = (uchar *)PKTDATA(NULL, p);
        for (i=0; i<len; i++) {
            xprintf("0x%02x ", *(data_ptr + i));
            if ((i % 16) ==  15) {
                xprintf("\n");
            }
        }
        xprintf("\n");
        if (expect) {
            pass = 1;
        }

        /* free packet */
        PKTFREE(NULL, p, FALSE, etc->pkt_mem);
    }else {
        if (!expect) {
            pass = 1;
        }
    }

    printf("rx_drop = 0x%x\n", (*(uint *)0xb80023f8));

    xprintf("**************************\n");


result:
    /* post more rx bufs */
    etc->chops->rxfill(etc->ch);
    
    if (pass) {
        xprintf("This test case is pass.\n");
        xprintf("*********************************************************************\n");
        xprintf("\n");
        return 0;
    }

    xprintf("This test case is failed.\n");
    xprintf("*********************************************************************\n");
    xprintf("\n");
    return -1;
    
}

/* Construct a valid entry with drop action */
static void
cfp_entry_init(etc_info_t * etc, uint l3_fram, uint slice_id, void *arg)
{
    int i;
    cfp_ioctl_buf_t *cfp_buf_ptr;

    cfp_buf_ptr = (cfp_ioctl_buf_t *)arg;

    for (i=0; i < 8; i++) {
        cfp_buf_ptr->cfp_entry.tcam[i] = 0;
        cfp_buf_ptr->cfp_entry.tcam_mask[i] = 0;
    }
    cfp_buf_ptr->cfp_entry.action= 0;

    /* Create valid entry and drop action */
    cfp_buf_ptr->entry_idx = 0;
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_VALID, 3, CFP_RAM_TYPE_TCAM, 
        CFP_L3_FRAMING_IPV4, slice_id, cfp_buf_ptr);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buf_ptr));

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_VALID, 3, CFP_RAM_TYPE_TCAM_MASK, 
        CFP_L3_FRAMING_IPV4, slice_id, cfp_buf_ptr);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buf_ptr));

    /* Configure the L3 Framming value */
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_L3_FRAMING, l3_fram, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_id, cfp_buf_ptr);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buf_ptr));
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_L3_FRAMING, 0x3, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, slice_id, cfp_buf_ptr);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buf_ptr));

    /* set slice id */
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_SLICE_ID, slice_id, 
            CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_id, cfp_buf_ptr);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buf_ptr));
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_SLICE_ID, 3, 
            CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, slice_id, cfp_buf_ptr);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buf_ptr));

    SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_DROP, 1, CFP_RAM_TYPE_ACTION, 
        CFP_L3_FRAMING_IPV4, slice_id, cfp_buf_ptr);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buf_ptr));
    
}


static void
etdiag_send_packet(etc_info_t * etc, uchar *tx_buf, int len)
{
    uchar *data_ptr;
    void *p;

    if (!(p = PKTGET(NULL, 76, TRUE, etc->pkt_mem))) {
        ET_ERROR(("et%d: PKTGET failed\n", etc->unit));
        return;
    }
    data_ptr= PKTDATA(NULL, p);

    bcopy(tx_buf, data_ptr, len);
    
    /* transmit the frame */
    etc->chops->tx(etc->ch, p);

    /* wait for frame to complete */
    while (!(etc->chops->getintrevents(etc->ch, FALSE) & INTR_TX));

    /* reclaim any completed tx frames */
    etc->chops->txreclaim(etc->ch, FALSE);
}

static int
etdiag_cfp_com_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int fail = 0;

    printf("COMMON FIELD : Valid Field Test\n");
    /* write a default drop entry */
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));   
    

    /* Construct the tx packet */
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);

    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 0) != 0) {
        fail = 1;
    }

    printf("COMMON FIELD : Port BitMap Field Test\n");
    /* CHECK ME */
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_SRC_PMAP, 0x1 << etc->unit, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    printf("unit = %d\n",etc->unit);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_SRC_PMAP, 0xff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

    /* Write the raw data to chip */
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 0) != 0) {
        fail = 1;
    }

    /* tpid = 0x88a8 is default */
    printf("COMMON FIELD : S-tag Status Field Test\n");
    printf("Drop the packet with Stag and VID !=0\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_S_TAGGED, 3, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_S_TAGGED, 3, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send packet without Stag and Ctag \n");

    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 1) != 0) {
        fail = 1;
    }
    printf("Send packet with Stag = 2 and Ctag = 1 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_DOUBLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 0) != 0) {
        fail = 1;
    }

    printf("COMMON FIELD : C-tag Status Field Test\n");
    printf("Drop the packet with Ctag and VID !=0\n");

    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_C_TAGGED, 3, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_C_TAGGED, 3, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send packet without Ctag \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 1) != 0) {
        fail = 1;
    }

    printf("Send packet with Ctag and VID = 1 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_SINGLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 0) != 0) {
        fail = 1;
    }


    printf("COMMON FIELD : L2 Framming Field Test\n");
    printf("Drop the DIXv2 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_L2_FRAMING, 0, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_L2_FRAMING, 3, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

    
    printf("Send packet with ethertype < 1500 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[12] = 0x05;
    txbuf[13] = 0x00;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
        fail = 1;
    }
    
    printf("Send packet with ethertype > 1500 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    
    if (cfp_check_result(etc, 0) != 0) {
        fail = 1;
    }

    printf("COMMON FIELD : L3 Framming Field Test\n");
    printf("Drop the IPv4 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_L3_FRAMING, 0, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_L3_FRAMING, 3, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send IPV4 packet \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    return fail;
    
}


static int
etdiag_cfp_nonip_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int fail = 0;
    
    printf("NONIP SLICE : ETHERTYPE Field Test\n");
    printf("Drop the packet with the EtherType = 0x0801\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_ETHERTYPE_SAP, 0x801, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_ETHERTYPE_SAP, 0xffff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IPV4 packet, ethertype = 0x0800 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send packet with ethertype = 0x801 \n");
    bcopy(pkt_pattern[PACKET_TYPE_NONIP_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[12] = 0x08;
    txbuf[13] = 0x01;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }
    

    printf("NONIP SLICE : C-TAG Field Test\n");
    printf("Drop the packet with the ctag = 0x8100 0x0002\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_CTAG, 0x0002, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_CTAG, 0xffff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send  NONIP packet with Ctag = 0x0001\n");
    bcopy(pkt_pattern[PACKET_TYPE_NONIP_SINGLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send  NONIP packet with Ctag = 0x0002\n");
    bcopy(pkt_pattern[PACKET_TYPE_NONIP_SINGLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[14] = 0x00;
    txbuf[15] = 0x02;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }
    
    printf("NONIP SLICE : S-TAG Field Test\n");
    printf("Drop the packet with the stag = 0x88a8 0x0002\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_STAG, 0x0002, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_STAG, 0xffff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_NONIP, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send NONIP packet with Stag = 0x0003\n");
    bcopy(pkt_pattern[PACKET_TYPE_NONIP_DOUBLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[14] = 0x00;
    txbuf[15] = 0x03;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send NONIP packet with Stag = 0x0002\n");
    bcopy(pkt_pattern[PACKET_TYPE_NONIP_DOUBLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    return fail;

}

static int
etdiag_cfp_nonip_udf_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int slice_idx, i;
    int fail= 0;

    printf("NONIP SLICE : UDF Field Test\n");

    printf("User offset base is Start of Frame\n");
    for (slice_idx = 0; slice_idx < 3; slice_idx++) {
        for (i=0; i < 9; i++) {
            cfp_entry_init(etc, CFP_L3_FRAMING_NONIP, slice_idx, cfp_buffer);
            /* Configure UDF first */
            printf("Configure the offset value is 12 for slice id %d UDF %d\n", slice_idx, i);
            cfp_buffer->field_idx = i; /* UDF index */
            cfp_buffer->l3_framing = CFP_L3_FRAMING_NONIP;
            cfp_buffer->slice_id= slice_idx;
            cfp_buffer->field_value = 0xc;
            cfp_buffer->flags = CFP_UDF_OFFSET_BASE_STARTOFFRAME;
            etc_ioctl(etc, ETCCFPUDFWR, HSADDR2PTR(cfp_buffer));

            printf("Configure the UDF value is 0x1234 to Drop \n");
            /* UDF value */
            SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_UDF0 + i, 0x1234, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_NONIP, slice_idx, cfp_buffer)
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            
            SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_UDF0 + i, 0xffff, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_NONIP, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

            /* UDF valid bit */
            SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_NONIP, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_NONIP, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

            printf("Send NONIP packet with offset 12 is 0x0801\n");
            bcopy(pkt_pattern[PACKET_TYPE_NONIP_NONE_TAG], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            txbuf[12] = 0x11;
            txbuf[13] = 0x22;
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 1) != 0) {
                fail = 1;
            }

            printf("Configure the UDF value is 0x0801 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_NONIP_UDF0 + i, 0x1122, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_NONIP, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
            
            printf("Send NONIP packet with offset 12 is 0x801\n");
            bcopy(pkt_pattern[PACKET_TYPE_NONIP_NONE_TAG], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            txbuf[12] = 0x11;
            txbuf[13] = 0x22;
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 0) != 0) {
                fail = 1;
            }

        }
    }
    return fail;
}

static int
etdiag_cfp_ipv4_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int fail = 0;
    
    printf("IPV4 SLICE : IP TOS Field Test\n");
    printf("Drop the IP TOS = 1 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_TOS, 0x01, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_TOS, 0xff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IPV4 packet TOS = 0 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV4 packet TOS = 1 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[15] = 0x01;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    printf("IPV4 SLICE : IP Protocol Field Test\n");
    printf("Drop the IP protocol = 06(TCP) packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_PROTO, 0x06, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_PROTO, 0xff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IPV4 packet protocol = 0x11 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV4 packet protocol = 06 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[23] = 0x06;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    printf("IPV4 SLICE : IP Fragmented Field Test\n");
    printf("Drop the IP fragmented packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IP  non-fragmented packet  \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IP fragmented packet \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[20] = 0x20;
    txbuf[24] = 0x44;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    printf("Drop Non-first Framgmented packet\n");
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_NON_FIRST_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_NON_FIRST_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

    printf("Send IP fragmented packet \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[20] = 0x20;
    txbuf[24] = 0x44;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IP non-first fragmented packet \n");
    txbuf[20] = 0x20;
    txbuf[21] = 0x40;
    txbuf[24] = 0x44;
    txbuf[25] = 0x6f;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    printf("IPV4 SLICE : IP AUTH Field Test\n");
    printf("Drop the IP AUTH protocol = 51 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_AUTH, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_IP_AUTH, 0x1, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IP packet protocol = 17 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV4 packet protocol = 51 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[23] = 0x33;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }


    printf("IPV4 SLICE : IP TTL Field Test\n");
    printf("Drop the IP TTL = 1 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);

    cfp_buffer->ram_type = CFP_RAM_TYPE_TCAM;
    cfp_buffer->field_idx = CFP_FIELD_IPV4_TTL_RANGE;
    cfp_buffer->field_value = 0x1;
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_TTL_RANGE, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_TTL_RANGE, 0x3, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IP packet TTL=64 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV4 packet TTL= 1 \n");bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[22] = 0x1;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }


    printf("IPV4 SLICE : C-tag Field Test\n");
    printf("Drop the packet with the ctag = 0x8100 0x0002\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_CTAG, 0x0002, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_CTAG, 0xffff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send  IPv4 packet with Ctag = 0x0001\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_SINGLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send IPv4 packet with Ctag = 0x0002\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_SINGLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[14] = 0x00;
    txbuf[15] = 0x02;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }
    

    printf("IPV4 SLICE : S-tag Field Test\n");
    printf("Drop the packet with the stag = 0x88a8 0x0002\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_STAG, 0x0002, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_STAG, 0xffff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send IPv4 packet with Stag = 0x0001\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_DOUBLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[14] = 0x00;
    txbuf[15] = 0x01;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send  IPv4 packet with Stag = 0x0002\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV4_DOUBLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    return fail;
}

static int
etdiag_cfp_ipv4_udf_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int slice_idx, i;
    int fail = 0;
    
    printf("IPV4 SLICE : UDF Field Test\n");

    printf("User offset base is end of L2\n");
    for (slice_idx = 0; slice_idx < 3; slice_idx++) {
        for (i=0; i < 9; i++) {
            cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            /* Configure UDF offset first */
            printf("Configure the offset value is 12 for slice id %d UDF %d\n", slice_idx, i);
            cfp_buffer->field_idx = i;
            cfp_buffer->slice_id= slice_idx;
            cfp_buffer->l3_framing = CFP_L3_FRAMING_IPV4;
            cfp_buffer->field_value = 12;
            cfp_buffer->flags = CFP_UDF_OFFSET_BASE_ENDOFL2;
            etc_ioctl(etc, ETCCFPUDFWR, HSADDR2PTR(cfp_buffer));

            /* UDF value */
            printf("Configure the UDF value is 0x0a00 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0 + i, 0x0a00, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0 + i, 0xffff, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

            /* UDF valid Bit */
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

            printf("Send  IPv4 packet with offset 12 is 0x0a01\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 1) != 0) {
                fail = 1;
            }
            
            printf("Configure the UDF value is 0xa01 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0 + i, 0x0a01, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
            
            printf("Send  IPv4 packet with offset 12 is 0x0a01\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 0) != 0) {
                fail = 1;
            }

        }
    }
    

    printf("User offset base is end of L3\n");
    for (slice_idx = 0; slice_idx < 1; slice_idx++) {
        for (i=0; i < 1; i++) {
            cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer); 
            /* Configure UDF first */
            printf("Configure the offset value is 2 for slice id %d UDF %d\n", slice_idx, i);
            cfp_buffer->field_idx = i;
            cfp_buffer->slice_id= slice_idx;
            cfp_buffer->l3_framing = CFP_L3_FRAMING_IPV4;
            cfp_buffer->field_value = 2;
            cfp_buffer->flags = CFP_UDF_OFFSET_BASE_ENDOFL3;
            etc_ioctl(etc, ETCCFPUDFWR, HSADDR2PTR(cfp_buffer));

            printf("Configure the UDF value is 0x0040 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0 + i, 0x0040, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0 + i, 0xffff, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

            /* UDF valid bit */
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

            printf("Send  IPv4 packet with offset 2 is 0x003f\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 1) != 0) {
                fail = 1;
            }
            
            printf("Configure the UDF value is 0x003f to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_UDF0 + i, 0x003f, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV4, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
            printf("Send  IPv4 packet with offset 2 is 0x003f\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV4_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 0) != 0) {
                fail = 1;
            }

        }
    }

    return fail;
}

static int
etdiag_cfp_ipv6_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int fail = 0;
    
    printf("IPV6 SLICE : Traffic Class Field Test\n");
    printf("Drop the IP TrafficClass = 1 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_TOS, 0x01, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_TOS, 0xff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send IPV6 packet TrafficClass= 3 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV6 packet TrafficClass = 1 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[15] = 0x10;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    printf("IPV6 SLICE : Next Header Field Test\n");
    printf("Drop the IP NextHeader = 06 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_PROTO, 0x06, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_PROTO, 0xff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IPV6 packet protocol = 17 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send IPV6 packet NextHeader = 06 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[20] = 0x06;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }


    printf("IPV6 SLICE : IP Fragmented Field Test\n");
    printf("Drop the IP fragmented packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send IPV6  non-fragmented packet  \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV6 fragmented packet \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[20] = 0x2c;
    txbuf[54] = 0x11;
    txbuf[55] = 0x1e;
    txbuf[56] = 0x02;
    txbuf[57] = 0x27;
    txbuf[58] = 0x11;
    txbuf[59] = 0x11;
    txbuf[60] = 0x22;
    txbuf[61] = 0x22;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }
    
    printf("Drop Non-first Framgmented packet\n");
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_NON_FIRST_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV4_NON_FIRST_FRAG, 0x1, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

    printf("Send IPv6 non-first fragmented packet \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[20] = 0x2c;
    txbuf[54] = 0x11;
    txbuf[55] = 0x1e;
    txbuf[56] = 0x02;
    txbuf[57] = 0x27;
    txbuf[58] = 0x11;
    txbuf[59] = 0x11;
    txbuf[60] = 0x22;
    txbuf[61] = 0x22;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }


    printf("IPV6 SLICE : IP AUTH Field Test\n");
    printf("Drop the IP AUTH protocol = 51 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_AUTH, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_IP_AUTH, 0x1, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send IPv6 packet protocol = 17 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV6 packet protocol = 51 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[19] = 0x18;
    txbuf[20] = 0x33;
    txbuf[54] = 0x11;
    txbuf[55] = 0x02;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    printf("IPV6 SLICE : IP HopLimit Field Test\n");
    printf("Drop the IP HopLimit = 1 packet\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);

    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_HOPLIMIT_RANGE, 0x1, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_HOPLIMIT_RANGE, 0x3, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send IPV6 packet HopLimit=255 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Send IPV6 packet HopLimit= 1 \n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[21] = 0x1;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }


    printf("IPV6 SLICE : C-tag Field Test\n");
    printf("Drop the packet with the ctag = 0x8100 0x0002\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_CTAG, 0x0002, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_CTAG, 0xffff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send  IPv4 packet with Ctag = 0x0001\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_SINGLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send IPv6 packet with Ctag = 0x0002\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_SINGLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[15] = 0x02;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }
    

    printf("IPV6 SLICE : S-tag Field Test\n");
    printf("Drop the packet with the stag = 0x88a8 0x0002\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer); 
    
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_STAG, 0x0002, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_STAG, 0xffff, 
        CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    
    printf("Send IPv6 packet with Stag = 0x0001\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_DOUBLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    txbuf[15] = 0x01;
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }
    
    printf("Send  IPv6 packet with Stag = 0x0002\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_DOUBLE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    }

    return fail;
}

static int
etdiag_cfp_ipv6_udf_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int slice_idx, i;
    int fail = 0;
    
    printf("IPV6 SLICE : UDFField Test\n");

    printf("User offset base is end of L2\n");
    for (slice_idx = 0; slice_idx < 3; slice_idx++) {
        for (i=0; i < 9; i++) {
            cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer); 
            /* Configure UDF first */
            printf("Configure the offset value is 24 for slice id %d UDF %d\n", slice_idx, i);
            cfp_buffer->field_idx = i;
            cfp_buffer->slice_id= slice_idx;
            cfp_buffer->l3_framing = CFP_L3_FRAMING_IPV6;
            cfp_buffer->field_value = 24;
            cfp_buffer->flags = CFP_UDF_OFFSET_BASE_ENDOFL2;
            etc_ioctl(etc, ETCCFPUDFWR, HSADDR2PTR(cfp_buffer));

            printf("Configure the UDF value is 0x3554 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0 + i, 0x3554, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0 + i, 0xffff, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

            /* UDF Valid bit */
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0_VLD + i, 0x1, 
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

            printf("Send IPv6 packet with offset 24 is 0x3555\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 1) != 0) {
                fail = 1;
            }
            
            printf("Configure the UDF value is 0x3555 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0 + i, 0x3555, 
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

            printf("Send IPv6 packet with offset 24 is 0x3555\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 0) != 0) {
                fail = 1;
            }
        }
    }
    

    printf("User offset base is end of L3\n");
    for (slice_idx = 0; slice_idx < 3; slice_idx++) {
        for (i=0; i < 9; i++) {
            cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer); 
            /* Configure UDF first */
            printf("Configure the offset value is 6 for slice id %d UDF %d\n", slice_idx, i);
            cfp_buffer->field_idx = i;
            cfp_buffer->slice_id= slice_idx;
            cfp_buffer->l3_framing = CFP_L3_FRAMING_IPV6;
            cfp_buffer->field_value = 6;
            cfp_buffer->flags = CFP_UDF_OFFSET_BASE_ENDOFL3;
            etc_ioctl(etc, ETCCFPUDFWR, HSADDR2PTR(cfp_buffer));

            printf("Configure the UDF value is 0x4443 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0 + i, 0x4443,
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0 + i, 0xffff,
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

            /* UDF valid bit */
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0_VLD + i, 0x1,
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0_VLD + i, 0x1,
                CFP_RAM_TYPE_TCAM_MASK, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
            
            printf("Send IPv6 packet with offset 6 is 0x4444\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            txbuf[54] = 0x11;
            txbuf[55] = 0x11;
            txbuf[56] = 0x22;
            txbuf[57] = 0x22;
            txbuf[58] = 0x33;
            txbuf[59] = 0x33;
            txbuf[60] = 0x44;
            txbuf[61] = 0x44;
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 1) != 0) {
                fail = 1;
            }
            
            printf("Configure the UDF value is 0x4444 to Drop \n");
            SET_CFP_FIELD_PARAM(CFP_FIELD_IPV6_UDF0 + i, 0x4444,
                CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, slice_idx, cfp_buffer);
            etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
            etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

            printf("Send IPv6 packet with offset 6 is 0x4444\n");
            bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
                ET_DIAG_TEST_PACKET_LEN);
            txbuf[54] = 0x11;
            txbuf[55] = 0x11;
            txbuf[56] = 0x22;
            txbuf[57] = 0x22;
            txbuf[58] = 0x33;
            txbuf[59] = 0x33;
            txbuf[60] = 0x44;
            txbuf[61] = 0x44;
            etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);
            if (cfp_check_result(etc, 0) != 0) {
                fail = 1;
            }

        }
    }

    return fail;
}

static int
etdiag_cfp_action_fields_tests(etc_info_t * etc, cfp_ioctl_buf_t *cfp_buffer)
{
    int i;
    int fail = 0;

    /* Rx channel ID */
    printf("ACTION : RX channel ID\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 0, cfp_buffer); 

    /* Remove drop action */
    SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_DROP, 0x0, 
        CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

    bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    
    for (i=0; i < NUMRXQ; i++) {
        printf("Set the Rx chhanel ID = %d\n", i);
        SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_RX_CHANNEL_ID, i, 
            CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV4, 0, cfp_buffer);
        etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
        etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

        etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

        /* CHECK ME : rx channel id */
        if (cfp_check_result(etc, 1) != 0) {
            fail = 1;
        }
    }
    
    /* classification ID */
    printf("ACTION : Classification ID\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV4, 1, cfp_buffer); 

    /* Remove drop action */
    SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_DROP, 0x0, 
        CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV4, 1, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

    for (i=1; i < 256; i++) {
        printf("Set the Classification ID = %d\n", i);
        SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_CLASSFICATION_ID, i, 
            CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV4, 1, cfp_buffer);
        etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
        etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

        bcopy(pkt_pattern[PACKET_TYPE_IPV4_NONE_TAG], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
        etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

        /* CHECK ME : classification */
        if (cfp_check_result(etc, 1) != 0) {
            fail = 1;
        }
    }  

    /* Chain action */
    printf("ACTION : Chain action\n");
    /* Create IPv6 slice 0 */
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 0, cfp_buffer); 
    
    /* Remove drop action */
    SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_DROP, 0x0, 
        CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

    /* set chain id */
    SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_CHAIN_ID, 123, 
        CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV6, 0, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

    printf("Create Chain entry with chain id 123 and no field action\n");
    cfp_entry_init(etc, CFP_L3_FRAMING_IPV6, 3, cfp_buffer);    
    /* Create Chain Slice 3 */
    cfp_buffer->entry_idx = 1;
    
    /* Chain ID */
    SET_CFP_FIELD_PARAM(CFP_FIELD_CHAIN_CHAIN_ID, 123, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 3, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    SET_CFP_FIELD_PARAM(CFP_FIELD_CHAIN_CHAIN_ID, 0xff, 
        CFP_RAM_TYPE_TCAM, CFP_L3_FRAMING_IPV6, 3, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));

    /* Remove drop action */
    SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_DROP, 0, 
        CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV6, 3, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));

    printf("Send IPv6 packets expect not to Drop\n");
    bcopy(pkt_pattern[PACKET_TYPE_IPV6_UDP], txbuf, 
        ET_DIAG_TEST_PACKET_LEN);
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 1) != 0) {
       fail = 1;
    }

    printf("Add Drop action on chain entry\n");
    SET_CFP_FIELD_PARAM(CFP_FIELD_ACT_DROP, 1, 
        CFP_RAM_TYPE_ACTION, CFP_L3_FRAMING_IPV6, 3, cfp_buffer);
    etc_ioctl(etc, ETCCFPFIELDWR, HSADDR2PTR(cfp_buffer));
    etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
    printf("Send IPv6 packets expect to Drop\n");
    etdiag_send_packet(etc, &txbuf[0], ET_DIAG_TEST_PACKET_LEN);

    if (cfp_check_result(etc, 0) != 0) {
       fail = 1;
    } 

    return fail;
}

static int
etdiag_cfp(etc_info_t * etc)
{
     cfp_ioctl_buf_t *cfp_buffer;
     int fail = 0;

     /* Environment initialization */
     /* a. open device */
     etc->loopbk = 1;
     etc_up(etc);

    
    if (!(cfp_buffer = (cfp_ioctl_buf_t *)KMALLOC(sizeof(cfp_ioctl_buf_t), 0))) {
        xprintf("Error : cfp buffer KMALLOC failed\n (eth0)\n");
        fail = 1;
        goto error;
    }

    /* Common fields tests */
    if (etdiag_cfp_com_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }

    /* NONIP fields tests */
    if (etdiag_cfp_nonip_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }   

    /* NONIP UDF fields tests */
    if (etdiag_cfp_nonip_udf_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }   

    /* IPV4 fields tests */
    if (etdiag_cfp_ipv4_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }

    /* IPV4 UDF fields tests */
    if (etdiag_cfp_ipv4_udf_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }

    /* IPV6 fields tests */
    if (etdiag_cfp_ipv6_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }

    /* IPV6 UDF fields tests */
    if (etdiag_cfp_ipv6_udf_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }    

    /* Action fields tests */
    if (etdiag_cfp_action_fields_tests(etc, cfp_buffer)) {
        fail = 1;
        goto error;
    }

error:
    /* clean up the used entry */
    
    if (cfp_buffer) {
        bzero(cfp_buffer, sizeof(cfp_ioctl_buf_t));
        cfp_buffer->entry_idx = 0;
        etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
        cfp_buffer->entry_idx = 1;
        etc_ioctl(etc, ETCCFPWR, HSADDR2PTR(cfp_buffer));
        KFREE(cfp_buffer);
    }
    etc->loopbk = 0;
    etc_down(etc, 0);

    return fail;
}


static int
etdiag_rate(etc_info_t * etc)
{
    uint tmp[3];
    int result = 0;

    /* Set channel 0 , pps = 100 */
    tmp[0] = 0;
    tmp[1] = 640;
    
    etc_ioctl(etc, ETCRXRATE, (void *)&tmp[0]);

    etc->chops->rxrateget(etc->ch, 0, &tmp[0]);
    if (tmp[0] != 640) {
        result = 1;
    }

    /* Set chan 1, rate 128000, burst 256 */
    tmp[0] = 1;
    tmp[1] = 128000;
    tmp[2] = 256;
    etc_ioctl(etc, ETCTXRATE, (void *)&tmp[0]);

    etc->chops->txrateget(etc->ch, 1, &tmp[0], &tmp[1]);
    if ((tmp[0] != 128000) ||(tmp[1] != 256)) {
        result = 1;
    }


    /* Recover */
    tmp[0] = 0;
    tmp[1] = 0;
    tmp[2] = 0;
    etc_ioctl(etc, ETCRXRATE, (void *)&tmp[0]);
    tmp[0] = 1;
    etc_ioctl(etc, ETCTXRATE, (void *)&tmp[0]);
    return result;
}

static int
etdiag_flowctrl(etc_info_t * etc)
{
    uint tmp[3];
    int result = 0;

    /* Set mode to mix mode */
    tmp[0] = FLOW_CTRL_MODE_MIX;
    etc_ioctl(etc, ETCFLOWCTRLMODE, (void *)&tmp[0]);

    etc->chops->flowctrlmodeget(etc->ch, &tmp[0]);
    if (tmp[0] != FLOW_CTRL_MODE_MIX) {
        return 1;
    }

    /* Set the on/off threshold of auto mode*/
    tmp[0] = 1500;
    tmp[1] = 2000;
    etc_ioctl(etc, ETCFLOWCTRLAUTOSET, (void *)&tmp[0]);

    etc->chops->flowctrlautoget(etc->ch, &tmp[0], &tmp[1]);
    if ((tmp[0] != 1500) ||(tmp[1] != 2000)) {
        result = 1;
    }

    /* Set the on/off threshold of auto mode*/
    tmp[0] = 1;
    etc_ioctl(etc, ETCFLOWCTRLCPUSET, (void *)&tmp[0]);

    etc->chops->flowctrlcpuget(etc->ch, &tmp[0]);
    if (tmp[0] == 0) {
        result = 1;
    }

    /* Set RX channel flow control, chan 0, on 4, off 6 */
    tmp[0] = 0;
    tmp[1] = 4;
    tmp[2] = 6;
    etc_ioctl(etc, ETCFLOWCTRLRXCHANSET, (void *)&tmp[0]);

    etc->chops->flowctrlrxchanget(etc->ch, 0, &tmp[0], &tmp[1]);
    if ((tmp[0] != 4) ||(tmp[1] != 6)) {
        result = 1;
    }
    

    /* Reset to default */
    tmp[0] = FLOW_CTRL_MODE_DISABLE;
    etc_ioctl(etc, ETCFLOWCTRLMODE, (void *)&tmp[0]);

    tmp[0] = FLWO_CTRL_AUTO_MODE_DEFAULT_ON_THRESH;
    tmp[1] = FLWO_CTRL_AUTO_MODE_DEFAULT_OFF_THRESH;
    etc_ioctl(etc, ETCFLOWCTRLAUTOSET, (void *)&tmp[0]);

    tmp[0] = 0;
    etc_ioctl(etc, ETCFLOWCTRLCPUSET, (void *)&tmp[0]);

    tmp[0] = 0;
    tmp[1] = 0;
    tmp[2] = 0;
    etc_ioctl(etc, ETCFLOWCTRLRXCHANSET, (void *)&tmp[0]);
    return result;
}

static int
etdiag_tpid(etc_info_t * etc)
{
    uint tmp[2];
    uint i;
    int result = 0;

    for (i=0; i < NUM_STAG_TPID; i++) {
        /* Set tpid */
        tmp[0] = i;
        tmp[1] = 0x9100;
        etc_ioctl(etc, ETCTPID, (void *)&tmp[0]);

        etc->chops->tpidget(etc->ch, i, &tmp[0]);
        if (tmp[0] != 0x9100) {
            result = 1;
        }
    }
    

    /* Recover */
    for (i=0; i < NUM_STAG_TPID; i++) {
        /* Set tpid */
        tmp[0] = i;
        tmp[1] = STAG_TPID_DEFAULT;
        etc_ioctl(etc, ETCTPID, (void *)&tmp[0]);
    }
    return 0;
}

static int
etdiag_ptag(etc_info_t * etc)
{
    uint tmp[1];
    int result = 0;

    /* Set private tag */
    tmp[0] = 3;
    etc_ioctl(etc, ETCPVTAG, (void *)&tmp[0]);

    etc->chops->pvtagget(etc->ch, &tmp[0]);
    if (tmp[0] != 3) {
        result = 1;
    }

    /* Reset to default value */
    tmp[0] = 0;
    etc_ioctl(etc, ETCPVTAG, (void *)&tmp[0]);
    return 0;
}


int
ui_cmd_etdiag(etc_info_t * etc, ui_cmdline_t *cmdline, int argc, char *argv[])
{
    char *subcmd;
    int fail = 0, fail_all = 0;

    if (!(subcmd = cmd_getarg(cmdline, 1)))
        return CFE_ERR_INV_PARAM;

     if (!strcmp(subcmd, "all")) {
        fail = etdiag_txrx(etc);
        if (fail) {
            fail_all = 1;
            printf("The TX/RX diagnostic test is failed!\n");
        }
        fail = etdiag_cfp(etc);
        if (fail) {
            fail_all = 1;
            printf("The CFP diagnostic test is failed!\n");
        }
        fail = etdiag_rate(etc);
        if (fail) {
            fail_all = 1;
            printf("The TX/RX rate diagnostic test is failed!\n");
        }
        fail = etdiag_flowctrl(etc);
        if (fail) {
            fail_all = 1;
            printf("The Flow Control diagnostic test is failed!\n");
        }
        fail = etdiag_tpid(etc);
        if (fail) {
            fail_all = 1;
            printf("The S-tag TPID diagnostic test is failed!\n");
        }
        fail = etdiag_ptag(etc);
        if (fail) {
            fail_all = 1;
            printf("The Private Tag diagnostic test is failed!\n");
        }
        if (!fail_all) {
            printf("The all diagnostic tests are passed!\n");
        }
        return 0;
     }
     else if (!strcmp(subcmd, "txrx")) { 
        fail = etdiag_txrx(etc);
        if (fail) {
            printf("The TX/RX diagnostic test is failed!\n");
        } else {
            printf("The TX/RX diagnostic test is passed!\n");
        }
        return 0;
     }
     else if (!strcmp(subcmd, "cfp")) { 
        fail = etdiag_cfp(etc);
        if (fail) {
            printf("The CFP diagnostic test is failed!\n");
        } else {
            printf("The CFP diagnostic test is passed!\n");
        }
        return 0;
     }
     else if (!strcmp(subcmd, "rate")) { 
        fail = etdiag_rate(etc);
        if (fail) {
            printf("The TX/RX RATE diagnostic test is failed!\n");
        } else {
            printf("The TX/RX RATE diagnostic test is passed!\n");
        }
        return 0;
     }
     else if (!strcmp(subcmd, "flowctrl")) { 
        fail = etdiag_flowctrl(etc);
        if (fail) {
            printf("The FLOW CONTROL diagnostic test is failed!\n");
        } else {
            printf("The FLOW CONTROL diagnostic test is passed!\n");
        }
        return 0;
     }
     else if (!strcmp(subcmd, "tpid")) { 
        fail = etdiag_tpid(etc);
        if (fail) {
            printf("The S-tag TPID diagnostic test is failed!\n");
        } else {
            printf("The S-tag TPID diagnostic test is passed!\n");
        }
        return 0;
     }
     else if (!strcmp(subcmd, "ptag")) { 
        fail = etdiag_ptag(etc);
        if (fail) {
            printf("The Private Tag diagnostic test is failed!\n");
        } else {
            printf("The Private Tag diagnostic test is passed!\n");
        }
        return 0;
     }
     else {
        return CFE_ERR_INV_PARAM;
     }

     return CFE_OK;
}



