/*
 * HND SiliconBackplane PCI core software interface.
 *
 * $Id: hndpci.h,v 1.2 2009/02/25 02:36:28 kliao Exp $
 * $Copyright Open Broadcom Corporation$
 */

#ifndef _hndpci_h_
#define _hndpci_h_


extern int hndpci_read_config(si_t *sih, uint port, uint bus, uint dev, uint func, uint off, void *buf,
                              int len);
extern int extpci_read_config(si_t *sih, uint port, uint bus, uint dev, uint func, uint off, void *buf,
                              int len);
extern int hndpci_write_config(si_t *sih, uint port, uint bus, uint dev, uint func, uint off, void *buf,
                               int len);
extern int extpci_write_config(si_t *sih, uint port, uint bus, uint dev, uint func, uint off, void *buf,
                               int len);
extern void hndpci_ban(uint16 core, uint8 unit);
extern int hndpci_init_pci(si_t *sih, uint port);
extern void hndpci_init_cores(si_t *sih);


#endif /* _hndpci_h_ */


