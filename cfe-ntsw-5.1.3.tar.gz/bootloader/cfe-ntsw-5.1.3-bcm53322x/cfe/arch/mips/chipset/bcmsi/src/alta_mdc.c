/*
 * $Id: alta_mdc.c,v 1.4 2009/08/19 07:56:06 cchao Exp $
 * $Copyright: (c) 2009 Broadcom Corp.
 * All Rights Reserved.$
 *
 */

#include "typedefs.h"
#include "bcmdevs.h"
#include "hndsoc.h"
#include "siutils.h"
#include "alta_osl.h"
#include "alta_keystone.h"
#include "alta_mdc.h"

#define MAX_ALTA_CHIPS          (1)
#define PL301B_BACKPLANE_CLOCK  (150000000UL)

typedef struct _alta_info_t {
    uint16                  vendor_id;
    uint16                  device_id;
    uint32                  base;
    volatile avregs_t       *av_regs;
    volatile dmaregs_t      *dma_regs;
    volatile dteregs_t      *dte_regs;
    osl_t                   *osh;
    si_t                    *sih;
    int                     irq;
    ALTA_ISR_FUNC           isr;
    void                    *isr_param;
} alta_info_t;
 
static int alta_count = 0;
static alta_info_t alta_list[MAX_ALTA_CHIPS];
static bool alta_initialized = FALSE;
 
static bool
device_match(uint16 v, uint16 d, uint32 base)
{
    if (alta_count >= MAX_ALTA_CHIPS) {
        return FALSE;
    }
    
    if (v != VENDOR_BROADCOM) {
        return FALSE;
    }
    
    if (d == ALTA_CORE_ID) {
        alta_list[alta_count].vendor_id = v;
        alta_list[alta_count].device_id = d;
        alta_list[alta_count].base = base;
        alta_count++;   
    }
    
    return FALSE;
}

int
alta_mdc_init(void)
{
    int i;
    
    if (alta_initialized) {
        return 0;
    }
    
    if (alta_osl_find_chip(device_match) || alta_count == 0) {
        /* No Alta chips found */
        return -1;
    }
    
    for(i=0; i<alta_count; i++) {
        alta_list[i].av_regs = NULL;
        alta_list[i].dma_regs = NULL;
        alta_list[i].dte_regs = NULL;
        alta_list[i].osh = NULL;
        alta_list[i].sih = NULL;
        alta_list[i].irq = -1;
    }

    alta_initialized = TRUE;

    return 0;
}

int
alta_mdc_get_number_of_units(void)
{
    if (!alta_initialized) {
        alta_mdc_init();
    }
    return alta_count;
}

int
alta_mdc_attach(int unit)
{
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    if (pinfo->av_regs != NULL) {
        /* Already attached */
        return 0;
    }
    
    /* Setup register addresses */
    pinfo->av_regs = (volatile avregs_t *)
        REG_MAP(ALTA_GET_AV_REG_ADDR(pinfo->base), 0x1000);
    pinfo->dma_regs = (volatile dmaregs_t *)
        REG_MAP(ALTA_GET_DMA_REG_ADDR(pinfo->base), 0x1000);
    pinfo->dte_regs = (volatile dteregs_t *)
        REG_MAP(ALTA_GET_DTE_REG_ADDR(pinfo->base), 0x1000);

    /* Get si handle of Alta core */
    pinfo->osh = osl_attach(NULL);
    if (pinfo->osh == NULL) {
        return -1;
    }
    pinfo->sih = si_attach(
        alta_list[unit].device_id, 
        pinfo->osh, 
        (void *)alta_list[unit].base, 
        PCI_BUS, 
        NULL, 
        NULL, 
        NULL);
    if (pinfo->sih == NULL) {
        return -1;
    }

    /* Reset Alta core before doing anything */        
    si_setcore(pinfo->sih, ALTA_CORE_ID, 0);
    si_core_reset(pinfo->sih, 0, 0);
    
    return 0;
}

int
alta_mdc_detach(int unit)
{
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return 0;
    }
    
    /* Reset Alta core to stop everything */
    si_setcore(pinfo->sih, ALTA_CORE_ID, 0);
    si_core_reset(pinfo->sih, 0, 0);
    
    /* Clear register addresses */
    REG_UNMAP(pinfo->av_regs);
    REG_UNMAP(pinfo->dma_regs);
    REG_UNMAP(pinfo->dte_regs);
    pinfo->av_regs = NULL;
    pinfo->dma_regs = NULL;
    pinfo->dte_regs = NULL;
    
    /* Release Alta core handle */
    if (pinfo->sih) {
        si_detach(pinfo->sih);
        pinfo->sih = NULL;
    }
    if (pinfo->osh) {
        osl_detach(pinfo->osh);
        pinfo->osh = NULL;
    }
    
    return 0;
}

static void
alta_isr(int ip)
{
    int unit;
    alta_info_t *pinfo = NULL;
    
    for(unit=0; unit<alta_count; unit++) {
        if (alta_list[unit].irq == ip) {
            pinfo = &alta_list[unit];

            if (!(ALTA_REG_READ(&pinfo->dte_regs->sdm_ctrl) & DTE_SDM_CTRL_INTR(1))) {
                /* Not for us since interrupt status not set */
                continue;
            }

            /* Mask IRQ (to prevent nested interrupt) */
            alta_osl_interrupt_mask(pinfo->irq);
            
            /* Acknowledge IRQ */
            alta_osl_interrupt_acknowledge(pinfo->irq);
            
            /* Call user's ISR */
            (*pinfo->isr)(unit, pinfo->isr_param);
            
            /* Clear interrupt status */
            ALTA_REG_WRITE(&pinfo->dte_regs->sdm_ctrl, 
                ALTA_REG_READ(&pinfo->dte_regs->sdm_ctrl) | DTE_SDM_CTRL_INTR(1));
            ALTA_REG_WRITE(&pinfo->dte_regs->sdm_ctrl, 
                ALTA_REG_READ(&pinfo->dte_regs->sdm_ctrl) & ~DTE_SDM_CTRL_INTR_ERR(1));
            
            /* Unmask IRQ */
            alta_osl_interrupt_unmask(pinfo->irq);
        }
    }
}

int
alta_mdc_interrupt_connect(int unit, uint32 nsec, ALTA_ISR_FUNC isr, void *param)
{
    uint32 lt;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->dte_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (nsec == 0 || isr == NULL) {
        return -1;
    }
    
    if (pinfo->irq != -1) {
        /* Already enabled */
        return -1;
    }
    
    pinfo->irq = si_irq(pinfo->sih);
    pinfo->isr = isr;
    pinfo->isr_param = param;

    /* Configure time for next interrupt */
    alta_mdc_get_localtime(unit, &lt);
    ALTA_REG_WRITE(&pinfo->dte_regs->iig0_int_len, LTIME_FROM_NSEC(nsec));
    ALTA_REG_WRITE(&pinfo->dte_regs->iig0_next_soi, LTIME_ADD_NSEC(lt, nsec));
    
    /* Clear interrupt status */
    ALTA_REG_WRITE(&pinfo->dte_regs->sdm_ctrl, 
        ALTA_REG_READ(&pinfo->dte_regs->sdm_ctrl) | DTE_SDM_CTRL_INTR(1));
    ALTA_REG_WRITE(&pinfo->dte_regs->sdm_ctrl, 
        ALTA_REG_READ(&pinfo->dte_regs->sdm_ctrl) & ~DTE_SDM_CTRL_INTR_ERR(1));

    /* We assume that different IRQs are used for different chips */
    alta_osl_interrupt_connect(pinfo->irq, alta_isr);
    
    return 0;
}

int
alta_mdc_init_audio_dma_set(int unit, AV_DMA_SET *pset)
{
    uint32 ch, cnt, mask, i;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (pset == NULL) {
        return -1;
    }
    if (pset->channels & (~((1 << AV_MAX_CHANNELS_PER_CHIP) - 1))) {
        return -1;
    }
    if (pset->bufaddr == 0 || pset->bufsize == 0) {
        return -1;
    }
    if ((pset->bufsize % 4) || pset->bufsize > AVDMA_MAX_CBUF_SIZE) {
        return -1;
    }

    /* Buffer size must be a power of 2 */
    if (pset->bufsize & (pset->bufsize - 1)) {
        return -1;
    }

    /* 
     * Special alignment requirement for Alta DMA:
     * address must be aligned with the size.
     */
    if (pset->bufaddr % pset->bufsize) {
        return -1;
    }

    /* Calculate address encoding mask */
    for(i=pset->bufsize, mask=0; i!=0; i<<=1, mask++);

    /* Calculate how many channels are interleaved in this buffer */
    cnt = 0;
    AVDMA_ITER(pset->channels, ch) {
        cnt++;
    }
    if (cnt == 0) {
        return -1;
    }

    i = 0;
    AVDMA_ITER(pset->channels, ch) {
        volatile dmachregs_t *regs = &pinfo->dma_regs->ch[ch];

        ALTA_REG_WRITE(&regs->csr, 
            0 << 30     |                   /* INC2 = 0 */
            cnt << 23   |                   /* INC7 = channel count */
            0 << 13     |                   /* Priority */
            1 << 9      |                   /* CBUF mode */
            1 << 6      |                   /* Auto Restart mode */
            1 << 5      |                   /* HW handshake */
            (pset->avout? 0 : 1) << 4  |    /* src inc (0:INC7, 1:INC2) */
            (pset->avout? 1 : 0) << 3  |    /* dst inc (0:INC7, 1:INC2) */
            (pset->avout? 0 : 1) << 2  |    /* src (0:AHB, 1:WB) */
            (pset->avout? 1 : 0) << 1  |    /* dst (0:AHB, 1:WB) */
            0                               /* Don't start yet */
            );

        ALTA_REG_WRITE(&regs->sz, 
            (4 << 16) | (pset->bufsize / 4));
        ALTA_REG_WRITE(&regs->src_addr, 
            pset->avout? pset->bufaddr + i * 4 : AV_FIFO(ch /8, ch % 8));
        ALTA_REG_WRITE(&regs->src_enc_mask, 
            pset->avout? mask : 0);
        ALTA_REG_WRITE(&regs->dst_addr, 
            pset->avout? AV_FIFO(ch /8, ch % 8) : pset->bufaddr + i * 4);
        ALTA_REG_WRITE(&regs->dst_enc_mask, 
            pset->avout? 0 : mask);

        i++;
    }

    return 0;
}

int
alta_mdc_start_audio_dma_set(int unit, AV_DMA_SET *pset)
{
    uint32 ch;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (pset == NULL) {
        return -1;
    }

    AVDMA_ITER(pset->channels, ch) {
        volatile dmachregs_t *regs = &pinfo->dma_regs->ch[ch];

        /* Set START bit */
        ALTA_REG_WRITE(&regs->csr, ALTA_REG_READ(&regs->csr) | 1);
    }

    return 0;
}

int
alta_mdc_stop_audio_dma_set(int unit, AV_DMA_SET *pset)
{
    uint32 ch;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (pset == NULL) {
        return -1;
    }

    AVDMA_ITER(pset->channels, ch) {
        volatile dmachregs_t *regs = &pinfo->dma_regs->ch[ch];

        /* Clear START bit */
        ALTA_REG_WRITE(&regs->csr, ALTA_REG_READ(&regs->csr) & (~1));
    }

    return 0;
}

int
alta_mdc_configure_audio_port(int unit, AVPORT_CONFIG *pparam)
{
    uint32 csr_val = 0, ocd_csr = 0;
    uint32 N_Reg = 0, F_Reg = 0, W_Reg = 0, B_Reg = 0, T_Reg = 0;
    uint32 NominalBandWidth = 0, FreqRatio = 0;
    int eNumOfChannels = 0, i;
    volatile avport_regs_t *regs;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (pparam == NULL) {
        return -1;
    }
    if (pparam->eIdx >= TOTAL_NUMBER_OF_AV_PORT) {
        return -1;
    }

    regs = &pinfo->av_regs->avport[pparam->eIdx];

    /* Get number of active channels */
    for(i=0; i<AV_MAX_CHANNELS_PER_PORT; i++) {
        if (pparam->ChannelMask & (1 << i)) {
            eNumOfChannels++;
        }
    }

    /* Ex. a stream 48K/sec * 32bits * 2 CH = 3.072Mbps (NominalBandWidth) */
    NominalBandWidth = 
        pparam->eAudioSampleRate * 
        pparam->eBitsPerSample * 
        eNumOfChannels;

    /* Set IxS mode, clocks/sample, sample shift, FB_POS */
    csr_val |= 
        AV_CSR_SAMP_SHFT(pparam->eSampleShift) | 
        AV_CSR_FB_POS(pparam->eFirstBitPos) |
        AV_CSR_DVB_IXS_SEL(0) | 
        AV_CSR_MODE(pparam->eClocksPerSample) | 
        AV_CSR_LSB_MSB(pparam->isFirstBitLSB);

    /* Figure out CSR value */
    switch (pparam->eIxS_Type) {

    case IXS_OUTPUT:    

        /* Incoming AVB (Alta view), Egress Mode (IxS view) */
        csr_val |= 
                AV_CSR_IO_MODE(0x0) | 
                AV_CSR_NUM_CHAN(eNumOfChannels) | 
                AV_CSR_SER_OE(1) | 
                AV_CSR_ICLK_OE(pparam->isAvIclkOe) | 
                AV_CSR_WCLK_OE(pparam->isAvWclkOe) |
                AV_CSR_MUTE_ALL(0);
        break;

    case IXS_INPUT:

        /* Outging AVB (Alta view), Ingress Mode (IxS view) & clocked by external */
        csr_val |= 
                AV_CSR_IO_MODE(0x1) | 
                AV_CSR_ICLK_SEL(0x1) | 
                AV_CSR_WCLK_SEL(0x1) | 
                AV_CSR_SER_OE(0) | 
                AV_CSR_ICLK_OE(0) | 
                AV_CSR_WCLK_OE(0) |
                AV_CSR_INV_ICLK(pparam->isInvertedIclk) | 
                AV_CSR_INV_WCLK(pparam->isInvertedWclk);
        break;

    case IXS_INPUT_INTERNAL:

        /* Outging AVB (Alta view), Ingress Mode (IxS view) & clocked by internal (Alta) */
        csr_val |= 
                AV_CSR_IO_MODE(0x1) | 
                AV_CSR_ICLK_SEL(0x0) | 
                AV_CSR_WCLK_SEL(0x0) | 
                AV_CSR_SER_OE(0) | 
                AV_CSR_ICLK_OE(1) | 
                AV_CSR_WCLK_OE(1) |
                AV_CSR_INV_ICLK(pparam->isInvertedIclk) | 
                AV_CSR_INV_WCLK(pparam->isInvertedWclk);
        break;

    default:
        return -1;
    }

    if (pparam->eIxS_Mode == IXS_INPUT) {
        ocd_csr |= 
                AV_OCG_CSR_WCLK_NE_SEL(pparam->OCG.eWclkSel) | 
                AV_OCG_CSR_SAMP_SHFT_DIR(pparam->OCG.eSampShftDir) | 
                AV_OCG_CSR_LTE_SEL(pparam->OCG.eLteSel) | 
                AV_OCG_CSR_PLLFB_DC(pparam->OCG.ePllFbDc);
    } else {
        ocd_csr |= 
                AV_OCG_CSR_WCLK_NE_SEL(pparam->OCG.eWclkSel) | 
                AV_OCG_CSR_SAMP_SHFT_DIR(pparam->OCG.eSampShftDir) | 
                AV_OCG_CSR_LTE_SEL(pparam->OCG.eLteSel) | 
                AV_OCG_CSR_PLLFB_DC(pparam->OCG.ePllFbDc) | 
                AV_OCG_CSR_INV_WCLK(pparam->OCG.isInvertedOutputWclk) | 
                AV_OCG_CSR_INV_ICLK(pparam->OCG.isInvertedOutputIclk) | 
                AV_OCG_CSR_ICLK_SRC_SEL(pparam->OCG.eIclkSrcSel) | 
                AV_OCG_CSR_SYNC_SEL(pparam->OCG.eSyncSel) |
                AV_OCG_CSR_APLL_SEL(pparam->OCG.is_ACLK_from_PL301b? 4 : 0);
    }

    if (pparam->OCG.eIclkSrcSel == INTERNAL_ICLK_DIVIDER) {

        /* Ex. for stream 48K/sec * 32bits * 2 CH = 3.072Mbps (NominalBandWidth)
         *     Assume nominalFrequency of DPLL is 25M; 
         *     N = (25M / 3.072M) / 2 - 1 = 3
         */
        uint32 aclk;
        if (pparam->OCG.is_ACLK_from_PL301b) {
            aclk = PL301B_BACKPLANE_CLOCK;
        } else {
            aclk = pparam->OCG.APLL_clock_speed;
        }
        FreqRatio = aclk / NominalBandWidth;

        if(FreqRatio < 2) {
            N_Reg = 0;
        }
        else {
            N_Reg = FreqRatio / 2 - 1;
        }

        ALTA_REG_WRITE(&regs->N_reg, N_Reg);
    }
        
    ALTA_REG_WRITE(&regs->ocd_csr, ocd_csr);

    /* XXX: Divider value for DPLL Feedback Clock Divider */
    F_Reg = 1;

    switch (pparam->eIxS_Mode) {

        case AUDIO_IXS_MODE:
            W_Reg = (pparam->eBitsPerSample * (eNumOfChannels / 2)) << 12 | 
                    (pparam->eBitsPerSample * (eNumOfChannels / 2));

            switch (pparam->eClocksPerSample) {
                case SAMPLECLOCKS_8:    
                    B_Reg = 7;
                    break;

                case SAMPLECLOCKS_16:
                    B_Reg = 15;
                    break;

                case SAMPLECLOCKS_20:
                    B_Reg = 19;
                    break;

                case SAMPLECLOCKS_24:
                    B_Reg = 23;
                    break;

                case SAMPLECLOCKS_32:
                    B_Reg = 31;
                    break;

                default:
                    REG_UNMAP(regaddr);
                    return -1;
            }

            T_Reg = 
                pparam->eBitsPerSample * 
                eNumOfChannels * 
                pparam->SamplePerTimestamp;

            break;

        default:
            return -1;
    }

    ALTA_REG_WRITE(&regs->F_reg, F_Reg);
    ALTA_REG_WRITE(&regs->W_reg, W_Reg);
    ALTA_REG_WRITE(&regs->B_reg, B_Reg);
    ALTA_REG_WRITE(&regs->T_reg, T_Reg);

    /* Write all settings into AV_CSR_Register (but not started) */
    csr_val |= AV_CSR_SW_RST(0x1) | AV_CSR_CH_ACT_MASK(0x0);
    ALTA_REG_WRITE(&regs->csr, csr_val);

    return 0;
}

int
alta_mdc_start_audio_port(int unit, AVPORT_CONFIG *pparam)
{
    uint32 csr_val;
    volatile avport_regs_t *regs;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (pparam == NULL) {
        return -1;
    }
    if (pparam->eIdx >= TOTAL_NUMBER_OF_AV_PORT) {
        return -1;
    }

    regs = &pinfo->av_regs->avport[pparam->eIdx];

    /* Get current CSR value */
    csr_val = ALTA_REG_READ(&regs->csr);

    /* Disable RESET */
    csr_val &= ~(AV_CSR_SW_RST(1));

    /* Activate channels */
    csr_val |= AV_CSR_CH_ACT_MASK(pparam->ChannelMask);

    /* Start it */
    ALTA_REG_WRITE(&regs->csr, csr_val);
    
    return 0;
}

int
alta_mdc_stop_audio_port(int unit, AVPORT_CONFIG *pparam)
{
    uint32 csr_val;
    volatile avport_regs_t *regs;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (pparam == NULL) {
        return -1;
    }
    if (pparam->eIdx >= TOTAL_NUMBER_OF_AV_PORT) {
        return -1;
    }

    regs = &pinfo->av_regs->avport[pparam->eIdx];

    /* Get current CSR value */
    csr_val = ALTA_REG_READ(&regs->csr);

    /* Enable RESET */
    csr_val |= AV_CSR_SW_RST(1);

    /* Deactivate channels */
    csr_val &= ~(AV_CSR_CH_ACT_MASK(0xFF));

    /* Stop it */
    ALTA_REG_WRITE(&regs->csr, csr_val);
    
    return 0;
}

int
alta_mdc_schedule_av_time_event(int unit, uint32 ltime)
{
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    /* Set Global Time Event register to activate enabled AV ports */
    ALTA_REG_WRITE(&pinfo->av_regs->te, ltime);

    return 0;
}

int
alta_mdc_get_localtime(int unit, uint32 *pltime)
{
    uint32 v;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (pltime == NULL) {
        return -1;
    }
    
    /* XXX: need to make sure atomic, or no one uses other debug data */
    v = ALTA_REG_READ(&pinfo->av_regs->glbl_ctrl);
    v &= ~AV_GLBL_CTRL_STAT_DBG_SEL(0xf);
    v |= AV_GLBL_CTRL_STAT_DBG_SEL(0xc);
    ALTA_REG_WRITE(&pinfo->av_regs->glbl_ctrl, v);
    
    *pltime = ALTA_REG_READ(&pinfo->av_regs->glbl_dbg_data);
    
    return 0;
}

int
alta_mdc_set_localtime(int unit, uint32 ltime)
{
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->dte_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    ALTA_REG_WRITE(&pinfo->dte_regs->ltnco_sum1, LTIME_TO_SUM1(ltime));
    ALTA_REG_WRITE(&pinfo->dte_regs->ltnco_sum2, LTIME_TO_SUM2(ltime));
    
    return 0;
}

int
alta_mdc_get_localtime_increment(int unit, uint32 *pval)
{
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->dte_regs == NULL) {
        /* not attached */
        return -1;
    }

    if (pval == NULL) {
        return -1;
    }
    
    *pval = ALTA_REG_READ(&pinfo->dte_regs->ltnco_inc);
    
    return 0;
}

int
alta_mdc_set_localtime_increment(int unit, uint32 val)
{
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->dte_regs == NULL) {
        /* not attached */
        return -1;
    }

    ALTA_REG_WRITE(&pinfo->dte_regs->ltnco_inc, val);
    
    return 0;
}

int
alta_mdc_locatime_to_nanosecond(uint32 ltime, uint32 *pnsec)
{
    if (pnsec == NULL) {
        return -1;
    }
    
    *pnsec = LTIME_TO_NSEC(ltime);
    
    return 0;
}

int
alta_mdc_locatime_to_picosecond(uint32 ltime, uint32 *ppsec)
{
    if (ppsec == NULL) {
        return -1;
    }
    
    *ppsec = LTIME_TO_PSEC(ltime);
    
    return 0;
}

int
alta_mdc_timestamp_status(int unit, E_TSFIFO_STATUS *pstatus)
{
    uint32 status;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->dte_regs == NULL) {
        /* not attached */
        return -1;
    }

    if (pstatus == NULL) {
        return -1;
    }
    
    status = ALTA_REG_READ(&pinfo->dte_regs->lts_status);

    if (status & TSFIFO_STATUS_UNDERFLOW) {
        *pstatus = TSFIFO_UNDERFLOW_ERR;
    } else if (status & TSFIFO_STATUS_OVERFLOW) {
        *pstatus = TSFIFO_OVERFLOW_ERR;
    } else if (status & TSFIFO_STATUS_FULL) {
        *pstatus = TSFIFO_FULL;
    } else if (status & TSFIFO_STATUS_EMPTY) {
        *pstatus = TSFIFO_EMPTY;
    } else {
        *pstatus = TSFIFO_AVAIL;
    }
    
    return 0;
}

int
alta_mdc_retrieve_timestamp(int unit, uint32 *pts, uint32 *pmask)
{
    uint32 status;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->dte_regs == NULL) {
        /* not attached */
        return -1;
    }

    if (pmask == NULL || pts == NULL) {
        return -1;
    }
    
    status = ALTA_REG_READ(&pinfo->dte_regs->lts_status);

    /* Check for persistent errors */
    if ((status & TSFIFO_STATUS_UNDERFLOW) || 
        (status & TSFIFO_STATUS_OVERFLOW)) {
        return -1;
    }

    if (status & TSFIFO_STATUS_EMPTY) {

        /* No timestamp available */
        *pmask = 0;

    } else {

        /* Read out timestamp and return */
        *pmask = ALTA_REG_READ(&pinfo->dte_regs->lts_fifo_out);
        *pts = ALTA_REG_READ(&pinfo->dte_regs->lts_fifo_out);
    }

    return 0;
}

int
alta_mdc_reset_timestamp(int unit)
{
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->dte_regs == NULL) {
        /* not attached */
        return -1;
    }

    ALTA_REG_WRITE(&pinfo->dte_regs->lts_status, 0);

    return 0;
}

int
alta_mdc_dma_get_totsz(int unit, uint32 channel, uint32 *ptotsz)
{
    volatile dmachregs_t *regs;
    alta_info_t *pinfo;

    if (!alta_initialized) {
        return -1;
    }
    if (unit >= alta_count) {
        return -1;
    }
    
    pinfo = &alta_list[unit];
    
    if (pinfo->av_regs == NULL) {
        /* not attached */
        return -1;
    }
    
    if (ptotsz == NULL) {
        return -1;
    }
    
    regs = &pinfo->dma_regs->ch[channel];
    *ptotsz = pinfo->dma_regs->ch[channel].sz & AV_DMA_SZ_TOTSZ_MASK;
    
    return 0;
}
