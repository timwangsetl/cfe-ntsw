/*
 * $Id: alta_mdc.h,v 1.3 2009/07/16 08:50:34 cchao Exp $
 * $Copyright: (c) 2009 Broadcom Corp.
 * All Rights Reserved.$
 *
 */

#ifndef _ALTA_MDC_H
#define _ALTA_MDC_H

#include "alta_api.h"

extern int alta_mdc_init(void);
extern int alta_mdc_get_number_of_units(void);

extern int alta_mdc_attach(int unit);
extern int alta_mdc_detach(int unit);

extern int alta_mdc_interrupt_connect(int unit, uint32 nsec, ALTA_ISR_FUNC isr, void *param);

extern int alta_mdc_init_audio_dma_set(int unit, AV_DMA_SET *pset);
extern int alta_mdc_start_audio_dma_set(int unit, AV_DMA_SET *pset);
extern int alta_mdc_stop_audio_dma_set(int unit, AV_DMA_SET *pset);

extern int alta_mdc_configure_audio_port(int unit, AVPORT_CONFIG *pparam);
extern int alta_mdc_start_audio_port(int unit, AVPORT_CONFIG *pparam);
extern int alta_mdc_stop_audio_port(int unit, AVPORT_CONFIG *pparam);

extern int alta_mdc_schedule_av_time_event(int unit, uint32 ltime);

extern int alta_mdc_get_localtime(int unit, uint32 *pltime);
extern int alta_mdc_set_localtime(int unit, uint32 ltime);
extern int alta_mdc_get_localtime_increment(int unit, uint32 *pval);
extern int alta_mdc_set_localtime_increment(int unit, uint32 val);
extern int alta_mdc_locatime_to_nanosecond(uint32 ltime, uint32 *pnsec);
extern int alta_mdc_locatime_to_picosecond(uint32 ltime, uint32 *ppsec);

extern int alta_mdc_timestamp_status(int unit, E_TSFIFO_STATUS *pstatus);
extern int alta_mdc_retrieve_timestamp(int unit, uint32 *pts, uint32 *pmask);
extern int alta_mdc_reset_timestamp(int unit);

extern int alta_mdc_dma_get_totsz(int unit, uint32 channel, uint32 *ptotsz);

#endif /* _ALTA_API_H */

