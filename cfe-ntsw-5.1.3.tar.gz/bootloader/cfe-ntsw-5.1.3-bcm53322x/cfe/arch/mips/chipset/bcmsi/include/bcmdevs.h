/* 
 * Broadcdcom device-specific manifest constants.
 *
 * $Copyright Open Broadcom Corporation$
 *
 * $Id: bcmdevs.h,v 1.3 2010/06/17 09:29:58 jimhuang Exp $
 */

#ifndef	_BCMDEVS_H
#define	_BCMDEVS_H

/* PCI vendor IDs */
#define	VENDOR_EPIGRAM		0xfeda
#define	VENDOR_BROADCOM		0x14e4
#define	VENDOR_3COM		0x10b7
#define	VENDOR_NETGEAR		0x1385
#define	VENDOR_DIAMOND		0x1092
#define	VENDOR_INTEL		0x8086
#define	VENDOR_DELL		0x1028
#define	VENDOR_HP		0x103c
#define	VENDOR_HP_COMPAQ	0x0e11
#define	VENDOR_APPLE		0x106b
#define VENDOR_SI_IMAGE		0x1095		
/* Silicon Image, used by Arasan SDIO Host */
#define VENDOR_BUFFALO		0x1154		/* Buffalo vendor id */
#define VENDOR_TI		0x104c		/* Texas Instruments */
#define VENDOR_RICOH		0x1180		/* Ricoh */

/* PCI Device IDs */
#define	BCM4710_DEVICE_ID	0x4710		/* 4710 primary function 0 */
#define	BCM47XX_ILINE_ID	0x4711		/* 47xx iline20 */
#define	BCM47XX_V90_ID		0x4712		/* 47xx v90 codec */
#define	BCM47XX_ENET_ID		0x4713		/* 47xx enet */
#define	BCM47XX_GMAC_ID		0x4715		/* 47xx Unimac based GbE */
#define	BCM47XX_USBH_ID		0x4716		/* 47xx usb host */
#define	BCM47XX_USBD_ID		0x4717		/* 47xx usb device */
#define	BCM47XX_IPSEC_ID	0x4718		/* 47xx ipsec */
#define	BCM47XX_ROBO_ID		0x4719		/* 47xx/53xx roboswitch core */
#define	BCM47XX_USB20H_ID	0x471a		/* 47xx usb 2.0 host */
#define	BCM47XX_USB20D_ID	0x471b		/* 47xx usb 2.0 device */
#define	BCM47XX_ATA100_ID	0x471d		/* 47xx parallel ATA */
#define	BCM47XX_SATAXOR_ID	0x471e		/* 47xx serial ATA & XOR DMA */
#define	BCM47XX_GIGETH_ID	0x471f		/* 47xx GbE (5700) */
#define BCM53000_GMAC_ID	0x4715


/* Chip IDs */
#define	BCM4306_CHIP_ID		0x4306		/* 4306 chipcommon chipid */
#define	BCM4704_CHIP_ID		0x4704		/* 4704 chipcommon chipid */
#define	BCM4710_CHIP_ID		0x4710		/* 4710 chipid */
#define	BCM4712_CHIP_ID		0x4712		/* 4712 chipcommon chipid */
#define	BCM4716_CHIP_ID		0x4716		/* 4716 chipcommon chipid */
#define	BCM53000_CHIP_ID	0x5300		/* 53000 chipcommon chipid */

/* Package IDs */
#define HDLSIM_PKG_ID		14		/* HDL simulator package id */
#define HWSIM_PKG_ID		15		/* Hardware simulator package id */

#define PCI_CFG_GPIO_XTAL	0x40	/* GPIO 14 for Xtal powerup */
#define PCI_CFG_GPIO_PLL	0x80	/* GPIO 15 for PLL powerdown */

/* XXX, need to be moved to a chip specific header file */
/* power control defines */
#define PLL_DELAY		150		/* us pll on delay */
#define FREF_DELAY		200		/* us fref change delay */
#define MIN_SLOW_CLK		32		/* us Slow clock period */
#define	XTAL_ON_DELAY		1000		/* us crystal power-on delay */

/* All core types according to the layout in the chip */
/*
 * This is to provide the coreflags that can be used
 * to check the core existence or overrided from external config
 */
#define CORE_CC             0x00000001
#define CORE_GMAC_COMMON    0x00000002
#define CORE_GMAC0          0x00000004
#define CORE_MIPS           0x00000008
#define CORE_USB20_EHCI     0x00000010
#define CORE_PCIE0          0x00000020
#define CORE_DDR2           0x00000040
#define CORE_SOCRAM         0x00000080
#define CORE_ALTA           0x00000100
#define CORE_USB20_OHCI     0x00000200
#define CORE_PL301B         0x00000400
#define CORE_PL301C         0x00000800
#define CORE_PL301A         0x00001000
#define CORE_GMAC1          0x00002000
#define CORE_PCIE1          0x00004000
#define CORE_DDR2_PHY       0x00008000
#define CORE_ALL            0x0000FFFF  /* The collection of all cores */

#endif /* _BCMDEVS_H */

