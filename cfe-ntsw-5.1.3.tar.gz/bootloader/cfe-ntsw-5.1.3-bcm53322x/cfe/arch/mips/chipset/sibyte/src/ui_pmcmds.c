/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Packet Manager commands			File: ui_pmcmds.c
    *  
    *  Commands and test stuff to check out the packet manager
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "sbmips.h"
#include "ui_command.h"

#include "lib_hssubr.h"
#include "lib_try.h"
#include "lib_memfuncs.h"
#include "lib_physio.h"
#include "env_subr.h"
#include "sb1250_defs.h"

#include "pcivar.h"
#include "pci_internal.h"
#include "pcireg.h"
#include "ldtreg.h"

#include "bcm1480_regs.h"
#include "bcm1480_pm.h"
#include "bcm1480_hr.h"
#include "bcm1480_ht.h"
#include "bcm1480_hsp.h"
#include "bcm1480_scd.h"

#include "ui_bitfields.h"

typedef volatile uint32_t sbeth_port_t;
typedef uint32_t sbeth_physaddr_t;
#define SBETH_PORT(x) PHYS_TO_K1(x)

#if CFG_L2_RAM
#define SBETH_VTOP(x) ((sbeth_physaddr_t)0xD0000000 + (sbeth_physaddr_t)(x))
#else
#define SBETH_VTOP(x) (K1_TO_PHYS((sbeth_physaddr_t)(x)))
#endif

#define WRITECSR(x,y) phys_write64(x,y)
#define READCSR(x) phys_read64(x)


/*  *********************************************************************
    *  Constants 
    ********************************************************************* */

#define REFCLK 		100	/* in MHz */
#define SPI4_MHZ	400	/* in MHz */
/* These settings should correspond to the Intel IXF1010 eval board */
#define CALENDAR_M 	1
#define CALENDAR_LEN 	10
#define ACTIVE_CHANNELS 10      // Enable 10 channels

/*  *********************************************************************
    *  PCI register stuff.  In HT mode, we need to talk to the
    *  HT bridges to set up PoHT functions
    ********************************************************************* */

#define	BCM1480_PCI_MAKE_TAG(p,b,d,f)					\
    (((p) << 24) | ((b) << 16) | ((d) << 11) | ((f) << 8))
#define BCM1480_HOST_PORT(tag) (((tag) >> 24) & 0xFF)


/* The BCM1480 integrated host bridges. */

#define	BCM1480_LDT_BRIDGE	(BCM1480_PCI_MAKE_TAG(1,0,4,0))

/* The BCM1480 integrated external PCI/HT bridges. */

#define BCM1480_EXT0_BRIDGE     (BCM1480_PCI_MAKE_TAG(1,0,0,0))
#define BCM1480_EXT1_BRIDGE     (BCM1480_PCI_MAKE_TAG(1,0,1,0))
#define BCM1480_EXT2_BRIDGE     (BCM1480_PCI_MAKE_TAG(1,0,2,0))
#define BCM1480_EXTx_BRIDGE(x)  (BCM1480_PCI_MAKE_TAG(1,0,(x),0))


/*  *********************************************************************
    *  Configuration
    ********************************************************************* */


/*  *********************************************************************
    *  prototypes
    ********************************************************************* */

int ui_init_pmcmds(void);
extern int dumpmem(hsaddr_t addr,hsaddr_t dispaddr,int length,int wlen);

/*  *********************************************************************
    *  Data
    ********************************************************************* */


static bitfield_t spi4_txintstat[] = {
    {M_BCM1480_HSP_TX_INT_TSTATTIMEOUT,"TSTAT_Timeout"},
    {M_BCM1480_HSP_TX_INT_DIP2RXERR,"DIP2_Error"},
    {M_BCM1480_HSP_TX_INT_SPI4RESET,"Port_Reset"},
    {0,NULL}};

static bitfield_t spi4_rxintstat[] = {
    {M_BCM1480_HSP_RX_INT_PERVCERR,"per_vc_err"},
    {M_BCM1480_HSP_RX_INT_EOPABORT,"eop_abort"},
    {M_BCM1480_HSP_RX_INT_SPI4PROTOERR,"spi4_proto_err"},
    {M_BCM1480_HSP_RX_INT_ESTOREOVERFLOW,"estore_ovflo"},
    {M_BCM1480_HSP_RX_INT_ALPHATRAINERR,"alpha_train_err"},
    {M_BCM1480_HSP_RX_INT_DIP4ERROR,"dip4_err"},
    {M_BCM1480_HSP_RX_INT_HRERROR,"hr_err"},
    {M_BCM1480_HSP_RX_INT_INTOVERFLOW,"intrnl_ovflo"},
    {0,NULL}};

static bitfield_t spi4_txcalibration[] = {
    {M_BCM1480_HSP_CAL_STARTCAL2,"StartCal|NotStartCal"},
    {M_BCM1480_HSP_CAL_PDTEST,"PDTest"},
    {M_BCM1480_HSP_CAL_CALFIN,"Cal_Finish|Cal_Inprog"},
    {M_BCM1480_HSP_CAL_S100M66M,"TestTXREF/2|TestTXREF/1"},
    {M_BCM1480_HSP_CAL_NO_CALIB,"No_Calib|Auto_Calib"},
    {M_BCM1480_HSP_CAL_BMODE,"BMode"},
    {M_BCM1480_HSP_CAL_CALSETP,"calsetp"},
    {M_BCM1480_HSP_CAL_CALSETN,"calsetn"},
    {M_BCM1480_HSP_CAL_CALPSTAT,"calpstat"},
    {M_BCM1480_HSP_CAL_CALNSTAT,"calnstat"},
    {0,NULL}};

static bitfield_t dscrerrs[] = {
    {M_BCM1480_PM_DSCR0_PE,"PE"},
    {M_BCM1480_PM_DSCR0_LE,"LE"},
    {M_BCM1480_PM_DSCR0_SE,"SE"},
    {0,NULL}};

static int pm_ports = 0;		/* all ports in use */

/*  *********************************************************************
    *  Descriptor structure
    ********************************************************************* */

typedef struct pmdscr_s {
    uint64_t  dscr_a;
    uint64_t  dscr_b;
} pmdscr_t;

#define PM_NRINGS 32
#define PM_RINGSIZE 16
#define PKTBUFSIZE 4096
#define PKTSIZE 1024
#define NUMPKTS 512

typedef struct pmring_s {
    pmdscr_t *dscr;
    void **ctx;
    int ringsize;
    int qno;
    int next_add;
    int next_rem;
    int onring;
} pmring_t;

typedef struct packet_s {
    struct packet_s *next;
    unsigned int len;
    int res0,res1;
    uint8_t  pkt[PKTBUFSIZE];
    uint8_t  pad[32];
    
} packet_t;

static packet_t *pm_pkt_pool = NULL;
static packet_t *pm_pkts[NUMPKTS];

static pmring_t *pmi_rings[PM_NRINGS];
static pmring_t *pmo_rings[PM_NRINGS];

static unsigned long rand(void)
{
    static unsigned long seed = 1;
    long x, hi, lo, t;

    x = seed;
    hi = x / 127773;
    lo = x % 127773;
    t = 16807 * lo - 2836 * hi;
    if (t <= 0) t += 0x7fffffff;
    seed = t;
    return t;
}

/*  *********************************************************************
    *  Bit Wrangling
    ********************************************************************* */

char *showfields(bitfield_t *fields,uint64_t val)
{
    int left,right;
    int idx;
    static char buffer[512];
    char fieldname[128];
    char *p = buffer;
    char *x,*setstr,*clearstr;

    *p = '\0';
    while (fields->name) {

	/* Determine left and right edge of bit field */
	right = -1; left = -1;
	for (idx = 0; idx < 64; idx++) {
	    if ((right < 0) && (fields->field & (1LL << idx))) right = idx;
	    if ((left < 0) && (fields->field & (0x8000000000000000LL >> idx))) left = (63-idx);
	    }

	/* If same, it's a one bit field */
	if (right == left) {
	    strcpy(fieldname,fields->name);
	    x = strchr(fieldname,'|');
	    if (x) {
		*x++ = '\0'; setstr = fieldname; clearstr = x;
		}
	    else {
		setstr = fieldname; clearstr = NULL;
		}
	 
	    if (fields->field & val) p += sprintf(p,"%s ",setstr);
	    else {
		if (clearstr) p += sprintf(p,"%s ",clearstr);
		}
	    }
	else {
	    p += sprintf(p,"%s=%u ",fields->name,
			 (int)((fields->field & val) >> right));
	    }

	fields++;
	}

    return buffer;
}


/*  *********************************************************************
    *  Packet Manager stuff
    ********************************************************************* */


static inline void pm_pkt_free(packet_t *pkt)
{
    pkt->next = pm_pkt_pool;
    pm_pkt_pool = pkt;
}

static inline packet_t *pm_pkt_alloc(void)
{
    packet_t *pkt = pm_pkt_pool;

    if (pkt) {
	pm_pkt_pool = pkt->next;
	return pkt;
	}
    else {
	return NULL;
	}
}

static void pm_init_pktpool(void)
{
    int idx,j;
    packet_t *pkt;

    for (idx = 0; idx < NUMPKTS; idx++) {
	pkt = KMALLOC(sizeof(packet_t),32);
	if (!pkt) break;
	pm_pkts[idx] = pkt;
//	for (j = 0; j < sizeof(pkt->pkt); j++) pkt->pkt[j] = ~(uint8_t) j;
	for (j = 0; j < sizeof(pkt->pkt); j+=4) {
	    pkt->pkt[j+0] =  0xAA;
	    pkt->pkt[j+1] =  0xAA;
	    pkt->pkt[j+2] =  0x55;
	    pkt->pkt[j+3] =  0x55;
	    }
	pm_pkt_free(pkt);
	}
}

static void pm_free_pktpool(void)
{
    int idx;
    for (idx = 0; idx < NUMPKTS; idx++) {
	if (pm_pkts[idx]) KFREE(pm_pkts[idx]);
	pm_pkts[idx] = NULL;
	}
    pm_pkt_pool = NULL;
}

static void pm_free_ring(pmring_t *ring)
{
    if (ring->dscr) KFREE(ring->dscr);
    if (ring->ctx) KFREE(ring->ctx);
    KFREE(ring);
}

static int pm_init_pmo_queue(pmring_t *ring)
{
    /* Set up Ring Base and Size */
    WRITECSR(A_BCM1480_PMO_LCL_REGISTER(ring->qno,R_BCM1480_PM_BASE_SIZE), 
	     (V_BCM1480_PM_BASE(SBETH_VTOP(ring->dscr)) |
	      V_BCM1480_PM_SIZE(ring->ringsize)));

    /* Enable Queue Configuration Register */
    WRITECSR(A_BCM1480_PMO_LCL_REGISTER(ring->qno,R_BCM1480_PM_CONFIG0),
	     (M_BCM1480_PM_QUEUE_ENABLE | M_BCM1480_PM_DS_CACHE_EN));

    /* Set up L2 Cacheability */
    WRITECSR(A_BCM1480_PMO_LCL_REGISTER(ring->qno,R_BCM1480_PM_CACHEABILITY),
	     V_BCM1480_PM_HDR_SIZE(511));

    /* 
     * Setup Interrupt Watermark Register
     * WRITECSR(A_BCM1480_PMO_LCL_REGISTER(ring->qno,R_BCM1480_PM_INT_WMK),
     * (V_BCM1480_PM_LOW_WATERMARK(lwm)|
     * V_BCM1480_PM_HIGH_WATERMARK(hwm)));
     */

    /* 
     * Initialize Interrupt Config Register 
     *
     * int_priority_val = int_priority ? M_BCM1480_PM_INT_PRIORITY : 0;
     * int_cnfg_val = V_BCM1480_PM_INT_CORE_ID(cpuid) | int_priority_val | 
     * V_BCM1480_PM_INT_PKT_CNT(int_pkt_cnt);
     * WRITECSR(A_BCM1480_PMO_LCL_REGISTER(ring->qno,R_BCM1480_PM_INT_CNFG), int_cnfg_val);
     */

    /* Initialize Descriptor Merge Timer */
    WRITECSR(A_BCM1480_PMO_LCL_REGISTER(ring->qno,R_BCM1480_PM_DESC_MERGE_TIMER), 16);

    return 0;
}

static int pm_init_pmi_queue(pmring_t *ring)
{
    /* Set up Ring Base and Size */
    WRITECSR(A_BCM1480_PMI_LCL_REGISTER(ring->qno,R_BCM1480_PM_BASE_SIZE),
	     (V_BCM1480_PM_BASE(SBETH_VTOP(ring->dscr)) |
	      V_BCM1480_PM_SIZE(ring->ringsize)));

    /* Enable Queue Configuration Register */
    WRITECSR(A_BCM1480_PMI_LCL_REGISTER(ring->qno,R_BCM1480_PM_CONFIG0),
	     (M_BCM1480_PM_QUEUE_ENABLE | M_BCM1480_PM_DS_CACHE_EN));

    /* Set up L2 Cacheability */
    WRITECSR(A_BCM1480_PMI_LCL_REGISTER(ring->qno,R_BCM1480_PM_CACHEABILITY),
	     V_BCM1480_PM_HDR_SIZE(511));

    /*
     * Setup Interrupt Watermark Register
     *
     *  WRITECSR(A_BCM1480_PMI_LCL_REGISTER(ring->qno,R_BCM1480_PM_INT_WMK),(V_BCM1480_PM_LOW_WATERMARK(lwm)|
     *  V_BCM1480_PM_HIGH_WATERMARK(hwm)));
     */

    /* 
     * Initialize Interrupt Config Register
     *      int_priority_val = int_priority ? M_BCM1480_PM_INT_PRIORITY : 0;
     *      int_cnfg_val = V_BCM1480_PM_INT_CORE_ID(cpuid) | int_priority_val | 
     *      V_BCM1480_PM_INT_PKT_CNT(int_pkt_cnt);
     *      WRITECSR(A_BCM1480_PMI_LCL_REGISTER(ring->qno,R_BCM1480_PM_INT_CNFG), int_cnfg_val);
     */

    /* 
     * Initialize Descriptor Merge Timer
     *
     * WRITECSR(A_BCM1480_PMI_LCL_REGISTER(ring->qno,R_BCM1480_PM_DESC_MERGE_TIMER), desc_merge_timer);
     */

    /* 
     * Update Global Debug Mode Register
     *
     *      debug_mode_val = debug_mode ? M_BCM1480_PM_DEBUG_MODE : 0;
     *      read_priority_val = read_priority ? M_BCM1480_PM_READ_PRIORITY : 0;
     *      write_priority_val = write_priority ? M_BCM1480_PM_WRITE_PRIORITY : 0;
     *      WRITECSR(A_BCM1480_PM_GLOBALDEBUGMODE_PMI, debug_mode_val | read_priority_val |
     *      write_priority_val );
     */

    return 0;
}

static pmring_t *pm_init_ring(int qno,int ringsize)
{
    int idx;
    pmring_t *ring;

    ring = (pmring_t *) KMALLOC(sizeof(pmring_t),0);
    if (!ring) return NULL;

    ring->dscr = (pmdscr_t *) KMALLOC(ringsize*sizeof(pmdscr_t),32);
    ring->ctx = (void **) KMALLOC(ringsize*sizeof(void *),8);
    ring->qno = qno;
    ring->ringsize = ringsize;
    ring->next_add = 0;
    ring->next_rem = 0;
    ring->onring = 0;

    for (idx = 0; idx < ringsize; idx++) {
	ring->dscr[idx].dscr_a = M_BCM1480_PM_DSCR0_HW;
	ring->dscr[idx].dscr_b = 0;
	ring->ctx[idx] = 0;
	}

    return ring;
}

static int pm_add_rxbuf(pmring_t *ring,packet_t *pkt)
{
    pmdscr_t *dscr = ring->dscr + ring->next_add;
    int newadd;

    pkt->len = sizeof(pkt->pkt);

    newadd = ring->next_add + 1;
    if (newadd >= ring->ringsize) newadd = 0;
    if (newadd == ring->next_rem) {
	printf("Ring %d: RX ring is full\n",ring->qno);
	return 0;
	}

    ring->ctx[ring->next_add] = pkt;
    dscr->dscr_a = M_BCM1480_PM_DSCR0_HW | V_BCM1480_PM_DSCR0_BUFFER_LENGTH(pkt->len);
    dscr->dscr_b = V_BCM1480_PM_DSCR1_BUFFER_ADDR(SBETH_VTOP(&(pkt->pkt[0])));

    ring->next_add = newadd;
    ring->onring++;

    return 1;
}

static inline void pm_start_rx(pmring_t *ring,int cnt)
{
    WRITECSR(A_BCM1480_PMI_LCL_REGISTER(ring->qno,R_BCM1480_PM_CNT), V_BCM1480_PM_COUNT(cnt));
}


static int pm_add_txbuf(pmring_t *ring,packet_t *pkt)
{
    pmdscr_t *dscr = ring->dscr + ring->next_add;
    int newadd;
    int ivc = ring->qno;
    int nxt_dest = 0;

    newadd = ring->next_add + 1;
    if (newadd >= ring->ringsize) newadd = 0;
    if (newadd == ring->next_rem) {
	printf("Ring %d: TX Ring is full\n",ring->qno);
	return 0;
	}

    ring->ctx[ring->next_add] = pkt;
    dscr->dscr_a = M_BCM1480_PM_DSCR0_HW | M_BCM1480_PM_DSCR0_SOP | 
	M_BCM1480_PM_DSCR0_EOP | V_BCM1480_PM_DSCR0_BUFFER_LENGTH(pkt->len);
    dscr->dscr_b = V_BCM1480_PM_DSCR1_BUFFER_ADDR(SBETH_VTOP(&(pkt->pkt[0]))) | 
	V_BCM1480_PM_DSCR1_IVC(ivc) | V_BCM1480_PM_DSCR1_NEXT_DEST(nxt_dest);

    ring->next_add = newadd;
    ring->onring++;


    return 1;
}

static inline void pm_start_tx(pmring_t *ring,int cnt)
{
    WRITECSR(A_BCM1480_PMO_LCL_REGISTER(ring->qno,R_BCM1480_PM_CNT), V_BCM1480_PM_COUNT(cnt));
}

static int pm_dequeue_rxbuf(pmring_t *ring,packet_t **ppkt)
{
    packet_t *pkt;
    uint64_t status;
    volatile pmdscr_t *dscr = ring->dscr + ring->next_rem;

    if (!(dscr->dscr_a & M_BCM1480_PM_DSCR0_HW) && (ring->next_rem != ring->next_add)) {
	status = dscr->dscr_a;
	if (dscr->dscr_a & (M_BCM1480_PM_DSCR0_PE | M_BCM1480_PM_DSCR0_SE | M_BCM1480_PM_DSCR0_LE)) {
	    printf("Ring %d: DscrErr: %016llX [ %s]\n",ring->qno,status,showfields(dscrerrs,status));
	    }
	pkt = ring->ctx[ring->next_rem];
	pkt->len = G_BCM1480_PM_DSCR0_BUFFER_LENGTH(dscr->dscr_a);
	*ppkt = pkt;
	ring->next_rem++;
	ring->onring--;
	if (ring->next_rem == ring->ringsize) ring->next_rem = 0;
	return 1;
	}
    return 0;
}

static int pm_dequeue_txbuf(pmring_t *ring,packet_t **ppkt)
{
    packet_t *pkt;
    volatile pmdscr_t *dscr = ring->dscr + ring->next_rem;

    if (!(dscr->dscr_a & M_BCM1480_PM_DSCR0_HW) && (ring->next_rem != ring->next_add)) {
	pkt = ring->ctx[ring->next_rem];
	*ppkt = pkt;
	ring->next_rem++;
	ring->onring--;
	if (ring->next_rem == ring->ringsize) ring->next_rem = 0;
	return 1;
	}
    return 0;
}

static void pm_calc_ramalloc(int txrx,int active,int spi4_mode);

static void pm_init_spi4_port(int port,int mhz)
{
    uint64_t value;
    int spi4_pllmult;
    uint64_t cpu_mhz;
    uint64_t sw_mhz;
    uint64_t spi4_mhz = mhz;

    cpu_mhz = G_BCM1480_SYS_PLL_DIV(READCSR(A_SCD_SYSTEM_CFG)) * (REFCLK/2);
    sw_mhz = cpu_mhz * 2 / G_BCM1480_SYS_SW_DIV(READCSR(A_SCD_SYSTEM_CFG));

    spi4_pllmult = spi4_mhz / (REFCLK/2);

	    /* enable the calendar */

	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CALENDAR_0),0);
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CALENDAR_1),0);


	    value = V_BCM1480_HSP_RX_CALENDAR_LEN(CALENDAR_LEN) |
		V_BCM1480_HSP_RX_CALENDAR_M(CALENDAR_M) |
		V_BCM1480_HSP_RX_ALPHA(4000) |
		0;

	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_1),value);

	    value = V_BCM1480_HSP_TX_MAXBURST1(8) |
		V_BCM1480_HSP_TX_MAXBURST2(4) |
		V_BCM1480_HSP_TX_ACTIVE_CHANNELS(ACTIVE_CHANNELS) |
		V_BCM1480_HSP_TX_CALENDAR_LEN(CALENDAR_LEN) |
		V_BCM1480_HSP_TX_CALENDAR_M(CALENDAR_M) |
		V_BCM1480_HSP_TX_ALPHA(4000) |
		0;

	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CFG_1),value);

	    /* Enable status register */
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_PORT_INT_EN),
		     (M_BCM1480_HSP_TX_INT_TSTATTIMEOUT |
		      M_BCM1480_HSP_TX_INT_DIP2RXERR |
		      M_BCM1480_HSP_TX_INT_SPI4RESET));
		      
	    /* Watch for all RX errors */
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_PORT_INT_EN),
		     (M_BCM1480_HSP_RX_INT_PERVCERR |
		      M_BCM1480_HSP_RX_INT_EOPABORT |
		      M_BCM1480_HSP_RX_INT_SPI4PROTOERR |
		      M_BCM1480_HSP_RX_INT_ESTOREOVERFLOW |
		      M_BCM1480_HSP_RX_INT_ALPHATRAINERR |
		      M_BCM1480_HSP_RX_INT_DIP4ERROR |
		      M_BCM1480_HSP_RX_INT_HRERROR |
		      M_BCM1480_HSP_RX_INT_INTOVERFLOW));


	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	    /* 
	     * Do the RX SPI4 config register.  Be sure to enable divide-by-4 mode
	     * if running < 200Mhz
	     */

	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0));

	    value &= ~(M_BCM1480_HSP_RX_PLL_MULTIPLIER | M_BCM1480_HSP_RX_PLL_DIV_4);

	    if (spi4_mhz < 200) {
		value |= V_BCM1480_HSP_RX_PLL_MULTIPLIER(spi4_pllmult*4) | M_BCM1480_HSP_RX_PLL_DIV_4;
		}
	    else {
		value |= V_BCM1480_HSP_RX_PLL_MULTIPLIER(spi4_pllmult);
		}

	    value &= ~_SB_MAKEMASK1(1);		/* Clear reserved bit */

	    value |= M_BCM1480_HSP_RSTAT_POLARITY;  /* For loopbackEnable either RX or TX rstat polarity, not both */

	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0),value);

	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	    
	    /*
	     * TX SPI4 Training Format Register 
	     */
 
	    /* The following register values makes TX to send some data out!! Please don't change!! */
	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_TRAINING_FMT));
	    value &= ~M_BCM1480_HSP_TX_TXPREFBURSTSZ;
	    value |= V_BCM1480_HSP_TX_TXPREFBURSTSZ(2);
	    value &= ~M_BCM1480_HSP_TX_TXMAXBURSTSZ;
	    value |= V_BCM1480_HSP_TX_TXMAXBURSTSZ(5);
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_TRAINING_FMT),value);
	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_TRAINING_FMT));


	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	    /*
	     * Fix up the calibration registers.  For TX, turn off the "STARTCAL2"
	     * bit.  It shouldn't be set, but it is.  For RX, disable "No Calibration"
	     * mode to allow the RX side to do its calibrations.
	     */

	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_CALIBRATION));
	    value &= ~M_BCM1480_HSP_CAL_STARTCAL2;
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_CALIBRATION),value);

	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_CALIBRATION));
	    value &= ~M_BCM1480_HSP_CAL_NO_CALIB;
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_CALIBRATION),value);

	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	    /*
	     * Do the SPI4 TX Config register 0.  This register contains PLL settings
	     * and error count tolerances.  
	     */

	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CFG_0));
	    value &= ~M_BCM1480_HSP_TX_RST_STATCNT;  
	    value |= V_BCM1480_HSP_TX_RST_STATCNT(0);

	    /*
	     * For the PLL, make sure the ratios are all sane.  If the spi4 clock
	     * is less than 200MHz, be sure to turn on the "divide-by-4" mode
	     * and run the PLL 4x faster.
	     */

	    value &= ~(M_BCM1480_HSP_TX_PLL_MULTIPLIER | M_BCM1480_HSP_TX_TX_PLL_DIV_4);

	    if (spi4_mhz < 200) {
		value |= V_BCM1480_HSP_TX_PLL_MULTIPLIER(spi4_pllmult*4) | M_BCM1480_HSP_TX_TX_PLL_DIV_4;
		}
	    else {
		value |= V_BCM1480_HSP_TX_PLL_MULTIPLIER(spi4_pllmult);
		}

	    /* 
	     * TSTATCLK is 1/4 the SPI clock.  If (TSTATCLK/4)/SWCLK is < 1/4, turn 
	     * on TSTAT slow mode.
	     */
	    if ((spi4_mhz / sw_mhz) < 4) {
		value |= M_BCM1480_HSP_TX_TSTAT_SLOW_MODE;
		}

	    /*  'n' DIP-2 Errors causes TX to go to Link Training */
	    value &= ~M_BCM1480_HSP_TX_DIP2_ERRLIMIT;
	    value |= V_BCM1480_HSP_TX_DIP2_ERRLIMIT(1);
//	    value |= M_BCM1480_HSP_TX_TSTAT_POLARITY;


	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CFG_0),value);

	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	    cfe_usleep(10000);

	    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

            /* 
	     * Bring ports out of reset.
	     */

	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CFG_0));
	    value &= ~M_BCM1480_HSP_TX_PORT_RESET;
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CFG_0),value);

            /* Enable RX Port */	    
	    value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0));
	    value &= ~M_BCM1480_HSP_RX_PORT_RESET;
	    WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0),value);


}

static void pm_free_rings(void)
{
    int idx;

    for (idx = 0; idx < PM_NRINGS; idx++) {
	if (pmi_rings[idx]) pm_free_ring(pmi_rings[idx]);
	if (pmo_rings[idx]) pm_free_ring(pmo_rings[idx]);
	pmi_rings[idx] = NULL;
	pmo_rings[idx] = NULL;
	}
}

static void pm_drain_rings(void)
{
    int idx;
    packet_t *pkt,*tpkt;
    int cnt;

    for (idx = 0; idx < PM_NRINGS; idx++) {
	if (pmo_rings[idx]) {
	    while (pm_dequeue_txbuf(pmo_rings[idx],&pkt)) pm_pkt_free(pkt);
	    }
	if (pmi_rings[idx] && pmo_rings[idx]) {
	    cnt = 0;
	    do {
		cnt = 0;
		while (pm_dequeue_rxbuf(pmi_rings[idx],&pkt)) {
		    pm_add_rxbuf(pmi_rings[idx],pkt); 
		    pm_start_rx(pmi_rings[idx],1);
		    cnt++;
		    }
		/* Keep trying to drain TX buffers while we do this, in case we're
		   in loopback mode and the tx buffers are waiting */
		while (pm_dequeue_txbuf(pmo_rings[idx],&tpkt)) pm_pkt_free(tpkt);
		} while (cnt > 0);
	    }
	}
}

static int ui_cmd_pm_init(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int port;
    int i;
    int j; 
    int cnt;
    sbeth_physaddr_t base_addr, default_path_addr, hr_cfg_addr, 
	hr_rule_type_addr,	tx_next_addr_addr;
    uint64_t value;
    volatile pcireg_t t;      /* used for reads that push writes */
    packet_t *pkt;
    char *x;
    int spi4_pllmult = SPI4_MHZ / (REFCLK / 2);
    uint64_t cpu_mhz;
    uint64_t sw_mhz;
    uint64_t spi4_mhz = SPI4_MHZ;
    int portmask;

    /*
     * Don't let us do this again
     */

    if (pm_ports != 0) {
	printf("The Packet Manager & High-Speed ports are already initialized.\n");
	return -1;
	}

    /*
     * Collect a list of which ports we're going to init
     */

    portmask = 0;
    for (cnt = 0; cnt < 3; cnt++) {
	x = cmd_getarg(cmd,cnt);
	if (x) {
	    j = atoi(x);
	    portmask |= 1<<j;
	    }
	}
    if (portmask == 0) portmask = 0x7;	/* default to all ports */

    pm_ports = portmask;


    if (cmd_sw_value(cmd,"-mhz",&x)) {
	spi4_mhz = atoi(x);
	}

    cpu_mhz = G_BCM1480_SYS_PLL_DIV(READCSR(A_SCD_SYSTEM_CFG)) * (REFCLK/2);
    sw_mhz = cpu_mhz * 2 / G_BCM1480_SYS_SW_DIV(READCSR(A_SCD_SYSTEM_CFG));

    spi4_pllmult = spi4_mhz / (REFCLK/2);

    printf("CPUCLK: %dMHz   SWCLK: %dMHz   SPI4CLK: %dMHz\n",cpu_mhz,sw_mhz,spi4_mhz);


    /*
     * Clean up from a previous invocation
     */

    pm_free_pktpool();
    pm_free_rings();

    pmi_rings[0]  = pm_init_ring(0,PM_RINGSIZE);
    pmi_rings[1]  = pm_init_ring(8,PM_RINGSIZE);
    pmi_rings[2]  = pm_init_ring(16,PM_RINGSIZE);

    pmo_rings[0]  = pm_init_ring(0,PM_RINGSIZE);
    pmo_rings[1]  = pm_init_ring(8,PM_RINGSIZE);
    pmo_rings[2]  = pm_init_ring(16,PM_RINGSIZE);

    pm_init_pktpool();

    if (!pmi_rings[0] || !pmi_rings[1] || !pmi_rings[2] || 
	!pmo_rings[0] || !pmo_rings[1] || !pmo_rings[2] || 
	!pm_pkt_pool) {
	printf("Memory allocation failed\n");
	return -1;
	}

    /*
     * Force the TX ports back into reset state
     */

    for (port = 0; port < 3; port++) {
	if (!(portmask & (1<<port))) continue;		/* skip ports we're not using */
	value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CFG_0));
	value |= M_BCM1480_HSP_TX_PORT_RESET;
	WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_CFG_0),value);
	value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0));
	value |= M_BCM1480_HSP_RX_PORT_RESET;
	WRITECSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0),value);
	}

    /* 
     * Initialize each port, including the H&R Blocks 
     */
    for (port = 0; port < 3; port++) {    

	if (!(portmask & (1<<port))) continue;		/* skip ports we're not using */

	int spi4 = 0;

	value = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0));

	if (G_BCM1480_HSP_LINK_MODE(value) == K_BCM1480_HSP_LINK_MODE_SPI4) {  
	    spi4 = 1;
	    }

	printf("Initializing TX/RX %d (%s)\n",port,spi4 ? "SPI4" : "PoHT");

	/*
	 * Using the # of active channels we're planning to support, carve
	 * up the TX and RX memory to give everyone a share.
	 */

	pm_calc_ramalloc(port,ACTIVE_CHANNELS,spi4);

	/*
	 * If the port is in SPI4 mode, do the SPI4 port initialization.
	 * If the port is in PoHT mode, the HT has already been initialized for us.
	 */

	if (spi4) {
	    pm_init_spi4_port(port,spi4_mhz);
	    }
	    

	/*
	 * Do Hash and Route initialization.
	 */

	base_addr = A_BCM1480_HR_BASE(port);
	default_path_addr = base_addr + R_BCM1480_HR_PATH_DEFAULT;    /* Default Path */
	value = (V_BCM1480_HR_PATH_DATA_DEST(3)  |  /* Destination= PMI */
		 V_BCM1480_HR_PATH_DATA_VC((port*8)&0x0F)    |  /* VC = 0 for TX0, 8 for TX1, 16 for TX2 */   
		 V_BCM1480_HR_PATH_DATA_NDEST(0) |  /* Next_Dest = 0 */
		 V_BCM1480_HR_PATH_TYPE(0));        /* Type = OVC Mode */
	WRITECSR(default_path_addr, value);

	hr_cfg_addr = base_addr + R_BCM1480_HR_CFG;              /* H&R Config Reg */
	value = (V_BCM1480_HR_HEADER_PTR(0)  |                   /* Header Pointer */
		 M_BCM1480_HR_HDR_PTR_IMMD   |                   /* Set Immediate Mode */
		 0);
	WRITECSR(hr_cfg_addr, value);

	hr_rule_type_addr = base_addr + R_BCM1480_HR_RULE_TYPE(0);       /* Rule Type 0 */
	value = (V_BCM1480_HR_RULE_TYPE_WORD_OFST_0(0)  |                /* Header Pointer */    
		 M_BCM1480_HR_RULE_TYPE_SEL_0);                          /* IVC is extracted */
	WRITECSR(hr_rule_type_addr, value);                          

#if 0  /* notused */
	hr_rule_op_addr = base_addr + R_BCM1480_HR_RULE_OP(0);       /* Rule OP 0 */
	value = (V_BCM1480_HR_RULE_OP_ENABLE_3((1<<8)-1));           /* Enable op 3 */
	/*    printf("Write to H&R Rule OP Register. Addr: %p Data: %llx\n", hr_rule_op_addr, value);
	      WRITECSR(hr_rule_op_addr, value);  */

	hr_path_addr = base_addr + R_BCM1480_HR_PATH(0);       /* Path 0 */
	value = (V_BCM1480_HR_ENABLE(0) |                      /* Enable Value */
		 V_BCM1480_HR_TEST(0) |                        /* Test Value */
		 V_BCM1480_HR_PATH_DATA_DEST(3) |              /* Dest= PMI */
		 V_BCM1480_HR_PATH_DATA_VC(0) |                /* VC = 0 */
		 V_BCM1480_HR_PATH_DATA_NDEST(0) |             /* Next_dest = 0 */
		 0);
	/*    printf("Write to H&R Path Register(%d).Addr: %p Data: %llx\n", hr_path_addr, value);
	      WRITECSR(hr_path_addr, value);
	*/
#endif

	if (!spi4) {
	    for (j = 0; j < 8; j++) {
		/* TX Next Addr Register */
		tx_next_addr_addr = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_NEXT_ADDR_REGISTER(j));  
		value =  (V_BCM1480_HSP_TX_NEXT_ADDR_EVEN(0x400000) |        /* Next_Dest(0) = 0x4000_0000 */
			  V_BCM1480_HSP_TX_NEXT_ADDR_ODD(0x400000)  |        /* Next_Dest(1) = 0x4000_0000 */
			  0);
		WRITECSR(tx_next_addr_addr, value);
		}

	    value = 0x40000000;
	    pci_conf_write(BCM1480_LDT_BRIDGE, PCI_MAPREG(1), value);   /* POHT = 0x4000_0000 */
	    /* HT: push the writes */
	    t = pci_conf_read(BCM1480_LDT_BRIDGE, PCI_ID_REG);

	    pci_conf_write(BCM1480_EXTx_BRIDGE(port),0x78,1<<18);
	    }

	}

    /*
     * We have three TX/RX pairs but the switch can only handle 16 channels.
     * The HR_MAPPING register lets us direct inbound packets to specific ranges
     * of PMI queues.
     *
     * Set things up so that for TX0 we have channels 0..7
     *                       for TX1 we have channels 8..15
     *                   and for TX2 we have channels 16..23
     *
     * The only change from the default below is TX2's RX2PMI_MAP_LO.
     * XXX probably don't want to do this for anything except our loopback test.
     */

    WRITECSR(A_BCM1480_HR_REGISTER(0,R_BCM1480_HR_MAPPING),
	     (V_BCM1480_HR_RX2PMI_MAP_LO(K_BCM1480_HR_RX2PMI_MAP_7_0) |
 	      V_BCM1480_HR_RX2PMI_MAP_HI(K_BCM1480_HR_RX2PMI_MAP_15_8)));

    WRITECSR(A_BCM1480_HR_REGISTER(1,R_BCM1480_HR_MAPPING),
	     (V_BCM1480_HR_RX2PMI_MAP_LO(K_BCM1480_HR_RX2PMI_MAP_7_0) |
 	      V_BCM1480_HR_RX2PMI_MAP_HI(K_BCM1480_HR_RX2PMI_MAP_15_8)));

    WRITECSR(A_BCM1480_HR_REGISTER(2,R_BCM1480_HR_MAPPING),
	     (V_BCM1480_HR_RX2PMI_MAP_LO(K_BCM1480_HR_RX2PMI_MAP_23_16) |
 	      V_BCM1480_HR_RX2PMI_MAP_HI(K_BCM1480_HR_RX2PMI_MAP_15_8)));


    /* Set up PMO Map to TX Mapping - everybody PMO channels 0..7 map to the same TX */
    value = (V_BCM1480_PM_MAP_DEST_ID0(0) |
	     V_BCM1480_PM_MAP_DEST_ID8(1) |
	     V_BCM1480_PM_MAP_DEST_ID16(2) |
	     V_BCM1480_PM_MAP_DEST_ID24(2) |  M_BCM1480_PM_MAP_DEST_HALF24 |
	     0);
    WRITECSR(A_BCM1480_PM_PMO_MAPPING, value);


    printf("Initializing PMI and PMO Queues\n");
    for (port = 0; port < 3; port++) {
	pm_init_pmo_queue(pmo_rings[port]);
	pm_init_pmi_queue(pmi_rings[port]);
	}

    /* Initialize The PMI Ring */
    for (port = 0; port < 3; port++) {
	cnt = 0;

	for (i = 0; i < PM_RINGSIZE-1; i++) {
	    pkt = pm_pkt_alloc();
	    if (pkt) cnt += pm_add_rxbuf(pmi_rings[port],pkt);
	    }
	pm_start_rx(pmi_rings[port],cnt);
	}

    /* Display TX/RX calibration, if in SPI4 mode */

    for (port = 0; port < 3; port++) {
	uint64_t reg,txreg,rxreg;

	if (!(portmask & (1<<port))) continue;

	reg = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_CFG_0));

	if (G_BCM1480_HSP_LINK_MODE(reg) == K_BCM1480_HSP_LINK_MODE_SPI4) {  
	    txreg = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_CALIBRATION));
	    rxreg = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_CALIBRATION));
	    printf("SPI4 Status, Port %d:  TX:%s   RX:%s\n",port,
		   (txreg & M_BCM1480_HSP_CAL_CALFIN) ? "Cal_Finished" : "Not_Cal     ",
		   (rxreg & M_BCM1480_HSP_CAL_CALFIN) ? "Cal_Finished" : "Not_Cal     ");
	    }
	}

    
    return 0;

}


static void pm_calc_ramalloc(int txrx,int active,int spi4_mode)
{
    int total_tx_ram,total_rx_ram;
    int per_tx_channel,per_rx_channel;
    int i;
    int cur_floor;
    uint64_t ramalloc[8];
    uint64_t phitcnt[4];
    uint64_t watermark[8];
    int almostfull,almostempty;

    /* XXX calculate the total at runtime by looking at what HT init left behind */

    total_rx_ram = 1024 - 256;		/* number of 16-byte blocks */
    total_tx_ram = 256 - 64;			/* number of 16-byte blocks */

    per_tx_channel = total_tx_ram / active;
    per_rx_channel = total_rx_ram / active;

    /*
     * Set the "almost full" watermark to 512 bytes (32 blocks) or 1/2 the
     * per channel allocation, whichever is smaller.  Set the "almost empty"
     * watermark to 1/4 the allocation.
     */

    almostfull = per_rx_channel / 2;
    if (almostfull > 32) almostfull = per_rx_channel - 32;

    almostempty = per_rx_channel / 4;

    /* This shouldn't happen, but we want to prevent the chip from going insane. */
    if (almostempty > almostfull) almostempty = almostfull / 2;


#ifdef _PM_DEBUG_
    printf("** TX: alloc=%d    RX: alloc=%d full=%d empty=%d\n",per_tx_channel,
	   per_rx_channel,almostfull,almostempty);
#endif

    /*
     * Do RX side
     */

    cur_floor = 0;
    memset(ramalloc,0,sizeof(ramalloc));
    memset(phitcnt,0,sizeof(phitcnt));
    memset(watermark,0,sizeof(watermark));

    for (i = 0; i < active; i++) {
	switch (i & 1) {
	    case 0:
		ramalloc[i/2] |= V_BCM1480_HSP_RX_RAMCEILING_0(cur_floor+per_rx_channel-1)|
		    V_BCM1480_HSP_RX_RAMFLOOR_0(cur_floor);
		break;
	    case 1:
		ramalloc[i/2] |= V_BCM1480_HSP_RX_RAMCEILING_1(cur_floor+per_rx_channel-1)|
		    V_BCM1480_HSP_RX_RAMFLOOR_1(cur_floor);
		break;
	    }

	switch (i & 1) {
	    case 0:
		watermark[i/2] |= V_BCM1480_HSP_RX_ALMOSTEMPTY_EVEN(almostempty) |
		    V_BCM1480_HSP_RX_ALMOSTFULL_EVEN(almostfull);
		break;
	    case 1:
		watermark[i/2] |= V_BCM1480_HSP_RX_ALMOSTEMPTY_ODD(almostempty) |
		    V_BCM1480_HSP_RX_ALMOSTFULL_ODD(almostfull);
		break;
	    }

	switch (i & 3) {
	    case 0:
		phitcnt[i/4] |= V_BCM1480_HSP_RX_PHITCNT_0(per_rx_channel/4);
		break;
	    case 1:
		phitcnt[i/4] |= V_BCM1480_HSP_RX_PHITCNT_1(per_rx_channel/4);
		break;
	    case 2:
		phitcnt[i/4] |= V_BCM1480_HSP_RX_PHITCNT_2(per_rx_channel/4);
		break;
	    case 3:
		phitcnt[i/4] |= V_BCM1480_HSP_RX_PHITCNT_3(per_rx_channel/4);
		break;
	    }

	cur_floor += per_rx_channel;

	}

    /*
     * Now transfer these calculations into the RX registers.
     */

    for (i = 0; i < 8; i++) {
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_PKT_RAMALLOC(i)),ramalloc[i]);
	}

    for (i = 0; i < 8; i++) {
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI_WATERMARK(i)),watermark[i]);
	}

    for (i = 0; i < 4; i++) {
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_PKT_RXPHITCNT(i)),phitcnt[i]);
	}

    /*
     * Now do the TX side.
     */


    cur_floor = 0;
    memset(ramalloc,0,sizeof(ramalloc));
    memset(phitcnt,0,sizeof(phitcnt));

    for (i = 0; i < active; i++) {
	if (i & 1) {
	    ramalloc[i/2] |= V_BCM1480_HSP_TX_RAMCEILING_1(cur_floor+per_tx_channel-1)|
		V_BCM1480_HSP_TX_RAMFLOOR_1(cur_floor);
	    }
	else {
	    ramalloc[i/2] |= V_BCM1480_HSP_TX_RAMCEILING_0(cur_floor+per_tx_channel-1)|
		V_BCM1480_HSP_TX_RAMFLOOR_0(cur_floor);
	    }

	switch (i & 3) {
	    case 0:
		phitcnt[i/4] |= V_BCM1480_HSP_TX_PHITCNT_0(per_tx_channel);
		break;
	    case 1:
		phitcnt[i/4] |= V_BCM1480_HSP_TX_PHITCNT_1(per_tx_channel);
		break;
	    case 2:
		phitcnt[i/4] |= V_BCM1480_HSP_TX_PHITCNT_2(per_tx_channel);
		break;
	    case 3:
		phitcnt[i/4] |= V_BCM1480_HSP_TX_PHITCNT_3(per_tx_channel);
		break;
	    }

	cur_floor += per_tx_channel;

	}


    /*
     * Now transfer these calculations into the TX registers.
     */

    for (i = 0; i < 8; i++) {
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_PKT_RAMALLOC(i)),ramalloc[i]);
	}

    for (i = 0; i < 4; i++) {
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_PKT_TXPHITCNT(i)),phitcnt[i]);
	}

}

static int ui_cmd_pm_newinit(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int i;
    int j; 
    int cnt;
    /*  int buf_size;*/
    sbeth_physaddr_t base_addr, 
	tx_next_addr_addr;
    uint64_t value;
    volatile pcireg_t t;      /* used for reads that push writes */
    packet_t *pkt;
    char *x;
    int txrx;
    int spi4_pllmult = SPI4_MHZ / (REFCLK / 2);
    uint64_t cpu_mhz;
    uint64_t sw_mhz;
    uint64_t spi4_mhz = SPI4_MHZ;
    int spi4_mode = 0;

    /*
     * Make sure we haven't done this before 
     */

    if (pm_ports) {
	printf("The Packet Manager & High-Speed ports are already initialized.\n");
	return -1;
	}

    /*
     * Command line args
     */

    if ((x = cmd_getarg(cmd,0))) txrx = atoi(x);
    else return ui_showusage(cmd);

    printf("** PM_INIT: initialize port %d\n",txrx);

    pm_ports = 1<<txrx;

    if (cmd_sw_value(cmd,"-mhz",&x)) {
	spi4_mhz = atoi(x);
	}

    cpu_mhz = G_BCM1480_SYS_PLL_DIV(READCSR(A_SCD_SYSTEM_CFG)) * (REFCLK/2);
    sw_mhz = cpu_mhz * 2 / G_BCM1480_SYS_SW_DIV(READCSR(A_SCD_SYSTEM_CFG));

    spi4_pllmult = spi4_mhz / (REFCLK/2);

    printf("** CPUCLK: %dMHz   SWCLK: %dMHz   SPI4CLK: %dMHz\n",cpu_mhz,sw_mhz,spi4_mhz);

    /*
     * Create descriptor rings and packet pool.
     */

    pm_init_pktpool();

    for (i = 0; i < ACTIVE_CHANNELS; i++) {
	pmi_rings[i] = pm_init_ring(i,PM_RINGSIZE);
	}

    for (i = 0; i < ACTIVE_CHANNELS; i++) {
	pmo_rings[i] = pm_init_ring(i,PM_RINGSIZE);
	}


    /*
     * Force the TX ports back into reset state
     */

    value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CFG_0));
    value |= M_BCM1480_HSP_TX_PORT_RESET;
    WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CFG_0),value);
    value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_0));
    value |= M_BCM1480_HSP_RX_PORT_RESET;
    WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_0),value);


    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    printf("Initializing H&R\n");

    base_addr = A_BCM1480_HR_BASE(txrx);

    /* Default path for stragglers is PMI queue zero */

    value = (V_BCM1480_HR_PATH_DATA_DEST(3)  |  /* Destination= PMI */
	     V_BCM1480_HR_PATH_DATA_VC(0)    |  
	     V_BCM1480_HR_PATH_DATA_NDEST(3) |  /* Next_Dest = PMI */
	     V_BCM1480_HR_PATH_TYPE(0));        /* Type = OVC Mode */
    WRITECSR(base_addr + R_BCM1480_HR_PATH_DEFAULT, value);	   

#if 1
    /* debug: route all unused entries to PMI */
    for (i = 0; i < 16; i++) {
	WRITECSR(base_addr + R_BCM1480_HR_PATH(i),
		 V_BCM1480_HR_PATH_DATA_DEST(3));
	}

    for (i = 0; i < ACTIVE_CHANNELS; i++) {
	value = V_BCM1480_HR_RULE_OP_OPERAND_3(i) |
	    V_BCM1480_HR_RULE_OP_ENABLE_3(0x0F);

	WRITECSR(base_addr+R_BCM1480_HR_RULE_OP(i),value);

	value = V_BCM1480_HR_RULE_TYPE_WORD_OFST_0(0) |
	    M_BCM1480_HR_RULE_TYPE_SEL_0;

	WRITECSR(base_addr+R_BCM1480_HR_RULE_TYPE(i),value);

	value = V_BCM1480_HR_ENABLE(1 << i) |
	    V_BCM1480_HR_TEST(1 << i) |
	    V_BCM1480_HR_PATH_TYPE(K_BCM1480_HR_PATH_TYPE_OVC) |
	    V_BCM1480_HR_PATH_DATA_DEST(3) | 	/* PMI */
	    V_BCM1480_HR_PATH_DATA_VC(i);

	WRITECSR(base_addr+R_BCM1480_HR_PATH(i),value);
	}
#else
    WRITECSR(base_addr + R_BCM1480_HR_RULE_TYPE(0),M_BCM1480_HR_RULE_TYPE_SEL_0);
#endif

    /* H&R Config Register */

    value = (V_BCM1480_HR_HEADER_PTR(0)  |                   /* Header Pointer */
	     M_BCM1480_HR_HDR_PTR_IMMD   |                   /* Set Immediate Mode */
	     /*   M_BCM1480_HR_SELECT_PTNUM_TO_TAG |
		  M_BCM1480_HR_PT_UNMATCH_ENABLE |
		  M_BCM1480_HR_PT_MULTIMATCH_ENABLE |  */
	     0);
    WRITECSR(base_addr + R_BCM1480_HR_CFG, value);

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */


    /*
     * Figure out if we're going to be in SPI4 mode or not.
     */


    value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_0));

    if (G_BCM1480_HSP_LINK_MODE(value) == K_BCM1480_HSP_LINK_MODE_SPI4) {  
	printf("** Link %d is in SPI-4 Mode.  Initializing port.\n",txrx);
	spi4_mode = 1;
	}


    /*
     * Allocate RAM buffers.  Divide the buffers among the active channels.
     */

    pm_calc_ramalloc(txrx,ACTIVE_CHANNELS,spi4_mode);

    /* 
     * Initialize the port.  If in SPI4 mode, do all the SPI4 init
     * stuff.
     */

    if (spi4_mode) {

	/*
	 * Set up a default calendar.  We may not use all the entries, but
	 * we'll put the whole schedule here and configure the number of 
	 * active channels to use some or all of it.
	 * 
	 * The default calendar configures each slot to go with its 
	 * corresponding VC. 
	 */

	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CALENDAR_0),
		 0x0706050403020100LL);
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CALENDAR_1),
		 0x0F0E0D0C0B0A0908LL);

	/*
	 * Enable the calendar.  The CALENDAR_LEN and CALENDAR_M parameters
	 * are related to what's on the other side of the link.
	 */

	value = V_BCM1480_HSP_TX_MAXBURST1(8) |
	    V_BCM1480_HSP_TX_MAXBURST2(4) |
	    V_BCM1480_HSP_TX_ACTIVE_CHANNELS(ACTIVE_CHANNELS) |
	    V_BCM1480_HSP_TX_CALENDAR_LEN(CALENDAR_LEN) |
	    V_BCM1480_HSP_TX_CALENDAR_M(CALENDAR_M) |
	    V_BCM1480_HSP_TX_ALPHA(4000) |
	    0;

	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CFG_1),value);

	/* Enable status register */
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_PORT_INT_EN),
		 (M_BCM1480_HSP_TX_INT_TSTATTIMEOUT |
		  M_BCM1480_HSP_TX_INT_DIP2RXERR |
		  M_BCM1480_HSP_TX_INT_SPI4RESET));
		      
	/* Watch for all RX errors */
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_PORT_INT_EN),
		 (M_BCM1480_HSP_RX_INT_PERVCERR |
		  M_BCM1480_HSP_RX_INT_EOPABORT |
		  M_BCM1480_HSP_RX_INT_SPI4PROTOERR |
		  M_BCM1480_HSP_RX_INT_ESTOREOVERFLOW |
		  M_BCM1480_HSP_RX_INT_ALPHATRAINERR |
		  M_BCM1480_HSP_RX_INT_DIP4ERROR |
		  M_BCM1480_HSP_RX_INT_HRERROR |
		  M_BCM1480_HSP_RX_INT_INTOVERFLOW));
		      

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	/* 
	 * Do the RX SPI4 config register.  Be sure to enable divide-by-4 mode
	 * if running < 200Mhz
	 */

	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CALENDAR_0),
		 0x0706050403020100LL);
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CALENDAR_1),
		 0x0F0E0D0C0B0A0908LL);

	value = V_BCM1480_HSP_RX_CALENDAR_LEN(CALENDAR_LEN) |
	    V_BCM1480_HSP_RX_CALENDAR_M(CALENDAR_M) |
	    V_BCM1480_HSP_RX_ALPHA(4000) |
	    0;

	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_1),value);

	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_0));

	value &= ~(M_BCM1480_HSP_RX_PLL_MULTIPLIER | M_BCM1480_HSP_RX_PLL_DIV_4);

	if (spi4_mhz < 200) {
	    value |= V_BCM1480_HSP_RX_PLL_MULTIPLIER(spi4_pllmult*4) | M_BCM1480_HSP_RX_PLL_DIV_4;
	    }
	else {
	    value |= V_BCM1480_HSP_RX_PLL_MULTIPLIER(spi4_pllmult);
	    }

	value &= ~_SB_MAKEMASK1(1);		/* Clear reserved bit */

	value |= M_BCM1480_HSP_RSTAT_POLARITY;  /* For loopbackEnable either RX or TX rstat polarity, not both */

	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_0),value);

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	    
	/*
	 * TX SPI4 Training Format Register 
	 */
 
	/* The following register values makes TX to send some data out!! Please don't change!! */
	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_TRAINING_FMT));
	value &= ~M_BCM1480_HSP_TX_TXPREFBURSTSZ;
	value |= V_BCM1480_HSP_TX_TXPREFBURSTSZ(2);
	value &= ~M_BCM1480_HSP_TX_TXMAXBURSTSZ;
	value |= V_BCM1480_HSP_TX_TXMAXBURSTSZ(5);
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_TRAINING_FMT),value);
	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_TRAINING_FMT));


	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	/*
	 * Fix up the calibration registers.  For TX, turn off the "STARTCAL2"
	 * bit.  It shouldn't be set, but it is.  For RX, disable "No Calibration"
	 * mode to allow the RX side to do its calibrations.
	 */

	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_CALIBRATION));
	value &= ~M_BCM1480_HSP_CAL_STARTCAL2;
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_CALIBRATION),value);

	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_CALIBRATION));
	value &= ~M_BCM1480_HSP_CAL_NO_CALIB;
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_CALIBRATION),value);

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	/*
	 * Do the SPI4 TX Config register 0.  This register contains PLL settings
	 * and error count tolerances.  
	 */

	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CFG_0));
	value &= ~M_BCM1480_HSP_TX_RST_STATCNT;  
	value |= V_BCM1480_HSP_TX_RST_STATCNT(0);

	/*
	 * For the PLL, make sure the ratios are all sane.  If the spi4 clock
	 * is less than 200MHz, be sure to turn on the "divide-by-4" mode
	 * and run the PLL 4x faster.
	 */

	value &= ~(M_BCM1480_HSP_TX_PLL_MULTIPLIER | M_BCM1480_HSP_TX_TX_PLL_DIV_4);

	if (spi4_mhz < 200) {
	    value |= V_BCM1480_HSP_TX_PLL_MULTIPLIER(spi4_pllmult*4) | M_BCM1480_HSP_TX_TX_PLL_DIV_4;
	    }
	else {
	    value |= V_BCM1480_HSP_TX_PLL_MULTIPLIER(spi4_pllmult);
	    }

	/* 
	 * TSTATCLK is 1/4 the SPI clock.  If (TSTATCLK/4)/SWCLK is < 1/4, turn 
	 * on TSTAT slow mode.
	 */
	if ((spi4_mhz / sw_mhz) < 4) {
	    value |= M_BCM1480_HSP_TX_TSTAT_SLOW_MODE;
	    }

	/*  'n' DIP-2 Errors causes TX to go to Link Training */
	value &= ~M_BCM1480_HSP_TX_DIP2_ERRLIMIT;
	value |= V_BCM1480_HSP_TX_DIP2_ERRLIMIT(1);
//	    value |= M_BCM1480_HSP_TX_TSTAT_POLARITY;


	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CFG_0),value);

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	cfe_usleep(10000);

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	/* 
	 * Bring ports out of reset.
	 */

	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CFG_0));
	value &= ~M_BCM1480_HSP_TX_PORT_RESET;
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_SPI4_CFG_0),value);

	/* Enable RX Port */	    
	value = READCSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_0));
	value &= ~M_BCM1480_HSP_RX_PORT_RESET;
	WRITECSR(A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_RX_SPI4_CFG_0),value);

	}
	    

    /*
     * In PoHT mode, we need to configure the HT address that packets will be written to, 
     * and also the corresponding BAR in the bridge to listen for packets at that address.
     */

    if (!spi4_mode) {
	printf("Write to TX0 Next_Addr Register\n");
	for (j = 0; j < 7; j++) {
	    tx_next_addr_addr = A_BCM1480_HSP_REGISTER(txrx,R_BCM1480_HSP_TX_NEXT_ADDR_REGISTER(j));  /* TX Next Addr Register */
	    value =  (V_BCM1480_HSP_TX_NEXT_ADDR_EVEN(0x400000) |        /* Next_Dest(0) = 0x4000_0000 */
		      V_BCM1480_HSP_TX_NEXT_ADDR_ODD(0x400000)  |        /* Next_Dest(1) = 0x4000_0000 */
		      0);
	    WRITECSR(tx_next_addr_addr, value);
	    }

	value = 0x40000000;
	printf("Write to PoHT Bar: Data: %p\n", value);
	pci_conf_write(BCM1480_LDT_BRIDGE, PCI_MAPREG(1), value);   /* POHT = 0x4000_0000 */
	/* HT: push the writes */
	t = pci_conf_read(BCM1480_LDT_BRIDGE, PCI_ID_REG);

	switch (i) {
	    case 0:
		pci_conf_write(BCM1480_EXT0_BRIDGE,0x78,1<<18);
		break;
	    case 1:
		pci_conf_write(BCM1480_EXT1_BRIDGE,0x78,1<<18);
		break;   
	    case 2:
		pci_conf_write(BCM1480_EXT2_BRIDGE,0x78,1<<18);
		break;
	    }
	}


    /*
     * Set up PMO Map to TX Mapping -- since this init routine assumes we're going to use only
     * one port for all our queues, it just maps the other two ports away from the one
     * we're interested in.
     *
     * PMO queues 0..n are mapped to the physical port we're interested in.  
     *
     * It is UNDEFINED if we try to map two TX ports to the same PMO queues, danger!
     */

    switch (txrx) {
	default:
	case 0:
	    value = (V_BCM1480_PM_MAP_DEST_ID0(0) |
		     V_BCM1480_PM_MAP_DEST_ID8(0) | M_BCM1480_PM_MAP_DEST_HALF8 |
		     V_BCM1480_PM_MAP_DEST_ID16(1) |
		     V_BCM1480_PM_MAP_DEST_ID24(2) |
		     0);
	    break;

	case 1:
	    value = (V_BCM1480_PM_MAP_DEST_ID0(1) |
		     V_BCM1480_PM_MAP_DEST_ID8(1) | M_BCM1480_PM_MAP_DEST_HALF8 |
		     V_BCM1480_PM_MAP_DEST_ID16(0) |
		     V_BCM1480_PM_MAP_DEST_ID24(2) |
		     0);
	    break;

	case 2:
	    value = (V_BCM1480_PM_MAP_DEST_ID0(2) |
		     V_BCM1480_PM_MAP_DEST_ID8(2) | M_BCM1480_PM_MAP_DEST_HALF8 |
		     V_BCM1480_PM_MAP_DEST_ID16(0) |
		     V_BCM1480_PM_MAP_DEST_ID24(1) |
		     0);
	    break;
	}
    WRITECSR(A_BCM1480_PM_PMO_MAPPING, value);



    printf("Initialize PMO Queues\n");
    for (i = 0; i < ACTIVE_CHANNELS; i++) {
	pm_init_pmo_queue(pmo_rings[i]);
	}

    printf("Initialize PMI Queues\n");
    for (i = 0; i < ACTIVE_CHANNELS; i++) {
	pm_init_pmi_queue(pmi_rings[i]);
	}

    /* Initialize The PMI Rings */
    for (i = 0; i < ACTIVE_CHANNELS; i++) {
	cnt = 0;
	for (j = 0; j < PM_RINGSIZE-1; j++) {
	    pkt = pm_pkt_alloc();
	    if (pkt) cnt += pm_add_rxbuf(pmi_rings[i],pkt);
	    }
	pm_start_rx(pmi_rings[i],cnt);
	}

    return 0;

}

static void fillpkt(packet_t *pkt,uint8_t sernum)
{
    int idx;

    pkt->pkt[0] = pkt->len >> 8;
    pkt->pkt[1] = pkt->len & 0xFF;
    for (idx = 2; idx < pkt->len; idx++) {
	pkt->pkt[idx] = sernum;
	sernum++;
	}
}

static int checkpkt(packet_t *pkt)
{
    unsigned int len;
    int idx;
    uint8_t sernum;

    len = ((unsigned int)pkt->pkt[0] << 8) + (unsigned int) (pkt->pkt[1]);
    if (len != pkt->len) {
	printf("Garbled length data in packet\n");
	return -1;
	}

    sernum = pkt->pkt[2];		/* get seed */
    for (idx = 3; idx < len; idx++) {
	sernum++;
	if (pkt->pkt[idx] != sernum) {
	    printf("Packet data was corrupted\n");
	    return -1;
	    }
	}

    return 0;
}

static int ui_cmd_pm_echotest(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int i;
    packet_t *pkt;
    uint64_t rxcnt = 0;
    int statcnt = 0;
    int pktlen;
    int randlen;
    char *x;
    static pmring_t *_pmi_rings[3];
    static pmring_t *_pmo_rings[3];
    static int ring_txrx[3];
    static int echo_counts[3];
    static int echo_sends[3];
    static uint8_t pkt_sernums[3];
    int nrings = 0;
    int ridx;
    int idx;
    uint64_t cpu_mhz;
    uint64_t start_time,end_time;
    int running = 1;
    int max_in_flight = 5;
    int max_sends = 100000;
    int rings_done;
    cfe_timer_t timer;
    int portmask = 0;
    int checkdata;

    cpu_mhz = G_BCM1480_SYS_PLL_DIV(READCSR(A_SCD_SYSTEM_CFG)) * (REFCLK/2);

    for (idx = 0; idx < 3; idx++) {
	x = cmd_getarg(cmd,idx);
	if (!x) break;
	i = atoi(x);
	portmask |= (1<<i);
	}
    if (portmask == 0) portmask = 0x7;		/* default to all ports */

    portmask &= pm_ports;

    nrings = 0;
    for (idx = 0; idx < 3; idx++) {
	if (portmask & (1<<idx)) {
	    ring_txrx[nrings] = idx;
	    _pmi_rings[nrings] = pmi_rings[idx];
	    _pmo_rings[nrings] = pmo_rings[idx];
	    nrings++;
	    }
	}


    echo_counts[0] = 0;
    echo_counts[1] = 0;
    echo_counts[2] = 0;
    echo_sends[0] = 0;
    echo_sends[1] = 0;
    echo_sends[2] = 0;
    pkt_sernums[0] = 0;
    pkt_sernums[1] = 0;
    pkt_sernums[2] = 0;

    if (nrings == 0) {
	return ui_showusage(cmd);
	}

    pktlen = 512; //PKTSIZE;
    if (cmd_sw_value(cmd,"-len",&x)) pktlen = atoi(x);
    randlen = cmd_sw_isset(cmd,"-randlen");

    if (cmd_sw_value(cmd,"-batch",&x)) max_in_flight = atoi(x);
    if (max_in_flight == 0) max_in_flight = 1;

    if (cmd_sw_value(cmd,"-count",&x)) max_sends = atoi(x);
    if (max_sends == 0) max_sends = 1;

    checkdata = cmd_sw_isset(cmd,"-checkdata");

    if (max_in_flight > max_sends) max_in_flight = max_sends;

    if (!pm_ports) {
	printf("PM not initialized.  do 'pm init' first.\n");
	return -1;
	}

    /* Drain pending TX completes and refill RX rings */
    pm_drain_rings();

    running = 1;
    start_time = SBREADCSR(A_BCM1480_SCD_ZBBUS_CYCLE_COUNT);


    /* Prime the TX rings with some data to send */

    for (ridx = 0; ridx < nrings; ridx++) {
	int num2add = max_in_flight-_pmo_rings[ridx]->onring;
	int addcnt = 0;

	/* If there's room on the TX ring, put  something there. */
	for (idx = 0; idx < num2add; idx++) {
	    pkt = pm_pkt_alloc();
	    if (!pkt) break;
	    pkt->len = randlen ? (16+(rand() % (PKTSIZE-16))) : pktlen;
	    if (checkdata) {
		fillpkt(pkt,pkt_sernums[ridx]);
		pkt_sernums[ridx]++;
		}
	    pm_add_txbuf(_pmo_rings[ridx],pkt);
	    addcnt++;
	    }
	/* Tell PMO that there are new packets */
	pm_start_tx(_pmi_rings[ridx],addcnt);
	echo_sends[ridx] += addcnt;
	}

    rings_done = 0;

    TIMER_SET(timer,CFE_HZ*3);

    while (running) {
	for (ridx = 0; ridx < nrings; ridx++) {
	    /* If a tx completed, send it again if we're still echoing, else free it. */
	    if (pm_dequeue_txbuf(_pmo_rings[ridx],&pkt)) {
		pkt->len = randlen ? (16+(rand() % (PKTSIZE-16))) : pktlen;
		if (checkdata) {
		    fillpkt(pkt,pkt_sernums[ridx]);
		    pkt_sernums[ridx]++;
		    }
		if (echo_sends[ridx] < max_sends) {
		    pm_add_txbuf(_pmo_rings[ridx],pkt);
		    pm_start_tx(_pmi_rings[ridx],1);
		    echo_sends[ridx]++;
		    }
		else {
		    pm_pkt_free(pkt);
		    }
		}
	    /* If an rx completed, put it back on the receive ring */
	    if (pm_dequeue_rxbuf(_pmi_rings[ridx],&pkt)) {
		if (checkdata) {
		    if (checkpkt(pkt) < 0) running = 0;
		    }
		pm_add_rxbuf(_pmi_rings[ridx],pkt);
		pm_start_rx(_pmi_rings[ridx],1);
		echo_counts[ridx]++;
		if (echo_counts[ridx] == max_sends) {
		    rings_done |= (1<<ridx);
		    }
		rxcnt++;
		if ((rxcnt % 1000000) == 0) printf("%lld\n",rxcnt);
		}
	    }

	/* Poll the console every now and then */
	statcnt++;
	if (statcnt > 100000) {
	    POLL();
	    if (console_status()) {
		running = 0;
		break;
		}
	    statcnt = 0;
	    }
	if (rings_done == (1<<nrings)-1) break;
	if (TIMER_EXPIRED(timer)) break;
	}

    end_time = SBREADCSR(A_BCM1480_SCD_ZBBUS_CYCLE_COUNT);


    for (ridx = 0; ridx < nrings; ridx++) {
	char *passfail = "FAIL";

	if ((echo_sends[ridx] == max_sends) && (echo_counts[ridx] == max_sends)) {
	    passfail = "PASS";
	    }

	printf("%s  TX/RX%d:   TX:%6d   RX:%6d\n",
	       passfail,
	       ring_txrx[ridx],
	       echo_sends[ridx],
	       echo_counts[ridx]);
	}


    return 0;

}

  
static int ui_cmd_pm_test(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int i,idx;
    int num_to_send = PM_RINGSIZE;
    packet_t *pkt;
    int cont;
    uint64_t rxcnt = 0;
    int statcnt = 0;
    int rxonly;
    int pktlen;
    int randlen;
    int dump;
    char *x;
    static pmring_t *_pmi_rings[3];
    static pmring_t *_pmo_rings[3];
    static uint64_t echo_counts[3];
    int nrings = 0;
    int ridx;
    int cnt;
    uint64_t cpu_mhz;
    int portmask = 0;

    cpu_mhz = G_BCM1480_SYS_PLL_DIV(READCSR(A_SCD_SYSTEM_CFG)) * (REFCLK/2);

    rxonly = cmd_sw_isset(cmd,"-recv");

    for (idx = 0; idx < 3; idx++) {
	x = cmd_getarg(cmd,idx);
	if (!x) break;
	i = atoi(x);
	portmask |= (1<<i);
	}
    if (portmask == 0) portmask = 0x7;		/* default to all ports */

    portmask &= pm_ports;

    nrings = 0;
    for (idx = 0; idx < 3; idx++) {
	if (portmask & (1<<idx)) {
	    _pmi_rings[nrings] = pmi_rings[idx];
	    _pmo_rings[nrings] = pmo_rings[idx];
	    nrings++;
	    }
	}

    echo_counts[0] = 0;
    echo_counts[1] = 0;
    echo_counts[2] = 0;

    if (nrings == 0) {
	return ui_showusage(cmd);
	}

    pktlen = 64; //PKTSIZE;
    if (cmd_sw_value(cmd,"-len",&x)) pktlen = atoi(x);
    randlen = cmd_sw_isset(cmd,"-randlen");

    dump = cmd_sw_isset(cmd,"-dump");

    cont = rxonly || cmd_sw_isset(cmd,"-continuous");    

    num_to_send = 5;
    if (cmd_sw_value(cmd,"-count",&x)) num_to_send = atoi(x);
    if (num_to_send > (PM_RINGSIZE-1)) num_to_send = PM_RINGSIZE-1;

    if (!pm_ports) {
	printf("PM not initialized.  do 'pm init' first.\n");
	return -1;
	}

    /* Drain pending TX completes and refill RX rings */
    pm_drain_rings();

    cnt = 0;
    if (!rxonly) {
	printf("Sending packets...\n");
	for (ridx = 0; ridx < nrings; ridx++) {
	    for (i = 0; i < num_to_send; i++) {
		pkt = pm_pkt_alloc();
		if (pkt) {
		    memcpy(pkt->pkt,"\xff\xff\xff\xff\xff\xff\x02\x00\x00\x11\x11\x11\x12\x34"
			   "\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33",32);
		    pkt->len = pktlen;
		    pm_add_txbuf(_pmo_rings[ridx],pkt);
		    }
		}
	    pm_start_tx(_pmo_rings[ridx],num_to_send);
	    cnt += num_to_send;
	    }
	printf("Sent %d packets on %d queues\n",cnt,nrings);
	}


    if (cont) {
	uint64_t start_time,end_time;
	uint64_t rate,ttlbits;
	int running = 1;

	start_time = SBREADCSR(A_BCM1480_SCD_ZBBUS_CYCLE_COUNT);

	while (running) {
	    for (ridx = 0; ridx < nrings; ridx++) {
		if (!rxonly) {
		    /* If a tx completed, send it again */
		    if (pm_dequeue_txbuf(_pmo_rings[ridx],&pkt)) {
			pkt->len = randlen ? (16+(rand() % (PKTSIZE-16))) : pktlen;
			pm_add_txbuf(_pmo_rings[ridx],pkt);
			pm_start_tx(_pmi_rings[ridx],1);
			}
		    }
		/* If an rx completed, put it back on the receive ring */
		if (pm_dequeue_rxbuf(_pmi_rings[ridx],&pkt)) {
		    if (dump) {
			printf("## Ring %d: Packet Received, len=%d\n",ridx,pkt->len);
			dumpmem((hsaddr_t)(long)pkt->pkt,(hsaddr_t)(long)pkt->pkt,pkt->len,4);
			}
		    pm_add_rxbuf(_pmi_rings[ridx],pkt);
		    pm_start_rx(_pmi_rings[ridx],1);
		    echo_counts[ridx]++;
		    rxcnt++;
		    if ((rxcnt % 1000000) == 0) printf("%lld\n",rxcnt);
		    }
		}

	    statcnt++;
	    if (statcnt > 100000) {
		if (console_status()) {
		    running = 0;
		    break;
		    }
		statcnt = 0;
		}
	    }

	end_time = SBREADCSR(A_BCM1480_SCD_ZBBUS_CYCLE_COUNT);

	printf("%lld packets (%lld bytes) transferred in %lld ZClks\n",rxcnt,
	       rxcnt*pktlen,end_time-start_time);

	ttlbits = rxcnt*pktlen*8;

	/* Zclk counts at 1 tick per 2 core clocks, or at cpu_mhz/2 */

	rate = (ttlbits * (cpu_mhz/2)) /  (end_time - start_time);

	printf("Rate: %lld Mbits/s,  %lld pkts/sec\n",rate,(rxcnt * 250000000)/(end_time-start_time));

	for (ridx = 0; ridx < nrings; ridx++) {
	    printf("echo_counts[%d] = %llu\n",ridx,echo_counts[ridx]);
	    }

	}

    else {
	printf("Receiving packets...\n");
	
	for (ridx = 0; ridx < nrings; ridx++) {
	    while (cnt > 0) {
		if (console_status()) break;
		if (pm_dequeue_rxbuf(_pmi_rings[ridx],&pkt)) {
		    if (dump) {
			printf("## Packet Received, len=%d\n",pkt->len);
			dumpmem((hsaddr_t)(long)pkt->pkt,(hsaddr_t)(long)pkt->pkt,pkt->len,4);
			}
		    cnt--;
		    pm_add_rxbuf(_pmi_rings[ridx],pkt);
		    pm_start_rx(_pmi_rings[ridx],1);
		    }
		}
	    }

	if ((cnt == 0) && (ridx == nrings)) printf("All packets were received\n");
	}


    return 0;
}


static int ui_cmd_pm_newtest(ui_cmdline_t *cmd,int argc,char *argv[])
{
    packet_t *pkt;
    uint64_t rxcnt = 0;
    int statcnt = 0;
    uint64_t rxbytes = 0;
    int dump,sum;
    int ridx;

    dump = cmd_sw_isset(cmd,"-dump");
    sum = cmd_sw_isset(cmd,"-sum");

    uint64_t start_time,end_time;
    uint64_t ttlbytes,rate;
    int running = 1;

    start_time = SBREADCSR(A_BCM1480_SCD_ZBBUS_CYCLE_COUNT);

    while (running) {
	for (ridx = 0; ridx < ACTIVE_CHANNELS; ridx++) {
	    /* If an rx completed, put it back on the receive ring */
	    if (pm_dequeue_rxbuf(pmi_rings[ridx],&pkt)) {
		if (dump || sum) {
		    printf("## Ring %d: Packet Received, len=%d\n",ridx,pkt->len);
		    if (dump) dumpmem((hsaddr_t)(long)pkt->pkt,(hsaddr_t)(long)pkt->pkt,pkt->len,4);
		    }
		rxbytes += pkt->len;
		pm_add_rxbuf(pmi_rings[ridx],pkt);
		pm_start_rx(pmi_rings[ridx],1);
		rxcnt++;
		if ((rxcnt % 1000000) == 0) printf("%lld\n",rxcnt);
		}
	    }

	statcnt++;
	if (statcnt > 100000) {
	    if (console_status()) {
		running = 0;
		break;
		}
	    statcnt = 0;
	    }
	}

    end_time = SBREADCSR(A_BCM1480_SCD_ZBBUS_CYCLE_COUNT);

    ttlbytes = rxbytes;

    printf("%lld packets (%lld bytes) transferred in %lld ZClks\n",rxcnt,
	   ttlbytes,end_time-start_time);

    rate = (ttlbytes * 250LL) /  (end_time - start_time);

    printf("Rate: %lld Mb/s,  %lld pkts/sec\n",rate,(rxcnt * 250000000)/(end_time-start_time));

    return 0;
}

static int ui_cmd_pm_showdescr(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int idx;
    uint64_t hw;
    pmring_t *pmi_ring;
    pmring_t *pmo_ring;
    char *x;

    if (!pm_ports) {
	printf("PM not initialized.  do 'pm init' first.\n");
	return -1;
	}

    x = cmd_getarg(cmd,0);
    if (!x) x = "0";
    idx = atoi(x);
    if (idx > PM_NRINGS) idx = PM_NRINGS;

    pmi_ring = pmi_rings[idx];
    pmo_ring = pmo_rings[idx];

    printf("PMI Queue %d---  base:%p, entries:%d, add/rem:%d/%d\n",pmi_ring->qno,
	   pmi_ring->dscr,pmi_ring->ringsize,pmi_ring->next_add,pmi_ring->next_rem);
    hw = READCSR(A_BCM1480_PMI_LCL_REGISTER(pmi_ring->qno,R_BCM1480_PM_LAST));
    for (idx = 0; idx < pmi_ring->ringsize; idx++) {
	printf(" PMI Dscr %d:  %016llX %016llX%s%s%s\n",idx,
	       pmi_ring->dscr[idx].dscr_a,
	       pmi_ring->dscr[idx].dscr_b,
	       (idx == pmi_ring->next_add) ? " <-add" : "",
	       (idx == pmi_ring->next_rem) ? " <-rem" : "",
	       (idx == hw) ? " <-hw" : "");
	}

    printf("PMO Queue %d---  base:%p, entries:%d, add/rem:%d/%d\n",pmo_ring->qno,
	   pmo_ring->dscr,pmo_ring->ringsize,pmo_ring->next_add,pmo_ring->next_rem);

    hw = READCSR(A_BCM1480_PMO_LCL_REGISTER(pmo_ring->qno,R_BCM1480_PM_LAST));
    for (idx = 0; idx < pmo_ring->ringsize; idx++) {
	printf(" PMO Dscr %d:  %016llX %016llX%s%s%s\n",idx,
	       pmo_ring->dscr[idx].dscr_a,
	       pmo_ring->dscr[idx].dscr_b,
	       (idx == pmo_ring->next_add) ? " <-add" : "",
	       (idx == pmo_ring->next_rem) ? " <-rem" : "",
	       (idx == hw) ? " <-hw" : "");
	}
	   
    return 0;

}

static int ui_cmd_pm_newring(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int idx;
    uint64_t hw;
    pmring_t *pmi_ring;
    pmring_t *pmo_ring;
    char *x;

    x = cmd_getarg(cmd,0);
    if (!x) x = "0";

    pmi_ring = pmi_rings[atoi(x)];
    pmo_ring = pmo_rings[atoi(x)];

    if (!pm_ports) {
	printf("PM not initialized.  do 'pm newinit' first.\n");
	return -1;
	}

    printf("PMI Queue %d---  base:%p, entries:%d, on:%d, add/rem:%d/%d\n",pmi_ring->qno,
	   pmi_ring->dscr,pmi_ring->ringsize,pmi_ring->onring,pmi_ring->next_add,pmi_ring->next_rem);
    hw = READCSR(A_BCM1480_PMI_LCL_REGISTER(pmi_ring->qno,R_BCM1480_PM_LAST));
    for (idx = 0; idx < pmi_ring->ringsize; idx++) {
	printf(" PMI Dscr %d:  %016llX %016llX%s%s%s\n",idx,
	       pmi_ring->dscr[idx].dscr_a,
	       pmi_ring->dscr[idx].dscr_b,
	       (idx == pmi_ring->next_add) ? " <-add" : "",
	       (idx == pmi_ring->next_rem) ? " <-rem" : "",
	       (idx == hw) ? " <-hw" : "");
	}

    printf("PMO Queue %d---  base:%p, entries:%d, on:%d, add/rem:%d/%d\n",pmo_ring->qno,
	   pmo_ring->dscr,pmo_ring->ringsize,pmo_ring->onring,pmo_ring->next_add,pmo_ring->next_rem);

    hw = READCSR(A_BCM1480_PMO_LCL_REGISTER(pmo_ring->qno,R_BCM1480_PM_LAST));
    for (idx = 0; idx < pmo_ring->ringsize; idx++) {
	printf(" PMO Dscr %d:  %016llX %016llX%s%s%s\n",idx,
	       pmo_ring->dscr[idx].dscr_a,
	       pmo_ring->dscr[idx].dscr_b,
	       (idx == pmo_ring->next_add) ? " <-add" : "",
	       (idx == pmo_ring->next_rem) ? " <-rem" : "",
	       (idx == hw) ? " <-hw" : "");
	}
	   
    return 0;

}

static int ui_cmd_pm_txram(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x;
    hsaddr_t port = 0,ctlreg,datareg;
    int low,high,idx;

    low = 0; high = 65535;

    if ((x = cmd_getarg(cmd,0))) port = atoi(x);
    else ui_showusage(cmd);

    if ((x = cmd_getarg(cmd,1))) low = xtoi(x);
    if ((x = cmd_getarg(cmd,2))) high = xtoi(x);

    ctlreg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_RAM_READCTL);
    datareg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_RAM_READWINDOW);

    for (idx = low; idx <= high; idx++) {
	phys_write64(ctlreg,V_BCM1480_HSP_TXVIS_RAM_ADDR(idx) | 
		     V_BCM1480_HSP_TXVIS_RAM(K_BCM1480_HSP_TXVIS_RAM_DRAM_128_151));
	printf("%04X:  %016llX   ",idx,phys_read64(datareg));

	phys_write64(ctlreg,V_BCM1480_HSP_TXVIS_RAM_ADDR(idx) | 
		     V_BCM1480_HSP_TXVIS_RAM(K_BCM1480_HSP_TXVIS_RAM_DRAM_64_127));
	printf("%016llX ",phys_read64(datareg));

	phys_write64(ctlreg,V_BCM1480_HSP_TXVIS_RAM_ADDR(idx) | 
		     V_BCM1480_HSP_TXVIS_RAM(K_BCM1480_HSP_TXVIS_RAM_DRAM_0_63));
	printf("%016llX\n",phys_read64(datareg));     
	if (console_status()) break;
	}

    return 0;
    
}

static int ui_cmd_pm_rxram(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x;
    hsaddr_t port = 0,ctlreg,datareg;
    int low,high,idx;

    low = 0; high = 65535;

    if ((x = cmd_getarg(cmd,0))) port = atoi(x);
    else ui_showusage(cmd);

    if ((x = cmd_getarg(cmd,1))) low = xtoi(x);
    if ((x = cmd_getarg(cmd,2))) high = xtoi(x);

    ctlreg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_RAM_READCTL);
    datareg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_RAM_READWINDOW);

    for (idx = low; idx <= high; idx++) {
	phys_write64(ctlreg,V_BCM1480_HSP_TXVIS_RAM_ADDR(idx) | 
		     V_BCM1480_HSP_TXVIS_RAM(K_BCM1480_HSP_RXVIS_RAM_DRAM_128_151));
	printf("%04X:  %016llX   ",idx,phys_read64(datareg));

	phys_write64(ctlreg,V_BCM1480_HSP_TXVIS_RAM_ADDR(idx) | 
		     V_BCM1480_HSP_TXVIS_RAM(K_BCM1480_HSP_RXVIS_RAM_DRAM_64_127));
	printf("%016llX ",phys_read64(datareg));

	phys_write64(ctlreg,V_BCM1480_HSP_TXVIS_RAM_ADDR(idx) | 
		     V_BCM1480_HSP_TXVIS_RAM(K_BCM1480_HSP_RXVIS_RAM_DRAM_0_63));

	printf("%016llX\n",phys_read64(datareg));
	if (console_status()) break;
	}

    return 0;
    
}

static int ui_cmd_pm_txvis(ui_cmdline_t *cmd,int argc,char *argv[])
{
    uint64_t port,reg;
    uint64_t idx = 0;
    uint64_t val,val2,val3;
    hsaddr_t ctlreg,datareg;

    if (!cmd_getarg(cmd,1)) return ui_showusage(cmd);
    port = atoi(cmd_getarg(cmd,0));
    reg = atoi(cmd_getarg(cmd,1));

    ctlreg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_RF_READCTL);
    datareg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_RF_READWINDOW);

    printf("Dumping visibility of TX port %d register file #%d\n",(int)port,(int)reg);

    switch (reg) {
	default:
	    for (idx = 0; idx < 24; idx++) {
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		printf("Regfile[%02X] = %016llX\n",idx,phys_read64(datareg));
		}

	    break;
	case 0:
	    for (idx = 0; idx < 24; idx++) {
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg+0) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		val = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg+1) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		val2 = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg+8) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		val3 = phys_read64(datareg);
		printf("Chan %2d   Head:%04X  Tail:%04X  Phit:%04X\n",idx,
		       (uint32_t)val,(uint32_t)val2,(uint32_t)val3);
		}
	    break;
	    

	case 2: case 5:
	    for (idx = 0; idx < 24; idx++) {
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg+0) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		val = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg+1) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		val2 = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg+2) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		val3 = phys_read64(datareg);
		printf("Chan %2d   Meta:%08llX %s %s BC:%2d %s IVC:%2d Data:%02llX_%016llX\n",idx,val3,
		       (val3 & 1) ? "SOP" : "---",
		       (val3 & 2) ? "EOP" : "---",
		       (int)((val3 >> 2) & 15),
		       (val3 & 64) ? "ERR" : "OK ",
		       (int)(val3 >> 7),
		       val2,val);
		}
	    break;
	    
	case 9:
	    for (idx = 0; idx < 24; idx++) {
		phys_write64(ctlreg,
			     V_BCM1480_HSP_TXRFVIS_RAM(reg) |
			     V_BCM1480_HSP_TXRFVIS_RAM_ADDR(idx));
		val = phys_read64(datareg);
		printf("Chan %2d   Push:%d   Pop:%d\n",idx,
		       (int)(val & 0x0F),(int)((val >> 4) & 0x0F));
		}
	    break;

	case 10:
	    phys_write64(ctlreg,
			 V_BCM1480_HSP_TXRFVIS_RAM(reg) |
			 V_BCM1480_HSP_TXRFVIS_RAM_ADDR(0));
	    val = phys_read64(datareg);
	    printf("Ready to pick:  %06llx\n",((val >> 32) & 0xFFFFFF));
	    printf("IVC OK:         %06llx\n",(val & 0xFFFFFF));
	    break;	    

	}

    return 0;
}

static int ui_cmd_pm_rxvis(ui_cmdline_t *cmd,int argc,char *argv[])
{
    uint64_t port,reg;
    uint64_t idx;
    uint64_t val,val2,val3;
    hsaddr_t ctlreg,datareg;

    if (!cmd_getarg(cmd,1)) return ui_showusage(cmd);
    port = atoi(cmd_getarg(cmd,0));
    reg = atoi(cmd_getarg(cmd,1));

    ctlreg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_RF_READCTL);
    datareg = A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_RF_READWINDOW);

    printf("Dumping visibility of RX port %d register file #%d\n",(int)port,(int)reg);


    switch (reg) {
	case 0:
	    for (idx = 0; idx < 24; idx++) {
		phys_write64(ctlreg,
			     V_BCM1480_HSP_RXRFVIS_RAM(reg+0) |
			     V_BCM1480_HSP_RXRFVIS_RAM_ADDR(idx));
		val = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_RXRFVIS_RAM(reg+1) |
			     V_BCM1480_HSP_RXRFVIS_RAM_ADDR(idx));
		val2 = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_RXRFVIS_RAM(reg+2) |
			     V_BCM1480_HSP_RXRFVIS_RAM_ADDR(idx));
		val3 = phys_read64(datareg);
		printf("Chan %2d   Meta:%016llX  Data:%016llX_%016llX\n",idx,
		       val3,val,val2);
		}
	    break;
	case 5:
	    for (idx = 0; idx < 24; idx++) {
		phys_write64(ctlreg,
			     V_BCM1480_HSP_RXRFVIS_RAM(reg+0) |
			     V_BCM1480_HSP_RXRFVIS_RAM_ADDR(idx));
		val = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_RXRFVIS_RAM(reg+1) |
			     V_BCM1480_HSP_RXRFVIS_RAM_ADDR(idx));
		val2 = phys_read64(datareg);
		phys_write64(ctlreg,
			     V_BCM1480_HSP_RXRFVIS_RAM(reg+3) |
			     V_BCM1480_HSP_RXRFVIS_RAM_ADDR(idx));
		val3 = phys_read64(datareg);
		printf("Chan %2d   Head:%04X  Tail:%04X  Phit:%04X\n",idx,
		       (uint32_t)val,(uint32_t)val2,(uint32_t)val3);
		}
	    break;
	default:
	    for (idx = 0; idx < 32; idx++) {
		phys_write64(ctlreg,
			     V_BCM1480_HSP_RXRFVIS_RAM(reg) |
			     V_BCM1480_HSP_RXRFVIS_RAM_ADDR(idx));
		printf("Regfile[%02X] = %016llX\n",idx,phys_read64(datareg));
		}
	}

    return 0;
}




static int ui_cmd_pm_show(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int port = 0;
    char *x;
    uint64_t reg;

    if ((x = cmd_getarg(cmd,0))) port = atoi(x);

    printf("** Port %d **\n",port);
    reg = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_SPI4_PORT_INT_STATUS));
    printf("TX SPI-4 Interrupt Status:   %016llX",reg);
    printf(" [ %s]\n",showfields(spi4_txintstat,reg));

    reg = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_TX_CALIBRATION));
    printf("TX SPI-4 Calibration:        %016llX",reg);
    printf(" [ %s]\n",showfields(spi4_txcalibration,reg));

    reg = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_SPI4_PORT_INT_STATUS));
    printf("RX SPI-4 Interrupt Status:   %016llX",reg);
    printf(" [ %s]\n",showfields(spi4_rxintstat,reg));

    reg = READCSR(A_BCM1480_HSP_REGISTER(port,R_BCM1480_HSP_RX_CALIBRATION));
    printf("RX SPI-4 Calibration:        %016llX",reg);
    printf(" [ %s]\n",showfields(spi4_txcalibration,reg));	/* same fields as TX */
	   
    return 0;
}


/*  *********************************************************************
    *  ui_init_pmcmds()
    *  
    *  Add BIGSUR-specific commands to the command table
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   0
    ********************************************************************* */


int ui_init_pmcmds(void)
{
    cmd_addcmd("pm init",
	       ui_cmd_pm_init,
	       NULL,
	       "initialize packet manager",
	       "pm init",
	       "-mhz=*;Set Freqency in MHz");

    cmd_addcmd("pm newinit",
	       ui_cmd_pm_newinit,
	       NULL,
	       "initialize packet manager",
	       "pm init [chan]",
	       "-mhz=*;Set Freqency in MHz");

    cmd_addcmd("pm test",
	       ui_cmd_pm_test,
	       NULL,
	       "Test packet manager",
	       "pm test [ring numbers,0,1,2]",
	       "-dump;Dump received data|"
	       "-continuous;Run until a keystroke|"
	       "-count=*;Send the specified number of packets|"
	       "-randlen;Use random packet length|"
	       "-batch=*;Send this many packets at once|"
	       "-recv;Don't send, just receive|"
	       "-len=*;Use specified packet length");

    cmd_addcmd("pm echotest",
	       ui_cmd_pm_echotest,
	       NULL,
	       "Test packet manager",
	       "pm echotest [ring numbers,0,1,2]",
	       "-count=*;Send the specified number of packets|"
	       "-randlen;Use random packet length|"
	       "-batch=*;Send this many packets at once|"
	       "-checkdata;Send barberpole pattern, check data on rx|"
	       "-len=*;Use specified packet length");

    cmd_addcmd("pm newtest",
	       ui_cmd_pm_newtest,
	       NULL,
	       "Test packet manager",
	       "pm test",
	       "-sum;Dump packet info|"
	       "-dump;Dump received data");

    cmd_addcmd("pm showdescr",	
	       ui_cmd_pm_showdescr,
	       NULL,
	       "Show pending descriptors",
	       "pm showdescr",
	       "");

    cmd_addcmd("pm newring",	
	       ui_cmd_pm_newring,
	       NULL,
	       "Show pending descriptors",
	       "pm newring [ring]",
	       "");

    cmd_addcmd("pm show",
	       ui_cmd_pm_show,
	       NULL,
	       "Display TX/RX registers",
	       "pm show 0|1|2",
	       "");

    cmd_addcmd("pm txvis",	
	       ui_cmd_pm_txvis,
	       NULL,
	       "Display TX RF Visibility",
	       "pm txvis (chan) (reg)",
	       "");


    cmd_addcmd("pm rxvis",	
	       ui_cmd_pm_rxvis,
	       NULL,
	       "Display RX RF Visibility",
	       "pm rxvis (chan) (reg)",
	       "");

    cmd_addcmd("pm txram",	
	       ui_cmd_pm_txram,
	       NULL,
	       "Display TX buffer RAM",
	       "pm txram (chan)",
	       "");

    cmd_addcmd("pm rxram",	
	       ui_cmd_pm_rxram,
	       NULL,
	       "Display RX buffer RAM",
	       "pm rxram (chan)",
	       "");


    return 0;
}




