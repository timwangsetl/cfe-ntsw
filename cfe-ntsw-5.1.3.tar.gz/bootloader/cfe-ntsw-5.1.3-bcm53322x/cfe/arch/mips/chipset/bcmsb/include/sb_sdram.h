/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  SDRAM Controller definitions              File: sb_sdram.h
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef _SBSDRAM_H_
#define _SBSDRAM_H_

/*
 * Register and bit definitions for the SDRAM Controller (OCP ID 0x803)
 */


/* SDRAM Controller Core Enumeration Space (Section 5) */

#define R_SDRAM_INIT            0x000
#define R_SDRAM_CONFIG          0x004
#define R_SDRAM_REFRESH         0x008
#define R_SDRAM_MEM_BASE        0x00C    /* Not 47xx series */


/* SDRAMINIT: SDRAM Initialization Control Register (0x000, R/W) */

#define M_SDRAMINIT_CBR         _DD_MAKEMASK1(0)        /* CBRCmd */
#define M_SDRAMINIT_PRE         _DD_MAKEMASK1(1)        /* PRECmd */
#define M_SDRAMINIT_MRS         _DD_MAKEMASK1(2)        /* MRSCmd */
#define M_SDRAMINIT_EN          _DD_MAKEMASK1(3)        /* SDRAMCtrlEn */

#define S_SDRAMINIT_BSIZE       4                      /* BitSize */
#define M_SDRAMINIT_BSIZE       _DD_MAKEMASK(2,S_SDRAMINIT_BSIZE)
#define V_SDRAMINIT_BSIZE(x)    _DD_MAKEVALUE(x,S_SDRAMINIT_BSIZE)
#define G_SDRAMINIT_BSIZE(x)    _DD_GETVALUE(x,S_SDRAMINIT_BSIZE,M_SDRAMINIT_BSIZE)
#define K_BSIZE_16M             0x0
#define K_BSIZE_64M             0x1
#define K_BSIZE_128M            0x2

#define M_SDRAMINIT_RST         _DD_MAKEMASK1(7)        /* SoftReset */
#define M_SDRAMINIT_SELFREF     _DD_MAKEMASK1(8)        /* SelfRefresh */
#define M_SDRAMINIT_PWRDOWN     _DD_MAKEMASK1(9)        /* PowerDown */
#define M_SDRAMINIT_32BIT       _DD_MAKEMASK1(10)       /* 32BitMem */
#define M_SDRAMINIT_9BITCOL     _DD_MAKEMASK1(11)       /* 9BitColumn */
 
/* SDRAMCFG: SDRAM Configuration Register (0x004, R/W) */

#define S_SDRAMCFG_BURST        0                       /* BurstLen */
#define M_SDRAMCFG_BURST        _DD_MAKEMASK(2,S_SDRAMCFG_BURST)
#define V_SDRAMCFG_BURST(x)     _DD_MAKEVALUE(x,S_SDRAMCFG_BURST)
#define G_SDRAMCFG_BURST(x)     _DD_GETVALUE(x,S_SDRAMCFG_BURST,M_SDRAMCFG_BURST)
#define K_BURST_PAGE            0x0
#define K_BURST_8               0x1
#define K_BURST_4               0x2
#define K_BURST_2               0x3

#define M_SDRAMCFG_FAST         _DD_MAKEMASK1(2)       /* FastMem */
#define M_SDRAMCFG_CAS2         M_SDRAMCFG_FAST
#define M_SDRAMCFG_CAS3         0

/* SDRAMREF: SDRAM Refresh Control Register (0x008, R/W) */

#define S_SDRAMREF_PERIOD       0                      /* RefreshPeriod */
#define M_SDRAMREF_PERIOD       _DD_MAKEMASK(8,S_SDRAMREF_PERIOD)
#define V_SDRAMREF_PERIOD(x)    _DD_MAKEVALUE(x,S_SDRAMREF_PERIOD)
#define G_SDRAMREF_PERIOD(x)    _DD_GETVALUE(x,S_SDRAMREF_PERIOD,M_SDRAMREF_PERIOD)

#define M_SDRAMREF_EN           _DD_MAKEMASK1(15)      /* RefreshEnable */

/* SDRAMBASE: SDRAM Memory Base Register (0x00C, R/W, optional) */

#define S_SDRAMBASE_SIZE        0                      /* SDRAMSize */
#define M_SDRAMBASE_SIZE        _DD_MAKEMASK(2,S_SDRAMBASE_SIZE)
#define V_SDRAMBASE_SIZE(x)     _DD_MAKEVALUE(x,S_SDRAMBASE_SIZE)
#define G_SDRAMBASE_SIZE(x)     _DD_GETVALUE(x,S_SDRAMBASE_SIZE,M_SDRAMBASE_SIZE)
#define K_SDRAM_SIZE_2M         0
#define K_SDRAM_SIZE_8M         1
#define K_SDRAM_SIZE_16M        2
#define K_SDRAM_SIZE_32M        3

#define S_SDRAMBASE_ADDR        13                     /* SDRAMBase */
#define M_SDRAMBASE_ADDR        _DD_MAKEMASK(19,S_SDRAMBASE_ADDR)
#define V_SDRAMBASE_ADDR(x)     _DD_MAKEVALUE(x,S_SDRAMBASE_ADDR)
#define G_SDRAMBASE_ADDR(x)     _DD_GETVALUE(x,S_SDRAMBASE_ADDR,M_SDRAMBASE_ADDR)

#endif /* _SBSDRAM_H_ */
