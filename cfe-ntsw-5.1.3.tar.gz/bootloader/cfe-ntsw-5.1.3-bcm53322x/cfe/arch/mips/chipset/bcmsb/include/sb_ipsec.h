/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM47XX IPSec crypto definitions              File: sb_ipsec.h
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */


#ifndef _SBIPSEC_H_
#define _SBIPSEC_H_

/* Register and field definitions for the IPSec crypto accelerator
   (OCP ID 0x80B) used in the Broadcom BCM47XX family SOC products.
 *
 * Reference:
 * 
 *   AirForce Dual-Band Wireless Networking Processor
 *   BCM4704/4704P  Programmer's Guide, 4704_4704P-PG00i-D8
 *   Broadcom Corp., 16215 Alton Parkway, Irvine CA, 06/18/03
 */

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))

/* IPSec Core (Section 7) */

#define R_BIST_STATUS           0x00C

#define R_DMA_MCR1              0x020
#define R_DMA_CTRL              0x024
#define R_DMA_STAT              0x028
#define R_DMA_ERR               0x02C
#define R_DMA_MCR2              0x030


/* BIST: Built-In Self Test Register (0x00C, RO) */


/* The following register formats are shared with the BCM582x series
   with exceptions as noted:
        -0: not 5820
        -1: not 5821
 */

/* MCR: Master Command Record 1 Address Register (MCR1@, 0x020, R/W) */
/* MCR: Master Command Record 2 Address Register (MCR2@, 0x030, R/W) */

/* DMACTL: DMA Control Register (0x0x024, R/W) */

#define M_DMACTL_WR_BURST       _DD_MAKEMASK1(16)   /* MasterWriteBurstSizeSel */
#define  K_DMA_WR_BURST_128     0
#define  K_DMA_WR_BURST_240     M_DMACTL_WR_BURST

#define M_DMACTL_MOD_NORM       _DD_MAKEMASK1(22)   /* ModulusNormalization */
#define M_DMACTL_RNG_MODE       _DD_MAKEMASK1(23)   /* RNGMode */
#define M_DMACTL_DMAERR_EN      _DD_MAKEMASK1(25)   /* DMAErrEn */
#define M_DMACTL_NORM_PCI       _DD_MAKEMASK1(26)   /* NormalPCI (-0) */
#define M_DMACTL_LE_CRYPTO      _DD_MAKEMASK1(27)   /* LECryptoNet (-0) */
#define M_DMACTL_MCR1_INT_EN    _DD_MAKEMASK1(29)   /* MCRInt1En */
#define M_DMACTL_MCR2_INT_EN    _DD_MAKEMASK1(30)   /* MCRInt2En */
#define M_DMACTL_RESET          _DD_MAKEMASK1(31)   /* SWREset */


/* DMASTAT: DMA Status Register (0x028, R/W) */

#define M_DMASTAT_MCR2_EMPTY    _DD_MAKEMASK1(24)   /* MCR2AllEmpty (-0) */
#define M_DMASTAT_MCR1_EMPTY    _DD_MAKEMASK1(25)   /* MCR1AllEmpty (-0) */
#define M_DMASTAT_MCR2_INTR     _DD_MAKEMASK1(26)   /* MCR2Intr */
#define M_DMASTAT_MCR2_FULL     _DD_MAKEMASK1(27)   /* MCR2Full */
#define M_DMASTAT_DMAERR_INTR   _DD_MAKEMASK1(28)   /* DMAErrIntr */
#define M_DMASTAT_MCR1_INTR     _DD_MAKEMASK1(29)   /* MCR1Intr */
#define M_DMASTAT_MCR1_FULL     _DD_MAKEMASK1(30)   /* MCR1Full */
#define M_DMASTAT_MSTR_ACCESS   _DD_MAKEMASK1(31)

/* DMAERR: DMA Error Address Register (0x02C, RO) */

#define M_DMAERR_RD_FAULT       _DD_MAKEMASK1(1)
#define M_DMAERR_ADDR           0xFFFFFFFC
#define G_DMAERR_ADDR(x)        ((x) & M_DMAERR_ADDR)


/* The formats and encodings of Command Records are not currently
   documented for the BCM47xx series but are assumed to be the same as
   the BCM582x chips.  See cfe_crypto.h.
 */


/* Identifiers for the BCM582x PCI chips */

#define K_PCI_VENDOR_BROADCOM    0x14e4
#define K_PCI_ID_BCM5820         0x5820
#define K_PCI_ID_BCM5821         0x5821
#define K_PCI_ID_BCM5822         0x5822
#define K_PCI_ID_BCM5823         0x5823

#endif /* _SBIPSEC_H_ */
