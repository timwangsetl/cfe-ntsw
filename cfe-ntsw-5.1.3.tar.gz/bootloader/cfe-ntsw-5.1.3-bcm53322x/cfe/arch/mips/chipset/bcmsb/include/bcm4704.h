/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  SOC chip definitions			File: bcm4704.h
    *
    *  Constants and macros specific to this SOC
    *  
    *********************************************************************  
    *
    *  Copyright 2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef _BCM4704_H_
#define _BCM4704_H_

/* Define the chip, to match legacy #ifdef's. */
#define BCM4704  1

/* Define the chip family */
#define BCM47XX  1
#define BCM47xx  1

/* BCM4704 Address map */
#define BCM4704_SDRAM		0x00000000 /* 0-128MB Physical SDRAM */
#define BCM4704_PCI_MEM		0x08000000 /* Host Mode PCI mem space (64MB)*/
#define BCM4704_PCI_CFG		0x0c000000 /* Host Mode PCI cfg space (64MB)*/
#define BCM4704_PCI_DMA		0x40000000 /* Client Mode PCI mem space (1GB)*/
#define	BCM4704_SDRAM_SWAPPED	0x10000000 /* Byteswapped Physical SDRAM */
#define BCM4704_ENUM		0x18000000 /* Beginning of core enum space */

/* BCM4704 Core register space */
#define BCM4704_REG_CHIPC	0x18000000 /* Chipcommon  registers */
#define BCM4704_REG_EMAC0	0x18001000 /* Ethernet MAC0 core registers */
#define BCM4704_REG_EMAC1	0x18002000 /* Ethernet MAC1 core registers */
#define BCM4704_REG_USB		0x18003000 /* USB core registers */
#define BCM4704_REG_PCI		0x18004000 /* PCI core registers */
#define BCM4704_REG_MIPS33	0x18005000 /* MIPS core registers */
#define BCM4704_REG_CODEC	0x18006000 /* AC97 Codec Core registers */
#define BCM4704_REG_IPSEC	0x18007000 /* BCM582x CryptoCore registers */
#define BCM4704_REG_MEMC	0x18008000 /* MEMC core registers */

#define BCM4704_REG_UARTS       (BCM4704_REG_CHIPC + 0x300) /* UART regs */

#define	BCM4704_EJTAG		0xff200000 /* MIPS EJTAG space (2M) */

/* Internal 16550-compatible UARTs */
#define BCM4704_UART0		(BCM4704_REG_UARTS + 0x00000000)
#define BCM4704_UART1		(BCM4704_REG_UARTS + 0x00000100)

/* Registers common to MIPS33 Core used in 5365 and 4704 */
#define MIPS33_EXTIF_REGION     0x1A000000 /* Chipcommon EXTIF region */
#define MIPS33_FLASH_REGION_AUX 0x1C000000 /* FLASH Region 2 */
#define MIPS33_FLASH_REGION     0x1FC00000 /* Boot FLASH Region  */

/* Offsets within the EXTIF_REGION, by chip select. */
#define EXTIF_CS01_OFFSET       0x00000000 /* CS01, aka EXTIF_PCMCIA_CE{1,2} */
#define EXTIF_CS23_OFFSET       0x00800000 /* CS23, aka EXTIF_IDE_CE{1,2} */
#define EXTIF_CS4_OFFSET        0x01000000 /* CS4,  aka EXTIF_PROGIF_CS */

/* bcm4704 mapping to generic sb_bp identifiers */
/* XXX It would be better to discover this dynamically. */

/* BSP Abstraction, pickup names via bsp_config.h. */

#define SB_ENUM_BASE            BCM4704_ENUM

#define SB_CHIPC_BASE           BCM4704_REG_CHIPC
#define SB_ENET0_BASE           BCM4704_REG_EMAC0
#define SB_ENET1_BASE           BCM4704_REG_EMAC1
#define SB_IPSEC_BASE           BCM4704_REG_IPSEC
#define SB_USB_BASE             BCM4704_REG_USB
#define SB_PCI_BASE             BCM4704_REG_PCI
#define SB_MIPS33_BASE          BCM4704_REG_MIPS33
#define SB_MEMC_BASE            BCM4704_REG_MEMC

#define SB_EXTIF_SPACE          MIPS33_EXTIF_REGION
#define SB_AUX_FLASH_SPACE      MIPS33_FLASH_REGION_AUX
#define SB_FLASH_SPACE          MIPS33_FLASH_REGION

#endif /* _BCM4704_H_ */
