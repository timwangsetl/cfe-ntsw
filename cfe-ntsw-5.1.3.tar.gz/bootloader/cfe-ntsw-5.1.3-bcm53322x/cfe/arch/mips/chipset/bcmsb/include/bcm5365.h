/*
   BCM5365 address space map and definitions
   
   Copyright 2002-2003, Broadcom Corporation
   All Rights Reserved.
    
   This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
   the contents of this file may not be disclosed to third parties, copied or
   duplicated in any form, in whole or in part, without the prior written
   permission of Broadcom Corporation.
*/

#ifndef _BCM5365_H_
#define _BCM5365_H_

/* Define the chip, to match legacy #ifdef's. */
#define BCM5365  1

/* Define the chip family */
#define BCM47XX  1
#define BCM47xx  1

/* BCM5365 Address map */
#define BCM5365_SDRAM		0x00000000 /* 0-128MB Physical SDRAM */
#define BCM5365_PCI_MEM		0x08000000 /* Host Mode PCI mem space (64MB) */
#define BCM5365_PCI_CFG		0x0C000000 /* Host Mode PCI cfg space (64MB) */
#define BCM5365_PCI_DMA		0x40000000 /* Client Mode PCI mem space (1GB)*/
#define	BCM5365_SDRAM_SWAPPED	0x10000000 /* Byteswapped Physical SDRAM */
#define BCM5365_ENUM		0x18000000 /* Beginning of core enum space */

/* BCM5365 Core register space */
#define BCM5365_REG_CHIPC	0x18000000 /* Chipcommon  registers */
#define BCM5365_REG_EMAC0	0x18001000 /* Ethernet MAC0 core registers */
#define BCM5365_REG_IPSEC	0x18002000 /* BCM582x CryptoCore registers */
#define BCM5365_REG_USB		0x18003000 /* USB core registers */
#define BCM5365_REG_PCI		0x18004000 /* PCI core registers */
#define BCM5365_REG_MIPS33	0x18005000 /* MIPS core registers */
#define BCM5365_REG_MEMC	0x18006000 /* MEMC core registers */

#define BCM5365_REG_UARTS       (BCM5365_REG_CHIPC + 0x300) /* UART regs */

#define	BCM5365_EJTAG		0xFF200000 /* MIPS EJTAG space (2M) */

/* Internal 16550-compatible UARTs */
#define	BCM5365_UART0		(BCM5365_REG_UARTS + 0x00000000)
#define	BCM5365_UART1		(BCM5365_REG_UARTS + 0x00000100)

/* Registers common to MIPS33 Core used in 5365 and 4704 */
#define MIPS33_EXTIF_REGION     0x1A000000 /* Chipcommon EXTIF region */
#define MIPS33_FLASH_REGION_AUX 0x1C000000 /* FLASH Region 2 */
#define MIPS33_FLASH_REGION     0x1FC00000 /* Boot FLASH Region  */

/* Offsets within the EXTIF_REGION, by chip select. */
#define EXTIF_MISC_OFFSET       0x00000000 /* Misc_CS */

/* bcm5365 mapping to generic sb_bp identifiers */
/* XXX It would be better to discover this dynamically. */

/* BSP Abstraction, pickup names via bsp_config.h. */

#define SB_ENUM_BASE            BCM5365_ENUM

#define SB_CHIPC_BASE           BCM5365_REG_CHIPC
#define SB_ENET0_BASE           BCM5365_REG_EMAC0
#define SB_IPSEC_BASE           BCM5365_REG_IPSEC
#define SB_USB_BASE             BCM5365_REG_USB
#define SB_PCI_BASE             BCM5365_REG_PCI
#define SB_MIPS33_BASE          BCM5365_REG_MIPS33
#define SB_MEMC_BASE            BCM5365_REG_MEMC

#define SB_EXTIF_SPACE          MIPS33_EXTIF_REGION
#define SB_AUX_FLASH_SPACE      MIPS33_FLASH_REGION_AUX
#define SB_FLASH_SPACE          MIPS33_FLASH_REGION

#endif /* _BCM5365_H_ */
