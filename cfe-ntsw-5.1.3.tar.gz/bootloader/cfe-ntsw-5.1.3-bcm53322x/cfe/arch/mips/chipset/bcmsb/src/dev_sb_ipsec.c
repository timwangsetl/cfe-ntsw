/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Broadcom Silicon Backplane IPSec Driver	File: dev_sb_ipsec.c
    *  
    *  Author: Ed Satterthwaite
    *
    *********************************************************************  
    *
    *  Copyright 2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

/*
   This is a simple driver for the crypto coprocessor in the IPSec
   core used in Broadcom OCP-based SOCs.  It provides only a minimal
   interface to the hardware, primarily via ioctl calls.

   The command interface uses MCR formats and codes identical to the
   BCM582x PCI parts, but the bus interface and the offsets of the
   CSRs are different.

   Reference:
     AirForce Dual-Band Wireless Networking Processor
     BCM4704/4704P  Programmer's Guide, 4704_4704P-PG00i-D8
     Broadcom Corp., 16215 Alton Parkway, Irvine CA, 06/18/03
*/
   
#include "cfe.h"
#include "lib_physio.h"
#include "pcivar.h"
#include "pcireg.h"

#include "cfe_crypto.h"
#include "sb_bp.h"
#include "sb_ipsec.h"

#ifndef CRYPTO_DEBUG
#define CRYPTO_DEBUG 0
#endif

static void sb_ipsec_probe(cfe_driver_t *drv,
			   unsigned long probe_a, unsigned long probe_b, 
			   void *probe_ptr);

/* Address mapping macros */

/* Note that PTR_TO_PHYS only works with 32-bit addresses, but then
   so do the SBP SOCs. */
#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((void *)KERNADDR(a))

#if ENDIAN_BIG
/*
   For the 5821 and successors, all mappings through the PCI host
   bridge use match bits mode if supported.  This works because the
   NORM_PCI bit in DMA Control is clear.

   The Silicon Backplane crypto cores appear to ignore it, so pointers
   to data byte sequences use match bytes, but control blocks and
   pointers to them use match bits.
 */

#else  /* !ENDIAN_BIG */
#undef PHYS_TO_PCI
#undef PCI_TO_PHYS
#define PHYS_TO_PCI(a) ((uint32_t) (a))
#define PCI_TO_PHYS(a) ((uint32_t) (a))
#endif

#define READCSR(sc,csr)      (phys_read32((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->regbase + (csr), (val)))


typedef struct bcm5821_state_s {
    uint32_t  regbase;
    uint8_t irq;
    pcitag_t tag;		/* tag for configuration registers */

    uint16_t device;            /* chip device code */
    uint8_t revision;           /* chip revision */

    cfe_devctx_t *devctx;

    crypto_info_t info;         /* chip capabilities */
} bcm5821_state_t;


static void
dumpcsrs(bcm5821_state_t *sc, const char *legend)
{
    xprintf("%s:\n", legend);
    xprintf("---DMA---\n");
    /* DMA control and status registers */
    xprintf("MCR1: %08X  CTRL: %08X  STAT: %08X  ERR:  %08X\n",
	    READCSR(sc, R_DMA_MCR1), READCSR(sc, R_DMA_CTRL), 
	    READCSR(sc, R_DMA_STAT), READCSR(sc, R_DMA_ERR));
    xprintf("MCR2: %08X\n", READCSR(sc, R_DMA_MCR2));
    xprintf("---------\n");
}


static void
bcm5821_hwinit(bcm5821_state_t *sc)
{
    uint32_t ctrl;
    uint32_t status;

    ctrl = (M_DMACTL_MCR1_INT_EN | M_DMACTL_MCR2_INT_EN |
	    M_DMACTL_DMAERR_EN);

    /* In both big- and little-endian modes, the OCP 80B crypto core
       appears to behave entirely independently of the settings of
       NORM_PCI and LE_CRYPTO bits in the DMA status register.  Also,
       correct results are obtained only when data is fetched using
       match-bytes mode.  With respect to those bits, the core behaves
       like a 5820, not a 5823.  */

#if ENDIAN_BIG
    /* Big-endian, data references use match-bits for the chips that
       support it. */
    switch (sc->info.chip) {
	case OCP80B:
	    /* Setting the (currently) ignored NORM_PCI and LE_CRYPTO
	       would be the consistent thing for the SB core and
	       appears to be harmless.  */
	    ctrl |= (M_DMACTL_NORM_PCI | M_DMACTL_LE_CRYPTO);
	    break;
	default:
	    /* For 5821 and successors, big endian will use
	       match-bits; M_DMACTL_NORM_PCI, M_DMACTL_LE_CRYPTO are
	       not set. */
	  break;
	}
#else
    /* Little-endian is always match-bytes.  For consisteny, both bits
       should be set, but they appear to be ignored. */
    ctrl |= (M_DMACTL_NORM_PCI | M_DMACTL_LE_CRYPTO);
#endif

#if 0  /* Empirically, this reduces performance. */
    ctrl |= M_DMACTL_WR_BURST;
#endif
    WRITECSR(sc, R_DMA_CTRL, ctrl);

    status = READCSR(sc, R_DMA_STAT);
    WRITECSR(sc, R_DMA_STAT, status);    /* reset write-to-clear bits */
    status = READCSR(sc, R_DMA_STAT);

    if (CRYPTO_DEBUG) dumpcsrs(sc, "init");
}


static void
bcm5821_start(bcm5821_state_t *sc)
{
    bcm5821_hwinit(sc);
}

static void
bcm5821_stop(bcm5821_state_t *sc)
{
    WRITECSR(sc, R_DMA_CTRL, 0);
}


/* Utilities */

static int
bcm5821_do_cmd(bcm5821_state_t *sc, int port, uint32_t *mcr)
{
    uint32_t status;
    int i;
    static const int R_DMA_MCR[2+1] = {
	0, R_DMA_MCR1,          R_DMA_MCR2};
    static const uint32_t M_DMASTAT_MCR_FULL[2+1] = {
	0, M_DMASTAT_MCR1_FULL, M_DMASTAT_MCR2_FULL};

    if (port != 1 && port != 2)
	return -1;

    status = READCSR(sc, R_DMA_STAT);
    WRITECSR(sc, R_DMA_STAT, status);    /* clear pending bits */
    status = READCSR(sc, R_DMA_STAT);

    for (i = 0; i < 10000; i++) {
	status = READCSR(sc, R_DMA_STAT);
	if ((status & M_DMASTAT_MCR_FULL[port]) == 0)
	    break;
	cfe_usleep(10);
	}
    if (i == 10000) {
	if (CRYPTO_DEBUG) dumpcsrs(sc, "bcm5821: full bit never clears");
	return -1;
	}

    WRITECSR(sc, R_DMA_MCR[port], PHYS_TO_PCI(PTR_TO_PHYS(mcr)));

    for (i = 0; i < 10000; i++) {
	if ((mcr[0] & M_MCR_DONE) != 0)
	    break;
	cfe_usleep(10);
	}
    if (i == 10000) {
	if (CRYPTO_DEBUG) dumpcsrs(sc, "bcm5821: done bit never sets");
	/*return -1;*/
	}

    status = READCSR(sc, R_DMA_STAT);
    WRITECSR(sc, R_DMA_STAT, status);    /* clear pending bits */
    cfe_usleep(100);

    return 0;
}


static int bcm5821_open(cfe_devctx_t *ctx);
static int bcm5821_read(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int bcm5821_inpstat(cfe_devctx_t *ctx,iocb_inpstat_t *inpstat);
static int bcm5821_write(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int bcm5821_ioctl(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int bcm5821_close(cfe_devctx_t *ctx);

/* CFE Device Driver dispatch structure */

const static cfe_devdisp_t bcm5821_dispatch = {
    bcm5821_open,
    bcm5821_read,
    bcm5821_inpstat,
    bcm5821_write,
    bcm5821_ioctl,
    bcm5821_close,	
    NULL,
    NULL
};


/* CFE Device Driver probe functions for SOC IPSec core. */

cfe_driver_t sb_ipsec = {
    "BCM4xxx IPSec",
    "crypt",
    CFE_DEV_OTHER,
    &bcm5821_dispatch,
    sb_ipsec_probe
};


static int
sb_ipsec_attach(cfe_driver_t *drv, int unit)
{
    bcm5821_state_t *sc;
    phys_addr_t pa;
    char descr[80];
    uint32_t flag, id;

    /* XXX The map of enumeration space should be discovered by scanning. */
    static const phys_addr_t ipsec_base[1] = {SB_IPSEC_BASE};

    pa = ipsec_base[unit];

    sc = (bcm5821_state_t *) KMALLOC(sizeof(bcm5821_state_t),0);
    if (sc == NULL) {
	xprintf("BCM4xxx IPSec: No memory to complete probe\n");
	return 0;
	}
    memset(sc, 0, sizeof(*sc));

    sc->regbase = (uint32_t)pa;

    flag = READCSR(sc, R_SBTPSFLAG);
    sc->irq = G_SBTSF_FN(flag);
    sc->tag = 0;
    id = READCSR(sc, R_SBIDHIGH);
    sc->device = G_SBID_CR(id);
    sc->revision = G_SBID_RV(id);
    sc->info.chip = OCP80B;

    sc->devctx = NULL;

    /* Enable the core by enabling the core clocks and then clearing
       RESET. */
    WRITECSR(sc, R_SBTMSTATELOW, M_SBTS_RS | M_SBTS_CE | M_SBTS_FC);
    (void)READCSR(sc, R_SBTMSTATELOW);   /* push */
    cfe_usleep(100);
    WRITECSR(sc, R_SBTMSTATELOW, M_SBTS_CE | M_SBTS_FC);
    (void)READCSR(sc, R_SBTMSTATELOW);   /* push */
    cfe_usleep(100);
    WRITECSR(sc, R_SBTMSTATELOW, M_SBTS_CE);
    (void)READCSR(sc, R_SBTMSTATELOW);   /* push */
    cfe_usleep(100);

    xsprintf(descr, "BCM%04X Crypto at 0x%08X", sc->device, sc->regbase);
    cfe_attach(drv, sc, NULL, descr);

    return 1;
}

/*
 *  Probe arguments:
 *         probe_a - index of the IPSec to probe
 */

static void
sb_ipsec_probe(cfe_driver_t *drv,
	       unsigned long probe_a, unsigned long probe_b, 
	       void *probe_ptr)
{
    int index = probe_a;

    if (index == 0)
	sb_ipsec_attach(drv, index);
}


/* The functions below are called via the dispatch vector for the 5821 */

static int
bcm5821_open(cfe_devctx_t *ctx)
{
    bcm5821_state_t *sc = ctx->dev_softc;

    sc->devctx = ctx;
    bcm5821_start(sc);
    return 0;
}

static int
bcm5821_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    return -1;
}

static int
bcm5821_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    return 0;
}

static int
bcm5821_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    return -1;
}

static int
bcm5821_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    bcm5821_state_t *sc = ctx->dev_softc;

    /* XXX WARNING: This driver is not compatible with 64-bit pointers */

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_CRYPTO_GETINFO:
	    *((crypto_info_t *)HSADDR2PTR(buffer->buf_ptr)) = sc->info;
	    break;
	case IOCTL_CRYPTO_CMD_1:
	    bcm5821_do_cmd(sc, 1, (uint32_t *)HSADDR2PTR(buffer->buf_ptr));
	    break;
	case IOCTL_CRYPTO_CMD_2:
	    bcm5821_do_cmd(sc, 2, (uint32_t *)HSADDR2PTR(buffer->buf_ptr));
	    break;
	default:
	    return -1;
	}

    return 0;
}

static int
bcm5821_close(cfe_devctx_t *ctx)
{
    bcm5821_state_t *sc = ctx->dev_softc;

    bcm5821_stop(sc);
    sc->devctx = NULL;
    return 0;
}
