/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef _SBCHIPC_56XXX_H_
#define _SBCHIPC_56XXX_H_

/*
 * Register and bit definitions for the Chip Common control
 * registers.
 */

/* Control and Interrupt Registers */
#define R_CHIPID                0x000
#define R_CORECAPABILITIES      0x004
#define R_INTSTATUS             0x020
#define R_IPSFLAG               0x100
#define R_INTVEC                0x104
/*
#define R_INTMASK               0x024
*/

/* GPIO Registers */
#define R_GPIOINPUT             0x060
#define R_GPIOOUTPUT            0x064
#define R_GPIOOUTEN             0x068
#define R_GPIOCONTROL           0x06C
#define R_GPIOINTPOLARITY       0x070
#define R_GPIOINTMASK           0x074
#define R_WATCHDOGCOUNTER       0x080

/* Backward compatibility aliases */
#define R_WATCHDOGCNTR          R_WATCHDOGCOUNTER

#define R_ICS_SOFT_RESET        0x110

/* Clock Control Registers */
#define R_PLL_CTRL1                 0x090
#define R_PLL_CTRL2                 0x094
#define R_PLL_STATUS                0x098

#define S_MIPS2SYSTEM_CLK_RATIO     0
#define M_MIPS2SYSTEM_CLK_RATIO     \
            _DD_MAKEMASK(2,S_MIPS2SYSTEM_CLK_RATIO)
#define V_MIPS2SYSTEM_CLK_RATIO     \
            _DD_MAKEVALUE(x,S_MIPS2SYSTEM_CLK_RATIO)
#define G_MIPS2SYSTEM_CLK_RATIO(x)     \
   _DD_GETVALUE(x,S_MIPS2SYSTEM_CLK_RATIO, M_MIPS2SYSTEM_CLK_RATIO)



/*
 * Flash timing control register.
 */
#define R_PARALLELFLASHWAITCNT  0x12C

/* CHIPID: ChipID Register (0x000, RO) */

#define S_CHIPID_CI             0                       /* ChipID */
#define M_CHIPID_CI             _DD_MAKEMASK(20,S_CHIPID_CI)
#define V_CHIPID_CI(x)          _DD_MAKEVALUE(x,S_CHIPID_CI)
#define G_CHIPID_CI(x)          _DD_GETVALUE(x,S_CHIPID_CI,M_CHIPID_CI)

#define S_CHIPID_RI             20                      /* RevisionID */
#define M_CHIPID_RI             _DD_MAKEMASK(4,S_CHIPID_RI)
#define V_CHIPID_RI(x)          _DD_MAKEVALUE(x,S_CHIPID_RI)
#define G_CHIPID_RI(x)          _DD_GETVALUE(x,S_CHIPID_RI,M_CHIPID_RI)

#define S_CHIPID_PO             24                      /* PackageOption */
#define M_CHIPID_PO             _DD_MAKEMASK(8,S_CHIPID_PO)
#define V_CHIPID_PO(x)          _DD_MAKEVALUE(x,S_CHIPID_PO)
#define G_CHIPID_PO(x)          _DD_GETVALUE(x,S_CHIPID_PO,M_CHIPID_PO)

/* CORECAP: Core Capabilities Register (0x004, RO) */

#define M_CORECAP_EM                    _DD_MAKEMASK1(0) /* EndianMode */
#define M_CORECAP_MEMC_IO_TYPE          _DD_MAKEMASK1(1)
#define M_CORECAP_MIPS_CLK_MODE         _DD_MAKEMASK1(2)
#define M_CORECAP_MIPS_EN_CLK_RATIO     _DD_MAKEMASK1(3)
#define S_CORECAP_DEF_MIPS_CLK_RATIO    4
#define M_CORECAP_DEF_MIPS_CLK_RATIO    \
            _DD_MAKEMASK(2,S_CORECAP_DEF_MIPS_CLK_RATIO)
#define M_CORECAP_MIPS_PLL_BYPASS       _DD_MAKEMASK1(6)
#define M_CORECAP_MIPS_PLL_PWRDN        _DD_MAKEMASK1(7)
#define M_CORECAP_FLASH_DATA_WIDTH      _DD_MAKEMASK1(8)
#define M_CORECAP_PORT_DISABLE_0        _DD_MAKEMASK1(17)
#define M_CORECAP_PORT_DISABLE_1        _DD_MAKEMASK1(18)
#define M_CORECAP_PORT_DISABLE_2        _DD_MAKEMASK1(19)
#define M_CORECAP_CORE_CLK_FREQ_SEL     _DD_MAKEMASK1(22)
#define M_CORECAP_SERIAL_FLASH          _DD_MAKEMASK1(24)


#endif /* _SBCHIPC_56XXX_H_ */
