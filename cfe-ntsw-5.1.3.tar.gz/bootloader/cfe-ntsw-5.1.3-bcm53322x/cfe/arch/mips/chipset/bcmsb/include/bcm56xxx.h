/*
   BCM56XXX address space map and definitions
   
   Copyright 2002-2003, Broadcom Corporation
   All Rights Reserved.
    
   This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
   the contents of this file may not be disclosed to third parties, copied or
   duplicated in any form, in whole or in part, without the prior written
   permission of Broadcom Corporation.
*/

#ifndef _BCM56XXX_H_
#define _BCM56XXX_H_

/* Define the chip, to match legacy #ifdef's. */
#define BCM56XXX  1

/* Define the chip family */
#define BCM47xx  1

#define BCM56XXX_SDRAM		0x00000000 /* 0-128MB Physical SDRAM */
#define	BCM56XXX_SDRAM_SWAPPED	0x10000000 /* Byteswapped Physical SDRAM */

/* BCM5365 Core register space */
#define BCM56XXX_REG_CHIPC	0x18000000 /* Chipcommon  registers */
#define BCM56XXX_REG_MIPS33	0x18005000 /* MIPS core registers */
#define BCM56XXX_REG_MEMC	0x18008000 /* MEMC core registers */
#define BCM56XXX_REG_CORECAP    0x18000004 /* core capability   */

#define BCM56XXX_REG_UARTS       (BCM56XXX_REG_CHIPC + 0x300) /* UART regs */


/* Internal 16550-compatible UARTs */
#define	BCM56XXX_UART0		(BCM56XXX_REG_UARTS + 0x00000000)
#define	BCM56XXX_UART1		(BCM56XXX_REG_UARTS + 0x00000100)

#define MIPS33_FLASH_REGION_AUX 0x1C000000 /* FLASH Region 2 */
#define MIPS33_FLASH_REGION     0x1FC00000 /* Boot FLASH Region  */

/* BSP Abstraction, pickup names via bsp_config.h. */


#define SB_CHIPC_BCM56XXX_BASE  BCM56XXX_REG_CHIPC
#define SB_CHIPC_BASE           SB_CHIPC_BCM56XXX_BASE
#define SB_MIPS33_BASE          BCM56XXX_REG_MIPS33
#define SB_MEMC_BASE            BCM56XXX_REG_MEMC
#define BCM56XXX_ICS_CMIC_BASE  0x08000000

#define SB_AUX_FLASH_SPACE      MIPS33_FLASH_REGION_AUX
#define SB_FLASH_SPACE          MIPS33_FLASH_REGION

#endif /* _BCM56XXX_H_ */
