/*
    Copyright 2001, Broadcom Corporation
    All Rights Reserved.
    
    This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
    the contents of this file may not be disclosed to third parties, copied or
    duplicated in any form, in whole or in part, without the prior written
    permission of Broadcom Corporation.
*/
/*
 * BCM4710 address space map and definitions
 *
 * Think twice before adding to this file, this is not the kitchen sink
 * These definitions are not guaranteed for all 47xx chips, only the 4710
 *
 * Copyright (C) 2000 Broadcom Corporation
 * $Id: bcm4710.h,v 1.1.1.1 2007/01/31 00:39:21 sanjayg Exp $
 */

#ifndef _BCM4710_H_
#define _BCM4710_H_

/* Define the chip, to match legacy #ifdef's.
   The 4702 and 4710 are bug-compatible, but 4702 lacks iLine support.  */
#define BCM4710  1

/* Define the chip family */
#define BCM47XX  1
#define BCM47xx  1

/* Address map */
#define BCM4710_SDRAM		0x00000000	/* Physical SDRAM */
#define BCM4710_PCI_MEM		0x08000000	/* Host Mode PCI memory access space (64 MB) */
#define BCM4710_PCI_CFG		0x0c000000	/* Host Mode PCI configuration space (64 MB) */
#define BCM4710_PCI_DMA		0x40000000	/* Client Mode PCI memory access space (1 GB) */
#define	BCM4710_SDRAM_SWAPPED	0x10000000	/* Byteswapped Physical SDRAM */
#define BCM4710_ENUM		0x18000000	/* Beginning of core enumeration space */

/* Core register space */
#define BCM4710_REG_SDRAM	0x18000000	/* SDRAM core registers */
#define BCM4710_REG_ILINE20	0x18001000	/* InsideLine20 core registers */
#define BCM4710_REG_EMAC0	0x18002000	/* Ethernet MAC 0 core registers */
#define BCM4710_REG_CODEC	0x18003000	/* Codec core registers */
#define BCM4710_REG_USB		0x18004000	/* USB core registers */
#define BCM4710_REG_PCI		0x18005000	/* PCI core registers */
#define BCM4710_REG_MIPS	0x18006000	/* MIPS core registers */
#define BCM4710_REG_EXTIF	0x18007000	/* External Interface core registers */
#define BCM4710_REG_EMAC1	0x18008000	/* Ethernet MAC 1 core registers */

#define	BCM4710_EXTIF		0x1f000000	/* External Interface base address */
#define	BCM4710_EJTAG		0xff200000	/* MIPS EJTAG space (2M) */

#define	BCM4710_UART		(BCM4710_REG_EXTIF + 0x00000300)


/* bcm4710 and bcm4702 mapping to generic sb_bp identifiers. */
/* XXX It would be better to discover this dynamically. */

/* System backplane addresses of core enumeration spaces. */

#define SB_ENUM_BASE            BCM4710_ENUM

#define SB_SDRAM_BASE           BCM4710_REG_SDRAM
#define SB_ILINE20_BASE         BCM4710_REG_ILINE20
#define SB_ENET0_BASE           BCM4710_REG_EMAC0
#define SB_CODEC_BASE           BCM4710_REG_CODEC
#define SB_USB_BASE             BCM4710_REG_USB
#define SB_PCI_BASE             BCM4710_REG_PCI
#define SB_MIPS_BASE            BCM4710_REG_MIPS
#define SB_EXTIF_BASE           BCM4710_REG_EXTIF
#define SB_ENET1_BASE           BCM4710_REG_EMAC1

/* System backplane addresses for external interfaces. */

#define SB_PCMCIA_BASE          BCM4710_EXTIF
#define SB_PROGINT_BASE         (BCM4710_EXTIF + 0x800000)
#define SB_FLASH_BASE           (BCM4710_EXTIF + 0xC00000)

#endif /* _bcm4710_h_ */
