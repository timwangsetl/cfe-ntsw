/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5836 MII driver                               File: sb_mii.c
    *  
    *  Basic operations for BCM5836 MII managment interface.
    *  Compatible with BCM4704/4704P.
    *  
    *********************************************************************  
    *
    *  Copyright 2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "sbmips.h"

#include "ui_command.h"

#include "lib_physio.h"

#include "sb_bp.h"
#include "sb_pci.h"
#include "sb_mac.h"

#include "mii.h"

#include "cfe_mii.h"


#define PHY_READCSR(sc,csr) (phys_read32((sc)->membase + (csr)))
#define PHY_WRITECSR(sc,csr,val) (phys_write32((sc)->membase + (csr), (val)))

#define M_MAC_MDIO_DIR_OUTPUT	0		/* for clarity */

typedef uint32_t phys_addr_t;
#define PHY_PORT(x) PHYS_TO_K1(x)

typedef struct sb_mii_softc_s {
    unsigned long base;
    int default_phyaddr;
    phys_addr_t membase;
} sb_mii_softc_t;


/*  *********************************************************************
    *  Forward declarations
    ********************************************************************* */

static cfe_mii_channel_t *sb_mii_attach(cfe_mii_t *ops,uint64_t probe_a,uint64_t probe_b);
static int sb_mii_init(cfe_mii_channel_t *chan);
static int sb_mii_default_addr(cfe_mii_channel_t *chan);
static void sb_mii_write(cfe_mii_channel_t *chan,int addr,int regidx,unsigned int regval);
static unsigned int sb_mii_read(cfe_mii_channel_t *chan,int addr,int regidx);


/*  *********************************************************************
    *  MII operations
    ********************************************************************* */

cfe_mii_t sb_mii = {
    sb_mii_attach,
    sb_mii_init,
    sb_mii_default_addr,
    sb_mii_write,
    sb_mii_read
};


static cfe_mii_channel_t *sb_mii_attach(cfe_mii_t *ops,uint64_t probe_a,uint64_t probe_b)
{
    cfe_mii_channel_t *chan;	
    sb_mii_softc_t *softc;

    chan = KMALLOC(sizeof(cfe_mii_channel_t)+sizeof(sb_mii_softc_t),0);

    if (!chan) return NULL;

    chan->ops = ops;
    chan->softc = (void *) (chan+1);

    softc = chan->softc;
    softc->base = probe_a;
    softc->default_phyaddr = probe_b;
    softc->membase = PHY_PORT(softc->base);

    return chan;
}

static int sb_mii_init(cfe_mii_channel_t *chan)
{
    return 0;
}

static int sb_mii_default_addr(cfe_mii_channel_t *chan)
{
    sb_mii_softc_t *s = chan->softc;

    return s->default_phyaddr;
}


static unsigned int sb_mii_read(cfe_mii_channel_t *chan,int phyaddr,int regidx)
{
    sb_mii_softc_t *s = chan->softc;
    uint32_t cmd, status;
    uint32_t data;
    int timeout;

    if (phyaddr < 0) phyaddr = s->default_phyaddr;

    PHY_WRITECSR(s, R_ENET_INT_STATUS, M_EINT_MI);
    (void)PHY_READCSR(s, R_ENET_INT_STATUS);

    cmd = (V_MIIDATA_OP(K_MII_OP_READ) | V_MIIDATA_TA(K_TA_VALID) |
           V_MIIDATA_RA(regidx) | V_MIIDATA_PM(phyaddr));
    PHY_WRITECSR(s, R_MII_DATA, cmd | V_MIIDATA_SB(K_MII_START));

    for (timeout = 1000; timeout > 0; timeout -= 100) {
	status = PHY_READCSR(s, R_ENET_INT_STATUS);
	if ((status & M_EINT_MI) != 0)
	    break;
	cfe_usleep(100);
	}

    if (timeout <= 0)
	return 0xFFFF;

    data = G_MIIDATA_D(PHY_READCSR(s, R_MII_DATA));
    return data;
}


static void sb_mii_write(cfe_mii_channel_t *chan,int phyaddr,int regidx,
                         unsigned int regval)
{
    sb_mii_softc_t *s = chan->softc;
    uint32_t cmd, status;
    int timeout;

    if (phyaddr < 0) phyaddr = s->default_phyaddr;

    PHY_WRITECSR(s, R_ENET_INT_STATUS, M_EINT_MI);
    (void)PHY_READCSR(s, R_ENET_INT_STATUS);

    cmd = (V_MIIDATA_OP(K_MII_OP_WRITE) | V_MIIDATA_TA(0x2) |
           V_MIIDATA_RA(regidx) | V_MIIDATA_PM(phyaddr) |
	   V_MIIDATA_D(regval));
    PHY_WRITECSR(s, R_MII_DATA, cmd | V_MIIDATA_SB(K_MII_START));

    for (timeout = 1000; timeout > 0; timeout -= 100) {
	status = PHY_READCSR(s, R_ENET_INT_STATUS);
	if ((status & M_EINT_MI) != 0)
	    break;
	cfe_usleep(100);
	}
}
