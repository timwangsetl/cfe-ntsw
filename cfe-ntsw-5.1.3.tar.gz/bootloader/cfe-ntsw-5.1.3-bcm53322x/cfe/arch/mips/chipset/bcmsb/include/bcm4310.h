/*
    Copyright 2001,2002,2003 Broadcom Corporation
    All Rights Reserved.
    
    This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
    the contents of this file may not be disclosed to third parties, copied or
    duplicated in any form, in whole or in part, without the prior written
    permission of Broadcom Corporation.
*/

/*
 * BCM4310 address space map and definitions
 */

#ifndef _BCM4310_H_
#define _BCM4310_H_

/* Define the chip, to match legacy #ifdef's. */
#define BCM4310  1

/* Define the chip family */
#define BCM47XX  1
#define BCM47xx  1

/* Address map */
#define BCM4310_SDRAM		0x00000000	/* 0-128MB Physical SDRAM */
#define BCM4310_PCI_MEM		0x08000000	/* Host Mode PCI mem space (64 MB) */
#define BCM4310_PCI_CFG		0x0c000000	/* Host Mode PCI cfg space (64 MB) */
#define BCM4310_PCI_DMA		0x40000000	/* Client Mode PCI mem space (1 GB) */
#define	BCM4310_SDRAM_SWAPPED	0x10000000	/* Byteswapped Physical SDRAM */
#define BCM4310_ENUM		0x18000000	/* Beginning of core enum space */

/* Core register space */
#define BCM4310_REG_CHIPC	0x18000000	/* Chipcommon  registers */
#define BCM4310_REG_WLAN	0x18001000	/* 802.11 MAC registers */
#define BCM4310_REG_EMAC0	0x18002000	/* Ethernet MAC 0 core registers */
#define BCM4310_REG_EMAC1	0x18003000	/* Ethernet MAC 1 core registers */
#define BCM4310_REG_USB		0x18004000	/* USB core registers */
#define BCM4310_REG_PCI		0x18005000	/* PCI core registers */
#define BCM4310_REG_MIPS	0x18006000	/* MIPS core registers */
#define BCM4310_REG_SDRAM	0x18007000	/* SDRAM core registers */

#define BCM4310_REG_UARTS       (BCM4310_REG_CHIPC + 0x300)      /* Internal UART registers */

#define	BCM4310_EJTAG		0xff200000	/* MIPS EJTAG space (2M) */

#define	BCM4310_UART0		(BCM4310_REG_UARTS + 0x00000000)
#define	BCM4310_UART1		(BCM4310_REG_UARTS + 0x00000100)

/* bcm4310 mapping to generic sb_bp identifiers */

/* BSP Abstraction, pickup names via bsp_config.h. */
/* XXX It would be better to discover this dynamically. */

#define SB_ENUM_BASE            BCM4310_ENUM

#define SB_CHIPC_BASE           BCM4310_REG_CHIPC
#define SB_WLAN_BASE            BCM4310_REG_WLAN
#define SB_ENET0_BASE           BCM4310_REG_EMAC0
#define SB_ENET1_BASE           BCM4310_REG_EMAC1
#define SB_USB_BASE             BCM4310_REG_USB
#define SB_PCI_BASE             BCM4310_REG_PCI
#define SB_MIPS_BASE            BCM4310_REG_MIPS
#define SB_SDRAM_BASE           BCM4310_REG_SDRAM

#endif /* _BCM4310_H_ */
