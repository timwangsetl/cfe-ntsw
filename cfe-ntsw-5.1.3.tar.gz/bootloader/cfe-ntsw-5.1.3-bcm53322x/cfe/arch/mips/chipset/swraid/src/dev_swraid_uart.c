/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  ServerWorks RAID uart driver		File: dev_swraid_uart.c
    *  
    *  Driver for the on-chip UARTs in the ServerWorks RAID controller
    *  chip ("Aragorn" and derivatives)
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */


#include "cfe.h"

#include "swraid_defs.h"
#include "swraid_periph.h"

#define READCSR(sc,x) *((volatile uint32_t *) ((sc)->uart_base+(x)))
#define WRITECSR(sc,p,v) *((volatile uint32_t *) ((sc)->uart_base+(p))) = (v)

static int swraid_uart_open(cfe_devctx_t *ctx);
static int swraid_uart_read(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int swraid_uart_inpstat(cfe_devctx_t *ctx,iocb_inpstat_t *inpstat);
static int swraid_uart_write(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int swraid_uart_ioctl(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int swraid_uart_close(cfe_devctx_t *ctx);

void swraid_uart_probe(cfe_driver_t *drv,
			unsigned long probe_a, unsigned long probe_b, 
			void *probe_ptr);


const cfe_devdisp_t swraid_uart_dispatch = {
    swraid_uart_open,
    swraid_uart_read,
    swraid_uart_inpstat,
    swraid_uart_write,
    swraid_uart_ioctl,
    swraid_uart_close,	
    NULL,
    NULL
};

const cfe_driver_t swraid_uart = {
    "Aragorn UART",
    "uart",
    CFE_DEV_SERIAL,
    &swraid_uart_dispatch,
    swraid_uart_probe
};

typedef struct swraid_uart_s {
    physaddr_t uart_base;
    int uart_flowcontrol;
    int baud_base;
    int uart_speed;
} swraid_uart_t;



void swraid_uart_probe(cfe_driver_t *drv,
			unsigned long probe_a, unsigned long probe_b, 
			void *probe_ptr)
{
    swraid_uart_t *softc;
    char descr[80];

    softc = (swraid_uart_t *) KMALLOC(sizeof(swraid_uart_t),0);
    if (softc) {
	softc->uart_base = probe_a;
	softc->baud_base = probe_b ? probe_b : PERIPH_CLOCK;
	softc->uart_speed = CFG_SERIAL_BAUD_RATE;
	softc->uart_flowcontrol = SERIAL_FLOW_NONE;
	xsprintf(descr, "%s at 0x%X", drv->drv_description, (uint32_t)probe_a);

	cfe_attach(drv, softc, NULL, descr);
	}
}


static void swraid_uart_setflow(swraid_uart_t *softc)
{
    /* noop for now */
}


static int swraid_uart_open(cfe_devctx_t *ctx)
{
    swraid_uart_t *softc = ctx->dev_softc;
    unsigned int brtc;

    brtc = UART_BAUDWORD(softc->baud_base, softc->uart_speed);

    WRITECSR(softc,R_UART_IMASK,0);

    WRITECSR(softc,R_UART_CONTROL,
	     V_UARTCTL_STOP(K_UARTCTL_STOP_1) |
	     V_UARTCTL_RXTIMO(4) |
	     M_UARTCTL_RXPAREVEN |
	     M_UARTCTL_RXPARITY);

    WRITECSR(softc,R_UART_BAUDWORD,brtc);

    WRITECSR(softc,R_UART_MISC,
	     V_UARTMISC_RXFIFOFILL(8) |
	     V_UARTMISC_TXFIFOFILL(8));

    WRITECSR(softc,R_UART_CONTROL,
	     V_UARTCTL_STOP(K_UARTCTL_STOP_1) |
	     V_UARTCTL_RXTIMO(4) |
	     M_UARTCTL_TXEN |
	     M_UARTCTL_RXEN |
	     M_UARTCTL_BREN);

    return 0;
}

static int swraid_uart_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    swraid_uart_t *softc = ctx->dev_softc;
    unsigned char *bptr;
    int blen;

    bptr = buffer->buf_ptr;
    blen = buffer->buf_length;

    while ((blen > 0) && (READCSR(softc,R_UART_ISTATUS) & M_UARTSTS_RXFNE)) {
	*bptr++ = (READCSR(softc,R_UART_FIFO) & M_UARTFIFO_FIFO);
	blen--;
	}

    buffer->buf_retlen = buffer->buf_length - blen;
    return 0;
}

static int swraid_uart_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    swraid_uart_t *softc = ctx->dev_softc;

    inpstat->inp_status = (READCSR(softc,R_UART_ISTATUS) & M_UARTSTS_RXFNE) ? 1 : 0;

    return 0;
}

static int swraid_uart_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    swraid_uart_t *softc = ctx->dev_softc;
    unsigned char *bptr;
    int blen;

    bptr = buffer->buf_ptr;
    blen = buffer->buf_length;
    while ((blen > 0) && (READCSR(softc,R_UART_ISTATUS) & M_UARTSTS_TXFTHLD)) {
	WRITECSR(softc,R_UART_FIFO, *bptr++);
	blen--;
	}

    buffer->buf_retlen = buffer->buf_length - blen;
    return 0;
}

static int swraid_uart_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    swraid_uart_t *softc = ctx->dev_softc;

    unsigned int *info = (unsigned int *) buffer->buf_ptr;

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_SERIAL_GETSPEED:
	    *info = softc->uart_speed;
	    break;
	case IOCTL_SERIAL_SETSPEED:
	    softc->uart_speed = *info;
	    /* NYI */
	    break;
	case IOCTL_SERIAL_GETFLOW:
	    *info = softc->uart_flowcontrol;
	    break;
	case IOCTL_SERIAL_SETFLOW:
	    softc->uart_flowcontrol = *info;
	    swraid_uart_setflow(softc);
	    break;
	default:
	    return -1;
	}

    return 0;
}

static int swraid_uart_close(cfe_devctx_t *ctx)
{
    swraid_uart_t *softc = ctx->dev_softc;

    WRITECSR(softc,R_UART_CONTROL,
	     V_UARTCTL_STOP(K_UARTCTL_STOP_1) |
	     V_UARTCTL_RXTIMO(4) |
	     M_UARTCTL_RXPAREVEN |
	     M_UARTCTL_RXPARITY);

    return 0;
}



