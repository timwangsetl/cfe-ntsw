/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Test commands                File: ui_bcm953000.c
    *  
    *  A temporary sandbox for misc test routines and commands.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#include "cfe.h"
#include "env_subr.h"

#include "ui_command.h"

#include "sbmips32.h"
#include "sb_bp.h"

#include "sb_utils.h"
#include "siutils.h"
#include "bsp_priv.h"

#ifdef CFG_SOCDIAG
extern void socdiag_init(void);
extern void et_socdiag_addcmd(void);
#endif /* CFG_SOCDIAG */

#include "chipc_i2c.h"
#include "hndpmu.h"

static int ui_cmd_i2c(ui_cmdline_t *cmd,int argc,char *argv[]);

static int ui_cmd_gpio(ui_cmdline_t *cmd,int argc,char *argv[]);

extern void et_addcmd(void);
int ui_init_nvramcmds(void);

int ui_init_bcm953000cmds(void);
static int ui_cmd_timertest(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_envdev(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_clock(ui_cmdline_t* cmd, int argc, char *argv[]);
static int ui_cmd_showconfig(ui_cmdline_t* cmd, int argc, char *argv[]);
static int ui_cmd_reset(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_power(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_reg(ui_cmdline_t *cmd, int argc, char *argv[]);
#ifdef _BCM953284MDU_
static int ui_cmd_slic(ui_cmdline_t *cmd, int argc, char *argv[]);
#endif
#ifdef CFG_QUICKTURN
/* hard coded for QT */
#define KS_I2C_ADDR0    0x45
#define KS_I2C_ADDR1    0x4a
#endif  /* CFG_QUICKTURN */

static int 
ui_cmd_i2c(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *command, *sub_cmd;
    cc_i2c_id_t i2c_id;    
    i2c_addr_t  i2c_addr;
    uint8       data[] = {0,0,0,0,0,0,0,0};
    int         len;
    int         speed;
    int i;
    
    if (!(command = cmd_getarg(cmd, 0))){
        return CFE_ERR_INV_PARAM;
    }
    
    if (!strcmp(command, "init")){
        if (ksi2c_init()){
            printf("%s,init failed!!\n",__func__);
            return -1;
        }
        printf("I2c bus init Done, i2c #0/#1 both disabled!\n");
    } else if (!strcmp(command, "busio")){
        char *bus_id=NULL, *p1=NULL, *p2=NULL;
        int act, op, val;
        uint8   op_val = 0;
        
        if (!(sub_cmd = cmd_getarg(cmd, 1))){
            printf("busio data|control|status|clock [bus_id] [arg..]\n",
                    __func__);
            return CFE_ERR_INV_PARAM;
        }
        
        bus_id = cmd_getarg(cmd, 2);
        p1 = cmd_getarg(cmd, 3);
        if (bus_id == NULL){
            printf("%s,bus id requirred! id=0/1!\n",__func__);
            return -1;
        }
        
        i2c_id = atoi(bus_id);
        if ( i2c_id < CC_I2C_NUM_BUS && bus_id > CC_I2C_ID0){
            i2c_id = (i2c_id) ? CC_I2C_ID1 : CC_I2C_ID0; 
        } else {
            printf("%s,bus_id incorrect!\n",__func__);
            return -1;
        }

        if (!strcmp(sub_cmd, "data")){
            op = 0; /* i2c_data */
            if (p1 == NULL){
                printf("%s,busio data [bus_id] [R/W(1/0)] [val(write)]\n",
                        __func__);
                return -1;
            }
            act = atoi(p1);
            if (act == I2C_OP_WRITE){    /* write OP */
                p2 = cmd_getarg(cmd, 4);
                if (p2 != NULL) {
                    val = atoi(p2);
                } else {
                    val = 0;
                }
            } else {  /* Read OP */
                act = I2C_OP_READ;
                val = 0;
            }
            
        } else if (!strcmp(sub_cmd, "control")){
            op = 1; /* i2c_control */
            if (p1 == NULL){
                printf("%s,busio control [bus_id] [R/W(1/0)] [val(write)]\n",
                        __func__);
                return -1;
            }
            act = atoi(p1);
            if (act == I2C_OP_WRITE){    /* write OP */
                p2 = cmd_getarg(cmd, 4);
                if (p2 != NULL) {
                    val = atoi(p2);
                } else {
                    val = 0;
                }
            } else {  /* Read OP */
                act = I2C_OP_READ;
                val = 0;
            }
        } else if (!strcmp(sub_cmd, "saddr")){
            op = 2; /* i2c_slaveaddr */
            if (p1 == NULL){
                printf("%s,busio saddr [bus_id] [R/W(1/0)] [val(write)]\n",
                        __func__);
                return -1;
            }
            act = atoi(p1);
            if (act == I2C_OP_WRITE){    /* write OP */
                p2 = cmd_getarg(cmd, 4);
                if (p2 != NULL) {
                    val = atoi(p2);
                } else {
                    val = 0;
                }
            } else {  /* Read OP */
                act = I2C_OP_READ;
                val = 0;
            }
        } else if (!strcmp(sub_cmd, "status")){
            op = 3; /* i2c_status*/
            act = I2C_OP_READ;  /* act is ignored, i2c_status is read only */
            val = 0;    /* dummy assignment */
        } else if (!strcmp(sub_cmd, "clock")){          
            op = 4; /* i2c_clock */
            if (p1 == NULL){
                printf("%s,busio clock [bus_id] [ccr(write only)]\n",__func__);
                return -1;
            }
            val = atoi(p1);
            val &= 0x7f;    /* mask for valid value */
            
            /* act is ignored, i2c_ccr is write only */
            act = I2C_OP_WRITE;
        } else {
            return CFE_ERR_INV_PARAM;
        }
        op_val = (uint8)val;
        if (ksi2c_test_busio(i2c_id, op, act, &op_val)){
            printf("%s,bus IO process failed!!\n",__func__);
        } else {
            char *op_s[]={"i2c_data","i2c_control","i2c_status","i2c_clock"};
            char *act_s[]={"Write", "Read"};
            printf("\n I2C_Bus_%d op(%s) action(%s) >> value(0x%02x) Done!\n",
                    i2c_id, op_s[op],act_s[act],op_val);
        }
    } else if (!strcmp(command, "dumpreg")){
        
        ksi2c_test_dumpreg();
    } else if (!strcmp(command, "reset")){
        ksi2c_reset(CC_I2C_ID0);
        printf("I2c bus_0 reset Done!\n");
        ksi2c_reset(CC_I2C_ID1);
        printf("I2c bus_1 reset Done!\n");
    } else if (!strcmp(command, "open")){
        int op_mode;
        char *bus_id=NULL;
        char *clk=NULL;
        
        bus_id = cmd_getarg(cmd, 1);
        if (bus_id == NULL){
            i2c_id = 0;
        } else {
            i2c_id = atoi(bus_id);
            if ( i2c_id < CC_I2C_NUM_BUS && bus_id > CC_I2C_ID0){
                i2c_id = (i2c_id) ? CC_I2C_ID1 : CC_I2C_ID0; 
            } else {
                printf("%s,bus_id incorrect!\n",__func__);
                return -1;
            }
        }
        printf("Opening I2C bus_%d....\n", i2c_id);

        op_mode = KS_I2C_BUS_PIO;
        clk = cmd_getarg(cmd, 2);
        if (clk == NULL){
            speed = KS_I2C_SPEED_DEFAULT;
        } else {
            speed = atoi(clk);
            if ((speed < KS_I2C_SPEED_DEFAULT) || 
                   (speed > KS_I2C_SPEED_HIGH)){
                speed = KS_I2C_SPEED_DEFAULT;
            }
        }
        
        if (ksi2c_open(i2c_id, op_mode, speed)){
            printf("\t Failed on opening this i2c bus!!\n");
        }
    } else if (!strcmp(command, "close")){
        char *bus_id=NULL;
        
        bus_id = cmd_getarg(cmd, 1);
        if (bus_id == NULL){
            i2c_id = 0;
        } else {
            i2c_id = atoi(bus_id);
            if ( i2c_id < CC_I2C_NUM_BUS && bus_id > CC_I2C_ID0){
                i2c_id = (i2c_id) ? CC_I2C_ID1 : CC_I2C_ID0; 
            } else {
                printf("bus_id incorrect!\n");
                return -1;
            }
        }
        
        printf("Closing I2C bus_#d....\n", i2c_id);
        if (ksi2c_close(i2c_id)){
            printf("\t Failed on closing this i2c bus!!\n");
        }
    } else if (!strcmp(command, "dev_read")){
        char *bus_id = NULL, *in_len = NULL, *slave_addr = NULL;
        char *devaddr_len = NULL, *devaddr = NULL;
        uint    dev_addr_len = 0;
        uint32   dev_addr = 0; /* support up to 32 bits address */
        
        bus_id = cmd_getarg(cmd, 1);
        slave_addr = cmd_getarg(cmd, 2);
        devaddr = cmd_getarg(cmd, 3);
        devaddr_len = cmd_getarg(cmd, 4);
        in_len = cmd_getarg(cmd, 5);
         if (bus_id == NULL || slave_addr == NULL || in_len == NULL ||
                devaddr == NULL || devaddr_len == NULL){
            printf("Usage : dev_read [bus_id] [slave_addr] [devaddr] "
                    "[devaddr_length(byte)] [data_length(byte)]\n");
            return -1;
        }
        i2c_id = atoi(bus_id);
        i2c_addr = atoi(slave_addr);
        dev_addr = atoi(devaddr);
        dev_addr_len = atoi(devaddr_len);
        len = atoi(in_len);
        
        if ( i2c_id < CC_I2C_NUM_BUS && bus_id > CC_I2C_ID0){
            i2c_id = (i2c_id) ? CC_I2C_ID1 : CC_I2C_ID0; 
        } else {
            printf("bus_id incorrect!\n");
            return -1;
        }

        if (len > 8){
            printf("max 8 bytes R/W for test only!\n");
            return -1;
        } else if (len <= 0){
            printf("length incorrect!\n");
            return -1;
        }
        
        if (dev_addr_len > 4){
            printf("max 4 bytes i2c device address is allowed!\n");
            return -1;
        } else if (dev_addr_len <= 0){
            printf("device address length incorrect!\n");
            return -1;
        }
        printf ("Reading %d bytes on I2C bus_%d(Addr=0x%02x) address=0x%x.\n",
                len, i2c_id, i2c_addr, dev_addr);

        if (ksi2c_i2cdev_read(i2c_id, i2c_addr, data, len, 
                dev_addr, dev_addr_len)){
            printf("\t Device read OP failed!!\n");
            return -1;
        } else {
            printf("\nI2C_Bus_%d Read >> value=[0x%02x", i2c_id, data[0]);
            for (i=1;i<len;i++)     printf(",0x%02x",data[i]);
            printf("] Done!!\n");
        }
        
    } else if (!strcmp(command, "dev_write")){
        char *bus_id = NULL, *in_len = NULL, *slave_addr = NULL;
        char *devaddr_len = NULL, *devaddr = NULL;
        uint    dev_addr_len = 0;
        uint32   dev_addr = 0; /* support up to 32 bits address */
        char    *in_data[8];

        memset(in_data, 0, sizeof(in_data));
        bus_id = cmd_getarg(cmd, 1);
        slave_addr = cmd_getarg(cmd, 2);
        devaddr = cmd_getarg(cmd, 3);
        devaddr_len = cmd_getarg(cmd, 4);
        in_len = cmd_getarg(cmd, 5);
         if (bus_id == NULL || slave_addr == NULL || in_len == NULL ||
                devaddr == NULL || devaddr_len == NULL){
            printf("Usage : dev_write [bus_id] [slave_addr] [devaddr] "
                    "[devaddr_length(byte)] [data_length(byte)] "
                    "[data0(byte)]..[data7(byte)]\n");
            return -1;
        }
        i2c_id = atoi(bus_id);
        i2c_addr = atoi(slave_addr);
        dev_addr = atoi(devaddr);
        dev_addr_len = atoi(devaddr_len);
        len = atoi(in_len);
        
        if ( i2c_id < CC_I2C_NUM_BUS && bus_id > CC_I2C_ID0){
            i2c_id = (i2c_id) ? CC_I2C_ID1 : CC_I2C_ID0; 
        } else {
            printf("bus_id incorrect!\n");
            return -1;
        }
    
        if (len > 8){
            printf("max 8 bytes R/W for test only!\n");
            return -1;
        } else if (len <= 0){
            printf("length incorrect!\n");
            return -1;
        }

        printf ("Writing %d bytes at I2C bus_%d(Addr=0x%02x),data={",
                len, i2c_id, i2c_addr);
        for (i=0;i<len;i++){
            in_data[i] = cmd_getarg(cmd, 6+i);
            data[i] = (in_data[i]!=NULL) ? atoi(in_data[i]) : 0;
            printf("0x%02x,",data[i]);
        }
        printf("}\n");
        
        if (dev_addr_len > 4){
            printf("max 4 bytes i2c device address is allowed!\n");
            return -1;
        } else if (dev_addr_len <= 0){
            printf("device address length incorrect!\n");
            return -1;
        }
        printf ("Wrtie %d bytes on I2C bus_%d(Addr=0x%02x) address=0x%x.\n",
                len, i2c_id, i2c_addr, dev_addr);
    
        if (ksi2c_i2cdev_write(i2c_id, i2c_addr, data, len, 
                dev_addr, dev_addr_len)){
            printf("\t Device write OP failed!!\n");
            return -1;
        } else {
            printf("\nI2C_Bus_%d Write >> value=[0x%02x", i2c_id, data[0]);
            for (i=1;i<len;i++)     printf(",0x%02x",data[i]);
            printf("] Done!!\n");
        }
    } else if (!strcmp(command, "read")){
        char *bus_id = NULL, *in_len = NULL, *slave_addr = NULL;
        
        bus_id = cmd_getarg(cmd, 1);
        slave_addr = cmd_getarg(cmd, 2);
        in_len = cmd_getarg(cmd, 3);
        if (bus_id == NULL || slave_addr == NULL || in_len == NULL){
            printf("Usage : read [bus_id] [slave_addr] [length(byte)]\n");
            return -1;
        }
        i2c_id = atoi(bus_id);
        i2c_addr = atoi(slave_addr);
        len = atoi(in_len);

        if ( i2c_id < CC_I2C_NUM_BUS && bus_id > CC_I2C_ID0){
            i2c_id = (i2c_id) ? CC_I2C_ID1 : CC_I2C_ID0; 
        } else {
            printf("bus_id incorrect!\n");
            return -1;
        }

        if (len > 8){
            printf("max 8 bytes R/W for test only!\n");
            return -1;
        } else if (len <= 0){
            printf("length incorrect!\n");
            return -1;
        }
        
        printf ("Reading %d bytes at I2C bus_%d(Addr=0x%02x)....\n",
                len, i2c_id, i2c_addr);
        if (ksi2c_read(i2c_id, i2c_addr, data, len)){
            printf("\t Read OP failed!!\n");
            return -1;
        } else {
            printf("\nI2C_Bus_%d Read >> value=[0x%02x", i2c_id, data[0]);
            for (i=1;i<len;i++)     printf(",0x%02x",data[i]);
            printf("] Done!!\n");
        }
        
    } else if (!strcmp(command, "write")){
        char *bus_id = NULL,*in_len = NULL,*in_data[] = {NULL,NULL,NULL,NULL};
        char *slave_addr = NULL;

        bus_id = cmd_getarg(cmd, 1);
        slave_addr = cmd_getarg(cmd, 2);
        in_len = cmd_getarg(cmd, 3);
        if (bus_id == NULL || slave_addr == NULL || in_len == NULL){
            printf("Usage : write [bus_id] [slave_addr] [length(byte)] "
                    "[data0(byte)]..[data3(byte)]\n", __func__);
            return -1;
        }
        i2c_id = atoi(bus_id);
        i2c_addr = atoi(slave_addr);
        len = atoi(in_len);

        if ( i2c_id < CC_I2C_NUM_BUS && bus_id > CC_I2C_ID0){
            i2c_id = (i2c_id) ? CC_I2C_ID1 : CC_I2C_ID0; 
        } else {
            printf("bus_id incorrect!\n");
            return -1;
        }
        if (len > 8){
            printf("max 8 bytes R/W for test only!\n");
            return -1;
        } else if (len <= 0){
            printf("length incorrect!\n");
            return -1;
        }

        printf ("Writing %d bytes at I2C bus_%d(Addr=0x%02x),data={",
                len, i2c_id, i2c_addr);
        for (i=0;i<len;i++){
            in_data[i] = cmd_getarg(cmd, 4+i);
            data[i] = (in_data[i]!=NULL) ? atoi(in_data[i]) : 0;
            printf("0x%02x,",data[i]);
        }
        printf("}\n");
        
        if (ksi2c_write(i2c_id, i2c_addr, data, len)){
            printf("%s,write failed!!\n",__func__);
            return -1;
        } else {
            printf("\nI2C_Bus_%d Write >> value=[0x%02x", i2c_id, data[0]);
            for (i=1;i<len;i++)     printf(",0x%02x",data[i]);
            printf("] Done!!\n");
        }
        
    } else {
        return CFE_ERR_INV_PARAM;
    }
    
    return 0;
}

#define GPIO_OP_PULLUP      0
#define GPIO_OP_PULLDOWN    1
static int 
ui_cmd_gpio(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int     pin_id = 0, pin_val = 0, rv = 0;
    uint16  ori_control_val = 0, ori_en = 0, temp = 0, tmp_bmp = 0;
    char *command, *sub_cmd;
    char *pin = NULL, *val = NULL;
    
    if (!(command = cmd_getarg(cmd, 0))){
        return CFE_ERR_INV_PARAM;
    }
    
    if (!strcmp(command, "dumpreg")){
        ksgpio_dumpreg();

    } else if (!strcmp(command, "init")){
        ksgpio_Init();
    } else if (!strcmp(command, "timer")){
        uint32 timer_val = 0;
        uint16 timer_en = 0;
       
        if (!(sub_cmd = cmd_getarg(cmd, 1))){
            printf("timer on|off [pin_id] [arg..]\n",__func__);
            return CFE_ERR_INV_PARAM;
        }

        pin = cmd_getarg(cmd, 2);
        val = cmd_getarg(cmd, 3);
        rv = ksgpio_TimerEnableGet(&timer_en);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }
        if (!strcmp(sub_cmd, "on")){
            if (pin == NULL || val == NULL){
                printf("Usage : timer on [pin_id] [val=0-0xffff]\n");
                return -1;
            }
            pin_id = atoi(pin);
            if (pin_id < 0 || pin_id > 15){
                printf("GPIO pin_id %d invalid!!(id at 0-15 is valid)\n", pin_id);
                return -1;
            }
            timer_val = atoi(val);
            printf("GPIO pin_id %d with timer(on_cnt=0x%x,off_cnt=0x%x\n", 
                    pin_id, (uint16)(timer_val >> 16), (uint16)timer_val);

            /* save the original GPIO pin control value */
            rv = ksgpio_CtrlGet(&ori_control_val);
            /* save the enabled pin configuraiton */
            rv |= ksgpio_OutEnGet(&ori_en);
            if (rv){
                printf("Command failed! Retry with 'gpio init' first!\n");
                return -1;
            }

            /* set the target pin to chipcommon core. */
            if (ori_control_val & (1 << pin_id)){
                printf("  Note:GPIO pin %d reserved for other core!\n", pin_id);
                temp = ori_control_val & ~((uint16)(1 << pin_id));
            }
            ksgpio_CtrlSet(temp);
            
            /* disable the all pins before write request */   
            printf("  Note:Output for All GPIO pins are disabled!\n");     
            ksgpio_OutEnSet(0);
            
            /* set timer on/off value */
            ksgpio_TimerSet((uint16)(timer_val >> 16), (uint16)timer_val);

            /* enable timer outmask for the pin */
            timer_en |= (1 << pin_id);
            ksgpio_TimerEnableSet(timer_en);
            
            /* eanble the the pin for the write request */        
            ksgpio_OutEnSet(1 << pin_id);
            
            /* restore the GPIO pins to original core. */
            printf("  Note:Restore each GPIO pin to original core.\n");
            ksgpio_CtrlSet(ori_control_val);
            
            /* restore the pins enabled configuraiton */
            printf("  Note:Restor origianl output enable status.\n");
            ksgpio_OutEnSet(ori_en);
            
        } else if (!strcmp(sub_cmd, "off")){
            if (pin == NULL){
                printf("Usage : timer off [pin_id]\n");
                return -1;
            }
            pin_id = atoi(pin);
            if (pin_id < 0 || pin_id > 15){
                printf("GPIO pin_id %d invalid!!(id at 0-15 is valid)\n", pin_id);
                return -1;
            }
            
            /* disable gpio timer on the pin */
            timer_en &= ~(1 << pin_id); 
            ksgpio_TimerEnableSet(timer_en);
            
        } else {
            return CFE_ERR_INV_PARAM;
        }    
        
    } else if (!strcmp(command, "write")){
        uint16 set_value = 0;
        
        pin = cmd_getarg(cmd, 1);
        val = cmd_getarg(cmd, 2);
        if (pin == NULL || val == NULL){
            printf("Usage : write [pin_id] [bit_value(1/0)]\n");
            return -1;
        }
        pin_id = atoi(pin);
        if (pin_id < 0 || pin_id > 15){
            printf("GPIO pin_id %d invalid!!(id at 0-15 is valid)\n", pin_id);
            return -1;
        }
        pin_val = atoi(val);
        if (!(pin_val == 0 || pin_val == 1)){
            printf("GPIO pin value %d will be treated as 1!!\n", pin_val);
            pin_val = 1;
        }
        
        /* save the original GPIO pin control value */
        rv = ksgpio_CtrlGet(&ori_control_val);
        /* save the enabled pin configuraiton */
        rv |= ksgpio_OutEnGet(&ori_en);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }
          
        /* set the target pin to chipcommon core. */
        if (ori_control_val & (1 << pin_id)){
            printf("  Note:GPIO pin %d reserved for other core!\n", pin_id);
            temp =  ori_control_val & ~((uint16)(1 << pin_id));
        }
        ksgpio_CtrlSet(temp);
        
        /* disable the all pins before write request */   
        printf("  Note:Output for All GPIO pins are disabled!\n");     
        ksgpio_OutEnSet(0);

        /* set the write value */
        set_value = (pin_val) ? (1 << pin_id) : 0;
        ksgpio_OutSet(set_value);
        
        /* eanble the the pin for the write request */        
        ksgpio_OutEnSet(1 << pin_id);
        
        ksgpio_OutGet(&temp);
        if (temp == set_value) {
            printf("GPIO pin %d write as %d done.\n", pin_id, pin_val);
        } else {
            printf("GPIO pin %d write as %d failed!\n", pin_id, pin_val);
        }
        
        /* restore the GPIO pins to original core. */
        printf("  Note:Restore each GPIO pin to original core.\n");
        ksgpio_CtrlSet(ori_control_val);
        
        /* restore the pins enabled configuraiton */
        printf("  Note:Restor origianl output enable status.\n");
        ksgpio_OutEnSet(ori_en);
        
    } else if (!strcmp(command, "out_enable")){
        
        pin = cmd_getarg(cmd, 1);
        if (pin == NULL){
            printf("Usage : out_enable [pin_id]\n");
            return -1;
        }
        pin_id = atoi(pin);
        if (pin_id < 0 || pin_id > 15){
            printf("GPIO pin_id %d invalid!!(id at 0-15 is valid)\n", pin_id);
            return -1;
        }

        rv = ksgpio_OutEnGet(&ori_en);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }
        
        if (ori_en & (1 << pin_id)) {
            printf("GPIO pin %d alread enabled!!\n", pin_id);
        } else {
            ksgpio_OutEnSet(ori_en | (1 << pin_id));
            printf("GPIO pin %d is change to be enabled!!\n", pin_id);
        }

    } else if (!strcmp(command, "out_disable")){
        
        pin = cmd_getarg(cmd, 1);
        if (pin == NULL){
            printf("Usage : out_disable [pin_id]\n");
            return -1;
        }
        pin_id = atoi(pin);
        if (pin_id < 0 || pin_id > 15){
            printf("GPIO pin_id %d invalid!!(id at 0-15 is valid)\n", pin_id);
            return -1;
        }

        rv = ksgpio_OutEnGet(&ori_en);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }

        if (ori_en & (1 << pin_id)) {
            ksgpio_OutEnSet(ori_en & ~(1 << pin_id));
            printf("GPIO pin %d changed to be disabled!!\n", pin_id);
        } else {
            printf("GPIO pin %d alread disabled!!\n", pin_id);
        }
    } else if (!strcmp(command, "pull_high")){

        pin = cmd_getarg(cmd, 1);
        if (pin == NULL){
            printf("Usage : pull_high [pin_bmp]\n");
            return -1;
        }
        tmp_bmp = atoi(pin);
        printf(" Request pull_high on pins 0x%02X\n", tmp_bmp);
        
        rv = ksgpio_PullGet(GPIO_OP_PULLUP, &temp);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }
        
        tmp_bmp |= temp;
        rv = ksgpio_PullSet(GPIO_OP_PULLUP, tmp_bmp);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }
        
        printf(" Finished Pull_high on pins 0x%02X\n", tmp_bmp);
        
    } else if (!strcmp(command, "pull_low")){
        pin = cmd_getarg(cmd, 1);
        if (pin == NULL){
            printf("Usage : pull_low [pin_bmp]\n");
            return -1;
        }
        tmp_bmp = atoi(pin);
        printf(" Request pull_low on pins 0x%02X\n", tmp_bmp);
        
        rv = ksgpio_PullGet(GPIO_OP_PULLDOWN, &temp);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }
        
        tmp_bmp |= temp;
        rv = ksgpio_PullSet(GPIO_OP_PULLDOWN, tmp_bmp);
        if (rv){
            printf("Command failed! Retry with 'gpio init' first!\n");
            return -1;
        }
        
        printf(" Finished pull_low on pins 0x%02X\n", tmp_bmp);

    } else {
        return CFE_ERR_INV_PARAM;
    }
    return 0;
}

int ui_init_bcm953000cmds(void)
{

    ui_init_nvramcmds();

    cmd_addcmd("test timer",
           ui_cmd_timertest,
           NULL,
           "Test the timer",
           "test timer",
           "");

    cmd_addcmd("envdev",
           ui_cmd_envdev,
           NULL,
           "set environment device",
           "envdev sourcedev",
           "");

    cmd_addcmd("clock",
           ui_cmd_clock,
           NULL,
           "Change CPU/PCI clock (clock <cpu> <pci>)",
           "clock",
           "");

    cmd_addcmd("reset",
           ui_cmd_reset,
           NULL,
           "Reset the system.",
           "reset [-yes] -cpu|-sysreset",
           "-yes;Don't ask for confirmation|"
           "-cpu;Reset the CPU|"
           "-sysreset;Full system reset");

    cmd_addcmd("power",
           ui_cmd_power,
           NULL,
           "Power on/off function.",
           "power [on|off] [func name] [id]",
           "-on/off;power on/off function|"
           "-func name;select function among pcie/sgmii/usb/ddr2|"
           "-id;select PCIE Serdes (1/all/low_leak) or|"
           ";DDR2 PHY byte lane(2/3)");

    cmd_addcmd("reg",
               ui_cmd_reg,
               NULL,
               "ROBO Switch Register Get/Set utility.",
               "reg [get/set] unit page addr len [pattern]\n\n",
               "get;Gets the value of the specified register|"
               "set;Sets the value of the specified register|"
               "unit;Applied chip ID|"
               "page;Page number of the specified register|"
               "addr;Address offset of the specified register|"
               "len;Length of the specified register|"
               "pattern;Values set to the specified register|");

    cmd_addcmd("show config",
           ui_cmd_showconfig,
           NULL,
           "Dump CP0 configuration registers",
           "show config",
           "");
    cmd_addcmd("i2c",
	       ui_cmd_i2c,
	       NULL,
	       "i2c bus Diagnostic",
	       "i2c command [args...]\n\n",
	       "init;Init i2c bus|"
	       "open;open i2c bus|"
	       "close;close i2c bus|"
	       "dumpreg;dump i2c registers|"
	       "busio;i2c bus direct I/O|"
	       "reset;i2c bus reset|"
	       "dev_read;read data from i2c bus on specific i2c_device address|"
           "dev_write;write data to i2c bus on specific i2c_device address|"
	       "read;read from i2c bus|"
	       "write;write to i2c bus");

    cmd_addcmd("gpio",
	       ui_cmd_gpio,
	       NULL,
	       "gpio Diagnostic",
	       "gpio command [args...]\n\n",
	       "init; init gpio|"
	       "dumpreg; dump gpio registers|"
	       "pull_high; Force Pull up on the indicated GPIO pins|"
	       "pull_low; Force Pull down on the indicated GPIO pins|"
	       "timer; set timer on/off on a indicated GPIO pin|"
	       "write; write 1/0 on a indicated GPIO pin|"
	       "out_enable; enable the IO on a indicated GPIO pin|"
	       "out_disable; disable the IO on a indicated GPIO pin");

#ifdef _BCM953284MDU_
    cmd_addcmd("slic",
           ui_cmd_slic,
	       NULL,
	       "slic  Diagnostic",
	       "slic [slab/zarlink] [args...]\n\n",
              "slab [id]; id: slic module id (1-3)|"
              "zarlink [id]");
#endif

    et_addcmd();
    
#ifdef CFG_SOCDIAG
    socdiag_init();
    et_socdiag_addcmd();
#endif /* CFG_SOCDIAG */

    return 0;
}
#ifdef _BCM953284MDU_

static int
ui_cmd_slic(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *command, *index;
    uint32 val, ss, i;

    if (!(command = cmd_getarg(cmd, 0))){
        ui_showusage(cmd);
        return CFE_ERR_INV_PARAM;
    }
    printf("slic need PCLK and FSYNC! Check the clock first.\n");
    
    if (!strcmp(command, "slab")) {               
        /* enable SPI 0,1,2 */
        *(volatile uint32 *)(0xb80002f4) = 0x1d;
        
        /* spi mode=3 */
        val = *(volatile uint32 *)(0xb8000280);
        val |= 0x3;
        *(volatile uint32 *)(0xb8000280) = val;

        /* GPIO 14 to unset the reset */
        *(volatile uint32 *)(0xb8000064)=0;
        *(volatile uint32 *)(0xb8000068)=0x4000;
        /* 300 ms in low */
        cfe_usleep(3*100000);
        *(volatile uint32 *)(0xb8000064)=0x4000;

        /* wait 300ms then start to read register*/ 
        cfe_usleep(3*100000);    
        
        index = cmd_getarg(cmd, 1);
        if (index) {
            ss=atoi(index);
        } else {
            ss = 1;
        }
            
        /* ss2 and ss3 shared the same SPI 2 interface
            GPIO 11 to select ss2 or ss3*/

        if(ss == 2) {
            *(volatile uint32 *)(0xb8000064)=0x4800;
            *(volatile uint32 *)(0xb8000068)=0x4800;
        }
        if(ss == 3) {
            ss = 2;
        }
        /* cmd=0x60 addr=0x0 write 2 byte cmd */
        *(volatile uint32 *)(0xb8000288)=0x60000000;
        *(volatile uint32 *)(0xb8000284)=0x81000000|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }

        *(volatile uint32 *)(0xb800028c)=0x4;

        *(volatile uint32 *)(0xb8000284)=0x80000010|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }

        val = *(volatile uint32 *)(0xb8000288);
        printf("silicon lab slic cmd=0x60 reg =0 val %x (should be 0xc1)\n",val);
        
        *(volatile uint32 *)(0xb800028c)=0x4;
        return 0;

    }

    if (!strcmp(command, "zarlink")) {

        /* enable SPI 0,1,2 */
        *(volatile uint32 *)(0xb80002f4) = 0x1d;
        
        /* spi mode=0 */
        val = *(volatile uint32 *)(0xb8000280);
        val &= ~0x3;       
        *(volatile uint32 *)(0xb8000280) = val;


        /* GPIO 14 to unset the reset */
        *(volatile uint32 *)(0xb8000064)=0;
        *(volatile uint32 *)(0xb8000068)=0x4000;
        /* 300 ms in low */
        cfe_usleep(3*100000);        
        *(volatile uint32 *)(0xb8000064)=0x4000;

        /* wait 300ms then start to read register*/ 
        cfe_usleep(3*100000);        
        
        index = cmd_getarg(cmd, 1);
        if (index) {
            ss=atoi(index);
        } else {
            ss = 1;
        }

        /* ss2 and ss3 shared the same SPI 2 interface
            GPIO 11 to select ss2 or ss3*/

        if(ss == 2) {
            *(volatile uint32 *)(0xb8000064)=0x4800;
            *(volatile uint32 *)(0xb8000068)=0x4800;
        }
        if(ss == 3) {
            ss = 2;
        }

        /* Read reg 6 */
        *(volatile uint32 *)(0xb8000288)=0x86000000;
        *(volatile uint32 *)(0xb8000284)=0x81000000|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }

        *(volatile uint32 *)(0xb800028c)=0x4;

        *(volatile uint32 *)(0xb8000284)=0x80000010|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }
        val = *(volatile uint32 *)(0xb8000288);
        printf("zarlink slic reg =6 val %x (should be 0x3fff)\n",val);
        *(volatile uint32 *)(0xb800028c)=0x4;

        /* Read reg 7 */
        *(volatile uint32 *)(0xb8000288)=0x87000000;
        *(volatile uint32 *)(0xb8000284)=0x81000000|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }

        *(volatile uint32 *)(0xb800028c)=0x4;

        *(volatile uint32 *)(0xb8000284)=0x80000010|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }

        val = *(volatile uint32 *)(0xb8000288);
        printf("zarlink slic reg =7 val %x (should be 0xff00)\n",val);
        *(volatile uint32 *)(0xb800028c)=0x4;


        /* Write 0x1234 to reg 6*/
        *(volatile uint32 *)(0xb8000288)=0x86801234;
        *(volatile uint32 *)(0xb8000284)=0x80008000|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }
        *(volatile uint32 *)(0xb800028c)=0x4;

        *(volatile uint32 *)(0xb8000288)=0x86000000;
        *(volatile uint32 *)(0xb8000284)=0x81000010|ss;

        /* check staus */
        for (i=0; i< 1000000 ; i++){
            val=*(volatile uint32 *)(0xb800028c);
            val &= 0x2;
            if (val)
                break;
        }
        val = *(volatile uint32 *)(0xb8000288);

        printf("zarlink slic write reg =6 0x1234 read: val %x \n",val);
        *(volatile uint32 *)(0xb800028c)=0x4;
        return 0;
    }

    /* default for ROBO chips spi mode=3 */
    val = *(volatile uint32 *)(0xb8000280);
    val |= 0x3;
    *(volatile uint32 *)(0xb8000280) = val;

    return 0;
}
#endif
static int
ui_cmd_reg(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *command, *unit, *page, *addr, *len, *value;
    uint8_t buf[32];
    int i, idx, fh, buflen;
    
    if (!(command = cmd_getarg(cmd, 0))){
        ui_showusage(cmd);
        return CFE_ERR_INV_PARAM;
    }
    
    /* For now, robo0 is the default for spi channel */
    if ((fh = cfe_open("robo0")) < 0) {
        printf("cfe_open robo0 failed\n");
        return CFE_ERR_DEVOPEN;
    }
    
    if (!strcmp(command, "get")) {
        if ((unit = cmd_getarg(cmd, 1)) &&
            (page = cmd_getarg(cmd, 2)) &&
            (addr = cmd_getarg(cmd, 3)) &&
            (len = cmd_getarg(cmd, 4))) {
                if ((buflen = atoi(len)) > sizeof(buf)) {
                    cfe_close(fh);
                    return CFE_ERR_INV_PARAM;
                }
                cfe_readblk(fh, ((atoi(page) & 0xff) << 8) |
                    ((atoi(addr) & 0xff) << 0),
                    PTR2HSADDR(buf), buflen);
                printf("[0x%x,0x%x,0x%x] = ", atoi(unit), atoi(page), atoi(addr));
                for (i=0; i<buflen; i++) {
#if ENDIAN_BIG
                    printf("0x%02x ", buf[buflen-1-i]);
#else
                    printf("0x%02x ", buf[i]);
#endif
                }
                printf("\n");
        } else {
            cfe_close(fh);
            return CFE_ERR_INV_PARAM;
        }
    } else if (!strcmp(command, "set")) {
        if ((unit = cmd_getarg(cmd, 1)) &&
            (page = cmd_getarg(cmd, 2)) &&
            (addr = cmd_getarg(cmd, 3)) &&
            (len = cmd_getarg(cmd, 4))) {
                if ((buflen = atoi(len)) > sizeof(buf)) {
                    cfe_close(fh);
                    return CFE_ERR_INV_PARAM;
                }
                for (i=0, idx=5; i<buflen; i++) {
                    if ((value = cmd_getarg(cmd, idx++))) {
#if ENDIAN_BIG
                        buf[buflen-1-i] = (uint8_t)atoi(value);
#else
                        buf[i] = (uint8_t)atoi(value);
#endif
                    } else {
                        cfe_close(fh);
                        return CFE_ERR_INV_PARAM;
                    }
                }
                cfe_writeblk(fh, ((atoi(page) & 0xff) << 8) |
                    ((atoi(addr) & 0xff) << 0),
                    PTR2HSADDR(buf), buflen);
        } else {
            cfe_close(fh);
            return CFE_ERR_INV_PARAM;
        }
    } else {
        cfe_close(fh);
        return ui_showusage(cmd);
   }
    cfe_close(fh);
    
    return 0;
}

static int ui_cmd_envdev(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x;

    x = cmd_getarg(cmd,0);
    if (x) {
    cfe_set_envdevice(x);
    printf("environment device set to %s\n",x);
    }

    return 0;
}

static int ui_cmd_clock(ui_cmdline_t* cmd, int argc, char *argv[])
{
    char *x = NULL, *y = NULL;
    unsigned long req_sb, req_cpu, req_pci;

    req_sb  = 100000000;
    req_cpu = 200000000;
    req_pci =  33000000;     /* Defaults at reset */

    x = cmd_getarg(cmd,0);
    y = cmd_getarg(cmd,1);

    if (x) req_cpu = atoi(x);
    if (y) req_pci = atoi(y);

    /* Multiply for user */
    if (req_pci < 1000000) req_pci *= 1000000;
    if (req_cpu < 1000000) req_cpu *= 1000000;

    if (x || y) { 
    si_setclock(req_cpu, req_pci);

    /* If either frequency changed, sb_setclock will reboot the system
       and there will be no return to the following code.
       XXX Furthermore, the reboot will reset the PCI frequency to
       the default for the board.
    */
    }

    cfe_cpu_speed = si_cpu_clock();
    printf("CPU clock at %dMhz\n", (cfe_cpu_speed+500000)/1000000);

    return 0;
}   

static int ui_cmd_reset(ui_cmdline_t *cmd,int argc,char *argv[])
{
    uint8_t data = 0;
    int confirm = 1;
    char str[50];
    int sys_reset_pin, cpu_reset_pin;
    char *sys_reset_str, *cpu_reset_str;

    sys_reset_pin = (sys_reset_str = env_getenv("SYS_RESET_PIN")) ?
                   atoi(sys_reset_str) :
#ifdef CFG_SYSTEM_RESET_GPIO_PIN
                   CFG_SYSTEM_RESET_GPIO_PIN;
#else
                   32; /* None */
#endif
    cpu_reset_pin = (cpu_reset_str = env_getenv("CPU_RESET_PIN")) ?
                   atoi(cpu_reset_str) :
#ifdef CFG_SYSTEM_RESET_GPIO_PIN
                   CFG_SYSTEM_RESET_GPIO_PIN;
#else
                   32; /* None */
#endif

    if (cmd_sw_isset(cmd,"-yes")) confirm = 0;

    if (cmd_sw_isset(cmd,"-sysreset")) data |= 0x1;

    if (cmd_sw_isset(cmd,"-cpu")) data |= 0x2;

    if (data == 0) {        /* no changes to reset pins were specified */
    return ui_showusage(cmd);
    }

    if (confirm) {
    console_readline("Are you sure you want to reset? ",str,sizeof(str));
    if ((str[0] != 'Y') && (str[0] != 'y')) return -1;
    }

    if (data & 0x1) {
        /* Reset system and CPU */
        /* Pulling GPIO bit 7 from high to low */
        si_gpioout(
            sih, 
            (1 << sys_reset_pin) |
            (1 << cpu_reset_pin),
            (1 << sys_reset_pin) |
            (1 << cpu_reset_pin),
            GPIO_HI_PRIORITY
            );
        si_gpioouten(
            sih, 
            (1 << sys_reset_pin) |
            (1 << cpu_reset_pin),
            (1 << sys_reset_pin) |
            (1 << cpu_reset_pin),
            GPIO_HI_PRIORITY
            );
        si_gpioout(
            sih, 
            (1 << sys_reset_pin) |
            (1 << cpu_reset_pin),
            0x0, 
            GPIO_HI_PRIORITY
            );
    } else if (data & 0x2) {
        if (sih->chiprev == 0) {
            /* Chip revision A0 */
            /*
             * Using system reset (GPIO 7) to cover CPU reset
             * since the CPU watchdog function is not working 
             * This section should be removed for the new revision of CPU
             * that fix the watchdog 
             */
            /* Reset system and CPU */
            /* Pulling GPIO bit 7 from high to low */
            si_gpioout(
                sih, 
                (1 << cpu_reset_pin),
                (1 << cpu_reset_pin),
                GPIO_HI_PRIORITY
                );
            si_gpioouten(
                sih, 
                (1 << cpu_reset_pin),
                (1 << cpu_reset_pin),
                GPIO_HI_PRIORITY
                );
            si_gpioout(
                sih, 
                (1 << cpu_reset_pin),
                0x0, 
                GPIO_HI_PRIORITY
                );
        }

        si_watchdog(sih, 1);
        /* should not return */
    }

    return -1;
}


static int ui_cmd_timertest(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int64_t t;

    t = cfe_ticks;

    while (!console_status()) {
    cfe_sleep(CFE_HZ);
    if (t != cfe_ticks) {
        xprintf("Time is 0x%llX\n",cfe_ticks);
        t = cfe_ticks;      
        }
    }

    return 0;
}


extern uint32_t read_config0(void);
extern uint32_t read_config1(void);

static int ui_cmd_showconfig(ui_cmdline_t *cmd,int argc,char *argv[])
{
    xprintf("config 0: 0x%08x,  1: 0x%08x\n", read_config0(), read_config1());

    return 0;
}

static int ui_cmd_power(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *switch_command;
    char *command;

    if (!(switch_command = cmd_getarg(cmd, 0))){
        return ui_showusage(cmd);
    }

    if (!strcmp(switch_command, "on")){
        printf("Power on command is not supported currently.\n");
        return -1;
    } else if (!strcmp(switch_command, "off")){
        /* nothing to do now */
    } else {
        return ui_showusage(cmd);
    }

    if (!(command = cmd_getarg(cmd, 1))){
        return ui_showusage(cmd);
    }

    if (!strcmp(command, "usb")){
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_USB, 0, \
                                             POWER_SWITCH_STATE_OFF);
        printf("Poweroff USB...\n");
    } else if (!strcmp(command, "pcie")){
        char *_id=NULL;
        int pcie_id = 0;

        _id = cmd_getarg(cmd, 2);
        if (_id == NULL){
            printf("PCIE id not specified.\n");
            return -1;
        } else if (!strcmp(_id, "all")) {
            pcie_id = POWER_SWITCH_ID_PCIE_ALL;
        } else if (!strcmp(_id, "low_leak")) {
            pcie_id = POWER_SWITCH_ID_PCIE_ALL_LOW_LEAK_MODE;
        } else {
            pcie_id = atoi(_id);
            if (pcie_id != 1) {
                printf("Incorre pcie id\n");
                return -1;
            }
        }

        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_PCIE, pcie_id, \
                                             POWER_SWITCH_STATE_OFF);

        if (pcie_id == POWER_SWITCH_ID_PCIE_ALL) {
            printf("Poweroff PCIE 0 and 1...\n");
        } else if (pcie_id == POWER_SWITCH_ID_PCIE_ALL_LOW_LEAK_MODE) {
            printf("Poweroff PCIE 0 and 1 Low Leak Mode...\n");
        } else {
            printf("Poweroff PCIE %d...\n", pcie_id);
        }
    } else if (!strcmp(command, "sgmii")){
        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_SGMII, 0, \
                                             POWER_SWITCH_STATE_OFF);

        printf("Poweroff SGMII Serdes...\n");
    } else if (!strcmp(command, "ddr2")){
        char *_id=NULL;
        int lane_id = 0;
        
        _id = cmd_getarg(cmd, 2);
        if (_id == NULL){
            printf("DDR2 PHY lane id not specified.\n");
            return -1;
        } else {
            lane_id = atoi(_id);
            if ((lane_id < 2) ||(lane_id > 3)){
                printf("Incorret DDR2 PHY lane id\n");
                return -1;
            }
        }

        si_pmu_power_switch(sih, POWER_SWITCH_FUNC_DDR2, lane_id, \
                                             POWER_SWITCH_STATE_OFF);

        printf("Poweroff DDR2 PHY lane %d...\n", lane_id);
    } else {
        printf("Incorrect functionality\n");
        return CFE_ERR_INV_PARAM;
    }

    return 0;
}


