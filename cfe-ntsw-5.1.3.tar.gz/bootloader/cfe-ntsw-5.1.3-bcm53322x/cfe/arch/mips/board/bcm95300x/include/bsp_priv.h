/*
 * $Copyright Broadcom Corporation$
 *
 * $Id: bsp_priv.h,v 1.2 2009/05/21 21:35:13 miyarn Exp $
 */
#ifndef _LANGUAGE_ASSEMBLY

/* Global SI handle */
extern si_t *bcm953000_sih;
#define sih bcm953000_sih

/* BSP UI initialization */
extern int ui_init_bcm953000cmds(void);
#if CFG_ET
extern void et_addcmd(void);
#endif


#endif

