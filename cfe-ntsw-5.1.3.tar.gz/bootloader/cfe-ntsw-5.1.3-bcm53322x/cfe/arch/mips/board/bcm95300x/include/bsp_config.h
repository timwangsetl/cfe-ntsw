/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BSP Configuration file			File: bsp_config.h
    *  
    *  This module contains global parameters and conditional
    *  compilation settings for building CFE.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef _BSP_CONFIG_H
#define _BSP_CONFIG_H

#define CFG_INIT_L1		1	/* initialize the L1 cache */
#define CFG_INIT_L2		0	/* there is no L2 cache */

#define CFG_INIT_DRAM		1	/* initialize DRAM controller */
#define CFG_DRAM_SIZE		xxx	/* size of DRAM if you don't initialize */


#ifdef QUICK_TURN
#define CFG_NETWORK	0   /* define to include network support */
#define CFG_FATFS       0
#define CFG_TCP		0
#define CFG_HTTPFS	0
#define CFG_URLS	0

#define CFG_FULLDIAG        1
#else

#define CFG_NETWORK	1	/* define to include network support */
#define CFG_FATFS       1
#define CFG_TCP		1
#define CFG_HTTPFS	1
#define CFG_URLS	1

#endif  /* QUICK_TURN */
#define CFG_UI			1	/* Define to enable user interface */
#define CFG_PTABLE          1

#define CFG_NVRAM_SIZE      0x10000	/* define nvram size */

#define CFG_MULTI_CPUS		0	/* no multi-cpu support */

#define CFG_HEAP_SIZE		1024	/* heap size in kilobytes */
#define CFG_STACK_SIZE		8192	/* stack size (bytes, rounded up to K) */

#define CFG_SERIAL_LEDS		0	/* never set this (UART can hang) */


#ifndef CFG_SERIAL_BAUD_RATE
#ifdef CFG_QUICKTURN
#define CFG_SERIAL_BAUD_RATE	2400	/* lower console speed for QT */
#else /* !CFG_QUICKTURN */
#define CFG_SERIAL_BAUD_RATE	9600	/* normal console speed */
#endif /* CFG_QUICKTURN */
#endif

#define CFG_VENDOR_EXTENSIONS   0

/* 
  * Config the 1st flash visible memory size (MBytes), default as 8 MB
  * The flash maximum visible memory size is 60 MB (directly mapping),
  * and 0 means that use the flash probing size.
  */
#define CFG_CS0_VISIBLE_MEM_SIZE   0

/* The 2nd flash type definition */
#define CS1_NONE        0
#define CS1_PFLASH      1
#define CS1_SFLASH_ST   2
#define CS1_SFLASH_AT   3

/* Define the 2nd flash type, default is none */
#if defined(_BCM953003EWAP_) || defined(_BCM953003RSP_)
#define CFG_CS1_FLASH_TYPE  CS1_NONE
#else /* SVK board */
#define CFG_CS1_FLASH_TYPE  CS1_PFLASH
#endif

/*
 * These parameters control the flash driver's sector buffer.  
 * If you write environment variables or make small changes to
 * flash sectors from user applications, you
 * need to have the heap big enough to store a temporary sector
 * for merging in small changes to flash sectors, so you
 * should set CFG_FLASH_ALLOC_SECTOR_BUFFER in that case.
 * Otherwise, you can provide an address in unallocated memory
 * of where to place the sector buffer.
 */
/* '1' to allocate sector buffer from the heap */
#define CFG_FLASH_ALLOC_SECTOR_BUFFER 0	
#define CFG_FLASH_SECTOR_BUFFER_ADDR  (1*1024*1024-128*1024) /* 1MB - 128K */
#define CFG_FLASH_SECTOR_BUFFER_SIZE  (128*1024)

/*
 * The flash staging buffer is where we store a flash image before we write
 * it to the flash.  It's too big for the heap.
 */

#define CFG_FLASH_STAGING_BUFFER_ADDR (1*1024*1024)
#define CFG_FLASH_STAGING_BUFFER_SIZE (16*1024*1024)


/*
 * GPIO pin for system reset
 */
#ifdef _BCM953003EWAP_
#define CFG_SYSTEM_RESET_GPIO_PIN       (7)
#elif defined(_BCM953003RSP_)
#define CFG_SYSTEM_RESET_GPIO_PIN       (6)
#endif

/*
 * SPI select for Robo device
 */
#ifdef _BCM953003RSP_
#define CFG_ROBO_SPI_SS     CC_SPI_SS0
#elif defined(_BCM953284MDU_)
#define CFG_ROBO_SPI_SS     CC_SPI_SS0
#else /* SVK board */
#define CFG_ROBO_SPI_SS     CC_SPI_SS1
#endif


/*
 * DRAM routines: use chipset defaults
 */
#define board_draminfo  bcmsi_draminfo
#define board_draminit  bcmsi_draminit


#ifdef CFG_QUICKTURN

/*
 * DDR configuration
 *
 * For Quickturn: MT47H256M8 x 4
 */

/* For backward compatibility */
#define MEMDDR
#define DDRM32X16X2

/* (required) PLL clock */
#define CFG_DDR_PLL_CLOCK       (300000)  /* KHz */

/* (required) Row bits: 0=11bits, 1=12bits, ..., 5=16bits */
#define CFG_DDR_ROW_BITS        4   /* 15 bits */

/* (required) Column bits: 1=9bits, 2=10bits, 3=11bits */
#define CFG_DDR_COLUMN_BITS     2   /* 10 bits */

/* (required) Bank bits: 0=2bits, 3=3bits */
#define CFG_DDR_BANK_BITS       3  

/* (required) Memory width: 0=16bits, 1=32bits, 2=64bits */
#define CFG_DDR_MEM_WIDTH       1

/* (required) CAS Latency (NOTE: could be affected by PLL clock) */
#define CFG_DDR_CAS_LATENCY     5

/* (required) t_wr (picoseconds) */
#define CFG_DDR_T_WR            15000

/* (optional) Refresh period (picoseconds) */
#define CFG_DDR_REFRESH_PRD     7800000

/* (optional) t_rfc (picoseconds) */
#define CFG_DDR_T_RFC           197500

#else /* !CFG_QUICKTURN */

#ifdef _BCM953003EWAP_

/*
 * DDR configuration
 *
 * For EWAP reference board: K4T1G164QQ-HCE6
 */

/* For backward compatibility */
#define MEMDDR
#define DDRM32X16X2

/* (required) PLL clock */
#define CFG_DDR_PLL_CLOCK       (331250)  /* KHz */

/* (required) Row bits: 0=11bits, 1=12bits, ..., 5=16bits */
#define CFG_DDR_ROW_BITS        2   /* 13 bits */

/* (required) Column bits: 1=9bits, 2=10bits, 3=11bits */
#define CFG_DDR_COLUMN_BITS     2   /* 10 bits */

/* (required) Bank bits: 0=2bits, 3=3bits */
#define CFG_DDR_BANK_BITS       3  

/* (required) Memory width: 0=16bits, 1=32bits, 2=64bits */
#define CFG_DDR_MEM_WIDTH       1

/* (required) CAS Latency (NOTE: could be affected by PLL clock) */
#define CFG_DDR_CAS_LATENCY     5

/* (required) t_wr (picoseconds) */
#define CFG_DDR_T_WR            15000

/* (optional) Refresh period (picoseconds) */
#define CFG_DDR_REFRESH_PRD     7800000

/* (optional) t_rfc (picoseconds) */
#define CFG_DDR_T_RFC           127500


#elif defined(_BCM953003RSP_)

/*
 * DDR configuration
 *
 * For RSP reference board: K4T51163QG-HCE6
 */

/* For backward compatibility */
#define MEMDDR
#define DDRM32X16X2

/* (required) PLL clock */
#define CFG_DDR_PLL_CLOCK       (331250)  /* KHz */

/* (required) Row bits: 0=11bits, 1=12bits, ..., 5=16bits */
#define CFG_DDR_ROW_BITS        2   /* 13 bits */

/* (required) Column bits: 1=9bits, 2=10bits, 3=11bits */
#define CFG_DDR_COLUMN_BITS     2   /* 10 bits */

/* (required) Bank bits: 0=2bits, 3=3bits */
#define CFG_DDR_BANK_BITS       0  

/* (required) Memory width: 0=16bits, 1=32bits, 2=64bits */
#define CFG_DDR_MEM_WIDTH       1

/* (required) CAS Latency (NOTE: could be affected by PLL clock) */
#define CFG_DDR_CAS_LATENCY     5

/* (required) t_wr (picoseconds) */
#define CFG_DDR_T_WR            15000

/* (optional) Refresh period t_refi (picoseconds) */
#define CFG_DDR_REFRESH_PRD     7800000

/* (optional) t_rfc (picoseconds) */
#define CFG_DDR_T_RFC           105000

#elif defined(_BCM953284MDU_)
/*
 * DDR configuration
 *
 * For BCM953284MDU board: K4T1G164QQ-HCE6
 */

#define MEMDDR
#define DDRM32X16X2

#define CFG_DDR_PLL_CLOCK       (300000)  /* KHz */

/* (required) Row bits: 0=11bits, 1=12bits, ..., 5=16bits */
#define CFG_DDR_ROW_BITS        2   /* 13 bits */

/* (required) Column bits: 1=9bits, 2=10bits, 3=11bits */
#define CFG_DDR_COLUMN_BITS     2   /* 10 bits */

/* (required) Bank bits: 0=2bits, 3=3bits */
#define CFG_DDR_BANK_BITS       3  

/* (required) Memory width: 0=16bits, 1=32bits, 2=64bits */
#define CFG_DDR_MEM_WIDTH       0

/* (required) CAS Latency (NOTE: could be affected by PLL clock) */
#define CFG_DDR_CAS_LATENCY     5

/* (required) t_wr (picoseconds) */
#define CFG_DDR_T_WR            15000

/* (optional) Refresh period (picoseconds) */
#define CFG_DDR_REFRESH_PRD     7800000

/* (optional) t_rfc (picoseconds) */
#define CFG_DDR_T_RFC           127500

#else /* SVK board */

/*
 * DDR configuration
 *
 * For SVK board: MT47H128M16HG-3A
 */

/* For backward compatibility */
#define MEMDDR
#define DDRM32X16X2

/* (required) PLL clock */
#define CFG_DDR_PLL_CLOCK       (331250)  /* KHz */

/* (required) Row bits: 0=11bits, 1=12bits, ..., 5=16bits */
#define CFG_DDR_ROW_BITS        3   /* 14 bits */

/* (required) Column bits: 1=9bits, 2=10bits, 3=11bits */
#define CFG_DDR_COLUMN_BITS     2   /* 10 bits */

/* (required) Bank bits: 0=2bits, 3=3bits */
#define CFG_DDR_BANK_BITS       3  

/* (required) Memory width: 0=16bits, 1=32bits, 2=64bits */
#define CFG_DDR_MEM_WIDTH       1

/* (required) CAS Latency (NOTE: could be affected by PLL clock) */
#define CFG_DDR_CAS_LATENCY     5

/* (required) t_wr (picoseconds) */
#define CFG_DDR_T_WR            15000

/* (optional) Refresh period (picoseconds) */
#define CFG_DDR_REFRESH_PRD     7680000

/* (optional) t_rfc (picoseconds) */
#define CFG_DDR_T_RFC           197500

#endif 

#endif /* CFG_QUICKTURN */

/*
 * Include chip- and board-specific stuff
 */

#include "bcm53000.h"
#include "bcm953000.h"

#endif /* _BSP_CONFIG_H */
