/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Board device initialization		File: bcm953300_devs.c
    *  
    *  This is the "C" part of the board support package.  The
    *  routines to create and initialize the console, wire up 
    *  device drivers, and do other customization live here.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000-2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "bcmnvram.h"
#include "ptable.h"
#include "cfe_mii.h"

#include "sbmips32.h"
#include "sb_bp.h"

#ifdef IDEDISK
#include "dev_ide.h"
#endif
#include "dev_newflash.h"

#include "sb_utils.h"

#if NTSW_WSS
#include "cfe_failsave.h"
#endif /* NTSW_WSS */

#define __MB    (1024 * 1024)
#define __KB    (1024)
#define __K64   (65536)

/*  *********************************************************************
    *  Devices we're importing
    ********************************************************************* */

extern cfe_driver_t ns16550_uart;
extern cfe_driver_t sb_mac;
extern cfe_driver_t sb_ipsec;
extern cfe_driver_t newflashdrv;

#ifdef FEAT_BROADCOM_DUAL_IMAGE
/* Dual image support */
extern cfe_driver_t dimagedrv;
#endif /* FEAT_BROADCOM_DUAL_IMAGE */

#if CFG_PCI
extern void cpci_add_devices(int init_pci);
extern cfe_driver_t bcm53300drv;                  /* StrataXGS Switch */
#endif

extern cfe_driver_t ds1743_nvram;
extern cfe_driver_t ds1743_clock;
extern cfe_mii_t sb_mii;

#if CFG_MSYS
extern cfe_driver_t bdkdrv;
#endif

extern void ui_init_bcm953300cmds(void);
extern int ui_init_phycmds(void);
extern int ui_init_toyclockcmds(void);
extern void ui_init_flashtestcmds(void);
extern int ui_init_disktestcmds(void);
extern int ui_init_vxbootcmds(void);
extern int ui_init_ptablecmds(void);

#if CFG_USB
extern int usb_init(uint32_t addr);
extern cfe_driver_t usb_disk;
extern int ui_init_usbcmds(void);
#endif

extern void pci_ext_arb_set(int enable);
extern void pci_ext_clk_set(int enable);
extern void board_setleds(uint32_t);
void board_led_msg(char *msg);

/*  *********************************************************************
    *  Some board-specific parameters
    ********************************************************************* */

typedef struct initenv_s {
    const char *name;
    const char *value;
    const char *def;
    const char *altname;
} initenv_t;

const initenv_t bcm953300_envvars[] = {
    {"ETH0_HWADDR","$$NVRAM","02:10:18:58:36:10","et0macaddr"},
    {"ETH1_HWADDR","$$NVRAM","02:10:18:53:45:10","et1macaddr"},
    {NULL,NULL}};

/* Change et0 phy address from 1 to 0 */
#define ET0PHYADDR      "0"
#define ET0MDCPORT      "0"
#define ET1PHYADDR      "1"
#define ET1MDCPORT      "1"

static nvram_import_t nvram_import_bcm95836cpci[] = {
    { "LINUX_CMDLINE",  "kernel_args",  NULL },
    { "ETH0_HWADDR",    "et0macaddr",   NULL },
    { "et0macaddr",     "et0macaddr",   NULL },
    { "et0phyaddr",     "et0phyaddr",   ET0PHYADDR },
    { "et0mdcport",     "et0mdcport",   ET0MDCPORT },
    { "ETH1_HWADDR",    "et1macaddr",   NULL },
    { "et1macaddr",     "et1macaddr",   NULL },
    { "et1phyaddr",     "et1phyaddr",   ET1PHYADDR },
    { "et1mdcport",     "et1mdcport",   ET1MDCPORT },
    { NULL, NULL }
};

/*  *********************************************************************
    *  Partition table support
    ********************************************************************* */

#ifdef INCLUDE_FLASH_DRIVERS

#if CFG_PTABLE
static ptable_t usr_ptbl;

#define PTAB_OFFSET 0xD0000

static int pt_read(ptable_t *ptbl);
static int pt_write(ptable_t *ptbl);

static ptable_drv_t pt_drv = { 
    pt_read, 
    pt_write 
};

static int
pt_read(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
	return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_readblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}

static int
pt_write(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
	return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_writeblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}

static int
user_parts(ptable_t *ptbl, newflash_probe_t *fprobe)
{
    newflash_part_t *fp = fprobe->flash_parts;
    partition_t *up = ptbl->part;
    int i, top = 0, uparts = 0;

    /* Check partition table */
    if (usr_ptbl.magic != PTABLE_MAGIC || ptable_check(&usr_ptbl) < 0) {
        return 0;
        }
    /* Add partitions */
    for (i = 0; i < PTABLE_MAX_PARTITIONS && up[i].size; i++) {
        if (top + up[i].size > fprobe->flash_size) break;
        /* Check for holes in partition map */
        if (up[i].offset > top) {
            fp[uparts].fp_size = top ? 0 : up[i].offset - top;
            fp[uparts].fp_name = top ? "unused" : "boot";
            if (++uparts >= FLASH_MAX_PARTITIONS) break;
            }
        fp[uparts].fp_size = up[i].size;
        fp[uparts].fp_name = up[i].name;
        if (++uparts >= FLASH_MAX_PARTITIONS) break;
        top = up[i].offset + up[i].size;
    }
    return uparts;
}

#endif /* CFG_PTABLE */

#endif /* INCLUDE_FLASH_DRIVERS */

/*  *********************************************************************
    *  SysConfig switch settings and related parameters
    ********************************************************************* */

int console_port;

/*  *********************************************************************
    *  board_led_msg()
    *  
    *   Write characters to OSRAM 4-char LED display.
    *  
    *  Input parameters: 
    *  	  String of 1 character or more in length
    *  	   
    *  Return value:
    *  	   nothing
    ******************************************************************** */
void board_led_msg(char * msg)
{
    int len = strlen(msg);
    uint32_t a0;
    int i;

    for (a0 = 0,i = 0; i < 4; i++) {
	a0 <<= 8;
	a0 |= (i < len) ? msg[i] : ' ';
	}
    board_setleds(a0);
}


/*  *********************************************************************
    *  bcm953300_initenv()
    *  
    *  Initialize default environment variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm953300_initenv(void)
{
    const initenv_t *ini;
    char *txt;

    ini = bcm953300_envvars;

    /* Assign either the forced value, or the value
       of another environment variable if the name starts
       with a dollar sign.  If that name is not defined
       either, then use the default from the table. */

    while (ini->name) {
	if (strcmp(ini->value, "$$NVRAM") == 0) {
	    txt = (char *)nvram_get(ini->altname);
	    if (!txt) txt = env_getenv(ini->altname);
	    if (!txt) txt = (char *) ini->def;
	    }
	else if (ini->value[0] == '$') {
	    txt = env_getenv(&(ini->value[1]));
	    if (!txt) txt = (char *) ini->def;
	    }
	else {
            txt = NULL;
	    if (ini->altname) txt = env_getenv(ini->altname);
	    if (!txt) txt = (char *) ini->value;
	    }
	if (txt) {
	    if (!env_getenv(ini->name)) {
		env_setenv(ini->name,txt,ENV_FLG_BUILTIN);
		}
	    }
	ini++;
	}

}


/*  *********************************************************************
    *  bcm953300_probeflash()
    *  
    *  Probe the flash and initialize as required.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm953300_probeflash(void)
{
#ifdef INCLUDE_FLASH_DRIVERS
    newflash_probe_t fprobe;

#if CFG_PTABLE
    ptable_init(&pt_drv);
#endif /* CFG_PTABLE */

    /*
     * JP1001 BCM953300
     * 1 2
     * o o (open)   = Boot from PLCC (512K AM29LV040B)
     * o-o (closed) = Boot from Intel 28F128J3C150 (16MB)
     * 
     * Note: BCM953300 has a 512K PLCC boot rom and a 16M (8M x 16)
     *       Intel 28F128J3C150 flash chip. To put CFE on the Intel
     *       flash, burn cfe.srec into PLCC, move jumper JP800 from
     *       pins 2-3 to jump pins 1-2, and then flash cfe.flash into it.
     *
     * Partitions are as follows:
     *
     *	512KB  - "boot"	 CFE
     *	3520KB - "trx"	 TRX header (for kernel compatibility)
     *	32KB   - "env"	 NVRAM (since we have no true NVRAM)
     *	32KB   - "nvram" NVRAM (environment for kernel compatibility)
     *  12MB   - "os"    FATFS
     */

    memset(&fprobe,0,sizeof(fprobe));
    fprobe.flash_phys = 0x1B000000;    /* Intel flash at CS4 */
#ifdef NTSW_WSS
    fprobe.flash_size = 2 * __MB;
#else
    fprobe.flash_size = 16 * __MB;
#endif /* NTSW_WSS */
    fprobe.flash_flags = FLASH_FLG_BUS8 | FLASH_FLG_DEV8;

#ifdef NTSW_WSS
    fprobe.flash_nparts = 5;
    fprobe.flash_parts[0].fp_size = BOOTROM_SIZE;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = 128*__KB;
    fprobe.flash_parts[1].fp_name = "log";
    fprobe.flash_parts[2].fp_size = 128*__KB;
    fprobe.flash_parts[2].fp_name = "flashfs";
    fprobe.flash_parts[3].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[3].fp_name = "nvram";
    fprobe.flash_parts[4].fp_size = 0;
    fprobe.flash_parts[4].fp_name = "os";
    cfe_add_device(&newflashdrv, 0, 0, &fprobe);    /* flash0 */

    /* flash1 is partitioned to support dual images (assume 4MB) */
    fprobe.flash_nparts = 6;
    fprobe.flash_parts[4].fp_size = (4*__MB - 4*128*__KB) / 2;
    fprobe.flash_parts[4].fp_name = "os";
    fprobe.flash_parts[5].fp_size = 0;
    fprobe.flash_parts[5].fp_name = "os2";
    fprobe.flash_phys = 0x1C000000;    /* shadow flash window */
    cfe_add_device(&newflashdrv,0,0,&fprobe);           /* flash1 */

#else
    /* Exclude upper partition in 8MB window */
    fprobe.flash_nparts = 4;
    fprobe.flash_parts[0].fp_size = 1*1024*1024 - 2*NVRAM_SPACE;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[1].fp_name = "env";
    fprobe.flash_parts[2].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[2].fp_name = "nvram";
    fprobe.flash_parts[3].fp_size = 7*1024*1024;
    fprobe.flash_parts[3].fp_name = "os";
    cfe_add_device(&newflashdrv,0,0,&fprobe);           /* flash0 */

    /* Full access (16MB) in 32MB shadow window */
    fprobe.flash_phys = 0x1C000000;    /* shadow flash window */
    fprobe.flash_nparts = 5;
    fprobe.flash_parts[0].fp_size = 1*1024*1024 - 2*NVRAM_SPACE;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[1].fp_name = "env";
    fprobe.flash_parts[2].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[2].fp_name = "nvram";
    fprobe.flash_parts[3].fp_size = 7*1024*1024;
    fprobe.flash_parts[3].fp_name = "os";
    fprobe.flash_parts[4].fp_size = 8*1024*1024;
    fprobe.flash_parts[4].fp_name = "user";
    cfe_add_device(&newflashdrv,0,0,&fprobe);           /* flash1 */
#endif /* NTSW_WSS */

    /* Because sometimes we want to program the entire device */
    fprobe.flash_nparts = 0;
    cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash2 */

#if CFG_PTABLE
    /* User-defined partitions */
    if (pt_read(&usr_ptbl) == 0 && 
        (fprobe.flash_nparts = user_parts(&usr_ptbl, &fprobe)) > 0) {
        cfe_add_device(&newflashdrv,0,0,&fprobe);       /* flash3 */
        }
#endif /* CFG_PTABLE */

    /* PLCC */
    memset(&fprobe,0,sizeof(fprobe));
    fprobe.flash_phys = 0x1FC00000;
    fprobe.flash_size = 512*1024;
    fprobe.flash_flags =  FLASH_FLG_BUS8 | FLASH_FLG_DEV16;
    fprobe.flash_nparts = 1;
    fprobe.flash_parts[0].fp_size = 512*1024;
    fprobe.flash_parts[0].fp_name = "boot";
    cfe_add_device(&newflashdrv,0,0,&fprobe);           /* flash3/flash4 */

#ifdef FEAT_BROADCOM_DUAL_IMAGE
    /*
     * Dual Image - virtual flash device for booting and upgrading
     */
    cfe_add_device(&dimagedrv, 0, 0, NULL);         /* vflash0 */
#endif /* FEAT_BROADCOM_DUAL_IMAGE */

    board_led_msg("FLASH");
    
#endif /* INCLUDE_FLASH_DRIVERS */
}


/*  *********************************************************************
    *  board_console_init()
    *  
    *  Add the console device and set it to be the primary
    *  console.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_console_init(void)
{
    uint32_t uart_clock;
    char console_port_str[16];

    /* The BCM953300 board does not have a CPLD, so hardcode console port. */
    console_port = 0;
    
    sprintf(console_port_str, "uart%d", console_port);

    uart_clock = sb_uart_clock();

    /* This hack prevents a divider value of 0 in the UART registers.  It's
       not obviously the right thing to do here. */
    if (uart_clock < (CFG_SERIAL_BAUD_RATE*16))
	uart_clock = 16*CFG_SERIAL_BAUD_RATE;

    /* Serial ports, note: no HW Flow control */
    cfe_add_device(&ns16550_uart,BCM95836_COM1,uart_clock,0);
    cfe_add_device(&ns16550_uart,BCM95836_COM2,uart_clock,0);

    /* Console */
    cfe_set_console(console_port_str);
#ifdef NTSW_WSS
    nvram_init((uint8_t *)PHYS_TO_K1(0x1C000000 + 384*__KB), NVRAM_SPACE);
#else
    /* change from 0x1B0F8000 to 0x1C0F8000, because we can't access this large
       range in 0x1B000000. Have to use 0x1C000000 */
    nvram_init((uint8_t *)PHYS_TO_K1(0x1C0F8000), 0x8000);
#endif /* NTSW_WSS */

    /* get current SB clock */
    cfe_cpu_speed = sb_cpu_clock();

    /* If for some reason sb_clock didn't work (unlikely), pick a default. */

    if (cfe_cpu_speed == 0) {
	cfe_cpu_speed = 200*1000*1000;		/* wire to 200Mhz for now */
    }

#if CFG_PCI
    cfe_startflags |= CFE_INIT_PCI;
#endif
}


/*  *********************************************************************
    *  board_device_init()
    *  
    *  Initialize and add other devices.  Add everything you need
    *  for bootstrap here, like disk drives, flash memory, UARTs,
    *  network controllers, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_init(void)
{
    char *str;
    int phyaddr;

    /* We would like the environment variables to be set up early.
     * For compatibility with HND conventions, some of the device
     * attach routines, e.g, for the MACs, interrogate the
     * environment.
     */

    /*
     * Print out the board name.
     *
     * The BCM953300 board does not have a CPLD, so we cannot 
     * provide any meaningful board ID, revision, etc.
     */
    printf("%s board (no CPLD)\n", CFG_BOARDNAME);

    bcm953300_probeflash();

#ifdef NTSW_WSS
    /* NVRAM is DS1743 TOD/NVRAM (Battery backed SRAM) */
    cfe_add_device(&ds1743_nvram,
           BCM953300_NVRAM_ADDR,
           BCM953300_NVRAM_VXWORKS,0);
    cfe_set_envdevice("nvram0");
    cfe_add_device(&ds1743_clock, BCM953300_NVRAM_ADDR, 0, 0);
#else
    /* change from flash0.env to flash1.env, using 0x1C000000 */
    cfe_set_envdevice("flash1.env");
#endif /* NTSW_WSS */

    bcm953300_initenv();

#if CFG_MSYS
    /* DiskOnChip Binary partition for boot */
    cfe_add_device(&bdkdrv, BCM953300_DOC_ADDR, 0, 0);
#endif

    /* Configure nvram import command */
    nvram_import_data = nvram_import_bcm95836cpci;

    /* Get PHY address for MAC 0 */
    str = env_getenv("et0phyaddr");
    phyaddr = str ? atoi(str) : atoi(ET0PHYADDR);

    /* MII interfaces - needed for PHY access outside MAC driver.
     * Must be initialized for the generic UI PHY commands to work. */
    cfe_add_mii(&sb_mii,SB_ENET0_BASE,phyaddr);

    cfe_add_device(&sb_mac,0,phyaddr,env_getenv("ETH0_HWADDR"));

#if CFG_USB
    usb_init(SB_USB_BASE);
    cfe_add_device(&usb_disk,0,0,0);
#endif

#if CFG_PCI
    /* We are a PCI host in a CPCI system.  Most of the supported PCI
       devices are not currently available for CPCI; we link only
       a subset. */
    cpci_add_devices(1);

#ifdef NTSW_WSS
    cfe_add_device(&bcm53300drv,0,0,NULL);
#endif /* NTSW_WSS */

#endif
}



/*  *********************************************************************
    *  board_device_reset()
    *  
    *  Reset devices.  This call is done when the firmware is restarted,
    *  as might happen when an operating system exits, just before the
    *  "reset" command is applied to the installed devices.   You can
    *  do whatever board-specific things are here to keep the system
    *  stable, like stopping DMA sources, interrupts, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_reset(void)
{
}

#if CFG_USB
/*  *********************************************************************
    *  board_usb_init()
    *  
    *  Turn on the OHCI controller at the core.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void board_usb_init(void)
{
    volatile uint32_t *reg;

    /* host mode (M_SBTS_UH=1) sequence taken from the BCM4710 UM */

    reg = (volatile uint32_t *) PHYS_TO_K1(SB_USB_BASE + R_SBTMSTATELOW);

    *reg = M_SBTS_RS | M_SBTS_CE | M_SBTS_FC | M_SBTS_UH;
    cfe_usleep(100);
    *reg = M_SBTS_CE | M_SBTS_FC | M_SBTS_UH;
    cfe_usleep(100);
    *reg = M_SBTS_CE | M_SBTS_UH;
    cfe_usleep(100);
}
#endif


/*  *********************************************************************
    *  board_final_init()
    *  
    *  Do any final initialization, such as adding commands to the
    *  user interface.
    *
    *  If you don't want a user interface, put the startup code here.  
    *  This routine is called just before CFE starts its user interface.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_final_init(void)
{
#if CFG_UI
    ui_init_bcm953300cmds();
    ui_init_phycmds();
#if CFG_FULLDIAG
    ui_init_toyclockcmds();
    ui_init_flashtestcmds();
    ui_init_disktestcmds();
#endif /* CFG_FULLDIAG */

#ifndef NTSW_WSS
    ui_init_vxbootcmds();
#endif /* NTSW_WSS */

#if CFG_PTABLE
    ui_init_ptablecmds();
#endif /* CFG_PTABLE */

#if CFG_USB
    board_usb_init();
    ui_init_usbcmds();
#endif
#endif /* CFG_UI */
    board_led_msg("CFE ");
}

#if CFG_BOARD_ENV
/*  *********************************************************************
    *  board_setup_env()
    *  
    *  Setup board specific env variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_setup_env(void)
{
    cfe_failsave_set_startup();
    return;
}
#endif /* CFG_BOARD_ENV */

#if CFG_BOARD_APP
/*  *********************************************************************
    *  board_appl_loop()
    *  Run board specific application.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_appl_loop(void)
{
    cfe_failsave_boot();
    return;
}
#endif /* CFG_BOARD_APP */
