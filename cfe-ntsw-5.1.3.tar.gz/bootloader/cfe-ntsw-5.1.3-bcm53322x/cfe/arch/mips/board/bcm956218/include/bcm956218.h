/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM956218 board-specific definitions       
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef __BCM956218_H
#define __BCM956218_H
/* Macros */

#define KB 1024
#define MB (1024*1024)

/*
 * Put board-specific stuff here
 */
#define BCM956218_NVRAM_SIZE            0x8000

#if 0
/* VxWorks-specific NVRAM addresses */
#define BCM956218_VXWORKS_MAC_ADDR      (BCM956218_NVRAM_ADDR + 0x400)
#endif

/* Internal NS16550-compatible dual UART */
#define BCM956218_COM1   BCM56XXX_UART0       /* console, DB-9 */
#define BCM956218_COM2   BCM56XXX_UART1       /* header */

#endif /* ! __BCM956218_H */
