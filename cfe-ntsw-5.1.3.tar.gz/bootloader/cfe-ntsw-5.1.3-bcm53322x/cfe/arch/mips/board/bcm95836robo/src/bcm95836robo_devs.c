/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Board device initialization		File: bcm95836robo_devs.c
    *  
    *  This is the "C" part of the board support package.  The
    *  routines to create and initialize the console, wire up 
    *  device drivers, and do other customization live here.
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003,2005
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "bcmnvram.h"
#include "cfe_mii.h"

#include "sbmips32.h"
#include "sb_bp.h"

#include "dev_newflash.h"
#include "sb_utils.h"

#include "net_enet.h"
#include "net_ebuf.h"
#if defined(CFG_ROBO) && defined(NTSW_WSS)
#include "net_ether.h"
#include "factory_config.h"
#endif /* defined(CFG_ROBO) && defined(NTSW_WSS) */
#include "cfe_spi.h"
#include "sb_spi.h"

#if  NTSW_WSS 
#include "cfe_failsave.h"
#endif /* NTSW_WSS */

#ifdef IDEDISK
/* Previous code was wrong and probably not relevant for this board. */
#endif

#if CFG_MDK == 1
#include "mdk_sys.h"
#endif

/*  *********************************************************************
    *  Devices we're importing
    ********************************************************************* */

extern cfe_driver_t ns16550_uart;
extern cfe_driver_t sb_mac;
extern cfe_driver_t newflashdrv;

#ifdef FEAT_BROADCOM_DUAL_IMAGE
/* Dual image support */
extern cfe_driver_t dimagedrv;
#endif /* FEAT_BROADCOM_DUAL_IMAGE */

#if CFG_PCI
extern void cpci_add_devices(int init_pci);
#endif

extern cfe_driver_t ds1743_nvram;
extern cfe_driver_t ds1743_clock;

extern cfe_mii_t sb_mii;

#ifdef CFG_ROBO
/* for low level SPI channel (GPIO) */
extern cfe_spi_t sb_spi;
/* for high level SPI driver */
extern cfe_driver_t spi_robo;
#endif /* defined(CFG_ROBO) */

#if CFG_MSYS
extern cfe_driver_t bdkdrv;
#endif

extern void ui_init_bcm95836robocmds(void);
extern int ui_init_phycmds(void);
extern int ui_init_toyclockcmds(void);
extern void ui_init_flashtestcmds(void);
extern int ui_init_vxbootcmds(void);

#if CFG_USB
static void board_usb_init(void);
extern int usb_init(uint32_t addr);
extern cfe_driver_t usb_disk;
extern int ui_init_usbcmds(void);
#endif

#if CFG_MDK_DEBUG == 1
extern int ui_init_mdkcmds(void);
#endif

extern void board_setleds(uint32_t);
void board_led_msg(char *msg);

#define __MB    (1024 * 1024)
#define __KB    (1024)

#define SWAP16(x) ((((x) >> 8) & 0xff) | (((x) & 0xff) << 8))

#if CFG_BOARD_APP
void board_appl_loop(void);
#endif /* CFG_BOARD_APP */

/*  *********************************************************************
    *  Some board-specific parameters
    ********************************************************************* */

typedef struct initenv_s {
    const char *name;
    const char *value;
    const char *def;
    const char *altname;
} initenv_t;

/* Note: et1 MAC port is not brought out on current revs */
const initenv_t bcm95836robo_envvars[] = {
#ifndef CFG_ROBO
    {"et0phyaddr","2",NULL},
#else
    {"et0phyaddr","$$NVRAM","6","et0phyaddr"},
    {"et1phyaddr", "$$NVRAM", "30", "et1phyaddr"},
#endif
    {"ETH0_HWADDR","$$NVRAM","02-10-18-58-36-10","et0macaddr"},
    {"et0mdcport","0",NULL,"et0mdcport"},
    {"ETH1_HWADDR","$$NVRAM","02-10-18-58-36-11","et1macaddr"},
    {"et1mdcport","1",NULL, "et1mdcport"},
    {"boardtype","bcm95836robo",NULL},
    {NULL,NULL}};

static nvram_import_t nvram_import_bcm95836robo[] = {
    { "LINUX_CMDLINE",  "kernel_args",  NULL },
    { "ETH0_HWADDR",    "et0macaddr",   NULL },
    { "et0phyaddr",     "et0phyaddr",   NULL },
    { "et0mdcport",     "et0mdcport",   NULL },
    { "ETH1_HWADDR",    "et1macaddr",   NULL },
    { "et1phyaddr",     "et1phyaddr",   NULL },
    { "et1mdcport",     "et1mdcport",   NULL },
    { NULL, NULL }
};


/*  *********************************************************************
    *  board_led_msg()
    *  
    *   Write characters to OSRAM 4-char LED display.
    *  
    *  Input parameters: 
    *  	  String of 1 character or more in length
    *  	   
    *  Return value:
    *  	   nothing
    ******************************************************************** */
void board_led_msg(char * msg)
{
    int len = strlen(msg);
    uint32_t a0;
    int i;

    for (a0 = 0,i = 0; i < 4; i++) {
	a0 <<= 8;
	a0 |= (i < len) ? msg[i] : ' ';
	}
    board_setleds(a0);
}


/*  *********************************************************************
    *  bcm95836robo_initenv()
    *  
    *  Initialize default environment variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm95836robo_initenv(void)
{
    const initenv_t *ini;
    char *txt;

    ini = bcm95836robo_envvars;

    /* Assign either the forced value, or the value
       of another environment variable if the name starts
       with a dollar sign.  If that name is not defined
       either, then use the default from the table. */

    while (ini->name) {
	if (strcmp(ini->value, "$$NVRAM") == 0) {
	    txt = (char *)nvram_get(ini->altname);
	    if (!txt) txt = env_getenv(ini->altname);
	    if (!txt) txt = (char *) ini->def;
	    }
	else if (ini->value[0] == '$') {
	    txt = env_getenv(&(ini->value[1]));
	    if (!txt) txt = (char *) ini->def;
	    }
	else {
            txt = NULL;
	    if (ini->altname) txt = env_getenv(ini->altname);
	    if (!txt) txt = (char *) ini->value;
	    }
	if (txt) {
	    if (!env_getenv(ini->name)) {
		env_setenv(ini->name,txt,ENV_FLG_BUILTIN);
		}
	    }
	ini++;
	}

#if defined(CFG_ROBO) && defined(NTSW_WSS)
    /*
     * Special case for eth1 MAC address (should be unique for each board):
     * - check "factory configurables" block.
     */
    if (nvram_get("et1macaddr") == NULL) {
        FACTORYCFG_H handle;
        handle = factory_config_open();
        if (handle) {
            unsigned char mac[6];
            char *macaddr = (char *)factory_config_get(handle, "macaddr");
            if (macaddr != NULL) {
                if (enet_parse_hwaddr(macaddr, mac) == 0) {
                    env_setenv("et1macaddr", macaddr, ENV_FLG_BUILTIN);
                }
            }
            factory_config_close(handle, FALSE);
        }
    } 

#endif /* defined(CFG_ROBO) && defined(NTSW_WSS) */

}


/*  *********************************************************************
    *  bcm95836robo_probeflash()
    *  
    *  Probe the flash and initialize as required.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm95836robo_probeflash(void)
{
#ifdef INCLUDE_FLASH_DRIVERS
    newflash_probe_t fprobe;
    int              sz_adj;

    sz_adj = 0;

    /*
     * JP1001 BCM95836ROBO
     * 1 2
     * o o (open)   = Boot from PLCC (512K AM29LV040B)
     * o-o (closed) = Boot from Intel 28F320J3A-110 (4MB)
     * 
     * Note: BCM95836 has a 512K PLCC boot rom and a 4M (2M x 16)
     *       Intel 28F320J3A flash chip. To put CFE on the Intel
     *       flash, burn cfe.srec into PLCC, move jumper JP800 from
     *       pins 2-3 to jump pins 1-2, and then flash cfe.flash into it.
     *
     * We configure 4 flash devices on the BCM95836ROBO:
     *
     *	flash0:	Intel flash, 4MB (boot/trx/os/nvram partitions).
     *	flash1:	Intel flash, 4MB (boot/trx/nvram partitions).
     *	flash2:	Intel flash, 4MB (single partition).
     *	flash3:	boot flash (PLCC or Intel flash, per jumper above), 512kB. 
     */

    memset(&fprobe,0,sizeof(fprobe));

    /* following bcm947xx_devs.c as modified by the switch group */
#ifndef CFG_ROBO
    fprobe.flash_phys = 0x1B000000;   /* shadow (Intel) flash at CS4 */
    fprobe.flash_size = 4*1024*1024; /*REAL_BOOTROM_SIZE;*/
    fprobe.flash_flags = FLASH_FLG_BUS8 | FLASH_FLG_DEV8;
#else
    fprobe.flash_phys = 0x1C000000;   /* shadow (AMD) flash at ParallelFlash */
#ifdef NTSW_WSS
    fprobe.flash_size = 2*1024*1024; /*REAL_BOOTROM_SIZE;*/
#else
    fprobe.flash_size = 8*1024*1024; /*REAL_BOOTROM_SIZE;*/
#endif
    fprobe.flash_flags = FLASH_FLG_BUS16 | FLASH_FLG_DEV16;
#endif

#ifdef NTSW_WSS
#ifdef CFG_REF_BOARD
    fprobe.flash_nparts = 3;
    fprobe.flash_parts[0].fp_size = 128 * __KB;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[1].fp_name = "nvram";
    fprobe.flash_parts[2].fp_size = 0;
    fprobe.flash_parts[2].fp_name = "os";

    cfe_add_device(&newflashdrv, 0, 0, &fprobe);    /* flash0 */

#else /* !CFG_REF_BOARD */    
    fprobe.flash_nparts = 5;
    fprobe.flash_parts[0].fp_size = 128*__KB;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = 128*__KB;
    fprobe.flash_parts[1].fp_name = "log";
    fprobe.flash_parts[2].fp_size = 128*__KB;
    fprobe.flash_parts[2].fp_name = "flashfs";
    fprobe.flash_parts[3].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[3].fp_name = "nvram";
    fprobe.flash_parts[4].fp_size = 0;
    fprobe.flash_parts[4].fp_name = "os";

    cfe_add_device(&newflashdrv, 0, 0, &fprobe);    /* flash0 */

    fprobe.flash_nparts = 6;
    fprobe.flash_parts[4].fp_size = (4*__MB - 4*128*__KB) / 2;
    fprobe.flash_parts[4].fp_name = "os";
    fprobe.flash_parts[5].fp_size = 0;
    fprobe.flash_parts[5].fp_name = "os2";

#endif /* CFG_REF_BOARD */    

    cfe_add_device(&newflashdrv, 0, 0, &fprobe);    /* flash1 */

#else /* NTSW_WSS */
    /* Check the flash size, if its 4 MB instead of 8 MB */
#if ENDIAN_BIG
    *(uint16_t*) 0xbc0000AA = 0x98;
    if (*(uint16_t*) 0xbc00004c == 0x0016) {
        sz_adj = 4096;
    }
    *(uint16_t*) 0xbc000000 = 0x00f0;
#else
    *(uint16_t*) 0xbc0000AA = 0x98;
    if (*(uint16_t*) 0xbc00004e == 0x0016) {
        sz_adj = 4096;
    }
    *(uint16_t*) 0xbc000000 = 0x00f0;
#endif
     
    /* Because CFE can only boot from the beginning of a partition */
    fprobe.flash_nparts = 4;
    fprobe.flash_parts[0].fp_size = 512 * 1024;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = (7616 - sz_adj) * 1024;
    fprobe.flash_parts[1].fp_name = "os";
    fprobe.flash_parts[2].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[2].fp_name = "env";
    fprobe.flash_parts[3].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[3].fp_name = "nvram";
    cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash0 */

    /* Because CFE can only flash an entire partition */
    fprobe.flash_nparts = 4;
    fprobe.flash_parts[0].fp_size = 512 * 1024;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = (7616 - sz_adj) * 1024;
    fprobe.flash_parts[1].fp_name = "os";
    fprobe.flash_parts[2].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[2].fp_name = "env";
    fprobe.flash_parts[3].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[3].fp_name = "nvram";
    cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash1 */
#endif /* NTSW_WSS */

    /* Because sometimes we want to program the entire device */
    fprobe.flash_nparts = 0;
    cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash2 */

#ifndef CFG_ROBO
    memset(&fprobe,0,sizeof(fprobe));

    /* We configure flash3 w/o partitions so that the "flash" UI command
     * will find it correctly by default.  Ugh.
     */
    fprobe.flash_phys = 0x1FC00000;	/* boot flash.  */
    fprobe.flash_size = 512*1024; /*REAL_BOOTROM_SIZE;*/
    fprobe.flash_flags = FLASH_FLG_BUS8 | FLASH_FLG_DEV16;
    fprobe.flash_nparts = 0;
    cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash3 */
#endif

#ifdef FEAT_BROADCOM_DUAL_IMAGE
    /*
     * Dual Image - virtual flash device for booting and upgrading
     */
    cfe_add_device(&dimagedrv, 0, 0, NULL);         /* vflash0 */
#endif /* FEAT_BROADCOM_DUAL_IMAGE */

    board_led_msg("FLASH");
    
#endif /* INCLUDE_FLASH_DRIVERS */
}


/*  *********************************************************************
    *  board_console_init()
    *  
    *  Add the console device and set it to be the primary
    *  console.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_console_init(void)
{
    uint32_t uart_clock;

    uart_clock = sb_uart_clock();

    /* This hack prevents a divider value of 0 in the UART registers.  It's
       not obviously the right thing to do here. */
    if (uart_clock < (CFG_SERIAL_BAUD_RATE*16))
	uart_clock = 16*CFG_SERIAL_BAUD_RATE;

    /* Console on BCM95836robo is COM1, note: no HW Flow control */
    cfe_add_device(&ns16550_uart, BCM95836_COM1, uart_clock, 0);

    /* Auxiliary UART */
    cfe_add_device(&ns16550_uart,BCM95836_COM2,uart_clock,0);

#ifdef CFG_UART1
    cfe_set_console("uart1");
#else
    cfe_set_console("uart0");
#endif

#ifndef CFG_ROBO
    /* Make nvram variables available early.  These are located in
     * the flash1/flash2 "nvram" partition.
     */
    nvram_init((uint8_t *)PHYS_TO_K1(0x1B3F8000), 0x8000);
#else
    /* Make nvram variables available early.  These are located in
     * the flash1/flash2 "nvram" partition.
     */
#ifdef NTSW_WSS
#ifdef CFG_REF_BOARD     
    nvram_init((uint8_t *) PHYS_TO_K1(0x1C000000 + 128*__KB), NVRAM_SPACE);
#else
    nvram_init((uint8_t *) PHYS_TO_K1(0x1C000000 + 384*__KB), NVRAM_SPACE);
#endif
#else
    nvram_init((uint8_t *)PHYS_TO_K1(0x1C7F8000), 0x8000);
#endif /* NTSW_WSS */
#endif

    /* get current SB clock */
    cfe_cpu_speed = sb_cpu_clock();

    /* If for some reason sb_clock didn't work (unlikely), pick a default. */

    if (cfe_cpu_speed == 0) {
	cfe_cpu_speed = 200*1000*1000;		/* wire to 200Mhz for now */
    }

#if CFG_PCI
    cfe_startflags |= CFE_INIT_PCI;
#endif
}


/*  *********************************************************************
    *  board_device_init()
    *  
    *  Initialize and add other devices.  Add everything you need
    *  for bootstrap here, like disk drives, flash memory, UARTs,
    *  network controllers, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_init(void)
{
#ifndef CFG_ROBO
    /* NVRAM is DS1743 TOD/NVRAM (Battery backed SRAM) */
    cfe_add_device(&ds1743_nvram,
		   BCM95836_ROBO_NVRAM_ADDR,
		   BCM95836_ROBO_NVRAM_SIZE,0);
    cfe_set_envdevice("nvram0");
    cfe_add_device(&ds1743_clock, BCM95836_ROBO_NVRAM_ADDR, 0, 0);
#endif

#if CFG_MSYS
    /* DiskOnChip Binary partition for boot */
    cfe_add_device(&bdkdrv, BCM95836_ROBO_DOC_ADDR, 0, 0);
#endif

    /* We would like the environment variables to be set up early.
     * For compatibility with HND conventions, some of the device
     * attach routines, e.g, for the MACs, interrogate the
     * environment.
     */
    bcm95836robo_probeflash();
#ifdef CFG_ROBO
#ifdef NTSW_WSS
    cfe_set_envdevice("flash0.nvram");
#else
    cfe_set_envdevice("flash0.env");
#endif
#endif
    bcm95836robo_initenv();

    /* Configure nvram import command */
    nvram_import_data = nvram_import_bcm95836robo;

    /* MII interfaces - needed for PHY access outside MAC driver.
     * Must be initialized for the generic UI PHY commands to work. */
    cfe_add_mii(&sb_mii,SB_ENET0_BASE,atoi(env_getenv("et0phyaddr")));

#ifndef CFG_ROBO
    cfe_add_device(&sb_mac, 0, 2, env_getenv("ETH0_HWADDR"));
#else
    cfe_add_device(&sb_mac, 0, atoi(env_getenv("et0phyaddr")), env_getenv("ETH0_HWADDR"));
    cfe_add_device(&sb_mac, 1, atoi(env_getenv("et1phyaddr")), env_getenv("ETH1_HWADDR"));
#endif
#if 0   /* MAC 1 is not brought out */
    cfe_add_mii(&sb_mii,SB_ENET1_BASE,atoi(env_getenv("et1phyaddr")));
    cfe_add_device(&sb_mac, 1, 1, env_getenv("et1macaddr"));
#endif

#if CFG_USB
    board_usb_init();
    usb_init(SB_USB_BASE);
    cfe_add_device(&usb_disk,0,0,0);
#endif

#if CFG_PCI
    /* We are a PCI host in a CPCI system.  Most of the supported PCI
       devices are not currently available for CPCI; we link only
       a subset. */
    cpci_add_devices(1);
#endif

#ifdef CFG_ROBO 
    /*
     * SPI interface for ROBO devices 
     * Using GPIO pin 1 for reset, pin 2 for ssl, 3 for clk, 4 for mosi, 5 for miso
     */
    cfe_add_spi((cfe_spi_t*)&sb_spi, 1, SB_SPI_ASSIGN_GPIO_PINS(2, 3, 4, 5));
    cfe_add_device(&spi_robo, 0, 0, 0);
#endif

#if CFG_MDK == 1
    /* Initialize MDK subsystem */
    mdk_sys_init();
#endif
}


/*  *********************************************************************
    *  board_device_reset()
    *  
    *  Reset devices.  This call is done when the firmware is restarted,
    *  as might happen when an operating system exits, just before the
    *  "reset" command is applied to the installed devices.   You can
    *  do whatever board-specific things are here to keep the system
    *  stable, like stopping DMA sources, interrupts, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_reset(void)
{
}

#if CFG_USB
/*  *********************************************************************
    *  board_usb_init()
    *  
    *  Turn on the OHCI controller at the core.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void board_usb_init(void)
{
    volatile uint32_t *reg;

    /* host mode (M_SBTS_UH=1) sequence taken from the BCM4710 UM */

    reg = (volatile uint32_t *) PHYS_TO_K1(SB_USB_BASE + R_SBTMSTATELOW);

    *reg = M_SBTS_RS | M_SBTS_CE | M_SBTS_FC | M_SBTS_UH;
    cfe_usleep(100);
    *reg = M_SBTS_CE | M_SBTS_FC | M_SBTS_UH;
    cfe_usleep(100);
    *reg = M_SBTS_CE | M_SBTS_UH;
    cfe_usleep(100);
}
#endif


/*  *********************************************************************
    *  board_final_init()
    *  
    *  Do any final initialization, such as adding commands to the
    *  user interface.
    *
    *  If you don't want a user interface, put the startup code here.  
    *  This routine is called just before CFE starts its user interface.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_final_init(void)
{
#if defined(CFG_ROBO) && defined(NTSW_WSS)
    int fh;
    uint16_t phyidl, phyidh,miiaddr;
    uint8_t miireg;
    uint32_t i;
#endif /* defined(CFG_ROBO) && defined(NTSW_WSS) */

#if CFG_UI
    ui_init_bcm95836robocmds();
    ui_init_phycmds();
#if CFG_MDK_DEBUG == 1
    ui_init_mdkcmds();
#endif
#if CFG_FULLDIAG
    ui_init_flashtestcmds();
#endif /* CFG_FULLDIAG */

#ifndef NTSW_WSS
    ui_init_toyclockcmds();
    ui_init_vxbootcmds();
#endif

#if CFG_USB
    board_usb_init();
    ui_init_usbcmds();
#endif

#endif /* CFG_UI */

    board_led_msg("CFE ");

#if defined(CFG_ROBO) && defined(NTSW_WSS)
    /* For now, robo0 is the default for spi channel */
    if ((fh = cfe_open("robo0")) < 0) {
	printf("cfe_open robo0 failed\n");
	return;
    }

    cfe_readblk(fh, ((0x10 << 8) | (0x4 << 0)),
		PTR2HSADDR(&phyidh), sizeof(phyidh));
    cfe_readblk(fh, ((0x10 << 8) | (0x6 << 0)),
		PTR2HSADDR(&phyidl), sizeof(phyidl));

#if ENDIAN_BIG
    phyidh =  SWAP16(phyidh);
    phyidl =  SWAP16(phyidl);
#endif

    if ((phyidh == 0x0143) && ((phyidl & 0xfff0) == 0xbe40)){ 
        /* if 5348/5347 chip*/
        /* reset chip */
        miiaddr = 0x37c;
        miireg = 0x1;
        cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));

        /* Wait for chip reset complete */
        for (i=0; i<100000; i++) {
            miireg = 0;
            cfe_readblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
            if (!(miireg & 0x1)) {
                /* Reset is complete */
                break;
            }
        }

        miiaddr = 0x140;
        /* MII port state override (page 1 register 40) */
        cfe_readblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
        /* Disable IMP port link before doing change in 1Q vlan, mstp
         * and management mode
         */
        miireg = 0x0;
        cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));

        /*
         * Make sure 802.1Q VLAN, MSTP and management mode are bothe disabled
         * The system may be reset from runtime...
         */
        miireg = 0;
        /* Disable management mode */
        cfe_writeblk(fh, 0x0300, PTR2HSADDR(&miireg), sizeof(miireg));
        /* Disable 802.1Q VLAN*/
        cfe_writeblk(fh, 0x3400, PTR2HSADDR(&miireg), sizeof(miireg));
        /* Disable MSTP */
        cfe_writeblk(fh, 0x4500, PTR2HSADDR(&miireg), sizeof(miireg));

        miireg = 0x47;
        /* Enable the IMP port link and speed duplex for in-band networking */
        cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));

        miireg = 0;
        /* Read back */
        cfe_readblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
        if ((miireg & 0x47) != 0x47) {
            printf("robo_rvmii: error enabling mode");
        }
   
    }else{
        /* Check if 5324 chip */
        if ((phyidh == 0x0143) && ((phyidl & 0xfff0) == 0xbc20)) {
            /* 5324 chip */
            /* do not override port status*/
            for (i = 0; i < 24; i++) {
                /* fe port*/
                miiaddr = 0xa0 + i;
                miireg = 0;
                cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
            }
            for (i = 0; i < 2; i++) {
                /* ge port*/
                miiaddr = 0xb9 + i;
                miireg = 0;
                cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
            }   
            miiaddr = 0xb8;
        }else {
            /* 5398 chip*/
            for (i = 0; i < 9; i++) {
                /* ge port*/
                miiaddr = 0x58 + i;
                miireg = 0;
                cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
            }
            miiaddr = 0xe;
        }

        /* MII port state override (page 0 register 14) */
        cfe_readblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
        /* Disable IMP port link before doing change in 1Q vlan, mstp
         * and management mode
         */
        miireg &= 0xF0;
        miireg |= 0x80;
        cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));

        /*
         * Make sure 802.1Q VLAN, MSTP and management mode are bothe disabled
         * The system may be reset from runtime...
         */
        miireg = 0;
        /* Disable management mode */
        cfe_writeblk(fh, 0x0200, PTR2HSADDR(&miireg), sizeof(miireg));
        /* Disable 802.1Q VLAN*/
        cfe_writeblk(fh, 0x3400, PTR2HSADDR(&miireg), sizeof(miireg));
        /* Disable MSTP */
        cfe_writeblk(fh, 0x4300, PTR2HSADDR(&miireg), sizeof(miireg));

        /* Enable the IMP port link and speed duplex for in-band networking */
        cfe_readblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));
        miireg |= 0x87;
        cfe_writeblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));

        miireg = 0;
        /* Read back */
        cfe_readblk(fh, miiaddr, PTR2HSADDR(&miireg), sizeof(miireg));

        if ((miireg & 0x87) != 0x87) {
            printf("robo_rvmii: error enabling mode");
        }
    }
    cfe_close(fh);
#endif /* defined(CFG_ROBO) && defined(NTSW_WSS) */

}

#if CFG_BOARD_ENV
/*  *********************************************************************
    *  board_setup_env()
    *  
    *  Setup board specific env variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_setup_env(void)
{
    cfe_failsave_set_startup();
    return;
}
#endif /* CFG_BOARD_ENV */

#if CFG_BOARD_APP
/*  *********************************************************************
    *  board_appl_loop()
    *   un board specific application.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_appl_loop(void)
{
    cfe_failsave_boot();
    return;
}
#endif /* CFG_BOARD_APP */
