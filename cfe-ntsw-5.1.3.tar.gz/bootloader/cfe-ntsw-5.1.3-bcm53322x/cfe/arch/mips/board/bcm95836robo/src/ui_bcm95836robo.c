/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Test commands				File: ui_bcm95836robo.c
    *  
    *  A temporary sandbox for misc test routines and commands.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003,2005
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#include "cfe.h"
#include "env_subr.h"

#include "ui_command.h"

#include "sbmips32.h"
#include "sb_bp.h"

#include "sb_utils.h"


int ui_init_nvramcmds(void);

int ui_init_bcm95836robocmds(void);

static int ui_cmd_reset(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_reg(ui_cmdline_t *cmd, int argc, char *argv[]);
static int ui_cmd_strap(ui_cmdline_t *cmd, int argc, char *argv[]);
#ifndef NTSW_WSS
static int ui_cmd_timertest(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_envdev(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_clock(ui_cmdline_t* cmd, int argc, char *argv[]);
static int ui_cmd_showconfig(ui_cmdline_t* cmd, int argc, char *argv[]);
#endif /* NTSW_WSS */

int ui_init_bcm95836robocmds(void)
{

    ui_init_nvramcmds();

    cmd_addcmd("reset",
	       ui_cmd_reset,
	       NULL,
	       "Reset the system.",
	       "reset [-yes] -cpu|-sysreset",
	       "-yes;Don't ask for confirmation|"
	       "-cpu;Reset the CPU|"
	       "-sysreset;Full system reset");

    cmd_addcmd("reg",
               ui_cmd_reg,
               NULL,
               "ROBO Switch Register Get/Set utility.",
               "reg [get/set] unit page addr len [pattern]\n\n",
               "get;Gets the value of the specified register|"
               "set;Sets the value of the specified register|"
               "unit;Applied chip ID|"
               "page;Page number of the specified register|"
               "addr;Address offset of the specified register|"
               "len;Length of the specified register|"
               "pattern;Values set to the specified register|");

    cmd_addcmd("strap",
            ui_cmd_strap,
            NULL,
            "STRAP pin setting and reset.",
            "strap [set|show] len [pattern]\n"
            "strap reset\n\n",
            "len;Total number of strap setting on this chip|"
            "set;set the strap pin value [pattern] and load to switch|"
            "pattern;<a1> <a2> <a3> <a4> <a5> strap pin value|"
            "reset;load the strap pin from 8051 to switch|"
            "show;show the strap pin value|");
    
#ifndef NTSW_WSS
    cmd_addcmd("test timer",
	       ui_cmd_timertest,
	       NULL,
	       "Test the timer",
	       "test timer",
	       "");

    cmd_addcmd("envdev",
	       ui_cmd_envdev,
	       NULL,
	       "set environment device",
	       "envdev sourcedev",
	       "");


    cmd_addcmd("clock",
	       ui_cmd_clock,
	       NULL,
	       "Change CPU/PCI clock (clock <cpu> <pci>)",
	       "clock",
	       "");

    cmd_addcmd("show config",
	       ui_cmd_showconfig,
	       NULL,
	       "Dump CP0 configuration registers",
	       "show config",
	       "");
#endif /* NTSW_WSS */
    return 0;
}

static int ui_cmd_reset(ui_cmdline_t *cmd,int argc,char *argv[])
{
    uint8_t data = 0;
    int confirm = 1;
    char str[50];

    if (cmd_sw_isset(cmd,"-yes")) confirm = 0;

    if (cmd_sw_isset(cmd,"-sysreset")) {
        data |= 0xFF;
    }

    if (cmd_sw_isset(cmd,"-cpu")) data |= 0xFF;

    if (data == 0) {		/* no changes to reset pins were specified */
	return ui_showusage(cmd);
	}

    if (confirm) {
	console_readline("Are you sure you want to reset? ",str,sizeof(str));
	if ((str[0] != 'Y') && (str[0] != 'y')) return -1;
	}

    sb_chip_reset();
    /* should not return */

    return -1;
}

static int
ui_cmd_reg(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *command, *unit, *page, *addr, *len, *value;
    uint8_t buf[32];
    int i, idx, fh, buflen;
    int slow = 0;    
    int bufiolen = 1;

    if (!(command = cmd_getarg(cmd, 0))){
        ui_showusage(cmd);
        return CFE_ERR_INV_PARAM;
    }

    /* For now, robo0 is the default for spi channel */
    if ((fh = cfe_open("robo0")) < 0) {
        printf("cfe_open robo0 failed\n");
        return CFE_ERR_DEVOPEN;
    }
    
    if (!strcmp(command, "get")) {
        if ((unit = cmd_getarg(cmd, 1)) &&
            (page = cmd_getarg(cmd, 2)) &&
            (addr = cmd_getarg(cmd, 3)) &&
            (len = cmd_getarg(cmd, 4))) {
                if ((buflen = atoi(len)) > sizeof(buf)) {
                    cfe_close(fh);
                    return CFE_ERR_INV_PARAM;
                }
                if (atoi(unit) == 6) {
                    /*
                     * Lower the HW SPI frequency since the strap pin
                     * is configured via 8051 SW SPI
                     */
                    slow = 1;
                } 
                cfe_ioctl(fh, 1,
                              (unsigned char *)&slow, sizeof(slow),
                              &bufiolen, 0);
                cfe_readblk(fh, (((atoi(unit) & 0xff) << 16) |
                                 ((atoi(page) & 0xff) << 8) |
                                 ((atoi(addr) & 0xff) << 0)),
                    PTR2HSADDR(buf), buflen);
                printf("[0x%x,0x%x,0x%x] = ", atoi(unit), atoi(page), atoi(addr));
                for (i=0; i<buflen; i++) {
#if ENDIAN_BIG
                    printf("0x%02x ", buf[buflen-1-i]);
#else
                    printf("0x%02x ", buf[i]);
#endif
                }
                printf("\n");
        } else {
            cfe_close(fh);
            return CFE_ERR_INV_PARAM;
        }
    } else if (!strcmp(command, "set")) {
        if ((unit = cmd_getarg(cmd, 1)) &&
            (page = cmd_getarg(cmd, 2)) &&
            (addr = cmd_getarg(cmd, 3)) &&
            (len = cmd_getarg(cmd, 4))) {
                if ((buflen = atoi(len)) > sizeof(buf)) {
                    cfe_close(fh);
                    return CFE_ERR_INV_PARAM;
                }

                for (i=0, idx=5; i<buflen; i++) {
                    if ((value = cmd_getarg(cmd, idx++))) {
#if ENDIAN_BIG
                        buf[buflen-1-i] = (uint8_t)atoi(value);
#else
                        buf[i] = (uint8_t)atoi(value);
#endif
                    } else {
                        cfe_close(fh);
                        return CFE_ERR_INV_PARAM;
                    }
                }
                if (atoi(unit) == 6) {
                    /*
                     * Lower the HW SPI frequency since the strap pin
                     * is configured via 8051 SW SPI
                     */
                    slow = 1;
                } 
                cfe_ioctl(fh, 1,
                              (unsigned char *)&slow, sizeof(slow),
                              &bufiolen, 0);
                cfe_writeblk(fh,(((atoi(unit) & 0xff) << 16) |
                                 ((atoi(page) & 0xff) << 8) |
                                 ((atoi(addr) & 0xff) << 0)),
                    PTR2HSADDR(buf), buflen);
        } else {
            cfe_close(fh);
            return CFE_ERR_INV_PARAM;
        }
    } else {
        cfe_close(fh);
        return ui_showusage(cmd);
   }
    /* anyway, back to the normal speed */
    slow = 0;
    cfe_ioctl(fh, 1,
                  (unsigned char *)&slow, sizeof(slow),
                  &bufiolen, 0);
    cfe_close(fh);
    
    return 0;
}

#define MAX_SUPPORTED_STRAP_NUM 8

static int
ui_cmd_strap(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *command, *len, *strapstr[MAX_SUPPORTED_STRAP_NUM];
    uint8_t strapv[MAX_SUPPORTED_STRAP_NUM];
    int fh, i;
    int slow = 0;
    int buflen = 1;    
    int rv = CFE_OK;

    if (!(command = cmd_getarg(cmd, 0))){
        ui_showusage(cmd);
        return CFE_ERR_INV_PARAM;
    }
    /* For now, robo0 is the default for spi channel */
    if ((fh = cfe_open("robo0")) < 0) {
    	printf("cfe_open robo0 failed\n");
    	return CFE_ERR_DEVOPEN;
    }
    /* 
      * Strap cmd is to control the slave 8051uC,
      * which is the low speed spi devices. 
      */
    slow = 1;
    if (cfe_ioctl(fh, 1,
                  (unsigned char *)&slow, sizeof(slow),
                  &buflen, 0) < 0) {
        printf("slow mode enable failed\n");
    }
    
    if (!strcmp(command, "set")) {
        if ((len = cmd_getarg(cmd, 1))) {
            if ((atoi(len) <=0) || (atoi(len) > MAX_SUPPORTED_STRAP_NUM)) {
                ui_showusage(cmd);
                rv = CFE_ERR_INV_PARAM;
                goto exit;
            }
        } else {
            ui_showusage(cmd);
            rv = CFE_ERR_INV_PARAM;
            goto exit;
        }
 
        for (i=0; i<atoi(len); i++) {
            if (!(strapstr[i] = cmd_getarg(cmd, i+2))) {
                ui_showusage(cmd);
                rv = CFE_ERR_INV_PARAM;
                goto exit;
            }
            strapv[i] = atoi(strapstr[i]);
        }
        for (i=0; i<atoi(len); i++) {
            cfe_writeblk(fh, (0x060000|i), PTR2HSADDR(&strapv[i]), 1);
            printf("A%d=0x%x ", i+1, strapv[i]);
        }
        printf("\n");
        /* Trigger the HW reset */
        if (cfe_ioctl(fh, 0, 0, 0, 0, 0) < 0) {
            printf("reset  failed\n");
        }
 
    } else if (!strcmp(command, "reset")) {
        if (cfe_ioctl(fh, 0, 0, 0, 0, 0) < 0) {
            printf("reset  failed\n");
        }
    } else if (!strcmp(command, "show")) {
        if ((len = cmd_getarg(cmd, 1))) {
            if ((atoi(len) <=0) || (atoi(len) > MAX_SUPPORTED_STRAP_NUM)) {
                ui_showusage(cmd);
                rv = CFE_ERR_INV_PARAM;
                goto exit;
            }
        } else {
            ui_showusage(cmd);
            rv = CFE_ERR_INV_PARAM;
            goto exit;
        }

        for (i=0; i<atoi(len); i++) {
            cfe_readblk(fh, (0x060000|i), PTR2HSADDR(&strapv[i]), 1);
            /* Error checking here ? */
            printf("A%d=0x%02X ", i+1, strapv[i]);
        }
        printf("\n");
    } else{
            rv = ui_showusage(cmd);
            goto exit;
    }

exit:
    /* back to the normal speed */
    slow = 0;
    if (cfe_ioctl(fh, 1,
                  (unsigned char *)&slow, sizeof(slow),
                  &buflen, 0) < 0) {
        printf("slow mode disable failed\n");
    }
    cfe_close(fh);
    return rv;
}

#ifndef NTSW_WSS

static int ui_cmd_envdev(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x;

    x = cmd_getarg(cmd,0);
    if (x) {
	cfe_set_envdevice(x);
	printf("environment device set to %s\n",x);
	}

    return 0;
}

static int ui_cmd_clock(ui_cmdline_t* cmd, int argc, char *argv[])
{
    char *x = NULL, *y = NULL;
    unsigned long req_sb, req_cpu, req_pci;

    req_sb  = 100000000;
    req_cpu = 200000000;
    req_pci =  33000000;     /* Defaults at reset */

    x = cmd_getarg(cmd,0);
    y = cmd_getarg(cmd,1);

    if (x) req_cpu = atoi(x);
    if (y) req_pci = atoi(y);

    /* Multiply for user */
    if (req_pci < 1000000) req_pci *= 1000000;
    if (req_cpu < 1000000) req_cpu *= 1000000;

    if (x || y) { 
	sb_setclock(req_cpu, req_pci);

	/* If either frequency changed, sb_setclock will reboot the system
	   and there will be no return to the following code.
	   XXX Furthermore, the reboot will reset the PCI frequency to
	   the default for the board.
	*/
	}

    cfe_cpu_speed = sb_cpu_clock();
    printf("CPU clock at %dMhz\n", (cfe_cpu_speed+500000)/1000000);

    return 0;
}   



static int ui_cmd_timertest(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int64_t t;

    t = cfe_ticks;

    while (!console_status()) {
	cfe_sleep(CFE_HZ);
	if (t != cfe_ticks) {
	    xprintf("Time is 0x%llX\n",cfe_ticks);
	    t = cfe_ticks;	    
	    }
	}

    return 0;
}


extern uint32_t read_config0(void);
extern uint32_t read_config1(void);

extern uint32_t read_bcm0(void);
extern uint32_t read_bcm1(void);
extern uint32_t read_bcm2(void);
extern uint32_t read_bcm3(void);
extern uint32_t read_bcm4(void);
extern uint32_t read_bcm5(void);
extern uint32_t read_bcm6(void);
extern uint32_t read_bcm7(void);

static int ui_cmd_showconfig(ui_cmdline_t *cmd,int argc,char *argv[])
{
    xprintf("config 0: 0x%08x,  1: 0x%08x\n", read_config0(), read_config1());

    xprintf("brcm   0: 0x%08x,", read_bcm0());
    xprintf("  1: 0x%08x,", read_bcm1());
    xprintf("  2: 0x%08x,", read_bcm2());
    xprintf("  3: 0x%08x\n", read_bcm3());

    xprintf("       4: 0x%08x,", read_bcm4());
    xprintf("  5: 0x%08x,", read_bcm5());
    xprintf("  6: 0x%08x,", read_bcm6());
    xprintf("  7: 0x%08x\n", read_bcm7());

    return 0;
}

#endif /* NTSW_WSS */
