
/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5836 SPI driver for ROBO devices              File: sb_spi.c
    *  
    *  Basic operations for BCM5836 GPIO to access SPI interface
    *  Compatible with BCM4704/4704P.
    *  
    *********************************************************************  
    *
    *  Copyright 2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "sbmips.h"

#include "ui_command.h"

#include "lib_physio.h"

#include "sb_bp.h"
#include "sb_pci.h"
#include "sb_mac.h"
#include "sb_chipc.h"

#include "cfe_spi.h"

#include "sb_spi.h"


#define READCSR(sc,csr) (phys_read32((sc)->membase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->membase + (csr), (val)))
#define OSL_DELAY(time) cfe_usleep(time) 

#define ASSERT(x) \
  do { if (!(x)) printf("sb_spi: assertion failed\n"); } while (0)

/* Mode flags */
#define SB_SPI_F_SLOW_CLK       0x1

typedef struct sb_spi_softc_s {
    unsigned long membase;
    unsigned long ssl, clk, mosi, miso, reset;
    unsigned long flags;
} sb_spi_softc_t;


/*  *********************************************************************
    *  Forward declarations
    ********************************************************************* */

static cfe_spi_channel_t *sb_spi_attach(cfe_spi_t * ops, uint64_t probe_a,
      uint64_t probe_b);
static int sb_spi_init(cfe_spi_channel_t * chan);
static int sb_spi_enable(cfe_spi_channel_t * chan, uint8_t slave);
static int sb_spi_disable(cfe_spi_channel_t * chan, uint8_t slave);
static int sb_spi_write(cfe_spi_channel_t * chan, uint8_t *buf, int len);
static int sb_spi_read(cfe_spi_channel_t * chan, uint8_t *buf, int len,
      uint8_t data_out);


/*  *********************************************************************
    *  MII operations
    ********************************************************************* */

cfe_spi_t sb_spi = {
    sb_spi_attach,
    sb_spi_init,
    sb_spi_enable,
    sb_spi_disable,
    sb_spi_write,
    sb_spi_read
};

static void
sb_delay(sb_spi_softc_t *s, int ticks)
{
    int idx;

    if (s->flags & SB_SPI_F_SLOW_CLK) {
        OSL_DELAY(2 * ticks);
    } else {
        for (idx = 0; idx < (ticks >> 3); idx++) {
            READCSR(s, R_GPIOOUTPUT);
        }
    }
}

static uint32_t
sb_gpio(sb_spi_softc_t *s, uint32_t regoff, uint32_t mask, uint32_t val)
{
    uint32_t w;

    ASSERT((val & ~mask) == 0);

    /* Mask and set */
    if (mask || val) {
        w = (READCSR(s, regoff) & ~mask) | val;
        WRITECSR(s, regoff, w);
    }

    /* Read back */
    w = READCSR(s, regoff);

    return (w);
}

static cfe_spi_channel_t *
sb_spi_attach(cfe_spi_t * ops, uint64_t probe_a, uint64_t probe_b)
{
    cfe_spi_channel_t *chan;
    sb_spi_softc_t *softc;

    chan = KMALLOC(sizeof(cfe_spi_channel_t) + sizeof(sb_spi_softc_t), 0);

    if (!chan)
        return NULL;

    chan->ops = ops;
    chan->softc = (void *)(chan + 1);

    softc = chan->softc;
    softc->membase = SB_CHIPC_BASE;
    softc->ssl = _DD_MAKEMASK1(SB_SSL_PIN(probe_b));
    softc->clk = _DD_MAKEMASK1(SB_CLK_PIN(probe_b));
    softc->mosi = _DD_MAKEMASK1(SB_MOSI_PIN(probe_b));
    softc->miso = _DD_MAKEMASK1(SB_MISO_PIN(probe_b));
    softc->reset = probe_a;
    softc->flags = 0;
    sb_gpio(softc, R_GPIOOUTPUT,
            softc->reset|softc->ssl|softc->clk|softc->mosi,
            softc->reset|softc->ssl);
    sb_gpio(softc, R_GPIOOUTEN,
            softc->reset|softc->ssl|softc->clk|softc->mosi|softc->miso,
            softc->reset|softc->ssl|softc->clk|softc->mosi);

    return chan;
}

static int
sb_spi_init(cfe_spi_channel_t * chan)
{
    return 0;
}

static int
sb_spi_enable(cfe_spi_channel_t * chan, uint8_t slave)
{
    sb_spi_softc_t *s = chan->softc;

    /* Use slave 0xff to control slow freq mode */
    if (slave == 0xff) {
        s->flags |= SB_SPI_F_SLOW_CLK;
        return 0;
    }

    /* Use slave 0xfe to control board system reset */
    if (slave == 0xfe) {
        sb_gpio(s, R_GPIOOUTPUT,  s->reset, 0);
        return 0;
    }

    /* Ignore if slave is non-zero */
    if (slave) {
        return 0;
    }

    /* Normal SPI access */
    sb_gpio(s, R_GPIOOUTPUT, s->ssl, 0);

    return 0;
}

static int
sb_spi_disable(cfe_spi_channel_t * chan, uint8_t slave)
{
    sb_spi_softc_t *s = chan->softc;

    /* Use slave 0xff to control slow freq mode */
    if (slave == 0xff) {
        s->flags &= ~SB_SPI_F_SLOW_CLK;
        return 0;
    }

    /* Use slave 0xfe to control board system reset */
    if (slave == 0xfe) {
        sb_gpio(s, R_GPIOOUTPUT, s->reset,  s->reset);
        return 0;
    }

    /* Ignore if slave is non-zero */
    if (slave) {
        return 0;
    }

    /* Normal SPI access */
    sb_gpio(s, R_GPIOOUTPUT, s->ssl, s->ssl);

    return 0;
}

static int
sb_spi_read(cfe_spi_channel_t * chan, uint8_t * buf, int len, uint8_t data_out)
{
    sb_spi_softc_t *s = chan->softc;
    int i;
    uint8_t mask, byte;

    for (i = 0; i < len; i++) {
        /* Bit bang from MSB to LSB */
        for (mask = 0x80, byte = 0; mask; mask >>= 1) {
            /* Clock low */
            sb_gpio(s, R_GPIOOUTPUT, s->clk, 0);
            sb_delay(s, 10);

            sb_gpio(s, R_GPIOOUTPUT, s->mosi, 0);

            /* Sample */
            if (sb_gpio(s, R_GPIOINPUT, 0, 0) & s->miso)
                byte |= mask;

            /* Clock high */
            sb_gpio(s, R_GPIOOUTPUT, s->clk, s->clk);
            sb_delay(s, 10);
        }
        buf[i] = byte;
    }
    return 0;
}

static int
sb_spi_write(cfe_spi_channel_t * chan, uint8_t *buf, int len)
{
    sb_spi_softc_t *s = chan->softc;
    int i;
    uint8_t mask;

    for (i = 0; i < len; i++) {
        /* Bit bang from MSB to LSB */
        for (mask = 0x80; mask; mask >>= 1) {
            /* Clock low */
            sb_gpio(s, R_GPIOOUTPUT, s->clk, 0);
            sb_delay(s, 10);

            /* Output on rising edge */
            if (mask & buf[i])
                sb_gpio(s, R_GPIOOUTPUT, s->mosi, s->mosi);
            else
                sb_gpio(s, R_GPIOOUTPUT, s->mosi, 0);

            /* Clock high */
            sb_gpio(s, R_GPIOOUTPUT, s->clk, s->clk);
            sb_delay(s, 10);
        }
    }
    return 0;
}

