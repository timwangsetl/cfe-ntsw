/*
 * $Id: sb_spi.h,v 1.1.1.1 2007/01/31 00:39:21 sanjayg Exp $
 *
 * $Copyright: (c) 2005 Broadcom Corp.
 * All Rights Reserved.$
 *
 */

#ifndef _SB_SPI_H_
#define _SB_SPI_H_

#define SB_SPI_ASSIGN_GPIO_PINS(ssl, clk, mosi, miso)   \
            (((ssl) << 24) | ((clk) << 16) | ((mosi) << 8) | (miso))

#define SB_SSL_PIN(a)       (((a) >> 24) & 0x1f)
#define SB_CLK_PIN(a)       (((a) >> 16) & 0x1f)
#define SB_MOSI_PIN(a)      (((a) >> 8)  & 0x1f)
#define SB_MISO_PIN(a)      (((a) >> 0)  & 0x1f)
    
#endif /* _SB_SPI_H_ */


