/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Board device initialization		File: bcm953314_devs.c
    *  
    *  This is the "C" part of the board support package.  The
    *  routines to create and initialize the console, wire up 
    *  device drivers, and do other customization live here.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  XX Copyright 2000,2001,2002,2003,2004
    *  Broadcom Corporation. All rights reserved.
    *
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "bcmnvram.h"
#include "ptable.h"
#include "cfe_mii.h"

#include "sbmips32.h"
#include "sb_bp.h"

#include "dev_newflash.h"
#include "sb_utils.h"
#include "sb_chipc_56xxx.h"

#include "dev_bcm53314.h"

#if CFG_MDK == 1
#include "mdk_sys.h"
#endif

#define READCSR(x)    \
  (*(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BCM56XXX_BASE+(x)))
#define WRITECSR(x,v) \
  (*(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BCM56XXX_BASE+(x)) = (v))
#define READ_SWITCH_CSR(x)    \
  (*(volatile uint32_t *)PHYS_TO_K1(BCM56XXX_ICS_CMIC_BASE+(x)))
#define WRITE_SWITCH_CSR(x,v) \
  (*(volatile uint32_t *)PHYS_TO_K1(BCM56XXX_ICS_CMIC_BASE+(x)) = (v))

/*  *********************************************************************
    *  Devices we're importing
    ********************************************************************* */

extern cfe_driver_t ns16550_uart;

#ifdef USE_BCM_ETH
extern cfe_driver_t bcm53314drv;
#endif

#define __MB (1024*1024)
#define __KB (1024)
#define __K64 65536

#if CFG_PTABLE
extern int ui_init_ptablecmds(void);
#endif /* CFG_PTABLE */

extern int ui_init_bcm953314cmds(void);
extern cfe_driver_t newflashdrv;
extern cfe_driver_t sflashdrv;

extern int ui_init_vxbootcmds(void);
extern void board_setleds(uint32_t);
extern void ui_init_flashtestcmds(void);
extern int ui_init_disktestcmds(void);
extern uint32_t read_bcm4(void);
#if CFG_MDK_DEBUG == 1
extern int ui_init_mdkcmds(void);
#endif
int bcm953314_probeflash(void);
void board_led_msg(char *msg);

#if CFG_BOARD_APP
void board_appl_loop(void);
#endif /* CFG_BOARD_APP */

/*  *********************************************************************
    *  Some board-specific parameters
    ********************************************************************* */

typedef struct initenv_s {
    const char *name;
    const char *value;
    const char *def;
    const char *altname;
} initenv_t;

static const initenv_t bcm953314_envvars[] = {
    {"ETH0_HWADDR","00-00-53-31-40-00","00-00-53-31-40-00","et0macaddr"},
    {"STARTUP", "$$NVRAM", "boot -elf -z flash0.os:", "startup"},
    {NULL,NULL}};

/*  *********************************************************************
    *  Partition table support
    ********************************************************************* */

#if CFG_PTABLE

static ptable_t usr_ptbl;

#define BOOT_SPACE      (512*__KB)
#define PTAB_OFFSET     (BOOT_SPACE - 0x8000)

static int pt_read(ptable_t *ptbl);
static int pt_write(ptable_t *ptbl);

static ptable_drv_t pt_drv = { 
    pt_read, 
    pt_write 
};

static int
pt_read(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
	return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_readblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}

static int
pt_write(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
	return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_writeblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}

static int
user_parts(ptable_t *ptbl, newflash_probe_t *fprobe)
{
    newflash_part_t *fp = fprobe->flash_parts;
    partition_t *up = ptbl->part;
    int i, top = 0, uparts = 0;

    /* Check partition table */
    if (usr_ptbl.magic != PTABLE_MAGIC || ptable_check(&usr_ptbl) < 0) {
        return 0;
        }
    /* Add partitions */
    for (i = 0; i < PTABLE_MAX_PARTITIONS && up[i].size; i++) {
        if (top + up[i].size > fprobe->flash_size) break;
        /* Check for holes in partition map */
        if (up[i].offset > top) {
            fp[uparts].fp_size = top ? 0 : up[i].offset - top;
            fp[uparts].fp_name = top ? "unused" : "boot";
            if (++uparts >= FLASH_MAX_PARTITIONS) break;
            }
        fp[uparts].fp_size = up[i].size;
        fp[uparts].fp_name = up[i].name;
        if (++uparts >= FLASH_MAX_PARTITIONS) break;
        top = up[i].offset + up[i].size;
    }
    return uparts;
}

#endif /* CFG_PTABLE */


/*  *********************************************************************
    *  board_led_msg()
    *  
    *   Write characters to OSRAM 4-char LED display.
    *  
    *  Input parameters: 
    *  	  String of 1 character or more in length
    *  	   
    *  Return value:
    *  	   nothing
    ******************************************************************** */
void board_led_msg(char * msg)
{
    int len = strlen(msg);
    uint32_t a0;
    int i;

    for (a0 = 0,i = 0; i < 4; i++) {
	a0 <<= 8;
	a0 |= (i < len) ? msg[i] : ' ';
	}
    board_setleds(a0);
}

/*  *********************************************************************
    *  bcm953314_initenv()
    *  
    *  Initialize default environment variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm953314_initenv(void)
{
    const initenv_t *ini;
    char *txt;

    ini = bcm953314_envvars;

    /* Assign either the forced value, or the value
       of another environment variable if the name starts
       with a dollar sign.  If that name is not defined
       either, then use the default from the table. */

    while (ini->name) {
	if (ini->value[0] == '$') {
	    txt = env_getenv(&(ini->value[1]));
	    if (!txt) txt = (char *) ini->def;
	    }
	else {
            txt = NULL;
	    if (ini->altname) txt = env_getenv(ini->altname);
	    if (!txt) txt = (char *) ini->value;
	    }
	if (txt) {
	    if (!env_getenv(ini->name)) {
		env_setenv(ini->name,txt,ENV_FLG_BUILTIN);
		}
	    }
	ini++;
	}

}

/*  *********************************************************************
    *  bcm953314_probeflash()
    *  
    *  Probe the flash and initialize as required.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static int fl_probe_done = 0;
int bcm953314_probeflash(void)
{
    newflash_probe_t fprobe;
    uint32_t         plcc;
    uint32_t         rev_id;

    plcc = ((READCSR(R_CORECAPABILITIES)) & M_CORECAP_FLASH_DATA_WIDTH) ? 1 : 0;

    rev_id = ((READ_SWITCH_CSR(R_CMIC_DEV_REV_ID)) >> 16) & 0xFF;

    if (plcc) {
        printf("Switch the jumper to 16bit flash before doing flprobe.\n");
        return -1;
    }

    if (fl_probe_done)
        return 0;
    else 
        fl_probe_done = 1;

#if CFG_PTABLE
    ptable_init(&pt_drv);
#endif /* CFG_PTABLE */

    memset(&fprobe,0,sizeof(fprobe));
    
    fprobe.flash_phys = 0x1C000000;
    // fprobe.flash_phys = 0x1FC00000;
	fprobe.flash_size = 16 * MB;
	fprobe.flash_flags = (FLASH_FLG_BUS16 | FLASH_FLG_DEV16);
	
	fprobe.flash_nparts = 4;
	fprobe.flash_parts[0].fp_size = 384*KB;
	fprobe.flash_parts[0].fp_name = "boot";
	fprobe.flash_parts[1].fp_size = 2048 * KB;
	fprobe.flash_parts[1].fp_name = "os";
	fprobe.flash_parts[2].fp_size = 13824 * KB;
	fprobe.flash_parts[2].fp_name = "fs";
	fprobe.flash_parts[3].fp_size = 128 * KB;
	fprobe.flash_parts[3].fp_name = "nvram";


    cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash0 */
    
    memset(&fprobe,0,sizeof(fprobe));
    fprobe.flash_phys = 0x1C000000;
	fprobe.flash_size = 16 * MB;
	fprobe.flash_flags = (FLASH_FLG_BUS16 | FLASH_FLG_DEV16);
	
	fprobe.flash_nparts = 1;
	fprobe.flash_parts[0].fp_size = 16 * MB;
	fprobe.flash_parts[0].fp_name = "image"; 
    cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash1 */

	//fprobe.flash_nparts = 0;
	//cfe_add_device(&newflashdrv, 0, 0, &fprobe);	/* flash2 */

#if CFG_PTABLE
        /* User-defined partitions */
    if (pt_read(&usr_ptbl) == 0 && 
        (fprobe.flash_nparts = user_parts(&usr_ptbl, &fprobe)) > 0) {
        cfe_add_device(&newflashdrv,0,0,&fprobe);       /* flash3 */
    }
#endif /* CFG_PTABLE */

    nvram_init((uint8_t *)PHYS_TO_K1(0x1C000000 + 384*__KB), NVRAM_SPACE);

    // cfe_set_envdevice("flash0.env");
    return 0;
}

/*  *********************************************************************
    *  board_console_init()
    *  
    *  Add the console device and set it to be the primary
    *  console.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_console_init(void)
{
    uint32_t uart_clock;
#ifdef QUICK_TURN
    /* QT DB Freq (f)   : Div (d)    : sim uart freq (9600 * d * 16) */
    /* 590k             : 1  (0.96)  : 1 * 9600 * 16 = 153600  (9600)*/
    /* 585k             : 2  (1.9)  :  2 * 9600 * 16 = 307200  (4800)*/
    uart_clock = 2304000;
#else
    uart_clock = sb_uart_clock();
#endif

    extern void (*platform_reset)(void);
    platform_reset = sb_chip_reset;

    /* This hack prevents a divider value of 0 in the UART registers.  It's
       not obviously the right thing to do here. */
    if (uart_clock < (CFG_SERIAL_BAUD_RATE*16))
	uart_clock = 16*CFG_SERIAL_BAUD_RATE;

    cfe_add_device(&ns16550_uart, BCM953314_COM1, uart_clock, 0);
    cfe_add_device(&ns16550_uart,BCM953314_COM2,uart_clock,0);
    cfe_set_console("uart0");
}


/*  *********************************************************************
    *  board_device_init()
    *  
    *  Initialize and add other devices.  Add everything you need
    *  for bootstrap here, like disk drives, flash memory, UARTs,
    *  network controllers, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_init(void)
{
    if ((READCSR(R_CORECAPABILITIES) & M_CORECAP_FLASH_DATA_WIDTH) == 0) {
        bcm953314_probeflash();
    }

    bcm953314_initenv();
    
    /* Add bcm953314 driver */
#ifdef USE_BCM_ETH
    cfe_add_device(&bcm53314drv,0,0,NULL);
#endif

#if CFG_MDK == 1
    /* Initialize MDK subsystem */
    mdk_sys_init();
#endif
}



/*  *********************************************************************
    *  board_device_reset()
    *  
    *  Reset devices.  This call is done when the firmware is restarted,
    *  as might happen when an operating system exits, just before the
    *  "reset" command is applied to the installed devices.   You can
    *  do whatever board-specific things are here to keep the system
    *  stable, like stopping DMA sources, interrupts, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_reset(void)
{
}


/*  *********************************************************************
    *  board_final_init()
    *  
    *  Do any final initialization, such as adding commands to the
    *  user interface.
    *
    *  If you don't want a user interface, put the startup code here.  
    *  This routine is called just before CFE starts its user interface.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_final_init(void)
{
    uint32_t gpioout, gpioen, gpiocontrol;
    
#if CFG_UI
    ui_init_bcm953314cmds();
#if CFG_PTABLE
//    ui_init_ptablecmds();
#endif /* CFG_PTABLE */
//    ui_init_vxbootcmds();
#if CFG_MDK_DEBUG == 1
    ui_init_mdkcmds();
#endif
#if CFG_FULLDIAG
//    ui_init_disktestcmds();
//    ui_init_flashtestcmds();
#endif /* CFG_FULLDIAG */
    board_led_msg("CFE ");
#endif /* CFG_UI */

    *(volatile uint32_t *)PHYS_TO_K1(0x18000064) |= 1<<3; 
    *(volatile uint32_t *)PHYS_TO_K1(0x18000068) &= ~(1<<3);

//    gpiocontrol = *(volatile uint32_t *)PHYS_TO_K1(0x1800006C);
//    gpioen = *(volatile uint32_t *)PHYS_TO_K1(0x18000068);
//    gpioout = *(volatile uint32_t *)PHYS_TO_K1(0x18000064);
//        
//    printf("gpiocontrol 0x%08x val32 0x%08x\n", PHYS_TO_K1(0x1800006C), gpiocontrol);
//    printf("gpioen 0x%08x val32 0x%08x\n", PHYS_TO_K1(0x18000068), gpioen);
//    printf("gpioout 0x%08x val32 0x%08x\n", PHYS_TO_K1(0x18000064), gpioout);
}

#if CFG_BOARD_ENV
/*  *********************************************************************
    *  board_setup_env()
    *  
    *  Setup board specific env variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
    /* If booting out of PLCC, no need to setup STARTUP env */
void board_setup_env(void)
{
    if (READCSR(R_CORECAPABILITIES) & M_CORECAP_FLASH_DATA_WIDTH) {
        return;
    }

    cfe_failsave_set_startup();
    return;
}
#endif /* CFG_BOARD_ENV */

#if CFG_BOARD_APP
/*  *********************************************************************
    *  board_appl_loop()
    *   un board specific application.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_appl_loop(void)
{
    cfe_failsave_boot();
    return;
}
#endif /* CFG_BOARD_APP */

