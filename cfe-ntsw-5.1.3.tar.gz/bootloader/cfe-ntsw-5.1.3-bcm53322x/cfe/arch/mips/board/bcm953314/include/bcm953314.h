/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM953314 board-specific definitions       
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef __BCM953314_H
#define __BCM953314_H
/* Macros */

#define KB 1024
#define MB (1024*1024)

/*
 * Put board-specific stuff here
 */
#define BCM953314_NVRAM_SIZE            0x8000

/* Internal NS16550-compatible dual UART */
#define BCM953314_COM1   BCM56XXX_UART0       /* console, DB-9 */
#define BCM953314_COM2   BCM56XXX_UART1       /* header */

#endif /* ! __BCM953314_H */
