/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  A temporary sandbox for misc test routines and commands.
    *  
    *  Author:  Sanjay Gupta
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#include "cfe.h"
#include "dev_newflash.h"
#include "env_subr.h"

#include "ui_command.h"

#include "sbmips32.h"
#include "sb_chipc_56xxx.h"

extern void board_led_msg(char* msg);
#include "sb_utils.h"

#include "bspi_flash.h"

int ui_init_bcm953314cmds(void);

#define DEBUG_UI

#ifdef DEBUG_UI
#define ERRCNT 1
int  bias=0;
void setTlbEntry(uint32_t EntryIdx, uint32_t EntryHi,
	uint32_t EntryLo0, uint32_t EntryLo1);
void setPageSize(uint32_t);
int getTlbWired(void);
void setTlbWired(int);

int one_tlb(uint32_t va, uint32_t pa0, uint32_t pa1);
static int ui_cmd_dcache_test(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_tlb_test(ui_cmdline_t *cmd,int argc,char *argv[]);
void * tlb_map(unsigned long len, unsigned long pa, unsigned long va);
#ifdef USE_BCM_ETH
static int ui_cmd_bcmdrv_test(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_eth_stat(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_eth_tx(ui_cmdline_t *cmd,int argc,char *argv[]);
#endif /* USE_BCM_ETH */

static int ui_cmd_cp0_wr(ui_cmdline_t *cmd,int argc,char *argv[]);
extern void write_bcm0(uint32_t v);
extern void write_bcm1(uint32_t v);
extern void write_bcm2(uint32_t v);
extern void write_bcm3(uint32_t v);
extern void write_bcm4(uint32_t v);
extern void write_bcm5(uint32_t v);
extern void write_bcm6(uint32_t v);
extern void write_bcm7(uint32_t v);
#endif /* DEBUG_UI */

#ifdef QUICK_TURN
static int ui_cmd_boot_from_ddr(ui_cmdline_t *cmd,int argc,char *argv[]);
#endif /* QUICK_TURN */

extern uint32_t read_config0(void);
extern uint32_t read_config1(void);

extern uint32_t read_bcm0(void);
extern uint32_t read_bcm1(void);
extern uint32_t read_bcm2(void);
extern uint32_t read_bcm3(void);
extern uint32_t read_bcm4(void);
extern uint32_t read_bcm5(void);
extern uint32_t read_bcm6(void);
extern uint32_t read_bcm7(void);

extern int ui_init_nvramcmds(void);
static void _do_mips_soft_reset(void);
static void __fetch_i_cache_and_lock(uint32_t * addr, uint32_t wrdLen);
static void do_mips_soft_reset(void);
static int ui_cmd_reset(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_showconfig(ui_cmdline_t* cmd, int argc, char *argv[]);
static int ui_cmd_fl_probe(ui_cmdline_t *cmd,int argc,char *argv[]);
extern int bcm953314_probeflash(void);
#if CFG_FULLDIAG
static int ui_cmd_sflash_rd(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_sflash_wr(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_sflash_flush(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_sflash_erase(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_envdev(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_schan_wr(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_schan_rd(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_mii_rd(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_mii_wr(ui_cmdline_t *cmd,int argc,char *argv[]);
#endif /* CFG_FULLDIAG */

int ui_init_bcm953314cmds(void)
{
//    ui_init_nvramcmds();

    cmd_addcmd("reboot",
	       ui_cmd_reset,
	       NULL,
	       "Reset the system.",
	       "reset [-yes] -cpu|-sysreset|-wdog",
	       "-yes;Don't ask for confirmation|"
	       "-cpu;Reset the CPU|"
	       "-sysreset;Full system reset|"
               "-wdog;watchdog reset");

//    cmd_addcmd("show config",
//	       ui_cmd_showconfig,
//	       NULL,
//	       "Dump CP0 configuration registers",
//	       "show config",
//	       "");

#if CFG_FULLDIAG
//    cmd_addcmd("envdev",
//	       ui_cmd_envdev,
//	       NULL,
//	       "set environment device",
//	       "envdev sourcedev",
//	       "");
//
//    cmd_addcmd("scw",
//	       ui_cmd_schan_wr,
//	       NULL,
//	       "Schan write",
//	       "Schan write",
//	       "");
//
//    cmd_addcmd("scr",
//	       ui_cmd_schan_rd,
//	       NULL,
//	       "Schan write",
//	       "Schan write",
//	       "");

//    cmd_addcmd("miir",
//	       ui_cmd_mii_rd,
//	       NULL,
//	       "MII read",
//	       "MII read",
//	       "");
//
//    cmd_addcmd("miiw",
//	       ui_cmd_mii_wr,
//	       NULL,
//	       "MII write",
//	       "MII write",
//	       "");
//   cmd_addcmd("sflashr",
//	       ui_cmd_sflash_rd,
//	       NULL,
//	       "Serial Flash read",
//	       "sflashr addr count",
//	       "");
//
//    cmd_addcmd("sflashw",
//	       ui_cmd_sflash_wr,
//	       NULL,
//	       "Serial Flash write",
//	       "sflashw addr value count",
//	       "");
//	cmd_addcmd("flush",
//	       ui_cmd_sflash_flush,
//	       NULL,
//	       "Serial Flash read cache flush",
//	       "flush",
//	       "");
//	cmd_addcmd("erase",
//	       ui_cmd_sflash_erase,
//	       NULL,
//	       "Serial Flash erase one sector",
//	       "erase addr",
//	       "");
#endif /* CFG_FULLDIAG */
//    cmd_addcmd("flprobe",
//	       ui_cmd_fl_probe,
//	       NULL,
//	       "Probe flash",
//	       "Probe flash",
//	       "");

//#ifdef DEBUG_UI
//    cmd_addcmd("tdc",
//	       ui_cmd_dcache_test,
//	       NULL,
//	       "test data cache",
//	       "test data cache",
//	       "");
//    cmd_addcmd("ttlb",
//	       ui_cmd_tlb_test,
//	       NULL,
//	       "test TLB",
//	       "test TLB",
//	       "");
//
//    cmd_addcmd("cpw",
//	       ui_cmd_cp0_wr,
//	       NULL,
//	       "write p0 register",
//	       "write p0 register",
//	       "");
//
//#ifdef USE_BCM_ETH
//    cmd_addcmd("ethstat",
//	       ui_cmd_eth_stat,
//	       NULL,
//	       "eth drv stats",
//	       "eth drv stats",
//               "");
//
//    cmd_addcmd("lbtest",
//	       ui_cmd_bcmdrv_test,
//	       NULL,
//	       "start eth loopback application",
//	       "bcmdrv [-v] ",
//	       "-v; verbose |"
//               "-pkt; dump pkt|"
//               "-d; drain rx pkts(no loopback)");
//
//    cmd_addcmd("etx",
//	       ui_cmd_eth_tx,
//	       NULL,
//	       "start eth loopback application",
//	       "lbtest [-v] ",
//	       "-v; verbose |"
//               "-pkt; dump pkt");
//#endif /* USE_BCM_ETH */
//
//#endif /* DEBUG_UI */

//#ifdef QUICK_TURN
//    cmd_addcmd("bootimg",
//	       ui_cmd_boot_from_ddr,
//	       NULL,
//	       "boot image from memory",
//	       "boot image from memory",
//	       "");
//#endif /* QUICK_TURN */

    return 0;
}

#ifdef DEBUG_UI

#define NUM_WR_PER_LINE 9
static int cache_seq_a[NUM_WR_PER_LINE] = { 4, 2, 1, 1, 2, 2, 1, 1, 2 };
static int cache_seq_b[NUM_WR_PER_LINE] = { 2, 1, 1, 2, 2, 1, 1, 2, 4 };
static int cache_seq_c[NUM_WR_PER_LINE] = { 2, 2, 1, 1, 2, 4, 2, 1, 1 };
static int cache_seq_d[NUM_WR_PER_LINE] = { 1, 1, 2, 4, 2, 1, 1, 2, 2 };


static int * pat_array[] = {cache_seq_a, cache_seq_b, cache_seq_c, cache_seq_d };

static unsigned int _calc_line_ofst(int start[], int index)
{
    unsigned int ofst = 0, ii;
    
    for (ii=0; ii<index; ii++) {
        switch(start[ii]) {
            case 4: ofst += 4; break;
            case 2: ofst += 2; break;
            case 1: ofst += 1; break;
        }
    }
    return ofst;
}

static int _write_pattern(int type, unsigned int pa, int pat)
{
    volatile unsigned short * pas;
    volatile unsigned int * pai;
    volatile unsigned char * pac;
    switch (type) {
        case 1:
            pac = (volatile unsigned char *)pa;
            *pac = (unsigned char) pat;
            break;
        case 2:
            pas = (volatile unsigned short *)pa;
            *pas = (unsigned short) pat;
            break;
        case 4:
            pai = (volatile unsigned int *)pa;
            *pai = (unsigned int) pat;
            break;
    }
    return type;
}
static unsigned int _read_pattern(int type, unsigned int pa, unsigned int * val)
{
    volatile unsigned short * pas;
    volatile unsigned int * pai;
    volatile unsigned char * pac;
    switch (type) {
        case 1:
            pac = (volatile unsigned char *)pa;
            *val = (unsigned int) (*pac);
            break;
        case 2:
            pas = (volatile unsigned short *)pa;
            *val = (unsigned int) (*pas);
            break;
        case 4:
            pai = (volatile unsigned int *)pa;
            *val = (unsigned int) (*pai);
            break;
    }
    return type;
}
static unsigned int _check_value(int type, int val, int exp)
{
    int ret = 0;
    char  *type_s = "UCSUW";

    switch (type) {
        case 1:
            ret = ((char) val == (char)exp);
            break;
        case 2:
            ret = ((short) val == (short)exp);
            break;
        case 4:
            ret = ((int) val == (int)exp);
            break;
    }
    if (!ret)
        printf("Type:%c exp:0x%x actual:0x%x\n", (char) *(type_s+type), exp, val);
    return !ret;
}

static int dcache_test_rnd(void)
{
    volatile unsigned int * pa, dummy;
    unsigned int ii, jj, tmp, errcnt=0, cache_sz;
    unsigned int banks, flush_wrd_sz;
    unsigned int addr_a, addr_b, addr_c, addr_d;
    int *pat_a, *pat_b, *pat_c, *pat_d;
    int pof_a, pof_b, pof_c, pof_d;
    unsigned int aof_a, aof_b, aof_c, aof_d;
    unsigned int cache_lines, line_sz, line_msk, value=0, check=0, type;

    banks = 4;
    cache_sz = 0x8000;
    line_sz = 16;
    line_msk = line_sz - 1;
    cache_lines = cache_sz/line_sz;
    flush_wrd_sz = cache_sz/4;

    printf("Starting random pattern test ...\n");

    /* flush out cache */
    pa = (volatile unsigned int *) PHYS_TO_K0(0x200000);
    for (ii=0; ii<flush_wrd_sz; ii++)
    {
        dummy = *(pa + ii);
    }

    pa = (volatile unsigned int *) PHYS_TO_K1(0x100000);
    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + ii;
            *(pa + tmp) = 0x55aa55aa;
        }
    }

    for (ii=0; ii<cache_lines; ii++) {
        /*
         * adjust the starting pattern to be written.
         */
        pat_a = pat_array[(ii%4)];
        pat_b = pat_array[((1+ii)%4)];
        pat_c = pat_array[((2+ii)%4)];
        pat_d = pat_array[((3+ii)%4)];

        pof_a = (0+ii)%NUM_WR_PER_LINE;
        pof_b = (1+ii)%NUM_WR_PER_LINE;
        pof_c = (2+ii)%NUM_WR_PER_LINE;
        pof_d = (3+ii)%NUM_WR_PER_LINE;

        /*
         * calculate the start offset within line.
         */
        aof_a = _calc_line_ofst(pat_a, pof_a);
        aof_b = _calc_line_ofst(pat_b, pof_b);
        aof_c = _calc_line_ofst(pat_c, pof_c);
        aof_d = _calc_line_ofst(pat_d, pof_d);
        
        addr_a = (0*cache_sz) + (ii*line_sz) + PHYS_TO_K0(0x100000);
        addr_b = (1*cache_sz) + (ii*line_sz) + PHYS_TO_K0(0x400000);
        addr_c = (2*cache_sz) + (ii*line_sz) + PHYS_TO_K0(0x1000000);
        addr_d = (3*cache_sz) + (ii*line_sz) + PHYS_TO_K0(0x1300000);

        for (jj=0; jj<NUM_WR_PER_LINE; jj++, value++) {
            type = *(pat_a + ((pof_a + jj)%NUM_WR_PER_LINE));
            aof_a += _write_pattern(type, addr_a + aof_a, value);
            aof_a &= line_msk;

            type = *(pat_b + ((pof_b + jj)%NUM_WR_PER_LINE));
            aof_b += _write_pattern(type, addr_b + aof_b, value);
            aof_b &= line_msk;

            type = *(pat_c + ((pof_c + jj)%NUM_WR_PER_LINE));
            aof_c += _write_pattern(type, addr_c + aof_c, value);
            aof_c &= line_msk;

            type = *(pat_d + ((pof_d + jj)%NUM_WR_PER_LINE));
            aof_d += _write_pattern(type, addr_d + aof_d, value);
            aof_d &= line_msk;
        }
    }

#if 0
    cfe_flushcache( CFE_CACHE_FLUSH_D);
    cfe_flushcache( CFE_CACHE_INVAL_D );
#else
    pa = (volatile unsigned int *) PHYS_TO_K0(0x200000);
    /* flush everything out */
    for (ii=0; ii<flush_wrd_sz; ii++)
    {
        dummy = *(pa + ii);
        dummy += 1;
    }
#endif

    for (ii=0; ii<cache_lines; ii++) {
        /*
         * adjust the starting pattern to be written.
         */
        pat_a = pat_array[(ii%4)];
        pat_b = pat_array[((1+ii)%4)];
        pat_c = pat_array[((2+ii)%4)];
        pat_d = pat_array[((3+ii)%4)];

        pof_a = (0+ii)%NUM_WR_PER_LINE;
        pof_b = (1+ii)%NUM_WR_PER_LINE;
        pof_c = (2+ii)%NUM_WR_PER_LINE;
        pof_d = (3+ii)%NUM_WR_PER_LINE;

        /*
         * calculate the start offset within line.
         */
        aof_a = _calc_line_ofst(pat_a, pof_a);
        aof_b = _calc_line_ofst(pat_b, pof_b);
        aof_c = _calc_line_ofst(pat_c, pof_c);
        aof_d = _calc_line_ofst(pat_d, pof_d);
        
        addr_a = (0*cache_sz) + (ii*line_sz) + PHYS_TO_K1(0x100000);
        addr_b = (1*cache_sz) + (ii*line_sz) + PHYS_TO_K1(0x400000);
        addr_c = (2*cache_sz) + (ii*line_sz) + PHYS_TO_K1(0x1000000);
        addr_d = (3*cache_sz) + (ii*line_sz) + PHYS_TO_K1(0x1300000);

        for (jj=0; jj<NUM_WR_PER_LINE; jj++, check++) {
            type = *(pat_a + ((pof_a + jj)%NUM_WR_PER_LINE));
            aof_a += _read_pattern(type, addr_a + aof_a, &value);
            aof_a &= line_msk;
            if (_check_value(type, value, check)) {
                errcnt++;
            }

            type = *(pat_b + ((pof_b + jj)%NUM_WR_PER_LINE));
            aof_b += _read_pattern(type, addr_b + aof_b, &value);
            aof_b &= line_msk;
            if (_check_value(type, value, check)) {
                errcnt++;
            }

            type = *(pat_c + ((pof_c + jj)%NUM_WR_PER_LINE));
            aof_c += _read_pattern(type, addr_c + aof_c, &value);
            aof_c &= line_msk;
            if (_check_value(type, value, check)) {
                errcnt++;
            }

            type = *(pat_d + ((pof_d + jj)%NUM_WR_PER_LINE));
            aof_d += _read_pattern(type, addr_d + aof_d, &value);
            aof_d &= line_msk;
            if (_check_value(type, value, check)) {
                errcnt++;
            }
        }
        if (errcnt > ERRCNT) {
            printf("\nToo many errors .. exiting ..\n");
            return -1;
        }
    }

    printf("random pattern test passed !!\n");
    return 0;
}
static int dcache_test_int(void)
{
    unsigned int * pa;
    volatile unsigned int * paf;
    unsigned int ii, jj, dummy, tmp, exp, errcnt, cache_sz;
    unsigned int banks, flush_sz;

    banks = 4;
    cache_sz = 0x2000;
    flush_sz = 0x2000;

    printf("Starting word dcache test ...\n");

    /* flush out cache */
    paf = (volatile unsigned int *) PHYS_TO_K0(0x200000);
    for (ii=0; ii<flush_sz; ii++)
    {
        dummy = *(paf + ii);
    }

    pa = (unsigned int *) PHYS_TO_K1(0x100000);
    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + ii;
            *(pa + tmp) = 0x55aa55aa;
        }
    }

    pa = (unsigned int *) PHYS_TO_K0(0x100000);
    for (ii=0; ii<cache_sz; ii+=2)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = jj*cache_sz + (ii);
            * (pa + tmp) = ((unsigned int)(pa + tmp + bias));
            tmp = jj*cache_sz + (ii + 1);
            * (pa + tmp) = ((unsigned int)(pa + tmp + bias));
        }
    }
#if 0
    cfe_flushcache( CFE_CACHE_FLUSH_D);
    cfe_flushcache( CFE_CACHE_INVAL_D );
#else
    paf = (volatile unsigned int *) PHYS_TO_K0(0x200000);
    /* flush everything out */
    for (ii=0; ii<2*flush_sz; ii++)
    {
        dummy = *(paf + ii);
        dummy += 1;
    }
#endif
    /* verify everything is OK */
    pa = (unsigned int *) PHYS_TO_K0(0x100000);
    errcnt = 0;

    for (ii=0; ii<cache_sz; ii+=2)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + (ii);
            dummy = *(pa + tmp);
            exp = ((unsigned int)(pa + tmp + bias));
            if (dummy != exp) {
                printf("Error: expected 0x%08x got 0x%08x at 0x%08x\n",
                       exp, dummy, (pa+tmp));
                if (++errcnt == ERRCNT) {
                    return 1;
                }
            }
            tmp = (jj*cache_sz) + (ii + 1);
            dummy = *(pa + tmp);
            exp = ((unsigned int)(pa + tmp + bias));
            if (dummy != exp) {
                printf("Error: expected 0x%08x got 0x%08x at 0x%08x\n",
                       exp, dummy, (pa+tmp));
                if (++errcnt == ERRCNT) {
                    return 1;
                }
            }
        }
    }
    /* verify everything is OK */
    pa = (unsigned int *) PHYS_TO_K1(0x100000);
    errcnt = 0;

    for (ii=0; ii<cache_sz; ii+=2)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + (ii);
            dummy = *(pa + tmp);
            exp = (((unsigned int)(pa + tmp + bias) & 0x1fffffff) | 0x80000000);
            if (dummy != exp) {
                printf("Error: expected 0x%08x got 0x%08x at 0x%08x\n",
                       exp, dummy, (pa+tmp));
                if (++errcnt == ERRCNT) {
                    return 1;
                }
            }
            tmp = (jj*cache_sz) + (ii + 1);
            dummy = *(pa + tmp);
            exp = (((unsigned int)(pa + tmp + bias) & 0x1fffffff) | 0x80000000);
            if (dummy != exp) {
                printf("Error: expected 0x%08x got 0x%08x at 0x%08x\n",
                       exp, dummy, (pa+tmp));
                if (++errcnt == ERRCNT) {
                    return 1;
                }
            }
        }
    }

    printf("word test passed !!\n");
    return 0;
}

static int dcache_test_16(void)
{
    volatile unsigned short * pa;
    unsigned short dummy, exp;
    unsigned int ii, jj, tmp, errcnt, cache_sz;
    unsigned int banks, flush_sz;

    banks = 4;
    cache_sz = 0x4000;
    flush_sz = 0x4000;

    printf("Starting 16bit pattern test ...\n");

    /* flush out cache */
    pa = (volatile unsigned short *) PHYS_TO_K0(0x200000);
    for (ii=0; ii<flush_sz; ii++)
    {
        dummy = *(pa + ii);
    }

    pa = (volatile unsigned short *) PHYS_TO_K1(0x100000);
    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + ii;
            *(pa + tmp) = 0x55aa;
        }
    }

    pa = (volatile unsigned short *) PHYS_TO_K0(0x100000);
    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = jj*cache_sz + (ii^7);
            * (pa + tmp) = tmp;
        }
    }

#if 0
    cfe_flushcache( CFE_CACHE_FLUSH_D);
    cfe_flushcache( CFE_CACHE_INVAL_D );
#else
    pa = (volatile unsigned short *) PHYS_TO_K0(0x200000);
    /* flush everything out */
    for (ii=0; ii<flush_sz; ii++)
    {
        dummy = *(pa + ii);
        dummy += 1;
    }
#endif
    /* verify everything is OK */
    pa = (volatile unsigned short *) PHYS_TO_K1(0x100000);
    errcnt = 0;

    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + (ii^7);
            dummy = *(pa + tmp);
            exp = (volatile unsigned short) tmp;
            if (dummy != exp) {
                printf("Error: expected 0x%08x got 0x%08x at 0x%08x\n",
                       exp, dummy, (pa+tmp));
                if (++errcnt == ERRCNT) {
                    return 1;
                }
            }
        }
    }

    printf("16bit pattern test passed !!\n");
    return 0;
}
static int dcache_test_8(void)
{
    volatile unsigned char * pa;
    unsigned char dummy, exp;
    unsigned int ii, jj, tmp, errcnt, cache_sz;
    unsigned int banks, flush_sz;

    banks = 4;
    cache_sz = 0x8000;
    flush_sz = 0x8000;

    printf("Starting 8bit dcache test ...\n");

    /* flush out cache */
    pa = (volatile unsigned char *) PHYS_TO_K0(0x200000);
    for (ii=0; ii<flush_sz; ii++)
    {
        dummy = *(pa + ii);
    }

    pa = (volatile unsigned char *) PHYS_TO_K1(0x100000);
    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + ii;
            *(pa + tmp) = 0x33;
        }
    }

    pa = (volatile unsigned char *) PHYS_TO_K0(0x100000);
    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = jj*cache_sz + (ii^15);
            * (pa + tmp) = tmp;
        }
    }

    pa = (volatile unsigned char *) PHYS_TO_K0(0x200000);
#if 0
    cfe_flushcache( CFE_CACHE_FLUSH_D);
    cfe_flushcache( CFE_CACHE_INVAL_D );
#else
    /* flush everything out */
    for (ii=0; ii<flush_sz; ii++)
    {
        dummy = *(pa + ii);
        dummy += 1;
    }
#endif
    /* verify everything is OK */
    pa = (volatile unsigned char *) PHYS_TO_K1(0x100000);
    errcnt = 0;

    for (ii=0; ii<cache_sz; ii++)
    {
        for (jj=0; jj<banks; jj++) {
            tmp = (jj*cache_sz) + (ii^15);
            dummy = *(pa + tmp);
            exp = (volatile unsigned char) tmp;
            if (dummy != exp) {
                printf("Error: expected 0x%08x got 0x%08x at 0x%08x\n",
                       exp, dummy, (pa+tmp));
                if (++errcnt == ERRCNT) {
                    return 1;
                }
            }
        }
    }

    printf("8bit pattern test passed !!\n");
    return 0;
}
static int ui_cmd_dcache_test(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char * x = NULL;

    x = cmd_getarg(cmd,0);
    if (x) bias = atoi(x);
    printf("bias is %d\n", bias);

    if (dcache_test_int())
        return -1;

    if (dcache_test_rnd())
        return -1;

    if (dcache_test_16())
        return -1;

    if (dcache_test_8())
        return -1;

    printf("D-cache test passed !!\n");
    return 0;
}

#define PGSZ (64<<10)		/* bcm5836 implements 64k page size */
#define TLBMASK 0x001e000	/* 64k mask for CP0 register 5 */
#define TLB_FLAGS 0x1f		/* cachable-writeback, dirty, valid, global */
#define TLBWIRED_MAX 31		/* seems to be the max value for bcm5836 */
#define TLB_ENTRY_SHIFT (31-25)

int
one_tlb(uint32_t va, uint32_t pa0, uint32_t pa1)
{
    int idx;

    idx = getTlbWired() + 1;
    if(idx > TLBWIRED_MAX) return 0;
    printf("v=%#08x even=%#08x odd=%#08x idx=%d\n", va, pa0, pa1, idx);
    setTlbWired(idx);
    setTlbEntry(idx, va,
	    (pa0 >> TLB_ENTRY_SHIFT) | TLB_FLAGS, 
	    (pa1 >> TLB_ENTRY_SHIFT) | TLB_FLAGS);
    return 1;
}

void *
tlb_map(unsigned long len, unsigned long pa, unsigned long va)
{
    int i, n;

    /* We require that va and len be two-page aligned to simplify the code
     * dealing with the (even, odd) TLB layout
     */
    if((len & ((PGSZ*2)-1)) || (pa & (PGSZ-1)) || (va & ((PGSZ*2)-1))) {
	printf("tlb_map(%#lx, %#lx, %#lx): ignoring non-rounded request\n",
		len, pa, va);
	return 0;
    }
    setPageSize(TLBMASK);
    n = len / (PGSZ*2);
    for(i=0; i<n; i++) {
	uint32_t even, odd;
	int off = i * PGSZ*2;

	even = off;
	odd = even + PGSZ;
	if(one_tlb(va+off, pa+even, pa+odd) == 0) break;
    }
    if(i < n) return 0;
    return (void *)va;
}


static int ui_cmd_tlb_test(ui_cmdline_t *cmd,int argc,char *argv[])
{
    uint32_t *va, *pa, len, ii, wrd, errcnt=0, tmp;
    char * x = NULL;

    va = (uint32_t*) 0xc0000000;
    pa = (uint32_t*) 0x100000;
    len = 0x100000;

    x = cmd_getarg(cmd,0);
    if (x) va = (uint32_t *) atoi(x);
    x = cmd_getarg(cmd,1);
    if (x) pa = (uint32_t *) atoi(x);
    x = cmd_getarg(cmd,2);
    if (x) {
        len = atoi(x);
    }

    wrd = len/4;

    printf("Mapping pages va: %p pa:%p len:0x%x\n",
               va, pa, len);

    setTlbWired(0);
    if (tlb_map(len, (uint32_t) pa, (uint32_t) va) == 0) {
        printf("failed to map pages !!\n");
        return -1;
    }

    /*
     * Do a simple read/write test.
     */
    printf("Writing pattern .. \n");
    for (ii=0; ii<wrd; ii++) {
        *(va + ii) = (unsigned long)(pa + ii);
    }
    printf("verifying pattern .. \n");
    for (ii=0; ii<wrd; ii++) {
        if(((tmp = *(va + ii)) != (unsigned long)(pa + ii))) {
            printf("Error: expected 0x%08x found 0x%08x at %p\n",
                   (unsigned long)(pa + ii), tmp, (va+ii));
           if(++errcnt == ERRCNT) {
               printf("Too many errors !!\n");
               return -1;
           }
        }
    }
    printf("TLB test ok !!\n");
    return 0;
}

#ifdef USE_BCM_ETH
extern void dump_eth_stats(void);

static int ui_cmd_eth_stat(ui_cmdline_t *cmd,int argc,char *argv[])
{
    dump_eth_stats();
    return 0;
}

static uint8_t  buf[2048];
static int fh = 0;
static int ui_cmd_eth_tx(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *y = NULL;
    uint32_t    len=64, cnt=1, ii;

    x = cmd_getarg(cmd,0);
    if (x) len = atoi(x);

    y = cmd_getarg(cmd,1);
    if (y) cnt = atoi(y);

    for (ii=0; ii<len-14; ii++) 
        buf[ii+14] = ii;

    while(cnt--) {
        cfe_write(fh, PTR2HSADDR(buf), len);
    }

    return 0;
}
static int ui_cmd_bcmdrv_test(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int rx, tx, rxb, txb, len, ii, verbose = 0, dump_pkt = 0, do_tx = 1;
    uint8_t tmp;

    if (!fh) {
        if ((fh = cfe_open("eth0")) < 0) {
            printf("Error : unable to open device (eth0)\n");
            return -1;
        }
    }

    xprintf("Press ENTER to stop loopback application\n");

    if (cmd_sw_isset(cmd,"-v")) {
	verbose = 1;
    }
    if (cmd_sw_isset(cmd,"-pkt")) {
	dump_pkt = 1;
    }
    if (cmd_sw_isset(cmd,"-d")) {
	do_tx = 0;
    }

    rx = rxb = tx = txb = 0;
    do {
        if (cfe_inpstat(fh)) {
            if ((len = cfe_read(fh, PTR2HSADDR(buf), 2048))) {
                if (dump_pkt) {
                    xprintf("RX Pkt : len = %d \n", len);
                    for (ii=0; ii<len; ii++) {
                        xprintf("0x%02x ", buf[ii]);
                        if ((ii % 16) ==  15) {
                            xprintf("\n");
                        }
                    }
                }
                /* swap DA and SA */
                for (ii=0; ii<6; ii++) {
                    tmp = buf[ii];
                    buf[ii] = buf[6+ii];
                    buf[6+ii] = tmp;
                }

                rxb += len;
                rx++;
                if (do_tx) {
                    if ((len = cfe_write(fh, PTR2HSADDR(buf), len))) {
                        txb += len;
                        tx++;
                    }
                }

                if (verbose) {
                    xprintf("r(%d:%d):t(%d:%d)", rx, rxb, tx, txb);
                }
            }
        }
    } while(!console_status());

    xprintf("LB test: tx: %d tx bytes %d rx: %d rx bytes %d\n",
            tx, txb, rx, rxb);

    return 0;
}
#endif /* USE_BCM_ETH */


static int ui_cmd_cp0_wr(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *z = NULL;
    unsigned long value = 0, addr = 0;

    x = cmd_getarg(cmd,0);
    if (x) addr = atoi(x);

    z = cmd_getarg(cmd,1);
    if (z) value = atoi(z);

    switch(addr){
        case 1:
            write_bcm1(value);
            break;
        case 2:
            write_bcm2(value);
            break;
        case 3:
            write_bcm3(value);
            break;
        case 4:
            write_bcm4(value);
            break;
        case 5:
            write_bcm5(value);
            break;
        case 6:
            write_bcm6(value);
            break;
        default:
            return -1;
    }

    return 0;
}

#endif /* DEBUG_UI */

#ifdef QUICK_TURN
static int ui_cmd_boot_from_ddr(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    unsigned long boot_addr = 0;
    volatile unsigned int * pa, tmp;
    volatile unsigned int ii;
    void (*entry)(int argc, char **argv, char **envp, int *prom_vec);

    x = cmd_getarg(cmd,0);
    if (x) boot_addr = atoi(x);

    pa = (volatile unsigned int *) PHYS_TO_K0(0x01f00000);
    for (ii=0; ii<0x8000; ii++) {
        tmp = *(pa + ii);
        tmp += 1;
    }

    if (boot_addr) {
        printf("Booting from addr 0x%x\n", boot_addr);

        entry = (void (*)(int , char **, char **, int *)) boot_addr;
        entry(0, NULL, NULL, NULL);
    }

    /* should not return */

    return -1;
}
#endif /* QUICK_TURN */

static void _do_mips_soft_reset(void)
{
    *(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BASE+R_ICS_SOFT_RESET) = 0;
    asm("sync");
    *(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BASE+R_ICS_SOFT_RESET) = 2;
    asm("sync");
    while (1);   /* Use 'wait' instead? */

}
#define L1CACHE_LINESIZE 32
static void __fetch_i_cache_and_lock(uint32_t * addr, uint32_t wrdLen)
{
    uint32_t addr_s, addr_e, ii;

    addr_e = (uint32_t) (addr + wrdLen);

    /* align the address to cache line */
    addr_s  = (uint32_t)addr & ~L1CACHE_LINESIZE;
    addr_e  = (addr_e + L1CACHE_LINESIZE) & (~L1CACHE_LINESIZE);

    for (ii=addr_s; ii<addr_e; ii+=L1CACHE_LINESIZE) {
        /* fetch and lock I-cache */
        asm(".set mips32; cache   0x1c, 0(%0)" :: "r" (ii));
    }
}

static void do_mips_soft_reset(void)
{
    __fetch_i_cache_and_lock((uint32_t*) _do_mips_soft_reset, 
           ((uint32_t)__fetch_i_cache_and_lock - (uint32_t)_do_mips_soft_reset)/4);
    _do_mips_soft_reset();
}

#define WRITECSR(x,v) \
  (*(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BCM56XXX_BASE+(x)) = (v))

static int ui_cmd_reset(ui_cmdline_t *cmd,int argc,char *argv[])
{
    uint8_t data = 0;
    int confirm = 1;
    char str[50];

//    if (cmd_sw_isset(cmd,"-yes")) confirm = 0;
//
//    if (cmd_sw_isset(cmd,"-sysreset")) data |= 1;
//
//    if (cmd_sw_isset(cmd,"-cpu")) data |= 0x2;
//
//    if (cmd_sw_isset(cmd,"-wdog")) data |= 0x4;
//
//    if (data == 0) {		/* no changes to reset pins were specified */
//	return ui_showusage(cmd);
//	}
//
//    if (confirm) {
//	console_readline("Are you sure you want to reset? ",str,sizeof(str));
//	if ((str[0] != 'Y') && (str[0] != 'y')) return -1;
//	}
//
//    if (data & 0x1) {
        sb_chip_reset();
//    } else 
//    if (data & 0x02) {
//        do_mips_soft_reset();
//    } else 
//    if (data & 0x04) {
//        WRITECSR(R_WATCHDOGCNTR, 1);
//        while(1);
//    }
    
    /* should not return */

    return -1;
}

static int ui_cmd_fl_probe(ui_cmdline_t *cmd,int argc,char *argv[])
{
    return bcm953314_probeflash();
}


#if CFG_FULLDIAG
static int ui_cmd_envdev(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x;

    x = cmd_getarg(cmd,0);
    if (x) {
	cfe_set_envdevice(x);
	printf("environment device set to %s\n",x);
	}

    return 0;
}

extern uint32_t do_schan_read_reg(unsigned int reg, int cnt, int step);
extern void
do_schan_write_reg(unsigned int reg, uint32_t value);

static int ui_cmd_schan_wr(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *y = NULL;
    unsigned long val = 0, addr = 0;

    x = cmd_getarg(cmd,0);
    if (x) addr = atoi(x);

    y = cmd_getarg(cmd,1);
    if (y) val = atoi(y);

    do_schan_write_reg(addr, val);

    return 0;
}

static int ui_cmd_schan_rd(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *y = NULL;
    char *z = NULL;
    unsigned long cnt = 0, addr = 0, step = 4;

    x = cmd_getarg(cmd,0);
    if (x) addr = atoi(x);

    y = cmd_getarg(cmd,1);
    if (y) cnt = atoi(y);

    z = cmd_getarg(cmd,2);
    if (z) step = atoi(z);

    do_schan_read_reg(addr, cnt, step);

    return 0;
}

uint32_t
do_mii_read_reg(uint32_t phy_addr, unsigned int reg, int cnt);
uint32_t
do_mii_write_reg(uint32_t phy_addr, unsigned int reg, int value);

static int ui_cmd_mii_rd(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *y = NULL;
    char *z = NULL;
    unsigned long cnt = 1, addr = 0, reg = 0;

    x = cmd_getarg(cmd,0);
    if (x) addr = atoi(x);

    y = cmd_getarg(cmd,1);
    if (y) reg = atoi(y);

    z = cmd_getarg(cmd,2);
    if (z) cnt = atoi(z);

    do_mii_read_reg(addr, reg, cnt);

    return 0;
}

static int ui_cmd_mii_wr(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *y = NULL;
    char *z = NULL;
    unsigned long value = 0, addr = 0, reg = 0;

    x = cmd_getarg(cmd,0);
    if (x) addr = atoi(x);

    y = cmd_getarg(cmd,1);
    if (y) reg = atoi(y);

    z = cmd_getarg(cmd,2);
    if (z) value = atoi(z);

    do_mii_write_reg(addr, reg, value);

    return 0;
}

#define SFLASH_SIZE (64*1024)
#define SFLASH_SECTOR_SIZE (4*1024)
#define isaligned(x, y) (((x) % (y)) == 0)
#define min(a,b) ((a) < (b) ? (a) : (b))
#define max(a,b) ((a) > (b) ? (a) : (b))

static int ui_cmd_sflash_rd(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *y = NULL;
    int i;
    unsigned long cnt = 1, addr = 0;
    unsigned char data;

    x = cmd_getarg(cmd,0);
    if (x) { 
        addr = atoi(x);
        if (addr > SFLASH_SIZE) {
            xprintf("address limit is 0x%x\n", SFLASH_SIZE);
        }
    }
         
    y = cmd_getarg(cmd,1);
    if (y) {
    	cnt = atoi(y);
    }
    
    xprintf("%s: addr = 0x%x, count = %d\n", __FUNCTION__, addr, cnt);
    
    for (i = 0; i < cnt; ++i)
	{
		data = 0;
		if (addr + i > SFLASH_SIZE) {
		    break;
		}
		data = i;
		if (bspi_read(0, addr + i,&data) != CFE_OK)
		{
			xprintf("%s:%d failed to read at 0x%08x\n",__FUNCTION__,__LINE__,addr+i);
			break;
		}
		if ((i % 16) == 0) {
		    xprintf("%08x:", addr+i);
		}
		if ((i % 4) == 0) {
		    xprintf(" ");
		}
		xprintf("%02x", data);
		
		if ((i & 0xf) == 0xf) {
		    xprintf("\n");   
		}
	}
    xprintf("\n");
    return 0;
}

static int ui_cmd_sflash_wr(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    char *y = NULL;
    char *z = NULL;
    unsigned long value = 0, addr = 0, cnt = 0, i, j;
    uint8_t *block = NULL;
    uint32_t start, offset, mask, len;

    x = cmd_getarg(cmd,0);
    if (x) { 
        addr = atoi(x);
        if (addr > SFLASH_SIZE) {
            xprintf("address limit is 0x%x\n", SFLASH_SIZE);
        }
    }

    y = cmd_getarg(cmd,1);
    if (y) value = atoi(y);

    z = cmd_getarg(cmd,2);
    if (z) cnt = atoi(z);
    
    if (!(block = KMALLOC(SFLASH_SECTOR_SIZE, 0)))
		return CFE_ERR_NOMEM;
    
    mask = SFLASH_SECTOR_SIZE-1;
    /* Backup and erase one block at a time */
	while (cnt) {
	    	
		/* Align offset */
		start = addr & ~mask;
		offset = addr & mask;
		/* Copy existing data into holding block if necessary */
		if (!isaligned(addr, SFLASH_SECTOR_SIZE) || (cnt < SFLASH_SECTOR_SIZE)) {
			for (i = 0; i < SFLASH_SECTOR_SIZE; ++i) {
		        if (bspi_read(0, start+i,&block[i]) != CFE_OK) {
			        xprintf("%s:%d failed to read at 0x%08x\n",__FUNCTION__,__LINE__,start+i);
			    }
			}
		}
		
		/* Copy input data into holding block */
		len = min(cnt, SFLASH_SECTOR_SIZE - (addr & mask));
		for (i = offset, j = 0; j < len; i++, j++) {
		    block[i] = (uint8_t)value;
        }
        /* Erase block */
		if (bspi_sector_erase(0, addr) < 0) {
			xprintf("%s:%d failed to erase at 0x%08x\n",__FUNCTION__,__LINE__,addr);
			break;
		}
        bspi_flush_prefetch_buffers();
		/*
		while (sflash_poll(sflash->cc, (uint32_t) cur.buf_offset));
        */
		/* Write holding block */
		for (i = 0; i < SFLASH_SECTOR_SIZE; i += 4) {
            if (bspi_page_program(0, start + i,&block[i],4) != CFE_OK)                     {
			    xprintf("%s:%d failed to write at 0x%08x\n",__FUNCTION__,__LINE__,addr+i);
		    }
        }
        bspi_flush_prefetch_buffers();
        addr += len;
		cnt -= len;
	}
        KFREE(block);
    return 0;
}

static int ui_cmd_sflash_flush(ui_cmdline_t *cmd,int argc,char *argv[])
{
    bspi_flush_prefetch_buffers();
    return 0;
}

static int ui_cmd_sflash_erase(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *x = NULL;
    unsigned long addr = 0;
    
    x = cmd_getarg(cmd,0);
    if (x) { 
        addr = atoi(x);
        if (addr > SFLASH_SIZE) {
            xprintf("address limit is 0x%x\n", SFLASH_SIZE);
        }
    }

    if (bspi_sector_erase(0, addr) < 0) {
        xprintf("%s:%d failed to erase at 0x%08x\n",__FUNCTION__,__LINE__,addr);
    }
    bspi_flush_prefetch_buffers();
    return 0;
}
#endif /* CFG_FULLDIAG */

static int ui_cmd_showconfig(ui_cmdline_t *cmd,int argc,char *argv[])
{
    xprintf("config 0: 0x%08x,  1: 0x%08x\n", read_config0(), read_config1());

    xprintf("brcm   0: 0x%08x,", read_bcm0());
    xprintf("  1: 0x%08x,", read_bcm1());
    xprintf("  2: 0x%08x,", read_bcm2());
    xprintf("  3: 0x%08x\n", read_bcm3());

    xprintf("       4: 0x%08x,", read_bcm4());
    xprintf("  5: 0x%08x,", read_bcm5());
    xprintf("  6: 0x%08x,", read_bcm6());
    xprintf("  7: 0x%08x\n", read_bcm7());

    return 0;
}
