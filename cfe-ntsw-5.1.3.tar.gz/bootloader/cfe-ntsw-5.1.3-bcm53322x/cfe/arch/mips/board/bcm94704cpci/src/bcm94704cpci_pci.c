/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Board-specific PCI description		File: bcm94702cpci_pci.c
    *  
    *  This file describes the board-specific PCI slots/devices
    *  and wiring thereof.
    *  
    *********************************************************************  
    *
    *  XX Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#include "lib_types.h"

#include "pcireg.h"
#include "pcivar.h"
#include "pci_internal.h"

/* The BCM94704CPCI card can function as either host or device.  As a
   host, it plugs into a CompactPCI System Slot.  The mapping from
   System to Logical Slot for interrupts on the backplane is defined
   by the CompactPCI spec (see Section 3.2.6 and Figure 8).

   Backplane:
   Slot    IDSEL   DevID   INT{A,B,C,D}  shift
    1 (HB)  16       0       {A,B,C,D}     0
    2       31      15       {B,C,D,A}     1
    3       30      14       {C,D,A,B}     2
    4       29      13       {D,A,B,C}     3
    5       28      12       {A,B,C,D}     0
    6       27      11       {B,C,D,A}     1
    7       26      10       {C,D,A,B}     2
    8       25       9       {D,A,B,C}     3

   However, INTA and INTC signals on the connector are mapped to INTA on
   the card, and the INTB and INTD signals are mapped to INTB. */

/* Return the base shift of a slot or device on the motherboard.
   This is board specific, for the BCM94704CPCI only. */
uint8_t
pci_int_shift_0(pcitag_t tag)
{
    int bus, device;

    pci_break_tag(tag, NULL, &bus, &device, NULL);

    if (bus == 0 && (device >= 9 && device <= 15))
	return ((16 - device) % 4);
    else
	return 0;
}

/* Return the mapping of a device/function interrupt to an interrupt
   line.  For the BCM94704CPCI, all interrupt signals from the
   backplane are mapped to the single interrupt eventually generated
   by the PCI core. */
uint8_t
pci_int_map_0(pcitag_t tag)
{
    pcireg_t data;
    int pin;

    data = pci_conf_read(tag, PCI_BPARAM_INTERRUPT_REG);
    pin = PCI_INTERRUPT_PIN(data);
    return (pin == 0) ? 0 : (((pin - 1) + pci_int_shift_0(tag)) % 2) + 1;
}
