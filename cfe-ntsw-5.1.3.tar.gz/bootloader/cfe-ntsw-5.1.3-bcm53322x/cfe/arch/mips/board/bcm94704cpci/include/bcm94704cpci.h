/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM94704CPCI board-specific definitions       File: bcm94704cpci.h
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef __BCM94704CPCI_H
#define __BCM94704CPCI_H
/* Macros */

#define KB 1024
#define MB (1024*1024)


/*
 * Put board-specific stuff here
 */

/* Definitions for the BCM94704CPCI_10 platform. */

#define BCM94704_CPCI_RESET_ADDR            (MIPS33_EXTIF_REGION + 0x0000)
#define BCM94704_CPCI_BOARDID_ADDR          (MIPS33_EXTIF_REGION + 0x4000)
#define BCM94704_CPCI_DOC_ADDR              (MIPS33_EXTIF_REGION + 0x6000)
#define BCM94704_CPCI_LED_ADDR              (MIPS33_EXTIF_REGION + 0xC000)
#define BCM94704_CPCI_NVRAM_ADDR            (MIPS33_EXTIF_REGION + 0xE000)
#define BCM94704_CPCI_NVRAM_SIZE            0x1FF0      /* 8K NVRAM + TOD */
#define BCM94704_CPCI_NVRAM_VXWORKS         0x1000      /* VxWorks reserved */

/* VxWorks-specific NVRAM addresses */
#define BCM94704_CPCI_VXWORKS_MAC_ADDR      (BCM94704_CPCI_NVRAM_ADDR + 0x400)

/* Internal NS16550-compatible dual UART */
#define BCM94704_COM1   BCM4704_UART0       /* console, DB-9 */
#define BCM94704_COM2   BCM4704_UART1       /* header */

#endif /* ! __BCM94704CPCI_H */
