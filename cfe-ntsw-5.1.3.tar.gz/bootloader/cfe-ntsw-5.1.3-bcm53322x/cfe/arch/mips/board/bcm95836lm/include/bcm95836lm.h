/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM95836LM board-specific definitions       File: bcm95836lm.h
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef __BCM95836LM_H
#define __BCM95836LM_H
/*
 * Put board-specific stuff here
 */

/* Definitions for the BCM95836LM platform. */

#define BCM95836LM_FPGA_ADDR            MIPS33_EXTIF_REGION
#define BCM95836LM_LED_ADDR             (MIPS33_EXTIF_REGION + 0xC000)

#define BCM95836LM_RESET                0x0000
#define BCM95836LM_FPGA_REV             0x2000
#define BCM95836LM_SLOTID               0x2001
#define BCM95836LM_ALT_CONSOLE          0x2007
#define BCM95836LM_CPUSUBSYSID          0x4000
#define BCM95836LM_BOARDID              0x8000

#define CPLD_BASE                       (PHYS_TO_K1(BCM95836LM_FPGA_ADDR))

#define CPLD_REG_READ(r)                *((volatile uint8_t *)((CPLD_BASE + r)^3))
#define CPLD_REG_WRITE(r,v)             *((volatile uint8_t *)((CPLD_BASE + r)^3)) = v

#define CPLD_GET_CPUSUBSYS_ID()         CPLD_REG_READ(BCM95836LM_CPUSUBSYSID)
#define CPLD_GET_BOARD_ID()             CPLD_REG_READ(BCM95836LM_BOARDID)
#define CPLD_GET_SLOT_ID()              CPLD_REG_READ(BCM95836LM_SLOTID)
#define CPLD_GET_CPLD_REV()             CPLD_REG_READ(BCM95836LM_FPGA_REV)
#define CPLD_GET_ALT_CONSOLE()          CPLD_REG_READ(BCM95836LM_ALT_CONSOLE)

/* CPU subsystem IDs */
#define CPUSUBSYS_BCM95695P48LM         0x13
#define CPUSUBSYS_BCM95674P6CX4LM       0x16
#define CPUSUBSYS_BCM956504P48LM        0x17
#define CPUSUBSYS_BCM956504P24REF       0x19


/* Internal NS16550-compatible dual UART */
#define BCM95836_COM1   BCM5836_UART0       /* console, DB-9 */
#define BCM95836_COM2   BCM5836_UART1       /* header */

#endif /* ! __BCM95836LM_H */
