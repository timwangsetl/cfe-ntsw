/*
 * $Copyright Broadcom Corporation$
 *
 * $Id: bsp_priv.h,v 1.2 2009/05/21 21:35:00 miyarn Exp $
 */
#ifndef _LANGUAGE_ASSEMBLY

/* Global SI handle */
extern si_t *bcm953001r_sih;
#define sih bcm953001r_sih

/* BSP UI initialization */
extern int ui_init_bcm953001rcmds(void);
#if CFG_ET
extern void et_addcmd(void);
#endif


#endif

