/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Board device initialization		File: bcm953001r_devs.c
    *  
    *  This is the "C" part of the board support package.  The
    *  routines to create and initialize the console, wire up 
    *  device drivers, and do other customization live here.
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "bcmnvram.h"
#include "ptable.h"
#include "cfe_mii.h"

#include "sbmips32.h"
#include "sb_bp.h"

#include "dev_newflash.h"
#include "sb_utils.h"
#include "siutils.h"
#include "bcmdevs.h"
#include "bsp_priv.h"
#include "et_cfe.h"
#include "hndmips.h"
#include "cfe_spi.h"
#include "sbchipc.h"

#include "cfe_irq.h"

#if CFG_SPI
#include "cfe_spi.h"
#include "chipc_spi.h"
#endif
#include "cfe_failsave.h"

extern cfe_driver_t bcmet;

#if CFG_MDK == 1
#include "mdk_sys.h"
#endif

/*  *********************************************************************
    *  Devices we're importing
    ********************************************************************* */
/* Defined as sih by bsp_config.h for convenience */
si_t *bcm953001r_sih = NULL;

extern cfe_driver_t ns16550_uart;
extern cfe_driver_t sb_mac;

#ifdef INCLUDE_FLASH_DRIVERS
extern cfe_driver_t newflashdrv;
extern cfe_driver_t sflashdrv;
#endif 

#ifdef FEAT_BROADCOM_DUAL_IMAGE
/* Dual image support */
extern cfe_driver_t dimagedrv;
#endif /* FEAT_BROADCOM_DUAL_IMAGE */

#if CFG_PCI
extern void cpci_add_devices(int init_pci);
#endif

extern cfe_driver_t ds1743_nvram;
extern cfe_driver_t ds1743_clock;

extern cfe_mii_t si_mii;

#if CFG_MDK_DEBUG == 1
extern int ui_init_mdkcmds(void);
#endif

#if CFG_SPI
/* for low level SPI channel */
extern cfe_spi_t chipc_spi;
#ifdef CFG_ROBO
/* for high level SPI driver */
extern cfe_driver_t spi_robo;
#endif
#endif

#define __MB (1024*1024)
#define __KB (1024)
#define __K64 65536

extern char *vxboot_mac_addr;

extern int ui_init_phycmds(void);
extern int ui_init_toyclockcmds(void);
extern void ui_init_flashtestcmds(void);
extern int ui_init_disktestcmds(void);
extern int ui_init_vxbootcmds(void);
#if CFG_PTABLE
extern int ui_init_ptablecmds(void);
#endif


extern void board_setleds(uint32_t);
void board_led_msg(char *msg);

/*  *********************************************************************
    *  Some board-specific parameters
    ********************************************************************* */

typedef struct initenv_s {
    const char *name;
    const char *value;
    const char *def;
    const char *altname;
} initenv_t;

/* Note: et1 MAC port is not brought out on current revs */
static const initenv_t bcm953001r_envvars[] = {
    {"et0phyaddr", "$$NVRAM", "30", "et0phyaddr"},
    {"ETH0_HWADDR","$$NVRAM","02-10-18-53-00-10","et0macaddr"},
    {"et0mdcport","0",NULL,"et0mdcport"},
#ifdef _BCM953003R_
    {"et1phyaddr", "$$NVRAM", "29", "et1phyaddr"},
    {"ETH1_HWADDR","$$NVRAM","02-10-18-53-00-11","et1macaddr"},
    {"et1mdcport","1",NULL,"et1mdcport"},
    {"boardtype","bcm953003r",NULL},
    {"coreflags","0x0000BCCB",NULL}, /* Exclude USB,Alta,PCIE0/1,GMAC0 */
#else /* BCM953001R */
    {"boardtype","bcm953001r",NULL},
    {"coreflags","0x00009CCB",NULL}, /* Exclude USB,Alta,PCIE0/1,GMAC1,GMAC0 */
#endif /* _BCM953003R_ */    
    {"SYS_RESET_PIN","7",NULL},
    {"CPU_RESET_PIN","7",NULL},
    {NULL,NULL}};

static nvram_import_t nvram_import_bcm953001r[] = {
    { "LINUX_CMDLINE",  "kernel_args",  NULL },
    { "ETH0_HWADDR",    "et0macaddr",   NULL },
    { "et0phyaddr",     "et0phyaddr",   NULL },
    { "et0mdcport",     "et0mdcport",   NULL },
#ifdef _BCM953003R_
    { "ETH1_HWADDR",    "et1macaddr",   NULL },
    { "et1phyaddr",     "et1phyaddr",   NULL },
    { "et1mdcport",     "et1mdcport",   NULL },
#endif /* _BCM953003R_ */
    { NULL, NULL }
};

/*  *********************************************************************
    *  Partition table support
    ********************************************************************* */

#if CFG_PTABLE

static ptable_t usr_ptbl;

#define PTAB_OFFSET     (CFG_BOOT_SIZE - CFG_PTABLE_SIZE)

static int pt_read(ptable_t *ptbl);
static int pt_write(ptable_t *ptbl);

static ptable_drv_t pt_drv = {
    pt_read,
    pt_write
};

static int
pt_read(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
        return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_readblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}

static int
pt_write(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
        return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_writeblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}
static int
user_parts(ptable_t *ptbl, newflash_probe_t *fprobe)
{
    newflash_part_t *fp = fprobe->flash_parts;
    partition_t *up = ptbl->part;
    int i, top = 0, uparts = 0;

    /* Check partition table */
    if (usr_ptbl.magic != PTABLE_MAGIC || ptable_check(&usr_ptbl) < 0) {
        return 0;
    }
    /* Add partitions */
    for (i = 0; i < PTABLE_MAX_PARTITIONS && up[i].size; i++) {
        if (top + up[i].size > fprobe->flash_size) break;
        /* Check for holes in partition map */
        if (up[i].offset > top) {
            fp[uparts].fp_size = top ? 0 : up[i].offset - top;
            fp[uparts].fp_name = top ? "unused" : "boot";
            if (++uparts >= FLASH_MAX_PARTITIONS) break;
            }
        fp[uparts].fp_size = up[i].size;
        fp[uparts].fp_name = up[i].name;
        if (++uparts >= FLASH_MAX_PARTITIONS) break;
        top = up[i].offset + up[i].size;
    }
		
		fprobe->flash_nparts = i;
    return uparts;
}

#endif /* CFG_PTABLE */


/*  *********************************************************************
    *  board_led_msg()
    *  
    *   Write characters to OSRAM 4-char LED display.
    *  
    *  Input parameters: 
    *  	  String of 1 character or more in length
    *  	   
    *  Return value:
    *  	   nothing
    ******************************************************************** */
void board_led_msg(char * msg)
{
    int len = strlen(msg);
    uint32_t a0;
    int i;

    for (a0 = 0,i = 0; i < 4; i++) {
	a0 <<= 8;
	a0 |= (i < len) ? msg[i] : ' ';
	}
    board_setleds(a0);
}


/*  *********************************************************************
    *  bcm953001r_initenv()
    *  
    *  Initialize default environment variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm953001r_initenv(void)
{
    const initenv_t *ini;
    char *txt;

    ini = bcm953001r_envvars;

    /* Assign either the forced value, or the value
       of another environment variable if the name starts
       with a dollar sign.  If that name is not defined
       either, then use the default from the table. */

    while (ini->name) {
	if (strcmp(ini->value, "$$NVRAM") == 0) {
	    txt = (char *)nvram_get(ini->altname);
	    if (!txt) txt = env_getenv(ini->altname);
	    if (!txt) txt = (char *) ini->def;
	    }
	else if (ini->value[0] == '$') {
	    txt = env_getenv(&(ini->value[1]));
	    if (!txt) txt = (char *) ini->def;
	    }
	else {
            txt = NULL;
	    if (ini->altname) txt = env_getenv(ini->altname);
	    if (!txt) txt = (char *) ini->value;
	    }
	if (txt) {
	    if (!env_getenv(ini->name)) {
		env_setenv(ini->name,txt,ENV_FLG_BUILTIN);
		}
	    }
	ini++;
	}

#if defined(CFG_ROBO) && defined(NTSW_WSS)
    /*
     * Special case for eth1 MAC address (should be unique for each board):
     * - check "factory configurables" block.
     */
    if (nvram_get("et1macaddr") == NULL) {
        FACTORYCFG_H handle;
        handle = factory_config_open();
        if (handle) {
            unsigned char mac[6];
            char *macaddr = (char *)factory_config_get(handle, "macaddr");
            if (macaddr != NULL) {
                if (enet_parse_hwaddr(macaddr, mac) == 0) {
                    env_setenv("et1macaddr", macaddr, ENV_FLG_BUILTIN);
                }
            }
            factory_config_close(handle, FALSE);
        }
    } 

#endif /* defined(CFG_ROBO) && defined(NTSW_WSS) */

}


/*  *********************************************************************
    *  bcm953001r_probeflash()
    *  
    *  Probe the flash and initialize as required.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm953001r_probeflash(void)
{
#ifdef INCLUDE_FLASH_DRIVERS
    newflash_probe_t fprobe, fprobe1;
    chipcregs_t *cc = NULL;
    uint32 fltype, bootsz, reg_val;
    int size = 0;
    cfe_driver_t *drv, *drv1 = NULL;

    memset(&fprobe, 0, sizeof(fprobe));
    memset(&fprobe1, 0, sizeof(fprobe1));

    if ((cc = (chipcregs_t *)si_setcoreidx(sih, SI_CC_IDX))) {
        fltype = R_REG(NULL, &cc->capabilities) & CC_CAP_FLASH_MASK;
        fprobe.flash_phys = SI_TLB_FLASH_PHYS;
    } else {
        return;
    }
    
    /* Workaround for default pflash waitcount issue on bcm5300x a0 */
    W_REG(NULL, &cc->pflash_waitcount, 0x0404141a);
    W_REG(NULL, &cc->pflash_waitcount_pf1, 0x0404141a);

    switch (fltype) {
        case PFLASH:
            drv = &newflashdrv;
            fprobe.flash_flags = FLASH_FLG_BUS16 | FLASH_FLG_DEV16;
            if (!(R_REG(NULL, &cc->pflash_config) & CC_CFG_DS)) {
                fprobe.flash_flags = FLASH_FLG_BUS8 | FLASH_FLG_DEV16;
            }
            break;
        case SFLASH_ST:
        case SFLASH_AT:
            ASSERT(cc);
            drv = &sflashdrv;
            /* Overload cmdset field */
            fprobe.flash_cmdset = (int)cc;
            break;
        default:
            /* No flash or unsupported flash */
            return;
    }
    
    /* Default is 1M boot partition */
    bootsz = CFG_BOOT_SIZE;
#if CFG_PTABLE
    ptable_init(&pt_drv);
#endif /* CFG_PTABLE */    
    
    /* Because CFE can only boot from the beginning of a partition */
    fprobe.flash_nparts = 4;
    fprobe.flash_parts[0].fp_size = bootsz;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[1].fp_name = "nvram";
    fprobe.flash_parts[2].fp_size = NVRAM_SPACE;
    fprobe.flash_parts[2].fp_name = "env";
    fprobe.flash_parts[3].fp_size = 0;
    fprobe.flash_parts[3].fp_name = "os";
    cfe_add_device(drv, 0, 0, &fprobe);

    /* We need flash1 since it's used by some common parts */
    cfe_add_device(drv, 0, 0, &fprobe);

    /* Because sometimes we want to program the entire device */
    fprobe.flash_nparts = 0;
    cfe_add_device(drv, 0, 0, &fprobe);

    /* if there is no 2nd flash, the 1st flash memory size is up to the maximum value = 256 MB */
    reg_val = FLASH_STRCF_1ST_MADDR_SEG_256MB;

    /* Config the first flash memory size to determine the next flash memory's starting address */
    if (CFG_CS1_FLASH_TYPE != CS1_NONE) {
        size = (fprobe.flash_size / MB);
        if (CFG_CS0_VISIBLE_MEM_SIZE != 0) {
            if (size > CFG_CS0_VISIBLE_MEM_SIZE) {
                size = CFG_CS0_VISIBLE_MEM_SIZE;
            }
        }
        switch (size) {
            case 4:
                reg_val = FLASH_STRCF_1ST_MADDR_SEG_4MB;
                break;
            case 8:
                reg_val = FLASH_STRCF_1ST_MADDR_SEG_8MB;
                break;
            case 16:
                reg_val = FLASH_STRCF_1ST_MADDR_SEG_16MB;
                break;
            case 32:
                reg_val = FLASH_STRCF_1ST_MADDR_SEG_32MB;
                break;
            case 64:
                reg_val = FLASH_STRCF_1ST_MADDR_SEG_64MB;
                break;
            case 128:
                reg_val = FLASH_STRCF_1ST_MADDR_SEG_128MB;
                break;
            case 256:
                reg_val = FLASH_STRCF_1ST_MADDR_SEG_256MB;
                break;
        }

        switch (CFG_CS1_FLASH_TYPE) {
            case CS1_PFLASH:
                fprobe1.flash_phys = (fprobe.flash_phys + (size*MB));
                drv1 = &newflashdrv;
                fprobe1.flash_flags = FLASH_FLG_BUS16 | FLASH_FLG_DEV16;
                if (!(R_REG(NULL, &cc->pflash_config) & CC_CFG_DS)) {
                    fprobe1.flash_flags = FLASH_FLG_BUS8 | FLASH_FLG_DEV16;
                }
                reg_val |= FLASH_STRCF_PF1;
                break;
            case CS1_SFLASH_ST:
            case CS1_SFLASH_AT:
                ASSERT(cc);
                fprobe1.flash_phys = (SI_FLASH2 + (size*MB));
                drv1 = &sflashdrv;
                /* Overload cmdset field */
                fprobe1.flash_cmdset = (int)cc;
                reg_val |= FLASH_STRCF_SF1;
                if (CFG_CS1_FLASH_TYPE == CS1_SFLASH_AT) {
                    reg_val |= FLASH_STRCF_SF1_TYPE;
                }
                break;
        }
    }

    /* Config the memory size of 1st flash and the flash type of 2nd flash if present */
    W_REG(NULL, &cc->flashstrconfig, reg_val);

    if (CFG_CS1_FLASH_TYPE != CS1_NONE) { 
        fprobe1.flash_nparts = 0;
        cfe_add_device(drv1, 1, 0, &fprobe1);
    }

#if CFG_PTABLE
   /* User-defined partitions */
   fprobe.flash_phys = SI_TLB_FLASH_PHYS;
   fprobe.flash_flags = (FLASH_FLG_BUS16 | FLASH_FLG_DEV16);
   if (pt_read(&usr_ptbl) == 0 &&
     (fprobe.flash_nparts = user_parts(&usr_ptbl, &fprobe)) > 0) {
       cfe_add_device(drv,0,0,&fprobe);       /* flash3 */
   }
#endif /* CFG_PTABLE */    

    board_led_msg("FLASH");
#endif /* INCLUDE_FLASH_DRIVERS */
}

/*  *********************************************************************
    *  board_console_init()
    *  
    *  Add the console device and set it to be the primary
    *  console.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_console_init(void)
{
    uint32_t uart_clock, w, bootsz;
    chipcregs_t *cc;

    sih = si_kattach(SI_OSH);
    if (sih == NULL) {
        printf("si_kattach failed in board_console_init().\n");
    }

    cc = (chipcregs_t *)REG_MAP(SI_ENUM_BASE, SI_CORE_SIZE);
   /* Set Uart clock as ALP clock */
    w = R_REG(NULL, &cc->corecontrol);
    w |= 0x1;
    W_REG(NULL, &cc->corecontrol, w);
    
#ifdef QUICK_TURN
    /* QT DB Freq (f)   : Div (d)    : sim uart freq (9600 * d * 16) */
    uart_clock = 21150; /* For qt17 config2 database */
#else
    uart_clock = si_uart_clock();
#endif

    /* This hack prevents a divider value of 0 in the UART registers.  It's
       not obviously the right thing to do here. */
    if (uart_clock < (CFG_SERIAL_BAUD_RATE*16))
	uart_clock = 16*CFG_SERIAL_BAUD_RATE;

    /* Initialize clocks and interrupts */
    si_mips_init(sih, 0);

    w = R_REG(NULL, &cc->corecontrol);
    if (w & CC_CORECTL_UART_SEL_UART0) {
        /* Console on BCM953000 is COM1, note: no HW Flow control */
        cfe_add_device(&ns16550_uart, BCM953000_COM1, uart_clock, 0);
    }

#ifdef CFG_UART1
    /* Set the UART1 IO selector */ 
    w |= CC_CORECTL_UART_SEL_UART1;
    W_REG(NULL, &cc->corecontrol, w);
    cfe_add_device(&ns16550_uart,BCM953000_COM2,uart_clock,0);
    cfe_set_console("uart1");
#else
    cfe_set_console("uart0");
#endif

    bootsz = CFG_BOOT_SIZE;
    nvram_init((uint8_t *) PHYS_TO_K1(0x1C000000 + bootsz), NVRAM_SPACE);
#if CFG_PCI
    cfe_startflags |= CFE_INIT_PCI;
#endif
}

/*  *********************************************************************
    *  board_device_init()
    *  
    *  Initialize and add other devices.  Add everything you need
    *  for bootstrap here, like disk drives, flash memory, UARTs,
    *  network controllers, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_init(void)
{
    void *regs;
    unsigned int unit;
    chipcregs_t *cc = NULL;
    uint32_t    num_gmac = 0;
    uint32_t    mask = 0;
    
#if CFG_INTERRUPTS
    cfe_irq_init();
#endif /* CFG_INTERRUPTS */
    
    /* We would like the environment variables to be set up early.
     * For compatibility with HND conventions, some of the device
     * attach routines, e.g, for the MACs, interrogate the
     * environment.
     */

    bcm953001r_probeflash();
    cfe_set_envdevice("flash0.env");
    bcm953001r_initenv();

    /* Configure nvram import command */
    nvram_import_data = nvram_import_bcm953001r;

    /* Initialization of SOC RAM of Keystone */
    if ((regs = si_setcore(sih, SOCRAM_CORE_ID, 0))) {
        si_core_reset(sih, 0, 0);

        SOCRAMMEMINIT((unsigned char *)PHYS_TO_K1(SI_FASTRAM), 
            (512 * 1024)); 
    }
#if CFG_SPI
	/*
     * Add a SPI interface : the handler to access SPI's devices.
     * BCM953001R uses SPI device 0 (SS0) for ROBO devices.
     */
    cfe_add_spi((cfe_spi_t*)&chipc_spi, 0, CC_SPI_SS0);
    /* ROBO devices : The maximum speed of operation is 2 MHz */


    chipc_spi_set_freq(sih, CC_SPI_SS0, 2000000);

#ifdef CFG_ROBO
    cfe_add_device(&spi_robo, 0, 0, 0);
#endif
#endif

    /* Check if this chip is low-cost package (53001) */
    if ((cc = (chipcregs_t *)si_setcoreidx(sih, SI_CC_IDX))) {
        if (R_REG(NULL, &cc->chipstatus) & CHIPSTAT_PO_MASK) {
            /* BCM53001 */
            num_gmac = 1;
        } else {
            /* BCM53003 */
            num_gmac = 2;
        }
    }

    for (unit = 0; unit < num_gmac; unit++) {
        if ((regs = si_setcore(sih, GMAC_CORE_ID, unit))) {
            cfe_add_device(&bcmet, BCM53000_GMAC_ID, unit, regs);
        }
    }

    /* MII interfaces - needed for PHY access outside MAC driver.
     * Must be initialized for the generic UI PHY commands to work. */
    cfe_add_mii(&si_mii, AI_GMACC_BASE, atoi(env_getenv("et0phyaddr")));

#if CFG_PCI
    /* We are a PCI host in a CPCI system.  Most of the supported PCI
       devices are not currently available for CPCI; we link only
       a subset. */
    cpci_add_devices(1);
#endif

#if CFG_SPI
    /*
     * Add a SPI interface : the handler to access SPI's devices.
     * BCM53115 uses SPI device 1 (SS1)
     */
    cfe_add_spi((cfe_spi_t*)&chipc_spi, CC_SPI_SS1, 0);


    /* BCM53115 : The maximum speed of operation is 2 MHz */
    chipc_spi_set_freq(sih, CC_SPI_SS1, 2000000);

#ifdef CFG_ROBO

    /* Add ROBO device */
    cfe_add_device(&spi_robo, 0, 0, 0);

#endif /* CFG_ROBO */

#endif

#if CFG_MDK == 1
    /* Initialize MDK subsystem */
    mdk_sys_init();
#endif

    /* Disable nmi mask */
    if (sih->chiprev != 0) {
        mask = (*(volatile uint32 *)(0xb800302c));
        mask &= ~0x20000000;
        *(volatile uint32 *)(0xb800302c) = mask;
    }
}



/*  *********************************************************************
    *  board_device_reset()
    *  
    *  Reset devices.  This call is done when the firmware is restarted,
    *  as might happen when an operating system exits, just before the
    *  "reset" command is applied to the installed devices.   You can
    *  do whatever board-specific things are here to keep the system
    *  stable, like stopping DMA sources, interrupts, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_reset(void)
{
}

/*  *********************************************************************
    *  board_final_init()
    *  
    *  Do any final initialization, such as adding commands to the
    *  user interface.
    *
    *  If you don't want a user interface, put the startup code here.  
    *  This routine is called just before CFE starts its user interface.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_final_init(void)
{
#if defined(CFG_ROBO) && defined(NTSW_WSS)
    int fh;
    uint16_t phyidl, phyidh,miiaddr;
    uint16_t miireg;
    uint32_t i;
#endif /* defined(CFG_ROBO) && defined(NTSW_WSS) */

#if CFG_UI
    ui_init_bcm953001rcmds();
    ui_init_phycmds();
#if CFG_PTABLE
    ui_init_ptablecmds();
#endif /* CFG_PTABLE */

#if CFG_MDK_DEBUG == 1
    ui_init_mdkcmds();
#endif
    
#if CFG_FULLDIAG
    ui_init_flashtestcmds();
#endif /* CFG_FULLDIAG */

#ifndef NTSW_WSS
    ui_init_toyclockcmds();
    ui_init_vxbootcmds();
#endif

#endif /* CFG_UI */

    board_led_msg("CFE ");
}
