/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Board device initialization
    *  
    *  This is the "C" part of the board support package.  The
    *  routines to create and initialize the console, wire up 
    *  device drivers, and do other customization live here.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "sbmips.h"

#include "env_subr.h"
#include "ptable.h"
#include "cfe_smbus.h"
#include "cfe_mii.h"

#include "sb1250_defs.h"
#include "sb1250_regs.h"
#include "sb1250_scd.h"
#include "sb1250_smbus.h"
#include "sb1250_mac.h"

#include "bcm91125xmc.h"

#include "dev_newflash.h"

#include "cfe_loader.h"
#include "cfe_autoboot.h"

#include "jedec.h"

#if CFG_MDK == 1
#include "mdk_sys.h"
#endif

/*  *********************************************************************
    *  Devices we're importing
    ********************************************************************* */

extern cfe_driver_t sb1250_uart;		/* SB1250 serial ports */
extern cfe_driver_t sb1250_ether;		/* SB1250 MACs */

extern cfe_driver_t newflashdrv;		/* CFI flash */

extern cfe_smbus_t sb1250_smbus;
extern cfe_driver_t smbus_24lc128;		/* Microchip EEPROM */
extern cfe_driver_t smbus_m41t81clock;		/* M41T81 SMBus RTC */
extern cfe_driver_t smbus_pcf8574;		/* PCF8574 */

extern cfe_mii_t sb1250_mii;

/*  *********************************************************************
    *  Commands we're importing
    ********************************************************************* */

extern int ui_init_soccmds(void);
extern int ui_init_testcmds(void);
extern int ui_init_resetcmds(void);
extern int ui_init_phycmds(void);
extern int ui_init_tempsensorcmds(void);
extern int ui_init_toyclockcmds(void);
extern int ui_init_memtestcmds(void);
extern int ui_init_flashtestcmds(void);
extern int ui_init_spdcmds(void);
extern int ui_init_disktestcmds(void);
extern int ui_init_vxbootcmds(void);
extern int ui_init_ptablecmds(void);
#if CFG_MDK_DEBUG == 1
extern int ui_init_mdkcmds(void);
#endif

/*  *********************************************************************
    *  Some other stuff we use
    ********************************************************************* */

extern void sb1250_show_cpu_type(void);
extern int cfe_device_download(int boot, char *options);


/*  *********************************************************************
    *  SysConfig switch settings and related parameters
    ********************************************************************* */

int board_rev;
int config_switch;

#define CONFIG_STARTUP_ENV	       	0x01	/* switch 1 */
#define CONFIG_PCI_INIT			0x02	/* switch 2 */

static int64_t blinky_timer;			/* for blinky */

typedef struct initenv_s {
    const char *name;
    const char *def;
    const char *altname;
} initenv_t;

static const initenv_t bcm91125xmc_envvars[] = {
    {"ETH0_HWADDR","02-10-18-47-04-10","et0macaddr"},
    {"ETH1_HWADDR","02-10-18-47-04-20","et1macaddr"},
    {NULL,NULL}};

/*  *********************************************************************
    *  Partition table support
    ********************************************************************* */

static ptable_t usr_ptbl;

#define PTAB_OFFSET 0xD0000

static int pt_read(ptable_t *ptbl);
static int pt_write(ptable_t *ptbl);

static ptable_drv_t pt_drv = { 
    pt_read, 
    pt_write 
};

static int
pt_read(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
	return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_readblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}

static int
pt_write(ptable_t *ptbl)
{
    int fh, res;

    if ((fh = cfe_open("flash0.boot")) < 0) {
	return CFE_ERR_DEVNOTFOUND;
        }
    res = cfe_writeblk(fh, PTAB_OFFSET, PTR2HSADDR(ptbl), sizeof(ptable_t));
    cfe_close(fh);
    return (res == sizeof(ptable_t)) ? 0 : CFE_ERR_IOERR;
}

static int
user_parts(ptable_t *ptbl, newflash_probe_t *fprobe)
{
    newflash_part_t *fp = fprobe->flash_parts;
    partition_t *up = ptbl->part;
    int i, top = 0, uparts = 0;

    /* Check partition table */
    if (usr_ptbl.magic != PTABLE_MAGIC || ptable_check(&usr_ptbl) < 0) {
        return 0;
        }
    /* Add partitions */
    for (i = 0; i < PTABLE_MAX_PARTITIONS && up[i].size; i++) {
        if (top + up[i].size > fprobe->flash_size) break;
        /* Check for holes in partition map */
        if (up[i].offset > top) {
            fp[uparts].fp_size = top ? 0 : up[i].offset - top;
            fp[uparts].fp_name = top ? "unused" : "boot";
            if (++uparts >= FLASH_MAX_PARTITIONS) break;
            }
        fp[uparts].fp_size = up[i].size;
        fp[uparts].fp_name = up[i].name;
        if (++uparts >= FLASH_MAX_PARTITIONS) break;
        top = up[i].offset + up[i].size;
    }
    return uparts;
}

static int board_id_get(unsigned int *board_id)
{
    int fh, res;
    uint8_t buf[1];

    if ((fh = cfe_open("BoardId0")) < 0) {
	return CFE_ERR_DEVNOTFOUND;
    }
    res = cfe_read(fh,PTR2HSADDR(buf),1);
    *board_id = (unsigned int)buf[0];
    cfe_close(fh);
    return res;
}

/*  *********************************************************************
    *  board_console_init()
    *  
    *  Add the console device and set it to be the primary
    *  console.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_console_init(void)
{
    uint64_t syscfg = SBREADCSR(A_SCD_SYSTEM_CFG);

    /* Console */
    cfe_add_device(&sb1250_uart,A_DUART,0,0);
    cfe_add_device(&sb1250_uart,A_DUART,1,0);

    /* 
     * Fill in board_rev, config_switch
     */
    board_rev = (G_SYS_CONFIG(syscfg) & 3);
    config_switch = (G_SYS_CONFIG(syscfg) >> 2) & 0x0f;

    config_switch = 3;          /* For Backward Compatibility */

    cfe_startflags = 0;
    if (config_switch & CONFIG_PCI_INIT) {
	cfe_startflags = CFE_INIT_PCI;
    }

    cfe_set_console("uart0");

    /*
     * SMBus buses - need to be initialized before we attach
     * devices that use them.
     */

    cfe_add_smbus(&sb1250_smbus,A_SMB_BASE(0),0);
    cfe_add_smbus(&sb1250_smbus,A_SMB_BASE(1),0);
     
    /* 
     * NVRAM (environment variables)
     */

    cfe_add_device(&smbus_24lc128,EEPROM0_SMBUS_CHAN,EEPROM0_SMBUS_DEV,0);
    cfe_add_device(&smbus_24lc128,EEPROM1_SMBUS_CHAN,EEPROM1_SMBUS_DEV,0);
    cfe_set_envdevice("eeprom0");	/* Connect NVRAM to 2nd 24lc128 */

}

/*  *********************************************************************
    *  bcm91125xmc_initenv()
    *  
    *  Initialize default environment variables.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void bcm91125xmc_initenv(void)
{
    const initenv_t *ini;
    char *txt;

    ini = bcm91125xmc_envvars;

    /* Assign either the forced value, or the value
       of another environment variable if the name starts
       with a dollar sign.  If that name is not defined
       either, then use the default from the table. */

    while (ini->name) {
        txt = NULL;
        if (ini->altname) txt = env_getenv(ini->altname);
        if (!txt) txt = (char *) ini->def;
	if (txt) {
	    if (!env_getenv(ini->name)) {
		env_setenv(ini->name,txt,ENV_FLG_BUILTIN);
            }
        }
	ini++;
    }

}

/*  *********************************************************************
    *  board_device_init()
    *  
    *  Initialize and add other devices.  Add everything you need
    *  for bootstrap here, like disk drives, flash memory, UARTs,
    *  network controllers, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_device_init(void)
{
    uint64_t gpio;
    newflash_probe_t fprobe;
    int plcc;
    unsigned int board_id =0xFF;

    bcm91125xmc_initenv();

    /*
     * Board ID
     */
    cfe_add_device(&smbus_pcf8574,PCF8574_SMBUS_CHAN,PCF8574_SMBUS_DEV,0);
    board_id_get(&board_id);

    /*
     * Print out the board version number.
     */
    printf("%s board revision %d Board Id: 0x%02X\n", CFG_BOARDNAME,board_rev,
            board_id);

    /*
     * Sense the GPIO pin to configure the
     * flash or PLCC as flash0, so we can program either in place.
     */

    gpio = SBREADCSR(A_GPIO_READ);

    /* 
     * Primary flash (Boot ROM)  (128MB), using "new" flash driver.
     * Partition the flash.
     *
     * Partitions are as follows:
     *
     *  Primary view:
     *	1MB   - "boot"	CFE
     *  127MB - "os"	VxWorks image
     *
     *  Alternate flash
     *	1MB   - "boot"	CFE
     *  127MB - "os"	Linux image
     */

    ptable_init(&pt_drv);

    plcc = (gpio & M_GPIO_BOOT_MODE) ? 0 : 1;

    /* Primary view */
    memset(&fprobe,0,sizeof(fprobe));
    fprobe.flash_phys = BOOTROM_PHYS;
    fprobe.flash_size = BCM91125_FLASH_SIZE;
    fprobe.flash_flags = (FLASH_FLG_BUS16 | FLASH_FLG_DEV16 | FLASH_FLG_MANUAL);
    fprobe.flash_type = FLASH_TYPE_FLASH;
    fprobe.flash_cmdset = FLASH_CFI_CMDSET_AMD_STD;
    fprobe.flash_nsectors = 1;
    fprobe.flash_sectors[0] = FLASH_SECTOR_RANGE(1024, 131072);
    fprobe.flash_ioctl_hook = 0;
    fprobe.flash_engine_hook = 0;
    fprobe.flash_nchips = 1;
    fprobe.flash_nparts = 2;
    fprobe.flash_parts[0].fp_size = BOOT_PARTITION_SIZE;
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[1].fp_size = BCM91125_FLASH_SIZE -  BOOT_PARTITION_SIZE;
    fprobe.flash_parts[1].fp_name = "os";
    cfe_add_device(&newflashdrv,0,0,&fprobe);

    fprobe.flash_phys = ALT_BOOTROM_PHYS;
    cfe_add_device(&newflashdrv,0,0,&fprobe);

    fprobe.flash_phys = BOOTROM_PHYS;
    fprobe.flash_nparts = 0;
    cfe_add_device(&newflashdrv,0,0,&fprobe);	/* flash2 */

    fprobe.flash_phys = ALT_BOOTROM_PHYS;
    cfe_add_device(&newflashdrv,0,0,&fprobe);   /* flash3 */

    /* User-defined partitions */
    if (pt_read(&usr_ptbl) == 0 && 
        (fprobe.flash_nparts = user_parts(&usr_ptbl, &fprobe)) > 0) {
        cfe_add_device(&newflashdrv,0,0,&fprobe); /* flash3 */
     }

    /*
     * MII interfaces - needed for PHY access outside MAC driver.
     * Must be initialized for the generic UI PHY commands to work.
     */

    cfe_add_mii(&sb1250_mii,A_MAC_BASE_0,1);
    cfe_add_mii(&sb1250_mii,A_MAC_BASE_1,1);

    /* 
     * MACs - must init after environment, since the hw address is stored there.
     *
     */
    cfe_add_device(&sb1250_ether,A_MAC_BASE_0,0,env_getenv("ETH0_HWADDR"));
    cfe_add_device(&sb1250_ether,A_MAC_BASE_1,0,env_getenv("ETH1_HWADDR"));

    /*
     * Reset the MAC address for MAC 1, since it's not hooked up to anything.
     * This prevents the OS from probing it.
     * SBWRITECSR(A_MAC_REGISTER(1,R_MAC_ETHERNET_ADDR),0);
     */

#if CFG_MDK == 1
    /* Initialize MDK subsystem */
    mdk_sys_init();
#endif

    /*
     * Real-time clock 
     */
    cfe_add_device(&smbus_m41t81clock,M41T81_SMBUS_CHAN,M41T81_SMBUS_DEV,0);

    /*
     * Set variable that contains CPU speed, spit out config register
     */

    printf("Config switch: %d\n", config_switch);

    sb1250_show_cpu_type();

}



/*  *********************************************************************
    *  board_device_reset()
    *  
    *  Reset devices.  This call is done when the firmware is restarted,
    *  as might happen when an operating system exits, just before the
    *  "reset" command is applied to the installed devices.   You can
    *  do whatever board-specific things are here to keep the system
    *  stable, like stopping DMA sources, interrupts, etc.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_reset(void)
{
    /*Nothing to do. */
}


/*  *********************************************************************
    *  board_blinkylight(arg)
    *  
    *  Blink the LED once per second
    *  
    *  Input parameters: 
    *  	   arg - not used
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

static void board_blinkylight(void *arg)
{
    static int light = 0;
    intptr_t reg;

    if (TIMER_EXPIRED(blinky_timer)) {
	light = !light;
	reg = light ? A_GPIO_PIN_SET : A_GPIO_PIN_CLR;
	SBWRITECSR(reg,M_GPIO_DEBUG_LED);
	TIMER_SET(blinky_timer,CFE_HZ);
	}
}


/*  *********************************************************************
    *  board_setup_autoboot()
    *  
    *  Set up autoboot methods.  This routine sets up the list of 
    *  places to find a boot program.
    *  
    *  Input parameters: 
    *  	   nothing
    *  
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void board_setup_autoboot(void)
{
    /*
     * If you had partitioned your flash, you could boot from it like this:
     */

    cfe_add_autoboot(CFE_AUTOBOOT_RAW,0,"flash0.os","elf","raw",NULL);

    /*
     * Now try running a script (file containing CFE commands) from
     * the TFTP server.   Your DHCP server must set option 130
     * to contain the name of the script.  Option 130 gets stored
     * in "BOOT_SCRIPT" when a DHCP reply is received.
     */

    cfe_add_autoboot(CFE_AUTOBOOT_NETWORK,LOADFLG_BATCH,
		     "eth0","raw","tftp","$BOOT_SERVER:$BOOT_SCRIPT");

    /*
     * Finally, try loading whatever the DHCP server says is the boot
     * program.  Do this as an ELF file, and failing that, try a
     * raw binary.
     */

    cfe_add_autoboot(CFE_AUTOBOOT_NETWORK,0,"eth0","elf","tftp",NULL);
    cfe_add_autoboot(CFE_AUTOBOOT_NETWORK,0,"eth0","raw","tftp",NULL);

}

/*  *********************************************************************
    *  board_final_init()
    *  
    *  Do any final initialization, such as adding commands to the
    *  user interface.
    *
    *  If you don't want a user interface, put the startup code here.  
    *  This routine is called just before CFE starts its user interface.
    *  
    *  Input parameters: 
    *  	   nothing
    *  	   
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_final_init(void)
{

    int flag;

    ui_init_soccmds();
    ui_init_resetcmds();
    ui_init_tempsensorcmds();
    ui_init_toyclockcmds();
    ui_init_memtestcmds();
    ui_init_phycmds();
    ui_init_flashtestcmds();
    ui_init_spdcmds();
    ui_init_disktestcmds();
    ui_init_vxbootcmds();
    ui_init_ptablecmds();
    ui_init_testcmds();
#if CFG_MDK_DEBUG == 1
    ui_init_mdkcmds();
#endif

    cfe_bg_add(board_blinkylight,NULL);
    TIMER_SET(blinky_timer,CFE_HZ);
    
    board_setup_autoboot();

    if (config_switch & CONFIG_STARTUP_ENV) {
	/* Change STARTUP's flags so it can run or error message if not set */
	if (env_getenv("STARTUP") == NULL) {
	    printf("*** STARTUP environment variable not set.\n\n");
	}
	else {
	    flag = env_envtype("STARTUP");
	    flag &= ~ENV_FLG_STARTUP_NORUN;
	    env_setflags("STARTUP",flag);
	    }
	}
    else {
	if (env_getenv("STARTUP") != NULL) {
	    /* Don't run the commands in STARTUP */
	    flag = env_envtype("STARTUP");
	    flag |= ENV_FLG_STARTUP_NORUN;
	    env_setflags("STARTUP",flag);
	    }
	}

    /* Do a clean reset when Linux exits to CFE */
    if (env_getenv("RESTART") == NULL) {
        env_setenv("RESTART", "reset -sysreset -yes", ENV_FLG_BUILTIN);
        }
}
