/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM956224 board-specific definitions       
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef __BCM956224_H
#define __BCM956224_H
/* Macros */

#define KB 1024
#define MB (1024*1024)

/*
 * Put board-specific stuff here
 */
#define BCM956224_NVRAM_SIZE            0x8000

/* Internal NS16550-compatible dual UART */
#define BCM956224_COM1   BCM56XXX_UART0       /* console, DB-9 */
#define BCM956224_COM2   BCM56XXX_UART1       /* header */

#endif /* ! __BCM956224_H */
