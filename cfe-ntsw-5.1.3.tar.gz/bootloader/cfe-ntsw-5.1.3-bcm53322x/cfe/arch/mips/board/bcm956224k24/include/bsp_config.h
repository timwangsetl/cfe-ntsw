/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BSP Configuration file			File: bsp_config.h
    *  
    *  This module contains global parameters and conditional
    *  compilation settings for building CFE.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */
#define CFG_INIT_L1		1	/* initialize the L1 cache */
#define CFG_INIT_L2		0	/* there is no L2 cache */

#define CFG_INIT_DRAM		1	/* initialize DRAM controller */
#define CFG_DRAM_SIZE		xxx	/* size of DRAM if you don't initialize */


#define CFG_VENDOR_EXTENSIONS   0


/*
 * These parameters control the flash driver's sector buffer.  
 * If you write environment variables or make small changes to
 * flash sectors from user applications, you
 * need to have the heap big enough to store a temporary sector
 * for merging in small changes to flash sectors, so you
 * should set CFG_FLASH_ALLOC_SECTOR_BUFFER in that case.
 * Otherwise, you can provide an address in unallocated memory
 * of where to place the sector buffer.
 */
/* '1' to allocate sector buffer from the heap */
#define CFG_FLASH_ALLOC_SECTOR_BUFFER 0	
#define CFG_FLASH_SECTOR_BUFFER_ADDR  (1*1024*1024-128*1024) /* 1MB - 128K */
#define CFG_FLASH_SECTOR_BUFFER_SIZE  (128*1024)

/*
 * The flash staging buffer is where we store a flash image before we write
 * it to the flash.  It's too big for the heap.
 */

#define CFG_FLASH_STAGING_BUFFER_ADDR (16*1024*1024)
#define CFG_FLASH_STAGING_BUFFER_SIZE (32*1024*1024)


#ifndef CFG_SERIAL_BAUD_RATE
#define CFG_SERIAL_BAUD_RATE	9600	/* normal console speed */
#endif

#define CFG_UI			1	/* Define to enable user interface */
#define CFG_MULTI_CPUS		0	/* no multi-cpu support */

#define CFG_SERIAL_LEDS   0	/* never set this (UART can hang) */
#define CFG_HEAP_SIZE	        1024    /* heap size in kilobytes */
#define CFG_STACK_SIZE	        8192	/* stack size (bytes, rounded up to K) */


/************* Robo/NTSW specific features *******/
#ifdef NTSW_WSS
#define CFG_NETWORK	    1	/* define to include network support */
#define CFG_TCP		    1
#define CFG_TCP_NEW         1
#define CFG_HTTPD           1
#define CFG_HTTPFS	    0
#define CFG_FATFS           0
#define CFG_URLS	    0
#define CFG_PTABLE          0
#define CFG_BOARD_ENV       1

#define CFG_NVRAM_SIZE      0x20000
#define CFG_FULLDIAG        0   /* 1: Enable unnecessary debugging functions */ 

#define CFG_NO_SREC_LOADER      1
#define CFG_NO_UBOOT_LOADER     1
#define CFG_NO_MISC_UI          1
#define CFG_NO_DISASM_UI        1

#else /* !NTSW_WSS */
#define CFG_PTABLE          1
#define CFG_TCP_NEW         0
#define CFG_FULLDIAG        1

#ifdef QUICK_TURN
#define CFG_NETWORK	0   /* define to include network support */
#define CFG_FATFS       0
#define CFG_TCP		0
#define CFG_HTTPFS	0
#define CFG_URLS	0

#else

#define CFG_NETWORK	1	/* define to include network support */
#define CFG_FATFS       1
#define CFG_TCP		1
#define CFG_HTTPFS	1
#define CFG_URLS	1

#endif  /* QUICK_TURN */
#endif  /* NTSW_WSS */

#define DIRECT_BOOT_PARTITION               "flash0.os"
#define DIRECT_BOOT_COMPRESSED              1

#define FAILSAVE_NET_DEVNAME                "eth0"
#define FAILSAVE_NET_DHCP                   0       /* Only for !CFG_UI */
#define FAILSAVE_NET_DHCP_RETRIES           5       /* Only for !CFG_UI */
#define FAILSAVE_NET_DHCP_FALLBACK          1       /* Only for CFG_UI */
#define FAILSAVE_NET_IPADDR                 "192.168.0.234"
#define FAILSAVE_NET_NETMASK                "255.255.255.0"
#define FAILSAVE_NET_GATEWAY                "192.168.0.1"

#if NTSW_WSS && CFG_RELEASE_STAGE
#undef CFG_UI
#define CFG_UI              0
#define CFG_BOARD_APP       1
#define CFG_NO_RAW_LOADER   1
#endif /* NTSW_WSS && CFG_RELEASE_STAGE */

/* Board specific defines. */


/*
 *  memory configuration
 */

/* 32M x 16 x 2 DDR - 128MB RAM */

#define MEMDDR

#if defined(QUICK_TURN)
#define DDRM16X16X1
#else
/* 64M x 16 x 1 DDR - 128MB RAM */
#define DDRM32X16X1
#endif

/* 32M x 16 x 1 SDR - 64MB RAM */
#define MEMSDR
#define SDRM32X16X1
#define SDRAM_INIT   0x0011



/*
 * Include chip- and board-specific stuff
 */

#include "bcm56xxx.h"
#include "bcm956224.h"

