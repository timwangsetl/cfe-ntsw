#if !defined(_BCM9MCXX_VERSION_H_)
#define _BCM9MCXX_VERSION_H_
/*  *********************************************************************
    *  SB1125 Board Support Package
    *
    *  BCM9MC-XX (MetroCore) Definitions   File: bcm9mcxx_vesion.h
    *
    *  Local version information for bcm9mcxx cfe code.
    *
    *  Author:  Travis B. Sawyer
    *
    *********************************************************************
    *
    *  Copyright 2006
    *  Broadcom Corporation. All rights reserved.
    *
    *  This software is furnished under license and may be used and
    *  copied only in accordance with the following terms and
    *  conditions.  Subject to these conditions, you may download,
    *  copy, install, use, modify and distribute modified or unmodified
    *  copies of this software in source and/or binary form.  No title
    *  or ownership is transferred hereby.
    *
    *  1) Any source code used, modified or distributed must reproduce
    *     and retain this copyright notice and list of conditions
    *     as they appear in the source file.
    *
    *  2) No right is granted to use any trade name, trademark, or
    *     logo of Broadcom Corporation.  The "Broadcom Corporation"
    *     name may not be used to endorse or promote products derived
    *     from this software without the prior written permission of
    *     Broadcom Corporation.
    *
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */
#define bcm9mcxx_version "0.2.5"
#define bcm9mcxx_date "$Date: 2007/08/22 18:20:08 $"

/*  
 *  CVS_TAG                bcm9mcxx_version   Features
 * -----------------------------------------------------------------------------------
 * BRCM_NTSW_CFE_04_20_2007     0.2.1         Turn Clock on while in CFE
 *                                            Add fpga diag,led diag, flash diag,
 *                                            REGRESS env to run some diags at once.
 *
 * BRCM_NTSW_CFE_05_02_2007     0.2.2         Change serial baud rate to 9600.
 *
 * BRCM_NTSW_CFE_08_20_2007     0.2.3         Re-arrange flash0 sectors to make
 *                                            room (> 14MB) for ramdisk image.
 *
 * BRCM_NTSW_CFE_08_21_2007     0.2.4         Added dd and ee ui commands.
 *
 * BRCM_NTSW_CFE_08_22_2007     0.2.5         Disable LED diag output at serial port
 */

#endif
