#if !defined(_BCM9MCXX_H_)
#define _BCM9MCXX_H_
/*  *********************************************************************
    *  SB1125 Board Support Package
    *
    *  BCM9MC-XX (MetroCore) Definitions   File: bcm9mcxx.h
    *
    *  This file contains I/O, chip select, and GPIO assignments
    *  for the MetroCore based boards.
    *
    *  Author:  Travis B. Sawyer
    *
    *********************************************************************
    *
    *  Copyright 2006
    *  Broadcom Corporation. All rights reserved.
    *
    *  This software is furnished under license and may be used and
    *  copied only in accordance with the following terms and
    *  conditions.  Subject to these conditions, you may download,
    *  copy, install, use, modify and distribute modified or unmodified
    *  copies of this software in source and/or binary form.  No title
    *  or ownership is transferred hereby.
    *
    *  1) Any source code used, modified or distributed must reproduce
    *     and retain this copyright notice and list of conditions
    *     as they appear in the source file.
    *
    *  2) No right is granted to use any trade name, trademark, or
    *     logo of Broadcom Corporation.  The "Broadcom Corporation"
    *     name may not be used to endorse or promote products derived
    *     from this software without the prior written permission of
    *     Broadcom Corporation.
    *
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


/*
 * I/O Address assignments for the MetroCore XX board
 *
 * Note:  At the time of writing it is planned that all MC chassis boards will
 * have the same CPU 'corner'.  Only the pci devices and generic bus
 * devices will change.  Have no fear, though, most of the chip selects are
 * passed through the FPGA.  For the most part, the fpga handles the addr/data
 * demuxing.
 *
 *
 * Summary of address map:
 *
 * Address         Size   CSel    Description
 * --------------- ----   ------  --------------------------------
 * 0x1FC00000      1/2MB   CS0    Boot ROM            AM29LV040B (PLCC)
 * 0x1EC00000      16MB    CS1    Alternate boot ROM  28F128J3C
 * 0x10090000      64KB    CS2    SD card
 * 0x100A0000      64KB    CS3    i2c Bus Master      Philips PCA9564D
 * 0x100B0000      64KB    CS4    LED display
 * 0x100C0000      64KB    CS5    BME 3200
 * 0x100D0000      64KB    CS6    SE  3200
 * 0x100E0000      64KB    CS7    FPGA
 *
 * GPIO assignments
 *
 * GPIO#    Direction   Description
 * -------  ---------   ------------------------------------------
 * GPIO0    Output      SW LED
 * GPIO1    Input       Boot Mode
 * GPIO2    Input       NMI Interrupt            (interrupt)
 * GPIO3    Input       RTC Interrupt            (interrupt)
 * GPIO4    Input       PHY 0 Interrupt          (interrupt)
 * GPIO5    Input       FPGA                     (interrupt)
 * GPIO6    Input       Fan Interrupt            (interrupt)
 * GPIO7    Input       Sense Interrupt          (interrupt)
 * GPIO8    Input       SFM Interrupt            (interrupt)
 * GPIO9    Input       LC3 Interrupt            (interrupt)
 * GPIO10   Input       LC2 Interrupt            (interrupt)
 * GPIO11   Input       LC1 Interrupt            (interrupt)
 * GPIO12   Input       LC0 Interrupt            (interrupt)
 * GPIO13   Output      Debug LED
 * GPIO14   Output      Debug LED
 * GPIO15   Output      Debug LED
 */

/*  *********************************************************************
    *  Macros
    ********************************************************************* */

#define MB (1024*1024)
#define K64 65536
#define __KB (1024)
#define NUM64K(x) (((x)+(K64-1))/K64)


/*  *********************************************************************
    *  GPIO pins
    ********************************************************************* */

#define GPIO_SW_LED             0
#define GPIO_BOOT_MODE          1
#define GPIO_NONMASKABLE_INT    2
#define GPIO_RTC_INTERRUPT      3
#define GPIO_PHY_INTERRUPT      4
#define GPIO_FPGA_INTERRUPT     5
#define GPIO_FAN_INTERRUPT      6
#define GPIO_SENSE_INTERRUPT    7
#define GPIO_SFM_INTERRUPT      8
#define GPIO_LC3_INTERRUPT      9
#define GPIO_LC2_INTERRUPT      10
#define GPIO_LC1_INTERRUPT      11
#define GPIO_LC0_INTERRUPT      12
#define GPIO_DEBUG_LED_0        13
#define GPIO_DEBUG_LED_1        14
#define GPIO_DEBUG_LED_2        15

#define M_GPIO_BOOT_MODE        _SB_MAKEMASK1(GPIO_BOOT_MODE)
#define M_GPIO_SW_LED           _SB_MAKEMASK1(GPIO_SW_LED)
#define M_GPIO_DEBUG_LED_0      _SB_MAKEMASK1(GPIO_DEBUG_LED_0)
#define M_GPIO_DEBUG_LED_1      _SB_MAKEMASK1(GPIO_DEBUG_LED_1)
#define M_GPIO_DEBUG_LED_2      _SB_MAKEMASK1(GPIO_DEBUG_LED_2)


#define M_GPIO_NONMASKABLE_INT    _SB_MAKEMASK1(GPIO_NONMASKABLE_INT )
#define M_GPIO_RTC_INTERRUPT      _SB_MAKEMASK1(GPIO_RTC_INTERRUPT   )
#define M_GPIO_PHY_INTERRUPT      _SB_MAKEMASK1(GPIO_PHY_INTERRUPT   )
#define M_GPIO_FPGA_INTERRUPT     _SB_MAKEMASK1(GPIO_FPGA_INTERRUPT  )
#define M_GPIO_FAN_INTERRUPT      _SB_MAKEMASK1(GPIO_FAN_INTERRUPT   )
#define M_GPIO_SENSE_INTERRUPT    _SB_MAKEMASK1(GPIO_SENSE_INTERRUPT )
#define M_GPIO_SFM_INTERRUPT      _SB_MAKEMASK1(GPIO_SFM_INTERRUPT   )
#define M_GPIO_LC3_INTERRUPT      _SB_MAKEMASK1(GPIO_LC3_INTERRUPT   )
#define M_GPIO_LC2_INTERRUPT      _SB_MAKEMASK1(GPIO_LC2_INTERRUPT   )
#define M_GPIO_LC1_INTERRUPT      _SB_MAKEMASK1(GPIO_LC1_INTERRUPT   )
#define M_GPIO_LC0_INTERRUPT      _SB_MAKEMASK1(GPIO_LC0_INTERRUPT   )



#define GPIO_OUTPUT_MASK (M_GPIO_SW_LED | M_GPIO_DEBUG_LED_0 | \
                          M_GPIO_DEBUG_LED_1 | M_GPIO_DEBUG_LED_2)
#define GPIO_DEBUG_LED_MASK (M_GPIO_DEBUG_LED_0 | \
                          M_GPIO_DEBUG_LED_1 | M_GPIO_DEBUG_LED_2)

#define GPIO_INTERRUPT_MASK ((V_GPIO_INTR_TYPEX(GPIO_NONMASKABLE_INT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_RTC_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_PHY_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_FPGA_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_FAN_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_SENSE_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_SFM_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_LC3_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_LC2_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_LC1_INTERRUPT,K_GPIO_INTR_LEVEL)) | \
                             (V_GPIO_INTR_TYPEX(GPIO_LC0_INTERRUPT,K_GPIO_INTR_LEVEL)))

#define GPIO_INT_INVERT_MASK ( M_GPIO_NONMASKABLE_INT | \
                               M_GPIO_PHY_INTERRUPT   | \
                               M_GPIO_FPGA_INTERRUPT  | \
                               M_GPIO_FAN_INTERRUPT   | \
                               M_GPIO_SENSE_INTERRUPT | \
                               M_GPIO_SFM_INTERRUPT   | \
                               M_GPIO_LC3_INTERRUPT   | \
                               M_GPIO_LC2_INTERRUPT   | \
                               M_GPIO_LC1_INTERRUPT   | \
                               M_GPIO_LC0_INTERRUPT)


/*  *********************************************************************
    *  Generic Bus
    ********************************************************************* */

/*
 * Boot ROM:  non-multiplexed, byte width, no parity, no ack
 * XXX: These are the (very slow) default parameters.   This can be sped up!
 */
#define BOOTROM_CS              0
#define BOOTROM_PHYS            0x1FC00000      /* address of boot ROM (CS0) */
#define BOOTROM_SIZE            NUM64K(MB/2)    /* size of boot ROM */
#define BOOTROM_TIMING0         V_IO_ALE_WIDTH(4) | \
                                V_IO_ALE_TO_CS(2) | \
                                V_IO_CS_WIDTH(24) | \
                                V_IO_RDY_SMPLE(1)
#define BOOTROM_TIMING1         V_IO_ALE_TO_WRITE(7) | \
                                V_IO_WRITE_WIDTH(7) | \
                                V_IO_IDLE_CYCLE(6) | \
                                V_IO_CS_TO_OE(0) | \
                                V_IO_OE_TO_CS(0)
#define BOOTROM_CONFIG          V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_1) | M_IO_NONMUX

/*
 * Strata Flash:  non-multiplexed, byte width, no parity, no ack
 * XXX: These are the (very slow) default parameters.   This can be sped up!
 */
#define ISTRATA_CS              1
#define ISTRATA_PHYS            0x1EC00000      /* address of alternate boot ROM (CS1) */
#define ISTRATA_SIZE            NUM64K(16*MB)    /* size of alternate boot ROM */
#define ISTRATA_TIMING0         V_IO_ALE_WIDTH(4) | \
                                V_IO_ALE_TO_CS(2) | \
                                V_IO_CS_WIDTH(24) | \
                                V_IO_RDY_SMPLE(1)
#define ISTRATA_TIMING1         V_IO_ALE_TO_WRITE(7) | \
                                V_IO_WRITE_WIDTH(7) | \
                                V_IO_IDLE_CYCLE(6) | \
                                V_IO_CS_TO_OE(0) | \
                                V_IO_OE_TO_CS(0)
#define ISTRATA_CONFIG          V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_1) | M_IO_NONMUX

/*
 * SDCard:  non-multiplexed, byte width, no parity, no ack
 */
#define SDCARD_CS               2
#define SDCARD_PHYS             0x10090000
#define SDCARD_SIZE             NUM64K(1)
#define SDCARD_TIMING0          V_IO_ALE_WIDTH(4) | \
                                M_IO_EARLY_CS | \
                                V_IO_ALE_TO_CS(2) | \
                                V_IO_CS_WIDTH(13) | \
                                V_IO_RDY_SMPLE(4)
#define SDCARD_TIMING1          V_IO_ALE_TO_WRITE(4) | \
                                V_IO_WRITE_WIDTH(8) | \
                                V_IO_IDLE_CYCLE(0xF) | \
                                V_IO_CS_TO_OE(0) | \
                                V_IO_OE_TO_CS(4)
#define SDCARD_CONFIG           V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_4) | M_IO_ENA_RDY | \
                                V_IO_TIMEOUT(8)

/*
 * I2C Bus Master:  non-multiplexed, byte width, no parity, no ack
 */
#define I2C_CS                 3
#define I2C_PHYS               0x100A0000
#define I2C_SIZE               NUM64K(1)
#define I2C_TIMING0            V_IO_ALE_WIDTH(4) | \
                               M_IO_EARLY_CS | \
                               V_IO_ALE_TO_CS(2) | \
                               V_IO_CS_WIDTH(6)

#define I2C_TIMING1            V_IO_ALE_TO_WRITE(2) | \
                               V_IO_WRITE_WIDTH(4) | \
                               V_IO_IDLE_CYCLE(6) | \
                               V_IO_CS_TO_OE(0) | \
                               V_IO_OE_TO_CS(0)
#define I2C_CONFIG             V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_1) | M_IO_NONMUX


/*
 * 4 Digit Display/MACs:  non-multiplexed, byte width, no parity, no ack
 */
#define LEDS_CS                 4
#define LEDS_PHYS               0x100B0000
#define LEDS_SIZE               NUM64K(1)
#define LEDS_TIMING0            V_IO_ALE_WIDTH(4) | \
                                V_IO_ALE_TO_CS(2) | \
                                V_IO_CS_WIDTH(13) | \
                                V_IO_RDY_SMPLE(1)
#define LEDS_TIMING1            V_IO_ALE_TO_WRITE(2) | \
                                V_IO_WRITE_WIDTH(8) | \
                                V_IO_IDLE_CYCLE(6) | \
                                V_IO_CS_TO_OE(0) | \
                                V_IO_OE_TO_CS(0)
#define LEDS_CONFIG             V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_1) | M_IO_NONMUX

#define MACS_CS                 4
#define MACS_PHYS               0x100B0000
#define MACS_SIZE               NUM64K(1)
#define MACS_TIMING0            V_IO_ALE_WIDTH(6) | \
                                M_IO_EARLY_CS | \
                                V_IO_ALE_TO_CS(2) | \
                                V_IO_CS_WIDTH(13) | \
                                V_IO_RDY_SMPLE(4)
#define MACS_TIMING1            V_IO_ALE_TO_WRITE(0) | \
                                V_IO_WRITE_WIDTH(8) | \
                                V_IO_IDLE_CYCLE(0xF) | \
                                V_IO_CS_TO_OE(0) | \
                                V_IO_OE_TO_CS(0)
#define MACS_CONFIG             V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_4) | M_IO_ENA_RDY | \
                                V_IO_TIMEOUT(0x80)



/*
 * BME3200:  non-multiplexed, byte width, no parity, no ack
 * NOTE: Only on SFM type boards.  Bad addr on other boards should be swallowed
 * NOTE: by the fgpa
 */
#define BME_CS                 5
#define BME_PHYS               0x100C0000
#define BME_SIZE               NUM64K(1)
#define BME_TIMING0            V_IO_ALE_WIDTH(4) | \
                               M_IO_EARLY_CS | \
                               V_IO_ALE_TO_CS(2) | \
                               V_IO_CS_WIDTH(13) | \
                               V_IO_RDY_SMPLE(4)
#define BME_TIMING1            V_IO_ALE_TO_WRITE(4) | \
                               V_IO_WRITE_WIDTH(8) | \
                               V_IO_IDLE_CYCLE(0xF) | \
                               V_IO_CS_TO_OE(0) | \
                               V_IO_OE_TO_CS(4)
#define BME_CONFIG             V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_4) | M_IO_ENA_RDY | \
                               V_IO_TIMEOUT(8)

/*
 * SE3200:  non-multiplexed, byte width, no parity, no ack
 * NOTE: Only on SFM type boards.  Bad addr on other boards should be swallowed
 * NOTE: by the fgpa
 */
#define SE_CS                 6
#define SE_PHYS               0x100D0000
#define SE_SIZE               NUM64K(1)
#define SE_TIMING0            V_IO_ALE_WIDTH(4) | \
                              M_IO_EARLY_CS | \
                              V_IO_ALE_TO_CS(2) | \
                              V_IO_CS_WIDTH(13) | \
                              V_IO_RDY_SMPLE(4)
#define SE_TIMING1            V_IO_ALE_TO_WRITE(4) | \
                              V_IO_WRITE_WIDTH(8) | \
                              V_IO_IDLE_CYCLE(0xF) | \
                              V_IO_CS_TO_OE(0) | \
                              V_IO_OE_TO_CS(0)
#define SE_CONFIG             V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_4) | M_IO_ENA_RDY | \
                              V_IO_TIMEOUT(8)

/*
 * FPGA:  non-multiplexed, byte width, no parity, no ack
 */
#define FPGA_CS                 7
#define FPGA_PHYS               0x100E0000
#define FPGA_SIZE               NUM64K(1)
#define FPGA_TIMING0            V_IO_ALE_WIDTH(4) | \
                                V_IO_ALE_TO_CS(2) | \
                                V_IO_CS_WIDTH(13) | \
                                V_IO_RDY_SMPLE(1)
#define FPGA_TIMING1            V_IO_ALE_TO_WRITE(2) | \
                                V_IO_WRITE_WIDTH(8) | \
                                V_IO_IDLE_CYCLE(6) | \
                                V_IO_CS_TO_OE(0) | \
                                V_IO_OE_TO_CS(3)
#define FPGA_CONFIG             V_IO_WIDTH_SEL(K_IO_WIDTH_SEL_1) | M_IO_NONMUX



/*  *********************************************************************
    *  SMBus Devices
    ********************************************************************* */
#define SPDEEPROM_SMBUS_CHAN    1
#define SPDEEPROM_SMBUS_DEV     0x54
#define DRAM_SMBUS_CHAN         SPDEEPROM_SMBUS_CHAN
#define DRAM_SMBUS_DEV          SPDEEPROM_SMBUS_DEV


#define EEPROM_SMBUS_CHAN       0
#define EEPROM_SMBUS_DEV        0x56
#define EEPROM_LC_SMBUS_DEV_BASE  0x50

#define M41T81_SMBUS_CHAN       1
#define M41T81_SMBUS_DEV        0x68

#define MAX6654_SMBUS_CHAN      1
#define MAX6654_SMBUS_DEV       0x2a
#define TEMPSENSOR_SMBUS_DEV    MAX6654_SMBUS_DEV
#define TEMPSENSOR_SMBUS_CHAN   MAX6654_SMBUS_CHAN

#define PCA9548_SMBUS_CHAN      1
#define PCA9548_SMBUS_DEV       0x73
#define PCA9548_SMBUS_SUBCHAN_MAX       8

#define MAX6653_SMBUS_DEV       0x2e


/*  *********************************************************************
    *  Board Serial Number to 'Name' structure
    ********************************************************************* */
#define BCM9MCXX_BRD_EEP_SIZE         8192
#define BCM9MCXX_BRD_EEP_ROWS         (BCM9MCXX_BRD_EEP_SIZE/16)
#define BCM9MCXX_BRD_TYPE_OFFSET      0
#define BCM9MCXX_SERNO_OFFSET         11
#define BCM9MCXX_MAC_ADDR_BASE_OFFSET 18
#define BCM9MCXX_BRD_TYPE_SIZE        11
#define BCM9MCXX_SERNO_SIZE           7
#define BCM9MCXX_MAC_ADDR_SIZE        17
#define BCM9MCXX_BRD_NAME_SIZE        32

#if !defined(__ASSEMBLER__)
/*
 * Add board types as they become available
 */
typedef enum
{
    MCXX_UNKNOWN   = -1,
    SFM3200_80     = 0,
    LM2000_24G_8GF = 1,
} bcm9mcxx_type_t;


typedef struct brdtype_name_s
{
    char sBrdType[BCM9MCXX_BRD_TYPE_SIZE];
    char sBrdName[BCM9MCXX_BRD_NAME_SIZE];
    bcm9mcxx_type_t eType;
} brdtype_name_t;

#define FPGA_BASE (PHYS_TO_K1(FPGA_PHYS))

#define FPGA_READ(__reg)           *((volatile uint8_t *)(FPGA_BASE + __reg))
#define FPGA_WRITE(__reg, __value) *((volatile uint8_t *)(FPGA_BASE + __reg)) = __value

#define FPGA_SLOT_ID_GET() ((FPGA_READ(0x11) >> 6) & 1)
#define FPGA_REV_GET()     ((FPGA_READ(1) & 0xFF))
#define FPGA_ID_GET()      ((FPGA_READ(0) & 0xFF))


extern const brdtype_name_t *bcm9mcxx_brdname_type_get(char *sBrdName);
extern int bcm9mcxx_board_type_get(char *pBrd);
extern int bcm9mcxx_base_mac_addr_get(char *pMacAddr);
extern int bcm9mcxx_board_serno_get(char *pBrd);
extern int ui_init_bcm9mcxxcmds(void);
extern int bcm9mcxx_gesw_write(uint16_t page, uint16_t reg, uint16_t r0, uint16_t r1, uint16_t r2, uint16_t r3);
extern int bcm9mcxx_gesw_read(uint16_t page, uint16_t reg, uint16_t *r0, uint16_t *r1, uint16_t *r2, uint16_t *r3);
extern int bcm9mcxx_gesw_init(void);
extern int bcm9mcxx_get_slot(void);
extern uint8_t local_eep_addr_get(void);
extern int bcm9mcxx_setup_eth1(void);

#endif /* __ASSEMBLER__ */
#endif /* _BCM9MCXX_H_ */
