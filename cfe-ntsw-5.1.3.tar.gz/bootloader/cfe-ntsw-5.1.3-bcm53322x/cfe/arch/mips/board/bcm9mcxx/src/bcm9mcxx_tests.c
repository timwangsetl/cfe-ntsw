/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *
    *  Test commands for bcm9mcxx board	  File: bcm9mcxx_tests.c
    *
    *
    *  Author:  Travis B. Sawyer
    *           Henry Qian
    *
    *********************************************************************
    *
    *  Copyright 2006
    *  Broadcom Corporation. All rights reserved.
    *
    *  This software is furnished under license and may be used and
    *  copied only in accordance with the following terms and
    *  conditions.  Subject to these conditions, you may download,
    *  copy, install, use, modify and distribute modified or unmodified
    *  copies of this software in source and/or binary form.  No title
    *  or ownership is transferred hereby.
    *
    *  1) Any source code used, modified or distributed must reproduce
    *     and retain this copyright notice and list of conditions
    *     as they appear in the source file.
    *
    *  2) No right is granted to use any trade name, trademark, or
    *     logo of Broadcom Corporation.  The "Broadcom Corporation"
    *     name may not be used to endorse or promote products derived
    *     from this software without the prior written permission of
    *     Broadcom Corporation.
    *
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "sbmips.h"
#include "sb1250_regs.h"
#include "dev_newflash.h"
#include "ui_command.h"


/*
 * The following devices require manufacturing tests
 *
 * Primary Console port HMI test
 * NVRAM address/data lines --- i2c eeprom
 * Flash address/data lines
 * DRAM address/data lines  --- already in code 'memorytest'
 * FPGA register test (Register 0x17)
 * Primary Ethernet port ext loopback test
 * SD mem address/data test
 * SATA controller register test (SFM only)
 * HDD read/write test (SFM only)
 * BCM5398 register test (SFM only)
 * BCM5398 int loopback tests (SFM only)
 * Secondary Console port ext loopback test
 * Secondary Ethernet port ext loopback test
 * MAX399 register test (SFM only)
 * ZM7300 DPM register test (PCA9564 i2c controller)
 * Fan/temp sensor register test (Through PCA i2c MUX)
 *
 */

static int ui_cmd_mtest(ui_cmdline_t *cmd,int argc, char *argv[]);
static int flashtest(int tc, char **tv, int num);
static int fpgatest(int tc, char **tv, int num);
static int ledtest(int tc, char **tv, int num);

typedef int IFV(int, char**, int);
IFV *mt[] = {	flashtest,
		fpgatest,
		ledtest,
};

int ui_init_bcm9mcxx_testcmds(void);
int ui_init_bcm9mcxx_testcmds(void)
{
	cmd_addcmd("mtest",
		ui_cmd_mtest,
		NULL,
		"Manufacturing Test",
		"mtest [d | a | num <arg...>]\n"
		"d   -- Display Available Tests for this board\n"
		"a   -- Run all tests with default parameters\n"
		"num -- Test number to run.",
		"");

	return 0;
}

/*  *********************************************************************
    *  int ui_cmd_mtest(ui_cmdline_t *cmd,int argc, char *argv[])
    *
    *  Manufacturing Test
    *
    *  Input parameters:
    *      cmd - command structure
    *      argc, argv - parameters
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */

int ui_cmd_mtest(ui_cmdline_t *cmd, int argc, char *argv[])
{
        int i, tnum, retv = 0;

        if (argc <= 0) {
                ui_showusage(cmd);
                return 0;
        }

        if (argv[0][0] == 'd') {
                for (i = 0; i < sizeof(mt)/sizeof(mt[0]); i++) {
                        printf("    %d - ", i);
                        mt[i](-1, 0, i); /* cmd usage line */
                }
                return 0;
        }
        if (argv[0][0] == 'a') {
                for (i = 0; i < sizeof(mt)/sizeof(mt[0]); i++) {
                        mt[i](-2, 0, i); /* run test with default value */
                }
                return 0;
        }

        tnum = atoi(argv[0]);
        printf("tnum = %d\n", tnum);
        if ((tnum >= 0) && (tnum < sizeof(mt)/sizeof(mt[0]))) {
                retv = mt[tnum](argc, argv, tnum);
        } else {
                ui_showusage(cmd);
        }

        return retv;
}

/*  *********************************************************************
    *  int ledtest(int tc, char **tv, int num)
    *
    *  Manufacturing Test
    *  Test the led's on the front panel, can be toggled { GREEN, YELLOW, OFF }
    *  [POWER]
    *  [STATUS]
    *  [FAN]
    *  [MODE]
    *  Input parameters:
    *      cmd - command structure
    *      argc,argv - parameters
    *      num - test number
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */

int ledtest(int tc, char **tv, int num) 
{

  /* call usage */
  if (tc == -1) {
    printf("ledtest - toggle front panel leds\n");
    return 0;
  }

  const int led_cntrl = 0x9;
  const int post_led = 0x0a;
  int sleep = 4*1E6; /* ~ 4s */
  unsigned char prev_state;

  /* save off previous state */
  prev_state = (FPGA_READ(led_cntrl) & 0xFF);
  
  /* set power status to green */
  FPGA_WRITE(led_cntrl,1<<2);
  printf("frontpanel leds:green_off_off_off\n");
  cfe_usleep(sleep); 
  /* set power status to yellow */
  FPGA_WRITE(led_cntrl,1<<3);
  printf("frontpanel leds:yellow_off_off_off\n");
  cfe_usleep(sleep); 

  FPGA_WRITE(led_cntrl,1<<6);
  printf("frontpanel leds:off_green_off_off\n");
  cfe_usleep(sleep); 

  FPGA_WRITE(led_cntrl,1<<7);
  printf("frontpanel leds:off_yellow_off_off\n");
  cfe_usleep(sleep) ;

  FPGA_WRITE(led_cntrl,1<<4);
  printf("frontpanel leds:off_off_green_off\n");
  cfe_usleep(sleep); 

  FPGA_WRITE(led_cntrl,1<<5);
  printf("frontpanel leds:off_off_yellow_off\n");
  cfe_usleep(sleep); 

  /* turn off power status */
  printf("All front panel led's should be off\n");
  FPGA_WRITE(led_cntrl,0x0);
  printf("led:off_off_off_off\n");
  cfe_usleep(sleep); 

  /* restore default state */
  printf("Restoring previous state\n");
  FPGA_WRITE(led_cntrl,prev_state);

  /* post leds are on side of line card */
  prev_state = (FPGA_READ(post_led) & 0xFF);
  printf("Turning on all post led's\n");
  FPGA_WRITE(post_led,0x0);
  cfe_usleep(sleep);
  printf("Turning off all post led's\n");
  FPGA_WRITE(post_led,0x3c);
  cfe_usleep(sleep);
  printf("Restoring previous state\n");
  FPGA_WRITE(post_led,prev_state);

  return 0;
}

/*  *********************************************************************
    *  int flashtest(int tc, char **tv, int num)
    *
    *  Manufacturing Test
    *  Smoke test to print out flash information. Read the image, write it back.
    *  Tests that the flash exists, and can be read from and written to.
    *  Input parameters:
    *      cmd - command structure
    *      argc,argv - parameters
    *      num - test number
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */

int flashtest(int tc, char **tv, int num)
{
  char *flashdev = "flash0.os";
  int devtype;
  flash_info_t flashinfo;
  int res;
  int sfd;
  uint8_t *ptr = NULL;

#if CFG_RUNFROMKSEG0
  ptr = (uint8_t *) KERNADDR(CFG_FLASH_STAGING_BUFFER_ADDR);
#else
  ptr = (uint8_t *) UNCADDR(CFG_FLASH_STAGING_BUFFER_ADDR);
#endif

  /* call usage */
  if (tc == -1) {
    printf("flashtest <flashdevice> simple read/restore test\n");
    return 0;
  }


  if (tc != -2) { /* check for cmd line argument */
    if (tv[1] != NULL ) { 
      flashdev = tv[1];
    }
  }

  /* taken from ui_flash.c */
	
  /*
   * Make sure it's a flash device.
   */
	
  res = cfe_getdevinfo(flashdev);
  if (res < 0 ) {
    return ui_showerror(CFE_ERR_DEVNOTFOUND,flashdev);
  }
	
  devtype = res & CFE_DEV_MASK;

  if ((res != CFE_DEV_FLASH) && (res != CFE_DEV_NVRAM)) {
    xprintf("Device '%s' is not a flash or eeprom device.\n",flashdev);
    return CFE_ERR_INV_PARAM;
  }

  sfd = cfe_open(flashdev);
  if (sfd < 0) {
    return ui_showerror(sfd,"Could not open flash device");
  }

  printf("Getting information for %s ..\n",flashdev);
  /* retrieve information about this flash */
  if (cfe_ioctl(sfd,IOCTL_FLASH_GETINFO,
		(unsigned char *) &flashinfo,
		sizeof(flash_info_t),
		&res,0) != 0) {
    /* do not assume anything */
    printf("Could not get flash info\n");
    return ui_showerror(CFE_ERR,flashdev);
  } else {

    printf("flash.base = 0x%llx\n",flashinfo.flash_base);
    printf("flash.size = 0x%x\n",flashinfo.flash_size); 
    printf("flash.type = %d\n",flashinfo.flash_type); 
    printf("flash_flags = %d\n",flashinfo.flash_flags); 

    /* retrieve image */
    printf("Retrieving flash image ..\n");
    res = cfe_read(sfd,PTR2HSADDR(ptr),flashinfo.flash_size);
    if (res < 0) {
      return ui_showerror(res,"Could not read from flash");
    }

    /* just restore it write back */
    printf("Restoring flash image ..\n");
    res = cfe_write(sfd,PTR2HSADDR(ptr),flashinfo.flash_size);
    if (res < 0) {
      return ui_showerror(res,"Could not write to flash\n");
    }

  }
  cfe_close(sfd);
  return 0;
}

/*  *********************************************************************
    *  int fpgatest(int tc, char **tv, int num)
    *
    *  Manufacturing Test
    *  Test W/R 1's and 0's to scratch pad register within fpga
    *  Assumes fpga exists
    *  Input parameters:
    *      cmd - command structure
    *      argc,argv - parameters
    *      num - test number
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */

int fpgatest(int tc, char **tv, int num)
{

  unsigned char pat_wr=0;
  unsigned char pat_rd=0;
  int stat=0;
  int sreg=0x17; /* default scratch register */
  int i;

  /* call usage */
  if (tc == -1) {
    printf("fpgatest <address in decimal> w/r test\n", num);
    return 0;
  }

  if (tc != -2) { /* check for cmd line arg */
    if (tv[1] != NULL) {
      sreg = atoi(tv[1]);
    }
  }

  printf("fpgatest testing register 0x%x...\n", sreg);
  /* walk 1's */
  for(i=0;i<8;i++) {
    pat_wr = (1<<i);
    FPGA_WRITE(sreg,pat_wr);
    pat_rd = (FPGA_READ(sreg) & 0xFF);
    if (pat_wr != pat_rd) {
      printf("fpga[0x%x]: ERROR exp:0x%x got:0x%x\n",sreg,pat_wr,pat_rd);
      stat = -1;
    }
  }
  /* walk 0's */
  for(i=0;i<8;i++) {
    pat_wr = ~(1<<i);
    FPGA_WRITE(sreg,pat_wr);
    pat_rd = (FPGA_READ(sreg) & 0xFF);
    if (pat_wr != pat_rd) {
      printf("fpga[0x%x]: ERROR exp:0x%x got:0x%x\n",sreg,pat_wr,pat_rd);
      stat = -1;
    }
  }
  return stat;
}

