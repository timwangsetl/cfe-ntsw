/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *
    *  Board device initialization		File: bcm9mcxx_devs.c
    *
    *  This is the "C" part of the board support package.  The
    *  routines to create and initialize the console, wire up
    *  device drivers, and do other customization live here.
    *
    *  Author:  Travis B. Sawyer
    *
    *********************************************************************
    *
    *  Copyright 2006
    *  Broadcom Corporation. All rights reserved.
    *
    *  This software is furnished under license and may be used and
    *  copied only in accordance with the following terms and
    *  conditions.  Subject to these conditions, you may download,
    *  copy, install, use, modify and distribute modified or unmodified
    *  copies of this software in source and/or binary form.  No title
    *  or ownership is transferred hereby.
    *
    *  1) Any source code used, modified or distributed must reproduce
    *     and retain this copyright notice and list of conditions
    *     as they appear in the source file.
    *
    *  2) No right is granted to use any trade name, trademark, or
    *     logo of Broadcom Corporation.  The "Broadcom Corporation"
    *     name may not be used to endorse or promote products derived
    *     from this software without the prior written permission of
    *     Broadcom Corporation.
    *
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "sbmips.h"
#include "env_subr.h"
#include "cfe_smbus.h"
#include "cfe_mii.h"

#include "sb1250_defs.h"
#include "sb1250_regs.h"
#include "sb1250_scd.h"
#include "sb1250_smbus.h"
#include "sb1250_mac.h"

#include "bcm9mcxx.h"
#include "bcm9mcxx_version.h"
#include "pcivar.h"
#include "pcireg.h"

#include "dev_newflash.h"
#include "dev_ide.h"
#include "cfe_loader.h"
#include "cfe_autoboot.h"

#include "jedec.h"

/*  *********************************************************************
    *  Devices we're importing
    ********************************************************************* */

extern cfe_driver_t sb1250_uart;		/* SB1250 serial ports */
extern cfe_driver_t sb1250_ether;		/* SB1250 MACs */

extern cfe_driver_t newflashdrv;		/* AMD & CFI flash */
extern cfe_smbus_t sb1250_smbus;
extern cfe_driver_t smbus_24lc64; 		/* Microchip EEPROM */
extern cfe_driver_t smbus_m41t81clock;		/* M41T81 SMBus RTC */
extern cfe_driver_t smbus_at24c02;		/* Atmel SPD EEPROM */
extern cfe_mii_t sb1250_mii;
extern cfe_driver_t frododrv;                   /* bcm5770 SATA PCI */
extern cfe_driver_t sb1250_pcihost;             /* driver for host downloads */
extern void pci_add_devices(int init);          /* driver collection du jour */

/*  *********************************************************************
    *  Commands we're importing
    ********************************************************************* */

extern int ui_init_bcm9mcxxcmds(void);
extern int ui_init_bcm9mcxx_testcmds(void);
extern int ui_init_corecmds(void);
extern int ui_init_soccmds(void);
extern int ui_init_testcmds(void);
extern int ui_init_resetcmds(void);
extern int ui_init_phycmds(void);
extern int ui_init_tempsensorcmds(void);
extern int ui_init_toyclockcmds(void);
extern int ui_init_memtestcmds(void);
extern int ui_init_ethertestcmds(void);
extern int ui_init_flashtestcmds(void);
extern int ui_init_disktestcmds(void);
extern int ui_init_vxbootcmds(void);
extern int ui_init_spdcmds(void);

/*  *********************************************************************
    *  Some other stuff we use
    ********************************************************************* */

extern void sb1250_show_cpu_type(void);
extern int cfe_device_download(int boot, char *options);
extern int bcm9mcxx_board_type_get(char *pBrd);

#if (defined(PCA9548_SMBUS_CHAN) && defined(MAX6653_SMBUS_DEV))
int PCA9548_subchan_select(cfe_smbus_channel_t *chan, unsigned char subchan);
int fan_smbus_write(cfe_smbus_channel_t *chan,int slaveaddr,int devaddr,int data);
static int fan_speed_init(void);
#endif

/*  *********************************************************************
    *  SysConfig switch settings and related parameters
    ********************************************************************* */

int fpga_rev;
int config_switch;
int slot;

/*
 * Due to the stuffing on the board config switch bits 0 & 1 are always on
 * STARTUP will only be run if the switch is in the '0' position
 */
#define CONFIG_STARTUP_ENV	       	0x01	/* switch 1 */
#define CONFIG_PCI_INIT			0x02	/* switch 2 */


static int64_t blinky_timer;			/* for blinky */

/*
 * Set variable if not already set 
 */
static inline
int try_setenv(const char *name, char *value, int flags)
{
    int rv = 0;

    /* If not already set, then set */
    if (env_getenv(name) == NULL) {
        rv = env_setenv(name, value, flags);
    }
    return rv;
}

/*  *********************************************************************
    *  board_console_init()
    *
    *  Add the console device and set it to be the primary
    *  console.
    *
    *  Input parameters:
    *  	   nothing
    *
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_console_init(void)
{
    uint64_t syscfg = SBREADCSR(A_SCD_SYSTEM_CFG);
    int plldiv;

    /* Console */
    cfe_add_device(&sb1250_uart,A_DUART,0,0);

    /* TBS TODO: Board rev from FPGA */
    fpga_rev = 0xFF;
    fpga_rev = FPGA_REV_GET();
    config_switch = G_SYS_CONFIG(syscfg) & 0x3F;

    cfe_startflags = CFE_INIT_PCI;

    cfe_set_console("uart0");

    plldiv = G_SYS_PLL_DIV(syscfg);

    /*
     * SMBus buses - need to be initialized before we attach
     * devices that use them.
     */

    cfe_add_smbus(&sb1250_smbus,A_SMB_BASE(0),0);
    cfe_add_smbus(&sb1250_smbus,A_SMB_BASE(1),0);

    /*
     * Board Type/Rev/MAC Address EEPROM
     */
    slot = bcm9mcxx_get_slot();
    if(0x15 == FPGA_ID_GET()) {
      cfe_add_device(&smbus_24lc64, EEPROM_SMBUS_CHAN, EEPROM_SMBUS_DEV,0);
      cfe_add_device(&smbus_24lc64, EEPROM_SMBUS_CHAN, EEPROM_SMBUS_DEV+1,0);
      cfe_add_device(&smbus_24lc64, EEPROM_SMBUS_CHAN, EEPROM_LC_SMBUS_DEV_BASE,0);
      cfe_add_device(&smbus_24lc64, EEPROM_SMBUS_CHAN, EEPROM_LC_SMBUS_DEV_BASE+1,0);
      cfe_add_device(&smbus_24lc64, EEPROM_SMBUS_CHAN, EEPROM_LC_SMBUS_DEV_BASE+2,0);
      cfe_add_device(&smbus_24lc64, EEPROM_SMBUS_CHAN, EEPROM_LC_SMBUS_DEV_BASE+3,0);
    } else { /* Our own eeprom */
      cfe_add_device(&smbus_24lc64, EEPROM_SMBUS_CHAN, local_eep_addr_get(),0);
    }
}

/*  *********************************************************************
    *  board_device_init()
    *
    *  Initialize and add other devices.  Add everything you need
    *  for bootstrap here, like disk drives, flash memory, UARTs,
    *  network controllers, etc.
    *
    *  Input parameters:
    *  	   nothing
    *
    *  Return value:
    *  	   nothing
    ********************************************************************* */
void board_device_init(void)
{

    uint64_t gpio;
    int plcc;
    newflash_probe_t fprobe;
    cfe_mii_channel_t *mii_channel;
    char sBrdType[BCM9MCXX_BRD_TYPE_SIZE+1];
    char sBrdSerNo[BCM9MCXX_SERNO_SIZE+1];
    char sBaseMacAddr[BCM9MCXX_MAC_ADDR_SIZE+1];
    const brdtype_name_t *pBrdInfo;
    /*
     * Print out the board version number.
     */
    memset(sBrdType, 0, 32);
    bcm9mcxx_board_type_get(sBrdType);
    bcm9mcxx_board_serno_get(sBrdSerNo);
    pBrdInfo = bcm9mcxx_brdname_type_get(sBrdType);
    printf("%s: %s (%s) Serial Number %s FPGA revision %d Slot %d\n",
	   CFG_BOARDNAME,
	   pBrdInfo->sBrdName,
	   sBrdType,
	   sBrdSerNo,
	   fpga_rev,
	   bcm9mcxx_get_slot());

    printf("%s: Local Version %s %s\n",
	   CFG_BOARDNAME,
	   bcm9mcxx_version,
	   bcm9mcxx_date);

    /*
     * Take chips out of reset, we'll need them!
     */
    FPGA_WRITE(0x05, 0x80);
    FPGA_WRITE(0x06, 0x00);
    cfe_nsleep(100);
    FPGA_WRITE(0x05, 0xFF);
    FPGA_WRITE(0x06, 0xFF);
    /* Disable interrupts */
    FPGA_WRITE(0x14, 0);
    /*
     * Figure out if CS0 is PLCC 1/2 MB Rom or the Strata flash is CS0
     */
    gpio = SBREADCSR(A_GPIO_READ);
    plcc = (gpio & M_GPIO_BOOT_MODE) ? 0 : 1;

#if (defined(PCA9548_SMBUS_CHAN) && defined(MAX6653_SMBUS_DEV))
    /*
     * Fans should blow as early as possible.
     * That's where we are.
     */
    if (fan_speed_init() == 0)
	printf("Start fans: OK\n");
    else
	printf("Start fans: Err\n");
#endif

    /*
     * Flash memory
     */
    memset(&fprobe,0,sizeof(fprobe));
    fprobe.flash_phys = (plcc) ? ISTRATA_PHYS : BOOTROM_PHYS;
    fprobe.flash_size = ISTRATA_SIZE*K64;
    fprobe.flash_flags =  FLASH_FLG_BUS8 | FLASH_FLG_DEV16;
    fprobe.flash_nchips = 1;
    fprobe.flash_nparts = 3;

    /* Partitions should be multiple of sector size, which is 128KB */
    fprobe.flash_parts[0].fp_name = "boot";
    fprobe.flash_parts[0].fp_size = 14*MB + (1*MB - 128*__KB);
    fprobe.flash_parts[1].fp_name = "os";
    fprobe.flash_parts[1].fp_size = 128*__KB;
    fprobe.flash_parts[2].fp_name = "env";
    fprobe.flash_parts[2].fp_size = 1*MB;

    cfe_add_device(&newflashdrv,0,0,&fprobe);	/* flash0 */
    cfe_set_envdevice("flash0.env");

    /* PLCC */
    memset(&fprobe,0,sizeof(fprobe));
    fprobe.flash_phys = (plcc) ? BOOTROM_PHYS : ISTRATA_PHYS;
    fprobe.flash_size = BOOTROM_SIZE*K64;
    fprobe.flash_flags =  FLASH_FLG_BUS8 | FLASH_FLG_DEV8;
    fprobe.flash_nparts = 1;
    fprobe.flash_parts[0].fp_size = 512*__KB;
    fprobe.flash_parts[0].fp_name = "boot";
    cfe_add_device(&newflashdrv,0,0,&fprobe);	/* flash1 */

    /*
     * MII interfaces - needed for PHY access outside MAC driver.
     * Must be initialized for the generic UI PHY commands to work.
     */
    cfe_add_mii(&sb1250_mii,A_MAC_BASE_0,1);
    cfe_add_mii(&sb1250_mii,A_MAC_BASE_1,0);

    /*
     * The BCM5461 mode select is floating on most designs, which
     * occasionally causes the PHY to enter non-copper mode after
     * reset.
     *
     * Here we force copper-mode and auto-negotiation for MAC 0
     * if a BCM5461 is detected.
     */

    mii_channel = MII_CHANNEL(0);

    if ((MII_READ(mii_channel,-1,0x02) == 0x0020) &&
        (MII_READ(mii_channel,-1,0x03) & 0xFFF0) == 0x60C0) {

        /* Set copper mode */
        MII_WRITE(mii_channel,-1,0x1C,0xFC00);
        /* Enable auto-negotiation */
        MII_WRITE(mii_channel,-1,0x00,0x1000);
    }

    /* look for and configure BCM5461 on eth1 interface */
    mii_channel = MII_CHANNEL(1);
 
    if ((MII_READ(mii_channel,1,0x02) == 0x0020) &&
        (MII_READ(mii_channel,1,0x03) & 0xFFF0) == 0x60C0) {
      printf("Configuring BCM5461S setting to copper mode PHY 1\n");
        /* Set copper mode */
      MII_WRITE(mii_channel,1,0x1C,0xFC00);
      /* Enable auto-negotiation */
      MII_WRITE(mii_channel,1,0x00,0x1000);
    }


    /*
     * SPD EEPROM. This is used to store the type of memory soldered
     * onto the board. [eeprom0]
     */
    cfe_add_device(&smbus_at24c02,SPDEEPROM_SMBUS_CHAN,SPDEEPROM_SMBUS_DEV,0);

    /*
     * MACs - must init after environment, since the hw address is stored there.
     *
     * NOTE: We retrieve the base mac address from the board info eeprom, then store it
     * NOTE: to the environment, as appropriate.
     */
    bcm9mcxx_base_mac_addr_get(sBaseMacAddr);
    try_setenv("ETH0_HWADDR", sBaseMacAddr,ENV_FLG_ADMIN);

    sBaseMacAddr[BCM9MCXX_MAC_ADDR_SIZE-1]++;
    try_setenv("ETH1_HWADDR", sBaseMacAddr,ENV_FLG_ADMIN);

    cfe_add_device(&sb1250_ether,A_MAC_BASE_0,0,env_getenv("ETH0_HWADDR"));
    cfe_add_device(&sb1250_ether,A_MAC_BASE_1,1,env_getenv("ETH1_HWADDR"));

    /*
     * Real-time clock
     */
    cfe_add_device(&smbus_m41t81clock,M41T81_SMBUS_CHAN,M41T81_SMBUS_DEV,0);


    cfe_add_device(&frododrv,0,IDE_PROBE_MASTER_TYPE(IDE_DEVTYPE_DISK),NULL);

   /*
     * Set variable that contains CPU speed, spit out config register
     */
    printf("Config switch: %d/0x%02X\n", config_switch, config_switch);

    sb1250_show_cpu_type();

    /* setup a REGRESS variable to run a bunch of cfe diags at once */
    try_setenv("REGRESS","memorytest;mtest a;show brdtype; show temp;show time",ENV_FLG_ADMIN);

    /* temp ==> add a shortcut to update the cfe.flash image */
    try_setenv("F9","ifconfig eth0 -auto && flash 10.100.17.10:cfe.flash flash1.boot",ENV_FLG_ADMIN);

}



/*  *********************************************************************
    *  board_device_reset()
    *
    *  Reset devices.  This call is done when the firmware is restarted,
    *  as might happen when an operating system exits, just before the
    *  "reset" command is applied to the installed devices.   You can
    *  do whatever board-specific things are here to keep the system
    *  stable, like stopping DMA sources, interrupts, etc.
    *
    *  Input parameters:
    *  	   nothing
    *
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_device_reset(void)
{
    /*Nothing to do. */
}


/*  *********************************************************************
    *  board_blinkylight(arg)
    *
    *  Blink the LED once per second
    *
    *  Input parameters:
    *  	   arg - not used
    *
    *  Return value:
    *  	   nothing
    ********************************************************************* */

static void board_blinkylight(void *arg)
{
    static int light = 0;
    intptr_t reg;

    if (TIMER_EXPIRED(blinky_timer)) {
	light = !light;
	reg = light ? A_GPIO_PIN_SET : A_GPIO_PIN_CLR;
	SBWRITECSR(reg, M_GPIO_SW_LED);
	TIMER_SET(blinky_timer,CFE_HZ);
	}
}


/*  *********************************************************************
    *  board_setup_autoboot()
    *
    *  Set up autoboot methods.  This routine sets up the list of
    *  places to find a boot program.
    *
    *  Input parameters:
    *  	   nothing
    *
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static void board_setup_autoboot(void)
{

    /*
     * If you had partitioned your flash, you could boot from it like this:
     */

    cfe_add_autoboot(CFE_AUTOBOOT_RAW,0,"flash0.os","elf","raw",NULL);

    /*
     * Now try running a script (file containing CFE commands) from
     * the TFTP server.   Your DHCP server must set option 130
     * to contain the name of the script.  Option 130 gets stored
     * in "BOOT_SCRIPT" when a DHCP reply is received.
     */

    cfe_add_autoboot(CFE_AUTOBOOT_NETWORK,LOADFLG_BATCH,
		     "eth0","raw","tftp","$BOOT_SERVER:$BOOT_SCRIPT");

    /*
     * Finally, try loading whatever the DHCP server says is the boot
     * program.  Do this as an ELF file, and failing that, try a
     * raw binary.
     */

    cfe_add_autoboot(CFE_AUTOBOOT_NETWORK,0,"eth0","elf","tftp",NULL);
    cfe_add_autoboot(CFE_AUTOBOOT_NETWORK,0,"eth0","raw","tftp",NULL);

}

/*  *********************************************************************
    *  board_final_init()
    *
    *  Do any final initialization, such as adding commands to the
    *  user interface.
    *
    *  If you don't want a user interface, put the startup code here.
    *  This routine is called just before CFE starts its user interface.
    *
    *  Input parameters:
    *  	   nothing
    *
    *  Return value:
    *  	   nothing
    ********************************************************************* */

void board_final_init(void)
{

    int flag;

    ui_init_bcm9mcxxcmds();
    ui_init_bcm9mcxx_testcmds();
    ui_init_corecmds();
    ui_init_soccmds();
    ui_init_resetcmds();
    ui_init_tempsensorcmds();
    ui_init_toyclockcmds();
    ui_init_memtestcmds();
    ui_init_phycmds();
    ui_init_ethertestcmds();
    ui_init_flashtestcmds();
    ui_init_disktestcmds();
    ui_init_vxbootcmds();
    ui_init_spdcmds();

    cfe_bg_add(board_blinkylight,NULL);
    TIMER_SET(blinky_timer,CFE_HZ);

    board_setup_autoboot();

    if( config_switch == 0x3f ) {
	/* Change STARTUP's flags so it can run or error message if not set */
	if (env_getenv("STARTUP") == NULL) {
	    printf("*** STARTUP environment variable not set.\n\n");
	} else {
            flag = env_envtype("STARTUP");
            flag &= ~ENV_FLG_STARTUP_NORUN;
	    env_setflags("STARTUP",flag);
        }
    } else {
	if (env_getenv("STARTUP") != NULL) {
	    /* Don't run the commands in STARTUP */
	    flag = env_envtype("STARTUP");
	    flag |= ENV_FLG_STARTUP_NORUN;
	    env_setflags("STARTUP",flag);

        }
    }


#if 0
    if (config_switch == (CONFIG_STARTUP_ENV | CONFIG_PCI_INIT)) {
	/* Change STARTUP's flags so it can run or error message if not set */
	if (env_getenv("STARTUP") == NULL) {
	    printf("*** STARTUP environment variable not set.\n\n");
	}
	else {
	    flag = env_envtype("STARTUP");
	    flag &= ~ENV_FLG_STARTUP_NORUN;
	    env_setflags("STARTUP",flag);
	    }
	}
    else {
	if (env_getenv("STARTUP") != NULL) {
	    /* Don't run the commands in STARTUP */
	    flag = env_envtype("STARTUP");
	    flag |= ENV_FLG_STARTUP_NORUN;
	    env_setflags("STARTUP",flag);
	    }
	}
#endif
}

#if (defined(PCA9548_SMBUS_CHAN) && defined(MAX6653_SMBUS_DEV))

/*  *********************************************************************
    *  int PCA9548_subchan_select(cfe_smbus_channel_t *chan, unsigned char subchan)
    *
    *  PCA9548 has 8 switched channels
    *  Devices off these channels might have same slave addresses, so it's better
    *  to switch to one channel at a time.
    *  subchan = 0 to deselect
    *
    *  Input parameters:
    *      cfe_smbus_channel_t *chan
    *      unsigned char subchan
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */

int PCA9548_subchan_select(cfe_smbus_channel_t *chan, unsigned char subchan)
{
	int err;
	unsigned char buf[1];

	/*
	 * valid subchan: 0 - (PCA9548_SMBUS_SUBCHAN_MAX - 1)
	 */
	if (subchan > (PCA9548_SMBUS_SUBCHAN_MAX - 1)) {
		printf("PCA9548_subchan_select: error subchan number: %d\n", subchan);
		return -1;
	}
	buf[0] = 1 << subchan;
	err = SMBUS_WRITE(chan, PCA9548_SMBUS_DEV, buf, 1);
	if (err < 0) {
		printf("PCA9548_subchan_select (%d): error: %d\n", subchan, err);
		return err;
	}
	return 0;
}

/*  *********************************************************************
    *  int fan_speed_init(void)
    *
    *   This function is intended to be called at board init time to have
    *   fans blow full speed
    *  
    *   Both subchannel 0 and 1 control one same set of two fans.
    *   Only subchannel 0 actually sets the fans at full speed
    *   subchannel 1 is inactive
    *  
    *   Both subchannel 2 and 3 control another same set of two fans.
    *   Only subchannel 2 actually sets the fans at full speed
    *   subchannel 3 is inactive
    *
    *  Input parameters:
    *      nothing
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */

int fan_speed_init(void)
{
	int err;
	cfe_smbus_channel_t *chan = SMBUS_CHANNEL(PCA9548_SMBUS_CHAN);

	/*
	 * Set channel 0 full speed
	 * ------------------------
	 */
	err = PCA9548_subchan_select(chan, 0);
	if (err < 0) {
		printf("PCA9548_subchan_select: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * Reset MAX6653 registers to default values
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x01, 0x80);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * enable fan control and monitor
	 * 0x01 - Enable fan-speed control
	 * 0x04 - Tachometer digital/analog input selection: analog input
	 * 0x08 - Invert the PWM output: PWM active high
	 * 0x10 - FAN_FAULT output enable: enabled
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x00, 0x1d);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * set fan characteristics register
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x20, 0x7d);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * set fan speed
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x22, 0x0f);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * Set channel 1 Sleep
	 * -------------------
	 */
	err = PCA9548_subchan_select(chan, 1);
	if (err < 0) {
		printf("PCA9548_subchan_select: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * Reset MAX6653 registers to default values
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x01, 0x80);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * disable fan control and monitor
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x00, 0x00);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * Set channel 2 full speed
	 * ------------------------
	 */
	err = PCA9548_subchan_select(chan, 2);
	if (err < 0) {
		printf("PCA9548_subchan_select: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * Reset MAX6653 registers to default values
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x01, 0x80);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * enable fan control and monitor
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x00, 0x1d);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * set fan speed
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x22, 0x0f);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * Set channel 3 Sleep
	 * -------------------
	 */
	err = PCA9548_subchan_select(chan, 3);
	if (err < 0) {
		printf("PCA9548_subchan_select: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * Reset MAX6653 registers to default values
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x01, 0x80);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * disable fan control and monitor
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x00, 0x00);
	if (err < 0) {
		printf("fan_smbus_write: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	/*
	 * deselect
	 * --------
	 */
	err = PCA9548_subchan_select(chan, 0);
	if (err < 0) {
		printf("PCA9548_subchan_select: %d - %s(%d)\n", err, __FILE__, __LINE__);
		return err;
	}

	return 0;
}

/*  *********************************************************************
    *  fan_smbus_write(chan,slaveaddr,devaddr,data)
    *
    *  write a byte to the temperature sensor chip
    *
    *  Input parameters:
    *      chan - SMBus channel
    *      slaveaddr -  SMBus slave address
    *      devaddr - byte with in the sensor device to read
    *
    *  Return value:
    *      0 if ok
    *      else -1
    ********************************************************************* */

int fan_smbus_write(cfe_smbus_channel_t *chan,int slaveaddr,int devaddr,int data)
{
    uint8_t buf[2];
    int err;

    /*
     * Write the data byte
     */

    buf[0] = devaddr;
    buf[1] = data;

    err = SMBUS_WRITE(chan,slaveaddr,buf,2);
    return err;
}

#endif
