/*  *********************************************************************
 *  Broadcom Common Firmware Environment (CFE)
 *
 *  BCM9MCXX-specific commands		File: ui_bcm9mcxx.c
 *
 *  A temporary sandbox for misc test routines and commands.
 *
 *  Author:  Travis B. Sawyer
 *
 *********************************************************************
 *
 *  Copyright 2006
 *  Broadcom Corporation. All rights reserved.
 *
 *  This software is furnished under license and may be used and
 *  copied only in accordance with the following terms and
 *  conditions.  Subject to these conditions, you may download,
 *  copy, install, use, modify and distribute modified or unmodified
 *  copies of this software in source and/or binary form.  No title
 *  or ownership is transferred hereby.
 *
 *  1) Any source code used, modified or distributed must reproduce
 *     and retain this copyright notice and list of conditions
 *     as they appear in the source file.
 *
 *  2) No right is granted to use any trade name, trademark, or
 *     logo of Broadcom Corporation.  The "Broadcom Corporation"
 *     name may not be used to endorse or promote products derived
 *     from this software without the prior written permission of
 *     Broadcom Corporation.
 *
 *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
 *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
 *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT
 *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN
 *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
 *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF
 *     THE POSSIBILITY OF SUCH DAMAGE.
 ********************************************************************* */


#include "cfe.h"

#include "ui_command.h"
#include "lib_string.h"
#include "sbmips.h"
#include "sb1250_regs.h"
#include "cfe_smbus.h"
#include "sb1250_scd.h"
#include "cfe_mii.h"

#include "bcm9mcxx.h"
#include "lib_physio.h"

#if (defined(PCA9548_SMBUS_CHAN) && defined(MAX6653_SMBUS_DEV))
static int ui_cmd_setfanspeed(ui_cmdline_t *cmd,int argc,char *argv[]);
extern int PCA9548_subchan_select(cfe_smbus_channel_t *chan, unsigned char subchan);
extern int fan_smbus_write(cfe_smbus_channel_t *chan,int slaveaddr,int devaddr,int data);
#endif

static int ui_cmd_memdump2(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_memedit2(ui_cmdline_t *cmd,int argc,char *argv[]);

/*  *********************************************************************
 *  Configuration
 ********************************************************************* */
#define my_isascii(__c)    (((__c) & ~0x7f) == 0)
/*  *********************************************************************
 *  prototypes
 ********************************************************************* */


/*  *********************************************************************
 *  Data
 ********************************************************************* */
/*
 * To get a match, just pluck off the first 6 characters.
 * The revision is after the dash
 */
static const brdtype_name_t brdtype_mx[] =
{
    {
        .sBrdType = "115661-0000",
        .sBrdName = "BCM9SFM3200_80",
        .eType    = SFM3200_80,
    },
    {
        .sBrdType = "115702-0000",
        .sBrdName = "BCM9LM2000_24G_8GF",
        .eType    = LM2000_24G_8GF,
    },
    {
        .sBrdType = "Unknown",
        .sBrdName = "Unknown",
        .eType    = MCXX_UNKNOWN,
    },
};


/*
 * Given an 11 character board string from the board eeprom,
 * retrieve the board type info from the matrix
 */
const brdtype_name_t *bcm9mcxx_brdname_type_get(char *sBrdName)
{
    int idx;

    idx = 0;
    while( MCXX_UNKNOWN != brdtype_mx[idx].eType) {
        if(0==lib_strncmp(sBrdName, brdtype_mx[idx].sBrdType, 6)) {
            return &brdtype_mx[idx];
        }
        idx++;
    }

    return &brdtype_mx[idx];

}

int bcm9mcxx_get_slot(void)
{
    if(0x15 == FPGA_ID_GET()) {
        return (FPGA_READ(0x11) >> 6) & 1;
    } else {
        return (FPGA_READ(0x11) & 0x3) + 2;
    }
}

uint8_t local_eep_addr_get(void)
{
  int slot;

  slot = bcm9mcxx_get_slot();

  if( slot < 2 ) {
    return EEPROM_SMBUS_DEV + slot;
  } else {
    return EEPROM_LC_SMBUS_DEV_BASE + slot - 2;
  }
}

static int eep_smbus_write(cfe_smbus_channel_t *chan,int slaveaddr,int devaddr,int b)
{
    int err;
    int64_t timer;
    uint8_t buf[3];


    buf[0] = (devaddr >> 8) & 0x3F;
    buf[1] = (devaddr & 0xFF);
    buf[2] = (uint8_t) b;

    err = SMBUS_WRITE(chan,slaveaddr,buf,3);
    if (err < 0) return err;

    /*
     * Pound on the device with a quick command (R/W=0)
     * to poll for the write complete.  See sect 7.0 of the
     * 24LC64 manual.
     */

    TIMER_SET(timer,50);
    err = -1;

    while (!TIMER_EXPIRED(timer)) {
	POLL();

	err = SMBUS_QCMD(chan,slaveaddr,0);
	if (err == 0) break;
	}

    return err;
}

static int eep_smbus_read(cfe_smbus_channel_t *chan,int slaveaddr,int devaddr)
{
    uint8_t buf[2];
    int err;

    buf[0] = (devaddr >> 8) & 0x3F;
    buf[1] = (devaddr & 0xFF);

    /*
     * Write the device address to the controller.
     */

    err = SMBUS_WRITE(chan,slaveaddr,buf,2);
    if (err < 0) return err;

    /*
     * Read the data byte
     */

    err = SMBUS_READ(chan,slaveaddr,buf,1);
    if (err < 0) return err;

    return buf[0];
}

static int ui_cmd_board_type_set(ui_cmdline_t *cmd, int argc, char *argv[])
{
    int res;
    int idx;
    char *value;
    cfe_smbus_channel_t *ch;

    value = cmd_getarg(cmd, 0);
    if(!value) {
        return ui_showusage(cmd);
    }

    /*
     * The value must be XXXXXX-YYYY
     */
    if(BCM9MCXX_BRD_TYPE_SIZE != strlen(value)) {
        return ui_showusage(cmd);
    }

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_BRD_TYPE_SIZE; idx++) {
        res = eep_smbus_write(ch,
			      local_eep_addr_get(),
			      idx + BCM9MCXX_BRD_TYPE_OFFSET, value[idx]);
        if (res < 0) {
            printf("Could not write to eeprom byte %d at %d/0x%02X\n",
                   idx + BCM9MCXX_BRD_TYPE_OFFSET, EEPROM_SMBUS_CHAN, local_eep_addr_get());
            return -1;
        }
    }

    return 0;
}
static int ui_cmd_board_sn_set(ui_cmdline_t *cmd, int argc, char *argv[])
{
    int res;
    int idx;
    char *value;
    cfe_smbus_channel_t *ch;

    value = cmd_getarg(cmd, 0);
    if(!value) {
        return ui_showusage(cmd);
    }

    /*
     * The value must be XXXXXXX
     */
    if( BCM9MCXX_SERNO_SIZE != strlen(value)) {
        return ui_showusage(cmd);
    }

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_SERNO_SIZE; idx++) {
        res = eep_smbus_write(ch,
			      local_eep_addr_get(),
			      idx + BCM9MCXX_SERNO_OFFSET,
			      value[idx]);
        if (res < 0) {
            printf("Could not write to eeprom byte %d at %d/0x%02X\n",
                   idx + BCM9MCXX_SERNO_OFFSET, EEPROM_SMBUS_CHAN, local_eep_addr_get());
            return -1;
        }
    }

    return 0;
}

static int ui_cmd_mac_addr_set(ui_cmdline_t *cmd, int argc, char *argv[])
{
    int res;
    int idx;
    char *value;
    cfe_smbus_channel_t *ch;

    value = cmd_getarg(cmd, 0);
    if(!value) {
        return ui_showusage(cmd);
    }

    /*
     * The value must be XX:XX:XX:XX:XX:XX
     * NOTE: This is also the base mac address for the board.
     * NOTE: SFM type boards need only 2 addresses, while Line Card type
     * NOTE: boards may need 24, or more.
     */
    if(BCM9MCXX_MAC_ADDR_SIZE != strlen(value)) {
        return ui_showusage(cmd);
    }

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_MAC_ADDR_SIZE; idx++) {
        res = eep_smbus_write(ch,
                              local_eep_addr_get(),
                              BCM9MCXX_MAC_ADDR_BASE_OFFSET+idx,
                              value[idx]);
        if (res < 0) {
            printf("Could not write to eeprom byte %d at %d/0x%02X\n",
                   BCM9MCXX_MAC_ADDR_BASE_OFFSET+idx, EEPROM_SMBUS_CHAN, local_eep_addr_get());
            return -1;
        }
    }

    return 0;
}

static int ui_cmd_eeprom_dump(ui_cmdline_t *cmd, int argc, char *argv[])
{
    cfe_smbus_channel_t *ch;
    int row;
    int col;
    char b[16];

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);
    printf("Addr   00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F     ASCII\n");
    printf("----   ----------------------------------------------- ---------------");
    for(row = 0; row < BCM9MCXX_BRD_EEP_ROWS; row++) {
        printf("\n%04X:  ", row*16);
        for(col = 0; col < 16; col++) {
            b[col] = eep_smbus_read(ch, local_eep_addr_get(), (row*16)+col);
            printf("%02X ", (uint8_t)b[col]);
        }

        for(col=0; col < 16; col++) {
            if(my_isascii(b[col])) {
                printf("%c", b[col]);
            } else {
                printf(".");
            }
        }
    }

    printf("\n");

    return 0;
}

static int ui_cmd_board_type_show(ui_cmdline_t *cmd, int argc, char *argv[])
{
    cfe_smbus_channel_t *ch;
    char sBrd[BCM9MCXX_BRD_TYPE_SIZE+1];
    int idx;

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_BRD_TYPE_SIZE; idx++) {
        sBrd[idx] = eep_smbus_read(ch,
				   local_eep_addr_get(),
				   idx + BCM9MCXX_BRD_TYPE_OFFSET);
    }
    sBrd[BCM9MCXX_BRD_TYPE_SIZE] = '\0';
    printf("Board Type: %s\n", sBrd);

    return 0;
}

static int ui_cmd_serno_show(ui_cmdline_t *cmd, int argc, char *argv[])
{
    cfe_smbus_channel_t *ch;
    char sBrd[BCM9MCXX_SERNO_SIZE+1];
    int idx;

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_SERNO_SIZE; idx++) {
        sBrd[idx] = eep_smbus_read(ch,
				   local_eep_addr_get(),
				   idx + BCM9MCXX_SERNO_OFFSET);
    }
    sBrd[BCM9MCXX_SERNO_SIZE] = '\0';
    printf("Board Serial Number: %s\n", sBrd);

    return 0;
}


int bcm9mcxx_gesw_read(uint16_t page, uint16_t reg, uint16_t *r0, uint16_t *r1, uint16_t *r2, uint16_t *r3)
{
    cfe_mii_channel_t *mii_channel;
    int timeout;

    mii_channel = MII_CHANNEL(1);

    /* For a read we must first set the page, and access bit */
    MII_WRITE(mii_channel,30, 16, (page << 8) | 0x0001);
    cfe_nsleep(100);
    /* Set the register and op as read */
    MII_WRITE(mii_channel,30, 17, (reg << 8) | 0x0002);
    cfe_nsleep(100);

    timeout = 100;
    while((MII_READ(mii_channel,30,17) & 0x0003) && timeout) {
        cfe_nsleep(100);
        timeout--;
    }

    if(!(MII_READ(mii_channel,30,17) & 0x0003)) {

        *r0 = MII_READ(mii_channel,30,24);
        *r1 = MII_READ(mii_channel,30,25);
        *r2 = MII_READ(mii_channel,30,26);
        *r3 = MII_READ(mii_channel,30,27);
        return 0;
    }
    return -1;
}

int bcm9mcxx_gesw_write(uint16_t page, uint16_t reg, uint16_t r0, uint16_t r1, uint16_t r2, uint16_t r3)
{
    cfe_mii_channel_t *mii_channel;
    int timeout;

    mii_channel = MII_CHANNEL(1);

    /* For a read we must first set the page, and access bit */
    MII_WRITE(mii_channel,30, 16, (page << 8) | 0x0001);
    cfe_nsleep(100);

    /* Set the value */
    MII_WRITE(mii_channel,30,24,r0);
    cfe_nsleep(100);
    MII_WRITE(mii_channel,30,25,r1);
    cfe_nsleep(100);
    MII_WRITE(mii_channel,30,26,r2);
    cfe_nsleep(100);
    MII_WRITE(mii_channel,30,27,r3);
    cfe_nsleep(100);

    /* Set the register and op as read */
    MII_WRITE(mii_channel,30, 17, (reg << 8) | 0x0001);
    cfe_nsleep(100);

    timeout = 100;
    while((MII_READ(mii_channel,30,17) & 0x0003) && timeout) {
        cfe_nsleep(100);
        timeout--;
    }

    if(!(MII_READ(mii_channel,30,17) & 0x0003)) {
        return 0;
    }

    return -1;
}

static int ui_cmd_gesw_read(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *x;
    int pageval;
    uint16_t reg;
    uint16_t reg0, reg1, reg2, reg3;
    int ret;

    x = cmd_getarg(cmd, 0);
    if(!x) {
        return ui_showusage(cmd);
    }
    pageval = atoi(x);

    x = cmd_getarg(cmd, 1);
    if(!x) {
        return ui_showusage(cmd);
    }

    reg = atoi(x);
    reg0 = reg1 = reg2 = reg3 = 0;
    ret = bcm9mcxx_gesw_read(pageval, reg, &reg0, &reg1, &reg2, &reg3);

    if(0 == ret) {
        printf("BCM5398 Reg 0x%02X on page 0x%02X = %04X %04X %04X %04X\n",
               reg, pageval,
               reg0, reg1, reg2, reg3);
    } else {
        printf("BCM5398 Read Timed Out\n");
    }

    return 0;

}

static int ui_cmd_gesw_write(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *x;
    int regval0, regval1, regval2, regval3;
    int pageval;
    uint16_t reg;
    int ret;

    x = cmd_getarg(cmd, 0);
    if(!x) {
        return ui_showusage(cmd);
    }
    pageval = atoi(x);

    x = cmd_getarg(cmd, 1);
    if(!x) {
        return ui_showusage(cmd);
    }

    reg = atoi(x);

    x = cmd_getarg(cmd, 2);
    if(!x) {
        return ui_showusage(cmd);
    }
    regval0 = atoi(x);

    x = cmd_getarg(cmd, 3);
    regval1 = x ? atoi(x) : 0;

    x = cmd_getarg(cmd, 4);
    regval2 = x ? atoi(x) : 0;

    x = cmd_getarg(cmd, 5);
    regval3 = x ? atoi(x) : 0;
    printf("Writing page %x reg %x to:  %04x %04x %04x %04x\n",
           pageval, reg, regval0, regval1, regval2, regval3);
    ret = bcm9mcxx_gesw_write(pageval,reg,regval0, regval1, regval2, regval3);
    if(0 == ret) {
        printf("Write successful\n");
    } else {
        printf("Write Timed Out\n");
    }

    return 0;
}

static uint16_t gesw_ports[] = {0, 1, 2, 3, 4, 7,8};

static int ui_cmd_gesw_stats(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *x;
    uint16_t port;
    uint16_t regval0, regval1, regval2, regval3;
    uint64_t stat;
    int ret;

    x = cmd_getarg(cmd, 0);
    if(!x) {
        return ui_showusage(cmd);
    }
    port = atoi(x);

    if(port > 8) {
        return ui_showusage(cmd);
    }

    port |= 0x20;

    ret = bcm9mcxx_gesw_read(port, 0x0, &regval0, &regval1, &regval2, &regval3);
    stat = ((uint64_t)regval1 << 16) | regval0;
    printf("TxOct: %d\n",stat);
    ret = bcm9mcxx_gesw_read(port, 0x8, &regval0, &regval1, &regval2, &regval3);
    stat = ((uint64_t)regval1 << 16) | regval0;
    printf("TxDrpPkts: %d\n",stat);



    ret = bcm9mcxx_gesw_read(port, 0x44, &regval0, &regval1, &regval2, &regval3);
    stat = ((uint64_t)regval3 << 48) |((uint64_t)regval2 << 32) | ((uint64_t)regval1 << 16) | regval0;
    printf("RxOct: %d\n",stat);

    return(0);
}



static int ui_cmd_gesw_status(ui_cmdline_t *cmd, int argc, char *argv[])
{
    uint16_t regval0, regval1, regval2, regval3;
    uint16_t reg;
    uint32_t fullreg;
    int ret;
    int speed[7];

    ret = bcm9mcxx_gesw_read(0x01, 0x0, &regval0, &regval1, &regval2, &regval3);

    printf("BCM5398 Switch Status\n");
    printf("Port:\t\tlc0\tlc1\tlc2\tlc3\tSFM\tFP\tIMP\n");
    printf("Link:\t\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
           (regval0 >> 0) & 0x1,
           (regval0 >> 1) & 0x1,
           (regval0 >> 2) & 0x1,
           (regval0 >> 3) & 0x1,
           (regval0 >> 4) & 0x1,
           (regval0 >> 7) & 0x1,
           (regval0 >> 8) & 0x1);

    ret = bcm9mcxx_gesw_read(0x1, 0x2, &regval0, &regval1, &regval2, &regval3);
    printf("StsChng:\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
           (regval0 >> 0) & 0x1,
           (regval0 >> 1) & 0x1,
           (regval0 >> 2) & 0x1,
           (regval0 >> 3) & 0x1,
           (regval0 >> 4) & 0x1,
           (regval0 >> 7) & 0x1,
           (regval0 >> 8) & 0x1);

    ret = bcm9mcxx_gesw_read(0x1, 0x8, &regval0, &regval1, &regval2, &regval3);
    printf("Dplx:\t\t%c\t%c\t%c\t%c\t%c\t%c\t%c\n",
           (regval0 >> 0) & 0x1 ? 'F' : 'H',
           (regval0 >> 1) & 0x1 ? 'F' : 'H',
           (regval0 >> 2) & 0x1 ? 'F' : 'H',
           (regval0 >> 3) & 0x1 ? 'F' : 'H',
           (regval0 >> 4) & 0x1 ? 'F' : 'H',
           (regval0 >> 7) & 0x1 ? 'F' : 'H',
           (regval0 >> 8) & 0x1 ? 'F' : 'H');


    ret = bcm9mcxx_gesw_read(0x1, 0x4, &regval0, &regval1, &regval2, &regval3);
    fullreg = (uint32_t)(regval1 << 16) | regval0;
    for(ret = 0; ret < 7; ret++) {
        reg = (fullreg >> (2 * gesw_ports[ret])) & 0x3;
        switch(reg) {
            case 0:
                speed[ret] = 10;
                break;
            case 1:
                speed[ret] = 100;
                break;
            case 2:
                speed[ret] = 1000;
                break;
            default:
                speed[ret] = -1;
                break;
        }
    }
    printf("Spd:\t\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
           speed[0], speed[1], speed[2], speed[3], speed[4], speed[5],speed[6]);

    return 0;
}


int bcm9mcxx_gesw_init(void)
{
    /*
     * The robo 5898 comes up in unmanaged mode
     * Setup port 7 (front panel port) for mirror traffic mode
     */
    /* Forward lookup failed messages to all ports */
    bcm9mcxx_gesw_write(0x0, 0x21, 0x0C0, 0, 0, 0);
    bcm9mcxx_gesw_write(0x0, 0x32, 0x1FF, 0, 0, 0);
    bcm9mcxx_gesw_write(0x0, 0x34, 0x1FF, 0, 0, 0);

    /* Ingress mirror mask */
    bcm9mcxx_gesw_write(0x2, 0x12, 0x17F, 0, 0, 0);
    /* Egress mirror mask */
    bcm9mcxx_gesw_write(0x2, 0x1C, 0x17F, 0, 0, 0);
    /* enable mirror, to port 7 */
    bcm9mcxx_gesw_write(0x2, 0x10, 0x8007, 0, 0, 0);


    return 0;
}


int bcm9mcxx_setup_eth1(void)
{
    char netcmd[128];

    sprintf(netcmd, "ifconfig eth1 -addr=10.0.0.%d -mask=255.255.255.240 -speed=auto",
            bcm9mcxx_get_slot()+1);

    /* Run through standard command line parser */
    ui_docommand(netcmd);

    return(0);
}


int bcm9mcxx_board_type_get(char *pBrd)
{
    cfe_smbus_channel_t *ch;
    int idx;

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_BRD_TYPE_SIZE; idx++) {
        pBrd[idx] = eep_smbus_read(ch,
				   local_eep_addr_get(),
				   idx + BCM9MCXX_BRD_TYPE_OFFSET);
    }
    pBrd[idx] = '\0';

    return 0;
}

int bcm9mcxx_board_serno_get(char *pBrd)
{
    cfe_smbus_channel_t *ch;
    int idx;

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_SERNO_SIZE; idx++) {
        pBrd[idx] = eep_smbus_read(ch,
				   local_eep_addr_get(),
				   idx + BCM9MCXX_SERNO_OFFSET);
    }
    pBrd[idx] = '\0';

    return 0;
} 

int bcm9mcxx_base_mac_addr_get(char *pMacAddr)
{
    cfe_smbus_channel_t *ch;
    int idx;

    ch = SMBUS_CHANNEL(EEPROM_SMBUS_CHAN);

    for(idx = 0; idx < BCM9MCXX_MAC_ADDR_SIZE; idx++) {
        pMacAddr[idx] = eep_smbus_read(ch,
				       local_eep_addr_get(),
				       BCM9MCXX_MAC_ADDR_BASE_OFFSET+idx);
    }
    pMacAddr[idx] = '\0';

    return 0;
}


#if (defined(PCA9548_SMBUS_CHAN) && defined(MAX6653_SMBUS_DEV))

/*  *********************************************************************
    *  ui_cmd_setfanspeed(cmd,argc,argv)
    *
    *  Set fan speed
    *
    *  Input parameters:
    *      cmd - command structure
    *      argc,argv - parameters
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */

static int ui_cmd_setfanspeed(ui_cmdline_t *cmd,int argc,char *argv[])
{
	cfe_smbus_channel_t *chan = SMBUS_CHANNEL(PCA9548_SMBUS_CHAN);
	int err;
	unsigned int subchan;
	unsigned int speed;

	if (argc != 2) {
		return ui_showusage(cmd);
	}

	subchan = atoi(argv[0]);
	speed = atoi(argv[1]);
	if ((subchan > 3) || (speed > 15)) {
		return ui_showusage(cmd);
	}
	err = PCA9548_subchan_select(chan, subchan);
	if (err < 0) {
		return err;
	}

	/*
	 * Reset MAX6653 registers to default values
	 * 0x01 - configuration register 2
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x01, 0x80);
	if (err < 0) {
		printf("fan_smbus_write 0x%x 0x01 0x80: error: %d\n", MAX6653_SMBUS_DEV, err);
		return err;
	}

	/*
	 * enable fan control and monitor
	 * 0x00 - configuration register 1
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x00, 0x1d);
	if (err < 0) {
		printf("fan_smbus_write 0x%x 0x00 0x19: error: %d\n", MAX6653_SMBUS_DEV, err);
		return err;
	}

	/*
	 * set fan speed
	 * 0x22 - fan-speed configuration register
	 */
	err = fan_smbus_write(chan, MAX6653_SMBUS_DEV, 0x22, speed);
	if (err < 0) {
		printf("fan_smbus_write 0x%x 0x22 %d: error: %d\n",
					MAX6653_SMBUS_DEV, speed, err);
		return err;
	}

	/*
	 * deselect
	 */
	err = PCA9548_subchan_select(chan, 0);
	if (err < 0) {
		return err;
	}
	return 0;
}
#endif

/*  *********************************************************************
    *  ui_cmd_memdump2(cmd,argc,argv)
    *
    *  Set fan speed
    *
    *  Input parameters:
    *      cmd - command structure
    *      argc,argv - parameters
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */
enum unit {
	BYTE = 0,
	HWORD,
	WORD,
	QUADWORD,
};

static int ui_cmd_memdump2(ui_cmdline_t *cmd,int argc,char *argv[])
{
	int i, addr, num;
	enum unit unit;

	if (argc == 2) {
		if (cmd_sw_isset(cmd, "-b")) {
			unit = BYTE;
		} else if (cmd_sw_isset(cmd, "-h")) {
			unit = HWORD;
		} else if (cmd_sw_isset(cmd, "-w")) {
			unit = WORD;
		} else if (cmd_sw_isset(cmd, "-q")) {
			unit = QUADWORD;
		} else {
			unit = WORD;
		}
		addr = atoi(argv[0]);
		num = atoi(argv[1]);
	} else {
		return ui_showusage(cmd);
	}

	for (i = 0; i < num; i++) {
		switch (unit) {
		case BYTE:
			printf("%08x: %02x %02x %02x %02x  %02x %02x %02x %02x  "
				"%02x %02x %02x %02x  %02x %02x %02x %02x\n", addr,
				phys_read8(addr + 0x0), phys_read8(addr + 0x1),
				phys_read8(addr + 0x2), phys_read8(addr + 0x3),
				phys_read8(addr + 0x4), phys_read8(addr + 0x5),
				phys_read8(addr + 0x6), phys_read8(addr + 0x7),
				phys_read8(addr + 0x8), phys_read8(addr + 0x9),
				phys_read8(addr + 0xA), phys_read8(addr + 0xB),
				phys_read8(addr + 0xC), phys_read8(addr + 0xD),
				phys_read8(addr + 0xE), phys_read8(addr + 0xF));
			addr += 0x10;
			break;
		case HWORD:
			printf("%08x: %04x %04x %04x %04x %04x %04x %04x %04x\n", addr,
				phys_read16(addr + 0x0), phys_read16(addr + 0x2),
				phys_read16(addr + 0x4), phys_read16(addr + 0x6),
				phys_read16(addr + 0x8), phys_read16(addr + 0xA),
				phys_read16(addr + 0xC), phys_read16(addr + 0xE));
			addr += 0x10;
			break;
		case WORD:
			printf("%08x: %08x %08x %08x %08x\n", addr,
				phys_read32(addr + 0x0),
				phys_read32(addr + 0x4),
				phys_read32(addr + 0x8),
				phys_read32(addr + 0xc));
			addr += 0x10;
			break;
		case QUADWORD:
			printf("%08x: %016llx %016llx\n", addr,
				phys_read64(addr + 0x0),
				phys_read64(addr + 0x8));
			addr += 0x10;
			break;
		}
	}
	return 0;
}

/*  *********************************************************************
    *  ui_cmd_memedit2(cmd,argc,argv)
    *
    *  Set fan speed
    *
    *  Input parameters:
    *      cmd - command structure
    *      argc,argv - parameters
    *
    *  Return value:
    *      0: success; < 0: error
    ********************************************************************* */
static int ui_cmd_memedit2(ui_cmdline_t *cmd,int argc,char *argv[])
{
	int addr, data;
	enum unit unit;

	if (argc == 2) {
		if (cmd_sw_isset(cmd, "-b")) {
			unit = BYTE;
		} else if (cmd_sw_isset(cmd, "-h")) {
			unit = HWORD;
		} else if (cmd_sw_isset(cmd, "-w")) {
			unit = WORD;
		} else {
			unit = WORD;
		}
		addr = atoi(argv[0]);
		data = atoi(argv[1]);
	} else {
		return ui_showusage(cmd);
	}

	switch (unit) {
	case BYTE:
		phys_write8(addr, data);
		break;
	case HWORD:
		phys_write16(addr, data);
		break;
	case WORD:
		phys_write32(addr, data);
		break;
	case QUADWORD:
		break;
	}
	return 0;
}

/*  *********************************************************************
 *  ui_init_bcm9mcxxcmds()
 *
 *  Add BCM91125F-specific commands to the command table
 *
 *  Input parameters:
 *  	   nothing
 *
 *  Return value:
 *  	   0
 ********************************************************************* */


int ui_init_bcm9mcxxcmds(void)
{

    cmd_addcmd("brdtypeset",
               ui_cmd_board_type_set,
               NULL,
               "Set the board type",
               "brdtypeset <value>\nWhere value is of the form XXXXXX-RRRR (in quotes)",
               "");

    cmd_addcmd("show brdtype",
               ui_cmd_board_type_show,
               NULL,
               "Show the board type",
               "show brdtype",
               "");

    cmd_addcmd("basemacaddrset",
               ui_cmd_mac_addr_set,
               NULL,
               "Set the base MAC Address",
               "basemacaddrset <value>\nWhere value is of the form XX:XX:XX:XX:XX:XX (in quotes)\n"
               "This is used to set the MAC addresses of ALL ethernet ports on the board",
               "");

    cmd_addcmd("eepread",
               ui_cmd_eeprom_dump,
               NULL,
               "Read board type eeprom",
               "eepread",
               "");

    cmd_addcmd("show serno",
               ui_cmd_serno_show,
               NULL,
               "Show the board serial number",
               "show serno",
               "");

    cmd_addcmd("brdsernoset",
               ui_cmd_board_sn_set,
               NULL,
               "Set the board serial number",
               "brdsernoset <value>\nWhere value is of type XXXXXXX (in quotes)",
               "");

    if(0x15 == FPGA_ID_GET()) {
      cmd_addcmd("gesw write",
		 ui_cmd_gesw_write,
		 NULL,
		 "Write BCM5398 GE Switch",
		 "gesw write <page> <reg> <value0> [val1] [val2] [val3]",
		 "");

      cmd_addcmd("gesw read",
		 ui_cmd_gesw_read,
		 NULL,
		 "Read BCM5398 GE Switch",
		 "gesw read <page> <reg>",
		 "");

      cmd_addcmd("gesw status",
		 ui_cmd_gesw_status,
		 NULL,
		 "Dump link status of the BCM5398 GE Switch",
		 "gesw status",
		 "");

      cmd_addcmd("gesw stats",
		 ui_cmd_gesw_stats,
		 NULL,
		 "MIB counters for a port of the BCM5398 GE Switch",
		 "gesw stats <port>",
		 "");
    }

    /* Gross hack for time being.  The linux driver expects the firmware
     * to put the ethernet address in the soc regs.  The only way to do
     * it is to open it up */
    bcm9mcxx_setup_eth1();
    /*
     * Need to setup the IMP port on the 5398 to match the address above
     */
    if(0x15 == FPGA_ID_GET()) {
      cfe_sleep(CFE_HZ*5);
      bcm9mcxx_gesw_init();
    }

#if (defined(PCA9548_SMBUS_CHAN) && defined(MAX6653_SMBUS_DEV))
    cmd_addcmd("setfanspeed",
               ui_cmd_setfanspeed,
               NULL,
               "Set fan speeds",
               "setfanspeed <num:0-3> <speed:0-15>",
               "");
#endif

    cmd_addcmd("dd",
               ui_cmd_memdump2,
               NULL,
               "Dump memory.",
               "dd [-b|-h|-w|-q] <addr> <length>\n\n"
               "This command displays data from memory as bytes, halfwords, words,\n"
               "or quadwords.\n",
               "-b;Dump memory as bytes|"
               "-h;Dump memory as halfwords (16-bits)|"
               "-w;Dump memory as words (32-bits)|"
               "-q;Dump memory as quadwords (64-bits)");

    cmd_addcmd("ee",
               ui_cmd_memedit2,
               NULL,
               "Modify contents of memory.",
               "ee [-b|-h|-w] <addr> <data>\n\n"
               "This command modifies the contents of memory.\n",
               "-b;Edit memory as bytes|"
               "-h;Edit memory as halfwords (16-bits)|"
               "-w;Edit memory as words (32-bits)");

    return 0;
}
