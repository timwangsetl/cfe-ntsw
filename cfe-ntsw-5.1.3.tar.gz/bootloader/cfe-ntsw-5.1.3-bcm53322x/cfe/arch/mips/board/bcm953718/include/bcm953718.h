/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM956218 board-specific definitions       
    *  
    *********************************************************************  
    *
    *  Copyright 2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef __BCM953718_H
#define __BCM953718_H
/* Macros */

#define KB 1024
#define MB (1024*1024)

/* Internal NS16550-compatible dual UART */
#define BCM953718_COM1   BCM56XXX_UART0       /* uart-0 */
#define BCM953718_COM2   BCM56XXX_UART1       /* uart-1 */

#endif /* ! __BCM953718_H */
