/*
 * $Copyright Broadcom Corporation$
 *
 * $Id: sbmips.h,v 1.3 2009/05/21 21:35:58 miyarn Exp $
 */
/*
 *  for now, work around build issues by doing this.  Ugh.
 */

#ifndef _SB_MIPS_H
#define _SB_MIPS_H

#include "sbmips32.h"

#endif /* _SB_MIPS_H */
