/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  CPU Configuration file           File: cpu_config.h
    *  
    *  This file contains the names of the routines to be used in the
    *  dispatch table in init_mips.S It lives here in the CPU
    *  directory so we can direct the init calls to routines named in
    *  this directory.
    *
    *  It also contains implementation-specific definitions for the
    *  MIPS74K core used in certain Broadcom 53xxx
    *  (SiliconBackplane) products.
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef _CPU_CONFIG_H
#define _CPU_CONFIG_H

#define CPUCFG_ARCHNAME     "MIPS"
#define CPUCFG_ELFTYPE      EM_MIPS

/*  *********************************************************************
    *  Map the function names
    ********************************************************************* */

#define CPUCFG_CPUINIT          mips74k_cpuinit
#define CPUCFG_ALTCPU_START1    mips74k_null
#define CPUCFG_ALTCPU_START2    mips74k_null
#define CPUCFG_ALTCPU_RESET     mips74k_null
#define CPUCFG_CPURESTART       mips74k_null
#define CPUCFG_DRAMINIT         board_draminit      /* no dram on CPU */
#define CPUCFG_CACHEOPS         mips74k_cacheops
#define CPUCFG_ARENAINIT        mips74k_arena_init
#define CPUCFG_PAGETBLINIT      mips74k_pagetable_init
#define CPUCFG_TLBHANDLER       mips74k_tlbhandler
#define CPUCFG_DIAG_TEST1       mips74k_null
#define CPUCFG_DIAG_TEST2       mips74k_null
#define CPUCFG_CPUSPEED         si_cpu_clock
#define CPUCFG_CPUSOCITYPE      si_cpu_socitype
#define CPUCFG_SYNCRANGE        mips74k_sync_range
#define CPUCFG_INVALRANGE       mips74k_inval_range


/*  *********************************************************************
    *  Implementation properties of MIPS74K
    ********************************************************************* */

/* This MIPS74K core ticks CP0 every cycle. */
#define CPUCFG_CYCLESPERCPUTICK 2

/* Hazard macros. MIPS74K supports Explicit Hazard Removal. */
#define HAZARD  ehb

#define ERET \
        .set push ; \
        eret ; \
        .set pop 



#define CPUCFG_COHERENT_DMA 0   /* The MIPS74K does not support coherent DMA. */

#define CPUCFG_REGS32   1   /* GPRs are 32 bits */
#define CPUCFG_REGS64   0   /* and are not 64 bits*/

#endif /* _CPU_CONFIG_H */
