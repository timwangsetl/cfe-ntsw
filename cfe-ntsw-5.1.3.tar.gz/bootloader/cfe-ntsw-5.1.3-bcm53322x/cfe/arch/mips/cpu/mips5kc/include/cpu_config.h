/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *
    *  CPU Configuration file			File: cpu_config.h
    *
    *  This file contains the names of the routines to be used
    *  in the dispatch table in init_mips.S
    *
    *  It lives here in the CPU directory so we can direct
    *  the init calls to routines named in this directory.
    *
    *  Author:  Mitch Lichtenberg (mpl@broadcom.com)
    *
    *********************************************************************
    *
    *  XX Copyright 2000,2001
    *  Broadcom Corporation. All rights reserved.
    *
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *
    *  This software is furnished under license and may be used and
    *  copied only in accordance with the license.
    ********************************************************************* */

/*
 */

#define CPUCFG_REGS64		1			/* 5KC is a MIPS64 CPU, 64-bit regs */
#define CPUCFG_REGS32		0			/* and therefore not 32-bits */

#define CPUCFG_CYCLESPERCPUTICK 2			/* 5KC takes 2 cycles per CP0 COUNT */

#define CPUCFG_ARCHNAME		"MIPS"
#define CPUCFG_ELFTYPE		EM_MIPS

#define CPUCFG_COHERENT_DMA	0			/* DMA is not coherent */

#define CPUCFG_CPUINIT		mips5kc_cpuinit
#define CPUCFG_ALTCPU_START1	mips5kc_null
#define CPUCFG_ALTCPU_START2	mips5kc_null
#define CPUCFG_ALTCPU_RESET	mips5kc_null
#define CPUCFG_CPURESTART	mips5kc_null
#define CPUCFG_DRAMINIT		board_draminit		/* no dram on CPU */
#define CPUCFG_PREDRAMINIT	board_bootebiinit	/* early ebi initialization */
#define CPUCFG_CACHEOPS		mips5kc_cacheops
#define CPUCFG_ARENAINIT	mips5kc_arena_init
#define CPUCFG_PAGETBLINIT	mips5kc_pagetable_init
#define CPUCFG_TLBHANDLER	mips5kc_tlbhandler
#define CPUCFG_DIAG_TEST1	mips5kc_null
#define CPUCFG_DIAG_TEST2	mips5kc_null
#define CPUCFG_CPUSPEED		board_cpuspeed
#define CPUCFG_INVALRANGE	mips5kc_inval_range
#define CPUCFG_SYNCRANGE	mips5kc_sync_range

#define CPUCFG_L1D_LINESIZE	32			/* L1 DCache line size */
#define CPUCFG_L1I_LINESIZE	32			/* L1 ICache line size */

/*
 * Hazard macro
 */

#define HAZARD ssnop ; ssnop ; ssnop ; ssnop ; ssnop ; ssnop ; ssnop
#define ERET \
		.set push  ; \
		.set mips4 ; \
		eret ; \
		.set pop


