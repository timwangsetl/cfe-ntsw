/*  *********************************************************************
    *  MIPS 5KC CPU Support Package
    *  
    *  MISP 5KC generic definitions		File: mips5kc.h
    *  
    *  Generic constants specific to the MIPS 5kc and 5kf processors
    *  
    *  Author:  Mitch Lichtenberg 
    *  
    *********************************************************************  
    *
    *  XX Copyright 2000,2001
    *  Broadcom Corporation. All rights reserved.
    *
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */


/*  *********************************************************************
    *  TLB info
    ********************************************************************* */

#define MIPS5KC_NTLBENTRIES	32

/*  *********************************************************************
    *  L1 Cache 
    ********************************************************************* */

#define L1C_I_NUMWAYS	4
#define L1C_I_NUMIDX  256
#define L1C_I_LINESIZE	32
#define L1C_I_IDXHIGH (L1C_I_LINESIZE*L1C_I_NUMWAYS*L1C_I_NUMIDX)
#define L1C_I_SIZE	L1C_I_IDXHIGH

#define L1C_D_NUMWAYS	4
#define L1C_D_NUMIDX  256
#define L1C_D_LINESIZE	32
#define L1C_D_IDXHIGH (L1C_D_LINESIZE*L1C_D_NUMWAYS*L1C_D_NUMIDX)
#define L1C_D_SIZE	L1C_D_IDXHIGH

#define L1CACHEOP(cachename,op) ((cachename) | ((op) << 2))

#define L1C_OP_IDXINVAL     0
#define L1C_OP_IDXLOADTAG   1
#define L1C_OP_IDXSTORETAG  2
#define L1C_OP_IMPLRSVD     3
#define L1C_OP_HITINVAL     4
#define L1C_OP_FILL         5
#define L1C_OP_HITWRITEBACK 6
#define L1C_OP_FETCHLOCK    7

#define L1C_I		    0
#define L1C_D		    1

/*  *********************************************************************
    *  End
    ********************************************************************* */
