/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Early print macros and functions
    *  
    *  Author:  Sanjay Gupta
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */
#include "sbmips.h"
#include "mipsmacros.h"
#include "bsp_config.h"

#if defined(SB_CHIPC_BCM56XXX_BASE)
#define INCLUDE_EARLY_PRINT     1
#define EARLY_UART_BASE     PHYS_TO_K1(BCM56XXX_UART0)
#else
#undef  INCLUDE_EARLY_PRINT
#endif

/*
 * Individual platforms can disable early print by 
 * defining CFG_EXCLUDE_EARLY_PRINT.
 */
#ifdef CFG_EXCLUDE_EARLY_PRINT
#undef  INCLUDE_EARLY_PRINT
#endif

//#if defined(INCLUDE_EARLY_PRINT)
//
///*
// * EARLY_UART_DEBUG macro prints 4 characters followed by space to console.
// */
//#define EARLY_UART_DEBUG(c1,c2,c3,c4)                     \
//        li a0, c1;                  \
//        JAL(early_console_putc);    \
//        nop ;                       \
//        li a0, c2;                  \
//        JAL(early_console_putc);    \
//        nop ;                       \
//        li a0, c3;                  \
//        JAL(early_console_putc);    \
//        nop ;                       \
//        li a0, c4;                  \
//        JAL(early_console_putc);    \
//        nop ;                       \
//        li a0, 0x20;                \
//        JAL(early_console_putc);    \
//        nop ;                   
//
///*
// * EARLY_UART_DEBUG1 macro prints 4 characters followed by space to console.
// * This macro should be used when the code is running un-cached.
// */
//#define EARLY_UART_DEBUG1(c1,c2,c3,c4)          \
//        li a0, c1;                          \
//        JAL_KSEG1(early_console_putc);      \
//        nop ;                               \
//        li a0, c2;                          \
//        JAL_KSEG1(early_console_putc);      \
//        nop ;                               \
//        li a0, c3;                          \
//        JAL_KSEG1(early_console_putc);      \
//        nop ;                               \
//        li a0, c4;                          \
//        JAL_KSEG1(early_console_putc);      \
//        nop ;                               \
//        li a0, 0x20;                        \
//        JAL_KSEG1(early_console_putc);      \
//        nop ;                   
//
///*
// * EARLY_UART_PRINT_MEM32 dumps the memory content for the specified address to
// * console.
// */
//#define EARLY_UART_PRINT_MEM32(a)               \
//        li  a0, (a)                         ;   \
//        JAL_KSEG1(early_console_print32)    ;   \
//        nop                                 ;   \
//        li  a0, 0x3D                        ;   \
//        JAL_KSEG1(early_console_putc)       ;   \
//        li  a0, (a)                         ;   \
//        lw  a0, 0(a0)                       ;   \
//        JAL_KSEG1(early_console_print32)    ;   \
//        nop                                 ;   \
//        li a0, 0x20                         ;   \
//        JAL_KSEG1(early_console_putc)       ;   \
//        nop                                 ;
//
//
//#else 

#define EARLY_UART_DEBUG(c1,c2,c3,c4)

#define EARLY_UART_DEBUG1(c1,c2,c3,c4)

#define EARLY_UART_PRINT_MEM32(a)


//#endif /* defined(INCLUDE_EARLY_PRINT) */
