/***************************************************************
**
**  Broadcom Corp. Confidential
**  Copyright 2007 Broadcom Corp.  All Rights Reserved.
**
**  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED 
**  SOFTWARE LICENSE AGREEMENT  BETWEEN THE USER AND BROADCOM.  
**  YOU HAVE NO RIGHT TO USE OR EXPLOIT THIS MATERIAL EXCEPT 
**  SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
**
**  File:         bspi_flash.c
**  Description:  Serial flash mgmt
**  Created:      Wed Mar 21 13:31:21 PDT 2007 - Jeffrey P. Fisher      
**
****************************************************************/

#include "cfe.h"
#include "bspi_flash.h"
#include "bchp_bspi.h"

#define SPI_WREN_CMD        (0x06)
#define SPI_WRDI_CMD        (0x04)
#define SPI_RDSR_CMD        (0x05)
#define SPI_READ_CMD        (0x03)
#define SPI_SE_CMD          (0x20)
#define SPI_PP_CMD          (0x02)
#define SPI_RDID_CMD        (0x9F)
#define SPI_POLLING_INTERVAL		10		/* in usecs */
#define BSPI_Pcs_eUpgSpiPcs0		0
#define SPI_CDRAM_CONT				0x80

#define SPI_CDRAM_PCS_PCS0			0x01
#define SPI_CDRAM_PCS_PCS1			0x02
#define SPI_CDRAM_PCS_PCS2			0x00
#define SPI_CDRAM_PCS_DISABLE_ALL	(SPI_CDRAM_PCS_PCS0 | SPI_CDRAM_PCS_PCS1 | SPI_CDRAM_PCS_PCS2)

#define SPI_SYSTEM_CLK		100000000	/* 100 MHz */
#define MAX_SPI_BAUD		6250000		/* SPBR = 8, 6.25MHZ */

#define MSPI_CALC_TIMEOUT(bytes,baud)	 ((((bytes * 9000)/baud) * 110)/100 + 1)

#define DBGMSG(x)	((void)0)


void bspi_flush_prefetch_buffers(void)
{
    /* Have to check if BSPI is idle before flush */
    while(ReadReg32(BCHP_BSPI_BUSY_STATUS));

    WriteReg32(BCHP_BSPI_B0_CTRL ,1);
    WriteReg32(BCHP_BSPI_B0_CTRL ,0);
    WriteReg32(BCHP_BSPI_B1_CTRL ,1);
    WriteReg32(BCHP_BSPI_B1_CTRL ,0);
}

static void bspi_enter_critical(void)
{
    while(ReadReg32(BCHP_BSPI_BUSY_STATUS));
    WriteReg32(BCHP_BSPI_B0_CTRL ,1);
    WriteReg32(BCHP_BSPI_B0_CTRL ,0);
    WriteReg32(BCHP_BSPI_B1_CTRL ,1);
    WriteReg32(BCHP_BSPI_B1_CTRL ,0);
    WriteReg32(BCHP_BSPI_MAST_N_BOOT_CTRL,1);
}
static void bspi_exit_critical(void)
{
	WriteReg32(BCHP_BSPI_MAST_N_BOOT_CTRL,0);
	cfe_usleep(100);
}

/*
Summary:
	poll for completion.
*/

static int mspi_wait(unsigned int timeout_ms)
{
	unsigned int loopCnt,lval;
	/* 
	 * Polling mode
	 */
	DBGMSG(("%s:%d(%d)\n",__FUNCTION__,__LINE__,timeout_ms));
	loopCnt = ((timeout_ms * 1000) / SPI_POLLING_INTERVAL) + 1;
	while (1)
	{
		lval = ReadReg32(BCHP_MSPI_MSPI_STATUS);
		if (lval & BCHP_MSPI_MSPI_STATUS_SPIF_MASK)
		{
			DBGMSG(("%s:%d status done 0x%08x\n",__FUNCTION__,__LINE__,lval));
			break;
		}

		if (loopCnt == 0)
		{
			/* Transfer finished, clear SPIF bit */
			WriteReg32( BCHP_MSPI_MSPI_STATUS, 0);
			DBGMSG(("%s:%d timeout = %d\n",__FUNCTION__,__LINE__,timeout_ms));
			return -1;
		}
		cfe_usleep(SPI_POLLING_INTERVAL);
		loopCnt--;
	}
	/* Transfer finished, clear SPIF bit */
	WriteReg32( BCHP_MSPI_MSPI_STATUS, 0);
	return 0;
}


/*
Summary:
	SPI transactionn.
*/

static int mspi_transaction( unsigned char *w_buf,
						unsigned char write_len,
						unsigned char *r_buf,
						unsigned char read_len)
{       
	unsigned int lval;
	unsigned char i, len;
	static int s_init = 0;

	/* set up clock once */
	if (!s_init)
	{
		s_init = 1;
		lval = SPI_SYSTEM_CLK / (2 * MAX_SPI_BAUD);
        WriteReg32(BCHP_MSPI_SPCR0_LSB, lval );

        /* Configure the clock */
        lval = ReadReg32(BCHP_MSPI_SPCR0_MSB);
        lval &= ~(BCHP_MSPI_SPCR0_MSB_CPOL_MASK | BCHP_MSPI_SPCR0_MSB_CPHA_MASK);
        lval |= (BCHP_MSPI_SPCR0_MSB_MSTR_MASK | (BCHP_MSPI_SPCR0_MSB_CPOL_MASK | BCHP_MSPI_SPCR0_MSB_CPHA_MASK));
        WriteReg32(BCHP_MSPI_SPCR0_MSB, lval );
	}

	len = write_len + read_len;
	for (i = 0; i < len; ++i)
	{
		if (i < write_len)
		{
			WriteReg32( BCHP_MSPI_TXRAM00 + (i * 8), (unsigned int)w_buf[i] );
		}
		lval = SPI_CDRAM_CONT | SPI_CDRAM_PCS_DISABLE_ALL;
		lval &= ~(1 << BSPI_Pcs_eUpgSpiPcs0);       
		WriteReg32( BCHP_MSPI_CDRAM00 + (i * 4) , lval );

	}
	
	lval = SPI_CDRAM_PCS_DISABLE_ALL;
	lval &= ~(1 << BSPI_Pcs_eUpgSpiPcs0);       
	WriteReg32( BCHP_MSPI_CDRAM00 + ((len - 1) * 4), lval );
	
	/* Set queue pointers */
	WriteReg32(  BCHP_MSPI_NEWQP, 0 );
	WriteReg32(  BCHP_MSPI_ENDQP,  len - 1 );
	
	/* Start SPI transfer */
	lval = ReadReg32( BCHP_MSPI_SPCR2);
	lval |= BCHP_MSPI_SPCR2_spe_MASK;
	WriteReg32(BCHP_MSPI_SPCR2, lval);

	/* Wait for SPI to finish */
	if (mspi_wait(MSPI_CALC_TIMEOUT(len,MAX_SPI_BAUD)) != 0)
	{
		return CFE_ERR_TIMEOUT;
	}

	for (i = write_len; i < len; ++i)
	{
		r_buf[i-write_len] = (unsigned char)ReadReg32( BCHP_MSPI_RXRAM01 + (i * 8));
	}

	return CFE_OK;
}


/*
Summary:
	do spi flash read.
*/

int bspi_read(char bus, unsigned int offset, unsigned char *data)
{
	unsigned char cmd[4];
	int result;
	
	cmd[0] = 0x9F;
	bspi_enter_critical();
	result = mspi_transaction(cmd,1,data,1);
	bspi_exit_critical();

	cmd[0] = SPI_READ_CMD;
#if ENDIAN_BIG
    cmd[1] = ((unsigned char*)&offset)[1];
	cmd[2] = ((unsigned char*)&offset)[2];
	cmd[3] = ((unsigned char*)&offset)[3];
#else
	cmd[1] = ((unsigned char*)&offset)[2];
	cmd[2] = ((unsigned char*)&offset)[1];
	cmd[3] = ((unsigned char*)&offset)[0];
#endif	
	bspi_enter_critical();
	result = mspi_transaction(cmd,4,data,1);
	bspi_exit_critical();
	return result;
}

/*
Summary:
	Erase the spi flash sector at offset.
*/
int bspi_sector_erase(char bus, unsigned int offset)
{
	int result;
	unsigned char cmd[4];
	unsigned char data;
	
	bspi_enter_critical();
	cmd[0] = SPI_WREN_CMD;
	if ((result = mspi_transaction(cmd,1,NULL,0)) != CFE_OK)
		goto done;

	cmd[0] = SPI_SE_CMD;
#if ENDIAN_BIG
    cmd[1] = ((unsigned char*)&offset)[1];
	cmd[2] = ((unsigned char*)&offset)[2];
	cmd[3] = ((unsigned char*)&offset)[3];
#else
	cmd[1] = ((unsigned char*)&offset)[2];
	cmd[2] = ((unsigned char*)&offset)[1];
	cmd[3] = ((unsigned char*)&offset)[0];
#endif
	if ((result = mspi_transaction(cmd,4,NULL,0)) != CFE_OK)
		goto done;
#ifndef CONFIG_ROM_EMULATOR
	do
	{
		cmd[0] = SPI_RDSR_CMD;
		if ((result = mspi_transaction(cmd,1,&data,1)) != CFE_OK)
			goto done;
	}while(data & 0x01/* busy*/);
#else
	cfe_usleep(100);
#endif

	cmd[0] = SPI_WRDI_CMD;
	result = mspi_transaction(cmd,1,NULL,0);
done:
	bspi_exit_critical();

	return result;
}

/*
Summary:
	program the spi flash page of data at offset.
*/
static inline void lmcpy(unsigned char* dst, unsigned char* src, int len)
{
	int i;
	for (i = 0; i < len; ++i)
	{
		dst[i] = src[i];
	}
}

int bspi_page_program(char bus, unsigned int offset, unsigned char *buf, int len)
{
	int result;
	static unsigned char cmd[16];
	unsigned char data;

	if (len > 12) /* Max bytes per transaction (command needs 4 bytes) */
		return CFE_ERR_INV_PARAM;

	bspi_enter_critical();

	cmd[0] = SPI_WREN_CMD;
	if ((result = mspi_transaction(cmd,1,NULL,0)) != CFE_OK)
		goto done;

	cmd[0] = SPI_PP_CMD;
#if ENDIAN_BIG
    cmd[1] = ((unsigned char*)&offset)[1];
	cmd[2] = ((unsigned char*)&offset)[2];
	cmd[3] = ((unsigned char*)&offset)[3];
#else
	cmd[1] = ((unsigned char*)&offset)[2];
	cmd[2] = ((unsigned char*)&offset)[1];
	cmd[3] = ((unsigned char*)&offset)[0];
#endif	
	lmcpy(&(cmd[4]),buf,len);

	if ((result = mspi_transaction(cmd,len + 4,NULL,0)) != CFE_OK)
		goto done;

#ifndef CONFIG_ROM_EMULATOR
	do
	{
		cmd[0] = SPI_RDSR_CMD;
		if ((result = mspi_transaction(cmd,1,&data,1)) != CFE_OK)
			goto done;
	}while(data & 0x01/* busy*/);
#else
	cfe_usleep(100);
#endif

	cmd[0] = SPI_WRDI_CMD;
	result = mspi_transaction(cmd,1,NULL,0);
done:
	bspi_exit_critical();
	return result;
}

int bspi_probe(char bus, unsigned int *vendor, unsigned int *dev)
{
	unsigned char cmd[4], data[4];
    int result;
	
	cmd[0] = SPI_RDID_CMD;
	bspi_enter_critical();
	if ((result = mspi_transaction(cmd,1,data,3)) != CFE_OK)
		goto done;
    *vendor = (unsigned int)data[0];
    *dev = (unsigned int)((data[1] << 8) | data[2]);

	cmd[0] = SPI_WRDI_CMD;
	result = mspi_transaction(cmd,1,NULL,0);
done:
	bspi_exit_critical();
	return result;
}

