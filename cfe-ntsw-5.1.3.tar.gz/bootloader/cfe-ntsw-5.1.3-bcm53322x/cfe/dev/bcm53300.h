/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM53300 StrataXGS Ethernet Switch		File: bcm53300.h
    *  
    *  Author: 
    *
    *********************************************************************  
    *
    *  Copyright 2005
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef _BCM56330_H_
#define _BCM56330_H_

/* Register and field definitions for the Broadcom BCM56330.

   Support is primarily for the CPU interface (CMIC) and its
   associated DMA.

   Reference:

       StrataXGS BCM56330 Programmer's Reference
          Guide
       Document 
*/

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))


/* Know devices. */

#define K_PCI_VENDOR_BROADCOM    0x14e4
#define K_PCI_ID_BCM56304         0xb304
#define K_PCI_ID_BCM53300         0xb006
#define K_PCI_ID_BCM53301         0xb206
#define K_PCI_ID_BCM53302         0xb008


/* Basic Switch Geometry */

#define GPIC_PORTS               24
#define IPIC_PORT                26
#define CMIC_PORT                28

/* Various bit maps have a standard bit position for each relevant port. */
#define GPIC_BIT(port)           (1 << (port))
#define IPIC_BIT                 (1 << IPIC_PORT)
#define CMIC_BIT                 (1 << CMIC_PORT)


/* PCI-accessible CSRs and their fields. */

/* Extensions to PCI configuration registers */

/* FIXME : These following regsiters  are not used
#define PCI_BUS_REG              0x40

#define PCI_TRDY_SHIFT           0
#define PCI_TRDY_MASK            0xff

#define PCI_RETRY_SHIFT          8
#define PCI_RETRY_MASK           0xff */


/* CMIC Registers in PCI Memory Space (Section 4) */

#define R_CMIC_SCHAN_MESSAGES    0x0000
#define R_CMIC_SCHAN_CTRL        0x0050
/* FIXME : These following regsiters  are not used
#define R_CMIC_TABLE_DMA_ADDR    0x0054
#define R_CMIC_TABLE_DMA_SIZE    0x0058
#define R_CMIC_SCHAN_ERR         0x005C */
/* FIXME : These following regsiters  are not used
#define R_CMIC_COS_AVAILABLE(cl) (0x0060+4*(cl)) */  /* 0 <= cl <= 7 */
#define R_CMIC_DMA_CTRL          0x0100
#define R_CMIC_DMA_STAT          0x0104
/* FIXME : These following regsiters  are not used
#define R_CMIC_HOL_STAT          0x0108 */
#define R_CMIC_CONFIG            0x010C
#define R_CMIC_DMA_DESC(ch)      (0x0110+4*(ch))   /* 0 <= ch <= 3 */

/* FIXME : These following regsiters  are not used
#define R_CMIC_I2C_SLAVE_ADDR    0x0120
#define R_CMIC_I2C_DATA          0x0124
#define R_CMIC_I2C_CTRL          0x0128
#define R_CMIC_I2C_STAT          0x012C
#define R_CMIC_I2C_CCR           0x012C
#define R_CMIC_I2C_SLAVE_XADDR   0x0130
#define R_CMIC_I2C_RESET         0x013C

#define R_CMIC_LINK_STAT         0x0140 */
#define R_CMIC_IRQ_STAT          0x0144
#define R_CMIC_IRQ_MASK          0x0148
/* FIXME : These following regsiters  are not used
#define R_CMIC_MEM_FAIL          0x014C
#define R_CMIC_IBP_WARN          0x0150
#define R_CMIC_IBP_DISCARD       0x0154 */
#define R_CMIC_MIIM_PARAM        0x0158
#define R_CMIC_MIIM_READ_DATA    0x015C
/* FIXME : These following regsiters  are not used
#define R_CMIC_SCAN_PORTS        0x0160
#define R_CMIC_STAT_DMA_ADDR     0x0164
#define R_CMIC_STAT_DMA_SETUP    0x0168
#define R_CMIC_STAT_DMA_PORTS    0x016C
#define R_CMIC_STAT_DMA_CURRENT  0x0170 */
#define R_CMIC_ENDIANESS_SEL     0x0174
#define R_CMIC_DEV_REV_ID        0x0178

/* FIXME : These following regsiters  are not used
#define R_CMIC_COS_CTRL_RX       0x0180
#define R_CMIC_HGTX_CTRL1        0x0184
#define R_CMIC_HGTX_CTRL2        0x0188
#define R_CMIC_MIRRORED_PORTS_TX 0x018C
#define R_CMIC_MIRROR_TO_PORTS   0x0190
#define R_CMIC_64BIT_STATS_CFG   0x0198
#define R_CMIC_TABLE_DMA_START   0x019C

#define R_CMIC_SCHAN_MSG_DMA     0x0800 */   /* alias */

/* FIXME : The following are not used
#define R_LED_CTRL               0x1000
#define R_LED_STATUS             0x1004
#define R_LED_PROGRAM_RAM_BASE   0x1800
#define R_LED_DATA_RAM_BASE      0x1C00 */

#define R_CMIC_SBUS_RING_MAP        0x0400
#define R_CMIC_MII_ADDRESS        0x04A0
#define R_CMIC_XGXS_MDIO_CONFIG_2        0x0508
#define R_CMIC_SOFT_RESET_REG        0x0580
#define R_CMIC_XGXS_PLL_CONTROL_1        0x0584

/* SCTL: Status and Control Register (0x0050) */

/* Bit positions used for set/clear commands. */
#define S_SCTL_MSG_START         0
#define S_SCTL_MSG_DONE          1
/* FIXME : The following are not used
#define S_SCTL_TABLE_DMA_EN      6
#define S_SCTL_TABLE_DMA_DONE    7
#define S_SCTL_LINK_STAT_MSG     8
#define S_SCTL_PCI_FATAL_ERR     9
#define S_SCTL_PCI_PARITY_ERR    10
#define S_SCTL_ARL_MSG_RCV_OFF   11
#define S_SCTL_ARL_MSG_DROPPED   12
#define S_SCTL_TABLE_DMA_DONE_1  13
#define S_SCTL_CBP_OK            15 */
/* FIXME : need to be checked, S_SCTL_MIIM_RD_START and 
    S_SCTL_MIIM_WR_START are reserved bits */
#define S_SCTL_MIIM_RD_START     16
#define S_SCTL_MIIM_WR_START     17
#define S_SCTL_MIIM_OP_DONE      18
/* FIXME : The following are not used
#define S_SCTL_MIIM_LINK_SCAN_EN 19 */

#define M_SCTL_MSG_START         _DD_MAKEMASK1(S_SCTL_MSG_START)
#define M_SCTL_MSG_DONE          _DD_MAKEMASK1(S_SCTL_MSG_DONE)
/* FIXME : The following are not used
#define M_SCTL_TABLE_DMA_EN      _DD_MAKEMASK1(S_SCTL_TABLE_DMA_EN)
#define M_SCTL_TABLE_DMA_DONE    _DD_MAKEMASK1(S_SCTL_TABLE_DMA_DONE)
#define M_SCTL_LINK_STAT_MSG     _DD_MAKEMASK1(S_SCTL_LINK_STAT_MSG)
#define M_SCTL_PCI_FATAL_ERR     _DD_MAKEMASK1(S_SCTL_PCI_FATAL_ERR)
#define M_SCTL_PCI_PARITY_ERR    _DD_MAKEMASK1(S_SCTL_PCI_PARITY_ERR)
#define M_SCTL_ARL_MSG_RCV_OFF   _DD_MAKEMASK1(S_SCTL_ARL_MSG_RCV_OFF)
#define M_SCTL_ARL_MSG_DROPPED   _DD_MAKEMASK1(S_SCTL_ARL_MSG_DROPPED)
#define M_SCTL_TABLE_DMA_DONE_1  _DD_MAKEMASK1(S_SCTL_TABLE_DMA_DONE_1)
#define M_SCTL_CBP_OK            _DD_MAKEMASK1(S_SCTL_CBP_OK) */
#define M_SCTL_MIIM_RD_START     _DD_MAKEMASK1(S_SCTL_MIIM_RD_START)
#define M_SCTL_MIIM_WR_START     _DD_MAKEMASK1(S_SCTL_MIIM_WR_START)
#define M_SCTL_MIIM_OP_DONE      _DD_MAKEMASK1(S_SCTL_MIIM_OP_DONE)
/* FIXME : The following are not used
#define M_SCTL_MIIM_LINK_SCAN_EN _DD_MAKEMASK1(S_SCTL_MIIM_LINK_SCAN_EN)

#define M_SCTL_NACK              _DD_MAKEMASK1(21) */

#define S_SCTL_BIT_POS           0
/* FIXME : The following are not used
#define M_SCTL_BIT_POS           _DD_MAKEMASK(5,S_SCTL_BIT_POS) */
#define V_SCTL_BIT_POS(x)        _DD_MAKEVALUE(x,S_SCTL_BIT_POS)
/* FIXME : The following are not used
#define G_SCTL_BIT_POS(x)        _DD_GETVALUE(x,S_SCTL_BIT_POS,M_SCTL_BIT_POS) */

#define M_SCTL_BITVAL            _DD_MAKEMASK1(7)
#define V_SCTL_BIT_0             0
#define V_SCTL_BIT_1             M_SCTL_BITVAL

         
/* DMACTL: DMA Control Register (0x0100) */

#define M_CH_DIRECTION(ch)       _DD_MAKEMASK1(0+8*(ch))  /* 0 <= ch <= 3 */
#define M_CH_NO_MOD_PBMP(ch)     _DD_MAKEMASK1(1+8*(ch))
#define M_ABORT_DMA_CH(ch)       _DD_MAKEMASK1(2+8*(ch))
#define M_CH_SEL_INTR(ch)        _DD_MAKEMASK1(3+8*(ch))
#define M_DROP_TX_PRTS0_CH(ch)   _DD_MAKEMASK1(4+8*(ch))

/* DMASTAT: DMA Status Register (0x0104) */

/* Bit positions used for set/clear commands. */

#define S_CH_DMA_EN(ch)          (0+(ch))                 /* 0 <= ch <= 3 */
#define S_CH_CHAIN_DONE(ch)      (4+(ch))
#define S_CH_DESC_DONE(ch)       (8+(ch))
#define S_DMA_RESET              12
#define S_STATA_DMA_OPN_CMPLT    13
#define S_STATS_DMA_ITER_DONE    14
#define S_STATS_DMA_ACTIVE       17
#define S_CH_DMA_ACTIVE(ch)      (18+(ch))

/* FIXME : The following are not used
#define M_CH_DMA_EN(ch)          _DD_MAKEMASK1(S_CHAN_DMA_EN(ch)) 
*/
#define M_CH_CHAIN_DONE(ch)      _DD_MAKEMASK1(S_CH_CHAIN_DONE(ch))
#define M_CH_DESC_DONE(ch)       _DD_MAKEMASK1(S_CH_DESC_DONE(ch))

#define M_DMA_RESET              _DD_MAKEMASK1(S_DMA_RESET)
#define M_STATA_DMA_OPN_CMPLT    _DD_MAKEMASK1(S_STATA_DMA_OPN_CMPLT)
#define M_STATS_DMA_ITER_DONE    _DD_MAKEMASK1(S_STATS_DMA_ITER_DONE)
#define M_STATS_DMA_ACTIVE       _DD_MAKEMASK1(S_STATS_DMA_ACTIVE)

#define M_CH_DMA_ACTIVE(ch)      _DD_MAKEMASK1(S_CH_DMA_ACTIVE(ch))

/* FIXME : The following are not used
#define S_PCI_PARITY_ERR         24
#define M_PCI_PARITY_ERR         _DD_MAKEMASK(2,S_PCI_PARITY_ERR)
#define V_PCI_PARITY_ERR(x)      _DD_MAKEVALUE(x,S_PCI_PARITY_ERR)
#define G_PCI_PARITY_ERR(x)      _DD_GETVALUE(x,S_PCI_PARITY_ERR,M_PCI_PARITY_ERR)

#define S_PCI_FATAL_ERR          29
#define M_PCI_FATAL_ERR          _DD_MAKEMASK(2,S_PCI_FATAL_ERR)
#define V_PCI_FATAL_ERR(x)       _DD_MAKEVALUE(x,S_PCI_FATAL_ERR)
#define G_PCI_FATAL_ERR(x)       _DD_GETVALUE(x,S_PCI_FATAL_ERR,M_PCI_FATAL_ERR)  */

#define S_DMA_BIT_POS            0
#define M_DMA_BIT_POS            _DD_MAKEMASK(5,S_DMA_BIT_POS)
#define V_DMA_BIT_POS(x)         _DD_MAKEVALUE(x,S_DMA_BIT_POS)
#define G_DMA_BIT_POS(x)         _DD_GETVALUE(x,S_DMA_BIT_POS,M_DMA_BIT_POS)

#define M_DMA_BITVAL             _DD_MAKEMASK1(7)
#define V_DMA_BIT_0              0
#define V_DMA_BIT_1              M_DMA_BITVAL


/* CONFIG: Configuration Register (0x010C) */

#define M_RD_BRST_EN             _DD_MAKEMASK1(0)
#define M_WR_BRST_EN             _DD_MAKEMASK1(1)
/* FIXME : The following are not used
#define M_BE_CHECK_EN            _DD_MAKEMASK1(2) */
#define M_MSTR_Q_MAX_EN          _DD_MAKEMASK1(3)
/* FIXME : The following are not used
#define M_LINK_STAT_EN           _DD_MAKEMASK1(4)
#define M_RESET_CPS              _DD_MAKEMASK1(5)
#define M_ACT_LOW_INT            _DD_MAKEMASK1(6)
#define M_SCHAN_ABORT            _DD_MAKEMASK1(7)
#define M_STACK_ARCH_EN          _DD_MAKEMASK1(8)
#define M_UNTAG_EN               _DD_MAKEMASK1(9)
#define M_LE_DMA_EN              _DD_MAKEMASK1(10)
#define M_I2C_EN                 _DD_MAKEMASK1(11)
#define M_LINK_SCAN_GIG          _DD_MAKEMASK1(12) */
#define M_IGNORE_ADR_ALIGN_EN    _DD_MAKEMASK1(13)
/* FIXME : The following are not used
#define M_DMA_GARBAGE_COLLECT_EN _DD_MAKEMASK1(15)
#define M_RESET_PCI_EN           _DD_MAKEMASK1(16)
#define M_TIME_STAMP_UPD_DIS     _DD_MAKEMASK1(17) */
#define M_SG_ENABLE              _DD_MAKEMASK1(18)
#define M_SG_RELOAD_ENABLE       _DD_MAKEMASK1(19)
/* FIXME : The following are not used
#define M_RLD_STS_UPD_DIS        _DD_MAKEMASK1(20)
#define M_STOP_LS_ON_CHANGE      _DD_MAKEMASK1(21)
#define M_ABORT_STAT_DMA         _DD_MAKEMASK1(22)
#define M_LS_START_ID0           _DD_MAKEMASK1(23)
#define M_COS_RX_EN              _DD_MAKEMASK1(24)
#define M_ABORT_TBL_DMA          _DD_MAKEMASK1(25) */
#define M_EXT_MDIO_MSTR_DIS      _DD_MAKEMASK1(26)


/* IRQSTAT: Interrupt Status Register (0x0144) */
/* IRQMASK: Interrupt Mask Register (0x0148) */

/* FIXME : The following are not used
#define M_IRQ_SCH_MSG_DONE       _DD_MAKEMASK1(0)
#define M_IRQ_CBP_FULL           _DD_MAKEMASK1(3)
#define M_IRQ_LINK_STAT_MOD      _DD_MAKEMASK1(4)
#define M_IRQ_TABLE_DMA_CNT0     _DD_MAKEMASK1(6)
#define M_IRQ_DESC_DONE(ch)      _DD_MAKEMASK1(7+2*(ch)) */ /* 0 <= ch <= 3 */
#define M_IRQ_CHAIN_DONE(ch)     _DD_MAKEMASK1(8+2*(ch))
/* FIXME : The following are not used
#define M_IRQ_PCI_PARITY_ERR     _DD_MAKEMASK1(15)
#define M_IRQ_PCI_FATAL_ERR      _DD_MAKEMASK1(16)
#define M_IRQ_SCHAN_ERR          _DD_MAKEMASK1(17)
#define M_IRQ_I2C_INTR           _DD_MAKEMASK1(18)
#define M_IRQ_MIIM_OP_DONE       _DD_MAKEMASK1(19)
#define M_IRQ_STATS_DMA_ITER_DONE _DD_MAKEMASK1(20)
#define M_IRQ_ARL_BUCKET_OVR     _DD_MAKEMASK1(21) */


/* MIIMP: MIIM Parameter Register (0x0158) */

#define S_MIIMP_PHY_DATA          0
#define M_MIIMP_PHY_DATA          _DD_MAKEMASK(16,S_MIIMP_PHY_DATA)
#define V_MIIMP_PHY_DATA(x)       _DD_MAKEVALUE(x,S_MIIMP_PHY_DATA)
#define G_MIIMP_PHY_DATA(x)       _DD_GETVALUE(x,S_MIIMP_PHY_DATA,M_MIIMP_PHY_DATA)

#define S_MIIMP_PHY_ID            16
#define M_MIIMP_PHY_ID            _DD_MAKEMASK(5,S_MIIMP_PHY_ID)
#define V_MIIMP_PHY_ID(x)         _DD_MAKEVALUE(x,S_MIIMP_PHY_ID)
#define G_MIIMP_PHY_ID(x)         _DD_GETVALUE(x,S_MIIMP_PHY_ID,M_MIIMP_PHY_ID)

#define M_MIIMP_INTERNAL_SEL      _DD_MAKEMASK1(23)

/* FIXME : PHY_REG need to be checked */
#define S_MIIMP_PHY_REG           24
#define M_MIIMP_PHY_REG           _DD_MAKEMASK(5,S_MIIMP_PHY_REG)
#define V_MIIMP_PHY_REG(x)        _DD_MAKEVALUE(x,S_MIIMP_PHY_REG)
#define G_MIIMP_PHY_REG(x)        _DD_GETVALUE(x,S_MIIMP_PHY_REG,M_MIIMP_PHY_REG)

/* MIIMRD: MIIM Read Data Register (0x015C) */

#define S_MIIMRD_DATA             0
#define M_MIIMRD_DATA             _DD_MAKEMASK(16,S_MIIMRD_DATA)
#define V_MIIMRD_DATA(x)          _DD_MAKEVALUE(x,S_MIIMRD_DATA)
#define G_MIIMRD_DATA(x)          _DD_GETVALUE(x,S_MIIMP_PHY_DATA,M_MIIMP_PHY_DATA)


/* ID: Device/Revision Module ID Register (0x0178) */

#define S_ID_DEV_ID               0
#define M_ID_DEV_ID               _DD_MAKEMASK(16,S_ID_DEV_ID)
#define V_ID_DEV_ID(x)            _DD_MAKEVALUE(x,S_ID_DEV_ID)
#define G_ID_DEV_ID(x)            _DD_GETVALUE(x,S_ID_DEV_ID,M_ID_DEV_ID)

#define S_ID_REV_ID               16
#define M_ID_REV_ID               _DD_MAKEMASK(8,S_ID_REV_ID)
#define V_ID_REV_ID(x)            _DD_MAKEVALUE(x,S_ID_REV_ID)
#define G_ID_REV_ID(x)            _DD_GETVALUE(x,S_ID_REV_ID,M_ID_REV_ID)

#define S_ID_MOD_ID               24
#define M_ID_MOD_ID               _DD_MAKEMASK(8,S_ID_MOD_ID)
#define V_ID_MOD_ID(x)            _DD_MAKEVALUE(x,S_ID_MOD_ID)
#define G_ID_MOD_ID(x)            _DD_GETVALUE(x,S_ID_MOD_ID,M_ID_MOD_ID)


/* DMA Control Block (DCB) Format (Section 18). */

/* Each DCB is 8 32-bit words.  The fields are defined below by word
   offset.  */

#define S_DCB0_MEM_ADDR          0
#define M_DCB0_MEM_ADDR          _DD_MAKEMASK(32,S_DCB0_MEM_ADDR)
#define V_DCB0_MEM_ADDR(x)       _DD_MAKEVALUE(x,S_DCB0_MEM_ADDR)
#define G_DCB0_MEM_ADDR(x)       _DD_GETVALUE(x,S_DCB0_MEM_ADDR,M_DCB0_MEM_ADDR)

#define S_DCB1_BYTE_COUNT        0
#define M_DCB1_BYTE_COUNT        _DD_MAKEMASK(15,S_DCB1_BYTE_COUNT)
#define V_DCB1_BYTE_COUNT(x)     _DD_MAKEVALUE(x,S_DCB1_BYTE_COUNT)
#define G_DCB1_BYTE_COUNT(x)     _DD_GETVALUE(x,S_DCB1_BYTE_COUNT,M_DCB1_BYTE_COUNT)


#define M_DCB1_CRC_REGEN         _DD_MAKEMASK1(15)
#define M_DCB1_L3_MOD_EGRESS          _DD_MAKEMASK1(16)
#define M_DCB1_RLD               _DD_MAKEMASK1(17)
#define M_DCB1_SG                _DD_MAKEMASK1(18)
#define M_DCB1_L3_STATS                _DD_MAKEMASK1(19)

#define S_DCB1_MH_OPCODE       20
#define M_DCB1_MH_OPCODE        _DD_MAKEMASK(4,S_DCB1_MH_OPCODE)
#define V_DCB1_MH_OPCODE(x)    _DD_MAKEVALUE(x,S_DCB1_MH_OPCODE)
#define G_DCB1_MH_OPCODE(x)    _DD_GETVALUE(x,S_DCB1_DST_PORT_30,M_DCB1_MH_OPCODE)

#define M_DCB1_ING_TAGGED       _DD_MAKEMASK1(24)

#define S_DCB1_MH_PRIORITY       25
#define M_DCB1_MH_PRIORITY        _DD_MAKEMASK(3,S_DCB1_MH_PRIORITY)
#define V_DCB1_MH_PRIORITY(x)    _DD_MAKEVALUE(x,S_DCB1_MH_PRIORITY)
#define G_DCB1_MH_PRIORITY(x)    _DD_GETVALUE(x,S_DCB1_MH_PRIORITY,M_DCB1_MH_PRIORITY)

#define S_DCB1_COS               28
#define M_DCB1_COS               _DD_MAKEMASK(3,S_DCB1_COS)
#define V_DCB1_COS(x)            _DD_MAKEVALUE(x,S_DCB1_COS)
#define G_DCB1_COS(x)            _DD_GETVALUE(x,S_DCB1_COS,M_DCB1_COS)

#define M_DCB1_C                 _DD_MAKEMASK1(31)

#define S_DCB2_PORT_MAP          0
#define M_DCB2_PORT_MAP          _DD_MAKEMASK(32,S_DCB2_PORT_MAP)
#define V_DCB2_PORT_MAP(x)       _DD_MAKEVALUE(x,S_DCB2_PORT_MAP)
#define G_DCB2_PORT_MAP(x)       _DD_GETVALUE(x,S_DCB2_PORT_MAP,M_DCB2_PORT_MAP)

#define S_DCB3_UNTAGGED_MAP      0
#define M_DCB3_UNTAGGED_MAP      _DD_MAKEMASK(32,S_DCB3_UNTAGGED_MAP)
#define V_DCB3_UNTAGGED_MAP(x)   _DD_MAKEVALUE(x,S_DCB3_UNTAGGED_MAP)
#define G_DCB3_UNTAGGED_MAP(x)   _DD_GETVALUE(x,S_DCB3_UNTAGGED_MAP,M_DCB3_UNTAGGED_MAP)

#define S_DCB4_L3_MAP            0
#define M_DCB4_L3_MAP            _DD_MAKEMASK(32,S_DCB4_L3_MAP)
#define V_DCB4_L3_MAP(x)         _DD_MAKEVALUE(x,S_DCB4_L3_MAP)
#define G_DCB4_L3_MAP(x)         _DD_GETVALUE(x,S_DCB4_L3_MAP,M_DCB4_L3_MAP)

#define S_DCB5_DST_MOD_ID      0
#define M_DCB5_DST_MOD_ID          _DD_MAKEMASK(7,S_DCB5_DST_MOD_ID)
#define V_DCB5_DST_MOD_ID(x)       _DD_MAKEVALUE(x,S_DCB5_DST_MOD_ID)
#define G_DCB5_DST_MOD_ID(x)       _DD_GETVALUE(x,S_DCB5_DST_MOD_ID,M_DCB5_DST_MOD_ID)

#define S_DCB5_DST_PORT      7
#define M_DCB5_DST_PORT          _DD_MAKEMASK(6,S_DCB5_DST_PORT)
#define V_DCB5_DST_PORT(x)       _DD_MAKEVALUE(x,S_DCB5_DST_PORT)
#define G_DCB5_DST_PORT(x)       _DD_GETVALUE(x,S_DCB5_DST_PORT,M_DCB5_DST_PORT)

#define S_DCB5_SRC_MOD_ID      13
#define M_DCB5_SRC_MOD_ID          _DD_MAKEMASK(7,S_DCB5_SRC_MOD_ID)
#define V_DCB5_SRC_MOD_ID(x)       _DD_MAKEVALUE(x,S_DCB5_SRC_MOD_ID)
#define G_DCB5_SRC_MOD_ID(x)       _DD_GETVALUE(x,S_DCB5_SRC_MOD_ID,M_DCB5_SRC_MOD_ID)

#define S_DCB5_SRC_PORT_TGID      20
#define M_DCB5_SRC_PORT_TGID          _DD_MAKEMASK(6,S_DCB5_SRC_PORT_TGID)
#define V_DCB5_SRC_PORT_TGID(x)       _DD_MAKEVALUE(x,S_DCB5_SRC_PORT_TGID)
#define G_DCB5_SRC_PORT_TGID(x)       _DD_GETVALUE(x,S_DCB5_SRC_PORT_TGID,M_DCB5_SRC_PORT_TGID)

#define S_DCB5_PFM      26
#define M_DCB5_PFM          _DD_MAKEMASK(2,S_DCB5_PFM)
#define V_DCB5_PFM(x)       _DD_MAKEVALUE(x,S_DCB5_PFM)
#define G_DCB5_PFM(x)       _DD_GETVALUE(x,S_DCB5_PFM,M_DCB5_PFM)

#define M_DCB5_SMP                 _DD_MAKEMASK1(28)

#define S_DCB6_RCV_COUNT         0
#define M_DCB6_RCV_COUNT         _DD_MAKEMASK(16,S_DCB6_RCV_COUNT)
#define V_DCB6_RCV_COUNT(x)      _DD_MAKEVALUE(x,S_DCB6_RCV_COUNT)
#define G_DCB6_RCV_COUNT(x)      _DD_GETVALUE(x,S_DCB6_RCV_COUNT,M_DCB6_RCV_COUNT)

#define M_DCB6_CRC_REGEN_P       _DD_MAKEMASK1(16)
#define M_DCB6_ING_TAGGED        _DD_MAKEMASK1(17)
#define M_DCB6_L3_BITMAP         _DD_MAKEMASK1(18)
#define M_DCB6_S         _DD_MAKEMASK1(19)

#define S_DCB6_COSW      20
#define M_DCB6_COSW          _DD_MAKEMASK(3,S_DCB6_COSW)
#define V_DCB6_COSW(x)       _DD_MAKEVALUE(x,S_DCB6_COSW)
#define G_DCB6_COSW(x)       _DD_GETVALUE(x,S_DCB6_COSW,M_DCB6_COSW)

#define M_DCB6_ER         _DD_MAKEMASK1(23)
#define M_DCB6_EW         _DD_MAKEMASK1(24)

#define S_DCB6_SRC_PORT      25
#define M_DCB6_SRC_PORT          _DD_MAKEMASK(6,S_DCB6_SRC_PORT)
#define V_DCB6_SRC_PORT(x)       _DD_MAKEVALUE(x,S_DCB6_SRC_PORT)
#define G_DCB6_SRC_PORT(x)       _DD_GETVALUE(x,S_DCB6_SRC_PORT,M_DCB6_SRC_PORT)

#define M_DCB6_CNG         _DD_MAKEMASK1(31)

#define S_DCB7_SRC_PORT_TGID      0
#define M_DCB7_SRC_PORT_TGID          _DD_MAKEMASK(6,S_DCB7_SRC_PORT_TGID)
#define V_DCB7_SRC_PORT_TGID(x)       _DD_MAKEVALUE(x,S_DCB7_SRC_PORT_TGID)
#define G_DCB7_SRC_PORT_TGID(x)       _DD_GETVALUE(x,S_DCB7_SRC_PORT_TGID,M_DCB7_SRC_PORT_TGID)

#define S_DCB7_SRC_MOD_ID      6
#define M_DCB7_SRC_MOD_ID          _DD_MAKEMASK(7,S_DCB7_SRC_MOD_ID)
#define V_DCB7_SRC_MOD_ID(x)       _DD_MAKEVALUE(x,S_DCB7_SRC_MOD_ID)
#define G_DCB7_SRC_MOD_ID(x)       _DD_GETVALUE(x,S_DCB7_SRC_MOD_ID,M_DCB7_SRC_MOD_ID)

#define S_DCB7_MH_OPCODE       26
#define M_DCB7_MH_OPCODE        _DD_MAKEMASK(4,S_DCB7_MH_OPCODE)
#define V_DCB7_MH_OPCODE(x)    _DD_MAKEVALUE(x,S_DCB7_MH_OPCODE)
#define G_DCB7_MH_OPCODE(x)    _DD_GETVALUE(x,S_DCB7_MH_OPCODE,M_DCB7_MH_OPCODE)

#define S_DCB7_PFM      30
#define M_DCB7_PFM          _DD_MAKEMASK(2,S_DCB7_PFM)
#define V_DCB7_PFM(x)       _DD_MAKEVALUE(x,S_DCB7_PFM)
#define G_DCB7_PFM(x)       _DD_GETVALUE(x,S_DCB7_PFM,M_DCB7_PFM)

/* DCB8 used for testing only */

#define S_DCB9_CPU_OPCODES       0
#define M_DCB9_CPU_OPCODES       _DD_MAKEMASK(24,S_DCB9_CPU_OPCODES)
#define V_DCB9_CPU_OPCODES(x)    _DD_MAKEVALUE(x,S_DCB9_CPU_OPCODES)
#define G_DCB9_CPU_OPCODES(x)    _DD_GETVALUE(x,S_DCB9_CPU_OPCODES,M_DCB9_CPU_OPCODES)

/* FIXME : The following are not used
#define M_OPC_CPU_UVLAN          _DD_MAKEMASK1(0)
#define M_OPC_CPU_SLF            _DD_MAKEMASK1(1)
#define M_OPC_CPU_DLF            _DD_MAKEMASK1(2)
#define M_OPC_CPU_L2MOVE         _DD_MAKEMASK1(3)
#define M_OPC_CPU_L2CPU          _DD_MAKEMASK1(4)
#define M_OPC_CPU_EZRMON_SRC     _DD_MAKEMASK1(5)
#define M_OPC_CPU_EZRMON_DST     _DD_MAKEMASK1(6)
#define M_OPC_CPU_L3SRC_MISS     _DD_MAKEMASK1(7)
#define M_OPC_CPU_L3DST_MISS     _DD_MAKEMASK1(8)
#define M_OPC_CPU_L3SRC_MOVE     _DD_MAKEMASK1(9)
#define M_OPC_CPU_MC_MISS        _DD_MAKEMASK1(10)
#define M_OPC_CPU_IPMC_MISS      _DD_MAKEMASK1(11)
#define M_OPC_CPU_FFP            _DD_MAKEMASK1(12)
#define M_OPC_CPU_L3HDR_ERR      _DD_MAKEMASK1(13)
#define M_OPC_CPU_PROTO_PKT      _DD_MAKEMASK1(14) */

#define S_DCB9_HDR       26
#define M_DCB9_HDR       _DD_MAKEMASK(2,S_DCB9_HDR)
#define V_DCB9_HDR(x)    _DD_MAKEVALUE(x,S_DCB9_HDR)
#define G_DCB9_HDR(x)    _DD_GETVALUE(x,S_DCB9_HDR,M_DCB9_HDR)

#define S_DCB9_MH_PRIORITY       28
#define M_DCB9_MH_PRIORITY       _DD_MAKEMASK(3,S_DCB9_MH_PRIORITY)
#define V_DCB9_MH_PRIORITY(x)    _DD_MAKEVALUE(x,S_DCB9_MH_PRIORITY)
#define G_DCB9_MH_PRIORITY(x)    _DD_GETVALUE(x,S_DCB9_MH_PRIORITY,M_DCB9_MH_PRIORITY)

#define M_DCB9_DONE         _DD_MAKEMASK1(31)

/* S-Channel Message Formats and Codes */

/* FIXME : The following are not used
#define SC_BLOCK_GPIC(n)         (0x0+(n))
#define SC_BLOCK_IPIC            0xC
#define SC_BLOCK_MMU             0xD */
#define SC_BLOCK_CMIC            0xF

#define M_SMHDR_C                _DD_MAKEMASK1(0)

#define S_SMHDR_COS              1
#define M_SMHDR_COS              _DD_MAKEMASK(3,S_SMHDR_COS)
#define V_SMHDR_COS(x)           _DD_MAKEVALUE(x,S_SMHDR_COS)
#define G_SMHDR_COS(x)           _DD_GETVALUE(x,S_SMHDR_COS,M_SMHDR_COS)

#define S_SMHDR_ECODE            4
#define M_SMHDR_ECODE            _DD_MAKEMASK(2,S_SMHDR_ECODE)
#define V_SMHDR_ECODE(x)         _DD_MAKEVALUE(x,S_SMHDR_ECODE)
#define G_SMHDR_ECODE(x)         _DD_GETVALUE(x,S_SMHDR_ECODE,M_SMHDR_ECODE)

#define M_SMHDR_E                _DD_MAKEMASK1(6)

#define S_SMHDR_DATA_LEN         7
#define M_SMHDR_DATA_LEN         _DD_MAKEMASK(7,S_SMHDR_DATA_LEN)
#define V_SMHDR_DATA_LEN(x)      _DD_MAKEVALUE(x,S_SMHDR_DATA_LEN)
#define G_SMHDR_DATA_LEN(x)      _DD_GETVALUE(x,S_SMHDR_DATA_LEN,M_SMHDR_DATA_LEN)

#define S_SMHDR_SRC_BLOCK        14
#define M_SMHDR_SRC_BLOCK        _DD_MAKEMASK(6,S_SMHDR_SRC_BLOCK)
#define V_SMHDR_SRC_BLOCK(x)     _DD_MAKEVALUE(x,S_SMHDR_SRC_BLOCK)
#define G_SMHDR_SRC_BLOCK(x)     _DD_GETVALUE(x,S_SMHDR_SRC_BLOCK,M_SMHDR_SRC_BLOCK)

#define S_SMHDR_DEST_BLOCK       20
#define M_SMHDR_DEST_BLOCK       _DD_MAKEMASK(6,S_SMHDR_DEST_BLOCK)
#define V_SMHDR_DEST_BLOCK(x)    _DD_MAKEVALUE(x,S_SMHDR_DEST_BLOCK)
#define G_SMHDR_DEST_BLOCK(x)    _DD_GETVALUE(x,S_SMHDR_DEST_BLOCK,M_SMHDR_DEST_BLOCK)

#define S_SMHDR_OP_CODE          26
#define M_SMHDR_OP_CODE          _DD_MAKEMASK(6,S_SMHDR_OP_CODE)
#define V_SMHDR_OP_CODE(x)       _DD_MAKEVALUE(x,S_SMHDR_OP_CODE)
#define G_SMHDR_OP_CODE(x)       _DD_GETVALUE(x,S_SMHDR_OP_CODE,M_SMHDR_OP_CODE)

#define SC_OP_RD_MEM_CMD         0x07
#define SC_OP_RD_MEM_ACK         0x08
#define SC_OP_WR_MEM_CMD         0x09
#define SC_OP_RD_REG_CMD         0x0B
#define SC_OP_RD_REG_ACK         0x0C
#define SC_OP_WR_REG_CMD         0x0D
#define SC_OP_L2_INS_CMD         0x0F
#define SC_OP_L2_DEL_CMD         0x11

/* switch register */
#define PORTS_PER_BLOCK     12
#define R_GPORT_W_BLOCK(g, p,offset)         (((g) << 20) | ((p) << 12) | offset)
#define R_GPORT(p,offset)         (((p) << 12) | offset)
#define R_BLOCK(g,offset)         (((g) << 20) | offset)

/* register with block parameter */
#define R_GMACC0(g, p)              R_GPORT_W_BLOCK(g, p,0x100)
#define R_GMACC1(g, p)              R_GPORT_W_BLOCK(g, p,0x101)
#define R_GMACC2(g, p)              R_GPORT_W_BLOCK(g, p,0x102)
#define R_GPCSC(g, p)             R_GPORT_W_BLOCK(g, p,0x103)
#define R_GSA0(g, p)             R_GPORT_W_BLOCK(g, p,0x104)
#define R_GSA1(g, p)             R_GPORT_W_BLOCK(g, p,0x105)
#define R_MAXFR(g, p)             R_GPORT_W_BLOCK(g, p,0x108)
#define R_GTH_FE_MAC1(g, p)             R_GPORT_W_BLOCK(g, p,0x200)
#define R_GTH_FE_MAC2(g, p)             R_GPORT_W_BLOCK(g, p,0x201)
#define R_GTH_FE_IPGT(g, p)             R_GPORT_W_BLOCK(g, p,0x202)
#define R_GTH_FE_IPGR(g, p)             R_GPORT_W_BLOCK(g, p,0x203)
#define R_GTH_FE_CLRT(g, p)             R_GPORT_W_BLOCK(g, p,0x204)
#define R_GTH_FE_MAXF(g, p)             R_GPORT_W_BLOCK(g, p,0x205)
#define R_GTH_FE_SUPP(g, p)             R_GPORT_W_BLOCK(g, p,0x206)
#define R_GTH_ESA0(g, p)             R_GPORT_W_BLOCK(g, p,0x210)
#define R_GTH_ESA1(g, p)             R_GPORT_W_BLOCK(g, p,0x211)
#define R_GTH_ESA2(g, p)             R_GPORT_W_BLOCK(g, p,0x212)
#define R_GE_PORT_CONFIG(g, p)              R_GPORT_W_BLOCK(g, p, 0x300)
#define R_PAUSE_CONTROL(g, p)              R_GPORT_W_BLOCK(g, p, 0x302)

/* register with block parameter only */
#define R_GPORT_CONFIG(g)              R_BLOCK(g, 0x80000)

/* register without block parameter */
#define R_HOLCOSPKTSETLIMIT(p)              R_GPORT(p, 0x600010)
#define R_GEGR_ENABLE(p)         R_GPORT(p, 0x0A900100)
#define R_UNKNOWN_UCAST_BLOCK_MASK(p)         R_GPORT(p, 0x0E700100)
#define R_BCAST_BLOCK_MASK(p)         R_GPORT(p, 0x0E700102)
#define R_PROTOCOL_PKT_CONTROL(p)              R_GPORT(p, 0xB700006)
#define R_EGR_PORT(p)         R_GPORT(p, 0x01900002)

/* register without any parameter */
#define R_MAC_CTRL          0x400000
#define R_MAC_XGXS_CTRL          0x400001
#define R_MAC_TXCTRL          0x400007
#define R_MAC_TXMAXSE          0x400009
#define R_MAC_RXCTRL          0x400021
#define R_MAC_RXMAXSE          0x400023
#define R_XPORT_CONFIG          0x480000

#define R_CPU_CONTROL_1          0x0B780004
#define R_EPC_LINK_BMAP           0x0E78010B
#define R_CPU_CONTROL_2          0x0E780115
#define R_ING_CONFIG            0x01780000
#define R_VLAN_CTRL            0x01780002
#define R_CFAPCONFIG            0x00680010
#define R_CFAPREADPINTER            0x00680011
#define R_CFAPFULLTHRESHOLD            0x00680012
#define R_PKTAGINGTIMER            0x00680013
#define R_MISCCONFIG            0x00680015
#define R_MMUPORTENABLE          0x0068001D
#define R_MEMFAILINTMASK         0x00680030
#define R_MEMFAILINTSTATUS         0x00680031
#define R_ING_HW_RESET_CONTROL_1          0x00780001
#define R_ING_HW_RESET_CONTROL_2          0x00780002
#define R_EGR_HW_RESET_CONTROL_0          0x00980000
#define R_EGR_HW_RESET_CONTROL_1          0x00980001
#define R_EPC_LINK_BMAP          0x0E78010B

/* Table S-Channel Base Addresses */
/* FIXME : The following are not used
#define M_L2_TABLE               0x01E00000
#define M_L2_HIT_BITS            0x01E10000
#define M_L2_STATIC_BITS         0x01E20000
#define M_L2_VALID_BITS          0x01E30000
#define M_L2MC_TABLE             0x01E40000 */
#define M_L2_ENTRY               0x06700000

#define M_PORT                   0x01700000
#define M_EGRESS_MASK            0x0E700000
#define M_MODPORT_MAP                   0x0E750000

/* FIXME : The following are not used
#define M_PORT_TRUNK_EGRESS      0x02E20000 */
#define M_PORT_MAC_BLOCK         0x0E740000

#define M_VLAN                   0x05700000
#define M_VLAN_STG               0x05710000

#define M_EGR_VLAN                   0x04910000
#define M_EGR_VLAN_STG               0x04920000

/* FIXME : The following are not used
#define M_TRUNK_GROUP            0x04E00000
#define M_TRUNK_BITMAP           0x04E10000 */

/* Table Size */
#define M_EGRESS_MASK_SIZE 2048
#define M_VLAN_SIZE 4096
#define M_STG_SIZE 256
#define M_MAC_BLOCK_SIZE 32

/* SGMII/SerDes PHY Registers (16 bits) */

#define R_MII_CONTROL            0x00
#define R_MII_STATUS             0x01
#define R_AN_ADV                 0x04
#define R_AN_LP_ABILITY          0x05
#define R_AN_EXPANSION           0x06
#define R_SGMII_CONTROL          0x0B
#define R_SGMII_STATUS           0x0C
#define R_SGMII_MISC             0x0E
#define R_SGMII_CONTROL_2        0x0F
#define R_SERDES_TX_CONTROL      0x10
#define R_SERDES_RX_CONTROL      0x11
#define R_SERDES_PHASE_CONTROL   0x12
#define R_MISC_CONTROL           0x14
#define R_MISC_STATUS            0x15
#define R_SERDES_PLL_CONTROL     0x16
#define R_SERDES_MUX_CONTROL     0x17
#define R_SERDES_PRBS_CONTROL    0x18
#define R_SERDES_PRBS_STATUS     0x19
#define R_SERDES_BERT_IPG        0x1A
#define R_SERDES_BERT_CONTROL    0x1B
#define R_SERDES_BERT_OVFL       0x1C
#define R_SERDES_BERT_MDIO_CTRL  0x1D
#define R_SERDES_BERT_MDIO_DATA  0x1E


/* SGMII: SGMII Control Register (0x0B) */

#define M_SGMII_TBI_LOOPBACK     _DD_MAKEMASK1(0)
#define M_SGMII_REMOTE_LPBK      _DD_MAKEMASK1(1)
#define M_SGMII_SG_AN_ENABLE     _DD_MAKEMASK1(2)
#define M_SGMII_AN_TEST_MODE     _DD_MAKEMASK1(3)
#define M_SGMII_CDET_EN          _DD_MAKEMASK1(4)
#define M_SGMII_SHORT_LATENCY_EN _DD_MAKEMASK1(5)
#define M_SGMII_EXT_CTRL         _DD_MAKEMASK1(6)
#define M_SGMII_REV_PHASE        _DD_MAKEMASK1(7)
#define M_SGMII_ERR_TIMER_EN     _DD_MAKEMASK1(8)
#define M_SGMII_AN_SEL           _DD_MAKEMASK1(10)

#define S_SGMII_PAUSE            11
#define M_SGMII_PAUSE            _DD_MAKEMASK(2,S_SGMII_PAUSE)
#define V_SGMII_PAUSE(x)         _DD_MAKEVALUE(x,S_SGMII_PAUSE)
#define G_SGMII_PAUSE(x)         _DD_GETVALUE(x,S_SGMII_PAUSE,M_SGMII_PAUSE)

#define S_SGMII_REMOTE_FAULT     13
#define M_SGMII_REMOTE_FAULT     _DD_MAKEMASK(2,S_SGMII_REMOTE_FAULT)
#define V_SGMII_REMOTE_FAULT(x)  _DD_MAKEVALUE(x,S_SGMII_REMOTE_FAULT)
#define G_SGMII_REMOTE_FAULT(x)  _DD_GETVALUE(x,S_SGMII_REMOTE_FAULT,M_SGMII_REMOTE_FAULT)

#define M_SGMII_FORCE_DATA_MODE  _DD_MAKEMASK1(15)

/* SGMII2: SGMII Control Register 2 (0x0F) */

#define M_SGMII2_FIBER_MODE      _DD_MAKEMASK1(0)
#define M_SGMII2_EN10B           _DD_MAKEMASK1(1)

/* MISC: Misc Control Register (0x14) */

#define M_MISC_LINK_STATUS       _DD_MAKEMASK1(0)
#define M_MISC_MAC_MODE          _DD_MAKEMASK1(1)
#define M_MISC_SGMII_ENABLE      _DD_MAKEMASK1(2)
#define M_MISC_SIGNAL_DETECT     _DD_MAKEMASK1(3)
#define M_MISC_SGMII_STATUS_CLR  _DD_MAKEMASK1(4)
#define M_MISC_IDDQ_MODE         _DD_MAKEMASK1(5)


/* PHY */
#define R_BASIC_MODE_CTRL_REG     0x00
#define R_BASIC_MODE_CTRL_RESTART_AN   (1 << 9) 	/* 1000 FULL capability */

#define R_AN_ADVERTISE_REG     0x04
#define R_AN_ADVERTISE_100_T_FULL   (1 << 8) 	/* 100 FULL capability */
#define R_AN_ADVERTISE_100_T_HALF   (1 << 7) 	/* 100 HALF capability */
#define R_AN_ADVERTISE_10_T_FULL   (1 << 6) 	/* 10 FULL capability */
#define R_AN_ADVERTISE_10_T_HALF   (1 << 5) 	/* 10 HALF capability */

#define R_1000_BASE_T_CTRL_REG     0x09
#define R_1000_BASE_T_1000_FULL   (1 << 9) 	/* 1000 FULL capability */
#define R_1000_BASE_T_1000_HALF   (1 << 8) 	/* 1000 HALF capability */

/* HiGig (XGXS) PHY Registers (16 bits) */
/* Registers accessible in all blocks */
/* FIXME : need to be checked */
#define R_XGXS_CONTROL            0x00
#define R_XGXS_STAT               0x01
#define R_XGXS_PHYID_LO           0x02
#define R_XGXS_PHYID_HI           0x03
#define R_XGXS_BLKNO              0x1F

/* phy 56xxx */
/* 1000X Control #1 Register: Controls 10B/SGMII mode */
#define DDS_1000X_CTRL1_REG     0x10
#define DDS_1000X_FIBER_MODE   (1 << 0) 	/* Enable SGMII fiber mode */
#define DDS_1000X_EN10B_MODE   (1 << 1) 	/* Enable TBI 10B interface */
#define DDS_1000X_INVERT_SD    (1 << 3) 	/* Invert Signal Detect */

#endif /* _BCM53300_H_ */
