/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5345 Gigabit Switching Processor		File: bcm5345.h
    *  
    *  Author: Ed Satterthwaite
    *
    *********************************************************************  
    *
    *  Copyright 2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef _BCM5345_H_
#define _BCM5345_H_

/* Register and field definitions for the Broadcom RoboSwitch-HS
   (BCM534x/Modena) family of gigabit ethernet managed switches.

   Support is primarily for the CPU interface (PCI) and its
   associated DMA.

   Reference:
       BCM5345M 24-Gigabit Switching Processor Data Sheet
       Document 5345M-DS01-R (10/21/03)
       Broadcom Corp., 1625 Alton Parkway, Irvine CA.
*/

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))


/* Known devices. */

#define K_PCI_VENDOR_BROADCOM    0x14E4
#define K_PCI_ID_BCM5345         0x5635


/* Basic Switch Geometry */

#define GE_PORTS                 24

/* The CPU is not a full-fledged port but appears in some bit maps. */
#define CPU_PORT                 24

/* Various bit maps have a standard bit position for each relevant
   port.  Note that the bit numbering is 0-origin, as are the pin
   names, but some of the documentation uses 1-origin port naming.  */
#define GE_BIT(port)             (1 << (port))
#define CPU_BIT                  (1 << CPU_PORT)


/* Extensions to PCI configuration registers */

/* XXX Undocumented, but includes power management capability. XXX */


/* PCI-accessible CSRs and their fields. */

/* Registers Numbers (Section 5) */

/* CPU Access Only Registers (32 bit) */

#define R_CPU_COMMAND            0x0000
#define R_TABLE_ACCESS_ENTRY_ID  0x0004
#define R_TABLE_DATA_BUFFER_0    0x0008
#define R_TABLE_DMA_ADDRESS      R_TABLE_DATA_BUFFER_0
#define R_TABLE_DATA_BUFFER_1    0x000C
#define R_TABLE_DATA_BUFFER_2    0x0010
#define R_CPU_INTERRUPT_VECTOR   0x0014
#define R_CPU_INTERRUPT_MASK     0x0018

#define R_DMA_CHANNEL_POINTERS   0x001C

#define R_RX_DMA_CHANNEL_0       0x0020
#define R_RX_DMA_CHANNEL_1       0x0024
#define R_RX_DMA_CHANNEL_2       0x0028
#define R_RX_DMA_CHANNEL_3       0x002C
#define R_RX_DMA_CHANNEL(n)      (R_RX_DMA_CHANNEL_0 + 4*(n))

#define R_TX_DMA_CHANNEL_0       0x0030
#define R_TX_DMA_CHANNEL_1       0x0034
#define R_TX_DMA_CHANNEL_2       0x0038
#define R_TX_DMA_CHANNEL_3       0x003C
#define R_TX_DMA_CHANNEL(n)      (R_TX_DMA_CHANNEL_0 + 4*(n))

#define R_SYSTEM_STATUS          0x0040
#define R_DEVICE_INFO            0x0044

/* Initialization Registers (16-bit) */

#define R_EEPROM_INIT_SETUP_1    0x0050
#define R_EEPROM_INIT_SETUP_2    0x0054
#define R_EEPROM_INIT_SETUP_3    0x0058
#define R_PCI_SETUP              0x005C
#define R_PHY_ADDR               0x0060
#define R_MGMT_PORT_MAC_ADDR_1   0x0064
#define R_MGMT_PORT_MAC_ADDR_2   0x0068
#define R_MGMT_PORT_MAC_ADDR_3   0x006C
#define R_MGMT_PORT_ETHERTYPE    0x0070

/* Search Engine Registers (16-bit) */

#define R_L2_CONTROL             0x0074
#define R_AGING_TIMER_CONTROL    0x0078
#define R_TRUNK_SETUP_0          0x007C
#define R_TRUNK_SETUP(n)         (R_TRUNK_SETUP_0 + 4*(n))
#define R_TRUNK_DIST_SELECTION   0x0094
#define R_RAPID_SPANNING_TREE    0x0098
#define R_PORT_BASED_VLAN_0      0x009C
#define R_PORT_BASED_VLAN(n)     (R_PORT_BASED_VLAN_0 + 4*(n))
#define R_PORT_VLAN_MAP_0        0x012C
#define R_PORT_VLAN_MAP_1        0x0130
#define R_CPU_VLAN_MEMBER_0      0x0134
#define R_CPU_VLAN_MEMBER_1      0x0138
#define R_L2_PORT_CONFIG_0       0x013C
#define R_L2_PORT_CONFIG(n)      (R_L2_PORT_CONFIG_0 + 4*(n))

/* Shared Buffer Registers (16-bit) */

#define R_SHARED_BUFFER_CONTROL  0x01A0
#define R_PQ_WEIGHTED_RR_GE      0x01A4
#define R_PQ_WEIGHTED_RR_CPU     0x01A8
#define R_CPU_CLASS_TO_QUEUE_1   0x01AC
#define R_CPU_CLASS_TO_QUEUE_2   0x01B0
#define R_OUTPUT_QUEUE_MAX_GE_0  0x01B4
#define R_OUTPUT_QUEUE_MAX_GE_1  0x01B8
#define R_OUTPUT_QUEUE_MAX_CPU_0 0x01BC
#define R_OUTPUT_QUEUE_MAX_CPU_1 0x01C0
#define R_OUTPUT_QUEUE_MGMT_0    0x01C4
#define R_OUTPUT_QUEUE_MGMT(n)   (R_OUTPUT_QUEUE_MGMT_0 + 4*(n))
#define R_BUFFER_MGMT_1          0x01E4
#define R_BUFFER_MGMT_2          0x01E8
#define R_BUFFER_MGMT_3          0x01EC

/* Global GE Port Configuration Registers (16-bit) */

#define R_GE_PORT_CONTROL_1      0x0200
#define R_GE_PORT_CONTROL_2      0x0204
#define R_PRIORITY_QUEUE_ASGN    0x0208
#define R_DIFFSERV_QUEUE_ASGN    0x020C
#define R_VENDOR_PHY_CONFIG      0x022C
#define R_MAC_CONFIG             0x0230
#define R_PORT_MONITORING_CONFIG 0x0234
#define R_TRAP_SNOOP             0x0238
#define R_CUSTOMER_BPDU_0_0      0x023C
#define R_CUSTOMER_BPDU_0(n)     (R_CUSTOMER_BPDU_0_0 + 4*(n))
#define R_CUSTOMER_BPDU_1_0      0x0248
#define R_CUSTOMER_BPDU_1(n)     (R_CUSTOMER_BPDU_1_0 + 4*(n))
#define R_STATION_MAC_ADDR_0     0x0254
#define R_STATION_MAC_ADDR(n)    (R_STATION_MAC_ADDR_0 + 4*(n))


/* Per-Port Configuration and Status Registers (16-bit).

   These are "distributed registers"that are not memory mapped 
   but are accessed via table managment commands.  The required 
   address for such commands is the register number, not the 
   byte offset. */

#define R_PORT_CONFIG_1(port)    (0x100 + ((port)<<3))
#define R_PORT_CONFIG_2(port)    (0x101 + ((port)<<3))
#define R_PORT_CONFIG_3(port)    (0x102 + ((port)<<3))
#define R_PORT_CONFIG_4(port)    (0x103 + ((port)<<3))
#define R_PORT_CONFIG_5(port)    (0x104 + ((port)<<3))
#define R_PORT_PRIO_VLAN(port)   (0x105 + ((port)<<3))
#define R_PORT_STATUS_1(port)    (0x106 + ((port)<<3))
#define R_PORT_STATUS_2(port)    (0x107 + ((port)<<3))



/* CPUCMD:  CPU Command Register (0x0000) */

#define S_TBL_MGMT_CMD           0
#define M_TBL_MGMT_CMD           _DD_MAKEMASK(3,S_TBL_MGMT_CMD)
#define V_TBL_MGMT_CMD(x)        _DD_MAKEVALUE(x,S_TBL_MGMT_CMD)
#define G_TBL_MGMT_CMD(x)        _DD_GETVALUE(x,S_TBL_MGMT_CMD,M_TBL_MGMT_CMD)
#define K_TBL_NOOP               0x0
#define K_TBL_READ               0x1
#define K_TBL_WRITE              0x2
#define K_TBL_DMA_READ           0x3
#define K_TBL_LEARN              0x4
#define K_TBL_SEARCH             0x5
#define K_TBL_DELETE             0x6
#define K_TBL_DMA_WRITE          0x7

#define S_TBL_SEL                3
#define M_TBL_SEL                _DD_MAKEMASK(3,S_TBL_SEL)
#define V_TBL_SEL(x)             _DD_MAKEVALUE(x,S_TBL_SEL)
#define G_TBL_SEL(x)             _DD_GETVALUE(x,S_TBL_SEL,M_TBL_SEL)
#define K_TBL_L2_MAC_ADDR        0x0
#define K_TBL_VLAN               0x1
#define K_TBL_VLAN_2             0x2
#define K_TBL_MCAST              0x3
#define K_TBL_DIST_REGISTER      0x4
#define K_TBL_MIB                0x5
#define K_TBL_EEPROM             0x6
#define K_TBL_MDIO               0x7

#define M_SW_MIB_RESET           _DD_MAKEMASK1(7)
#define M_SW_RESET               _DD_MAKEMASK1(8)


/* IRQSTAT: CPU Interrupt Vector Register      (0x0014) */
/* IRQMASK: CPU Interrupt Vector Mask Register (0x0018) */

#define M_IRQ_TX_PKT             _DD_MAKEMASK1(0)
#define M_IRQ_TX_PKT_LAST        _DD_MAKEMASK1(1)
#define M_IRQ_RX_PKT             _DD_MAKEMASK1(2)
#define M_IRQ_RX_PKT_LAST        _DD_MAKEMASK1(3)
#define M_IRQ_TBL_CMD_DONE       _DD_MAKEMASK1(4)
#define M_IRQ_MIB_CNT_OF         _DD_MAKEMASK1(5)
#define M_IRQ_BIST_DONE          _DD_MAKEMASK1(6)
#define M_IRQ_MEM_INIT_DONE      _DD_MAKEMASK1(7)
#define M_IRQ_PCI_TGT_PARITY_ERR _DD_MAKEMASK1(8)
#define M_IRQ_PCI_MST_PARITY_ERR _DD_MAKEMASK1(9)
#define M_IRQ_PCI_FATAL_ERR      _DD_MAKEMASK1(10)
#define M_IRQ_CPU_INIT_START     _DD_MAKEMASK1(11)


/* DMA: Frame Rx/Tx DMA Channel Pointer Register (0x001C) */

#define S_DMA_NXT_ALLOC_RX_CH    0
#define M_DMA_NXT_ALLOC_RX_CH    _DD_MAKEMASK(2,S_DMA_NXT_ALLOC_RX_CH)
#define V_DMA_NXT_ALLOC_RX_CH(x) _DD_MAKEVALUE(x,S_DMA_NXT_ALLOC_RX_CH)
#define G_DMA_NXT_ALLOC_RX_CH(x) _DD_GETVALUE(x,S_DMA_NXT_ALLOC_RX_CH,M_DMA_NXT_ALLOC_RX_CH)

#define S_DMA_NXT_RX_CH          8
#define M_DMA_NXT_RX_CH          _DD_MAKEMASK(2,S_DMA_NXT_RX_CH)
#define V_DMA_NXT_RX_CH(x)       _DD_MAKEVALUE(x,S_DMA_NXT_RX_CH)
#define G_DMA_NXT_RX_CH(x)       _DD_GETVALUE(x,S_DMA_NXT_RX_CH,M_DMA_NXT_RX_CH)

#define S_DMA_NXT_ALLOC_TX_CH    16
#define M_DMA_NXT_ALLOC_TX_CH    _DD_MAKEMASK(2,S_DMA_NXT_ALLOC_TX_CH)
#define V_DMA_NXT_ALLOC_TX_CH(x) _DD_MAKEVALUE(x,S_DMA_NXT_ALLOC_TX_CH)
#define G_DMA_NXT_ALLOC_TX_CH(x) _DD_GETVALUE(x,S_DMA_NXT_ALLOC_TX_CH,M_DMA_NXT_ALLOC_TX_CH)

#define S_DMA_NXT_TX_CH          24
#define M_DMA_NXT_TX_CH          _DD_MAKEMASK(2,S_DMA_NXT_TX_CH)
#define V_DMA_NXT_TX_CH(x)       _DD_MAKEVALUE(x,S_DMA_NXT_TX_CH)
#define G_DMA_NXT_TX_CH(x)       _DD_GETVALUE(x,S_DMA_NXT_TX_CH,M_DMA_NXT_TX_CH)


/* SYS: System Status Register                   (0x0040) */

#define M_M_SYS_NOW_BIST         _DD_MAKEMASK1(0)
#define M_M_SYS_LAST_BIST_X      _DD_MAKEMASK1(1)
#define M_M_SYS_NOW_SB_INIT      _DD_MAKEMASK1(2)
#define M_M_SYS_NOW_L2_INIT      _DD_MAKEMASK1(4)
#define M_M_SYS_NOW_MIB_INIT     _DD_MAKEMASK1(5)
#define M_M_SYS_NOW_EP_INIT      _DD_MAKEMASK1(6)
#define M_M_SYS_NOW_TBL_MGMT     _DD_MAKEMASK1(7)
#define M_M_SYS_LAST_TBL_CMD_X   _DD_MAKEMASK1(8)

#define S_SYS_LAST_OF_MIB_ID     9
#define M_SYS_LAST_OF_MIB_ID     _DD_MAKEMASK(12,S_SYS_LAST_OF_MIB_ID)
#define V_SYS_LAST_OF_MIB_ID(x)  _DD_MAKEVALUE(x,S_SYS_LAST_OF_MIB_ID)
#define G_SYS_LAST_OF_MIB_ID(x)  _DD_GETVALUE(x,S_SYS_LAST_OF_MIB_ID,M_SYS_LAST_OF_MIB_ID)

#define M_M_SYS_PORT24_ENABLE    _DD_MAKEMASK1(21)


/* DEVINFO: Device Information Register          (0x0044) */

#define S_DEVINFO_REV_ID         8
#define M_DEVINFO_REV_ID         _DD_MAKEMASK(8,S_DEVINFO_REV_ID)
#define V_DEVINFO_REV_ID(x)      _DD_MAKEVALUE(x,S_DEVINFO_REV_ID)
#define G_DEVINFO_REV_ID(x)      _DD_GETVALUE(x,S_DEVINFO_REV_ID,M_DEVINFO_REV_ID)

#define S_DEVINFO_DEVICE_ID      16
#define M_DEVINFO_DEVICE_ID      _DD_MAKEMASK(16,S_DEVINFO_DEVICE_ID)
#define V_DEVINFO_DEVICE_ID(x)   _DD_MAKEVALUE(x,S_DEVINFO_DEVICE_ID)
#define G_DEVINFO_DEVICE_ID(x)   _DD_GETVALUE(x,S_DEVINFO_DEVICE_ID,M_DEVINFO_DEVICE_ID)



/* INIT1: EEPROM Initialization Register 1       (0x0050) */

#define S_INIT1_EP_L2_SIZE       0
#define M_INIT1_EP_L2_SIZE       _DD_MAKEMASK(6,S_INIT1_EP_L2_SIZE)
#define V_INIT1_EP_L2_SIZE(x)    _DD_MAKEVALUE(x,S_INIT1_EP_L2_SIZE)
#define G_INIT1_EP_L2_SIZE(x)    _DD_GETVALUE(x,S_INIT1_EP_L2_SIZE,M_INIT1_EP_L2_SIZE)

#define M_INIT1_CPU_CFGRDY       _DD_MAKEMASK1(7)

#define S_INIT1_EP_CONF          10
#define M_INIT1_EP_CONF          _DD_MAKEMASK(4,S_INIT1_EP_CONF)
#define V_INIT1_EP_CONF(x)       _DD_MAKEVALUE(x,S_INIT1_EP_CONF)
#define G_INIT1_EP_CONF(x)       _DD_GETVALUE(x,S_INIT1_EP_CONF,M_INIT1_EP_CONF)
#define K_EP_CONF_L2_INIT        0x1
#define K_EP_CONF_VLAN_INIT      0x2
#define K_EP_CONF_SPAN_INIT      0x4
#define K_EP_CONF_MC_INIT        0x8

#define M_INIT1_EP_PRST          _DD_MAKEMASK1(14)
#define M_INIT1_CPU_PRST         _DD_MAKEMASK1(15)


/* INIT2: EEPROM Initialization Register 2       (0x0054) */

#define S_INIT2_EP_VLAN_SIZE     0
#define M_INIT2_EP_VLAN_SIZE     _DD_MAKEMASK(8,S_INIT2_EP_VLAN_SIZE)
#define V_INIT2_EP_VLAN_SIZE(x)  _DD_MAKEVALUE(x,S_INIT2_EP_VLAN_SIZE)
#define G_INIT2_EP_VLAN_SIZE(x)  _DD_GETVALUE(x,S_INIT2_EP_VLAN_SIZE,M_INIT2_EP_VLAN_SIZE)

#define M_INIT2_SCL_OUT          _DD_MAKEMASK1(8)
#define M_INIT2_SDA_IN           _DD_MAKEMASK1(9)
#define M_INIT2_SDA_OUT_EN_N     _DD_MAKEMASK1(10)
#define M_INIT2_SDA_OUT          _DD_MAKEMASK1(11)
#define M_INIT2_EP_AXS_EN        _DD_MAKEMASK1(12)

#define S_INIT2_EEPROM_ID        13
#define M_INIT2_EEPROM_ID        _DD_MAKEMASK(3,S_INIT2_EEPROM_ID)
#define V_INIT2_EEPROM_ID(x)     _DD_MAKEVALUE(x,S_INIT2_EEPROM_ID)
#define G_INIT2_EEPROM_ID(x)     _DD_GETVALUE(x,S_INIT2_EEPROM_ID,M_INIT2_EEPROM_ID)


/* INIT3: EEPROM Initialization Register 3       (0x0058) */

#define S_INIT3_EP_VLAN2_SIZE    0
#define M_INIT3_EP_VLAN2_SIZE    _DD_MAKEMASK(4,S_INIT3_EP_VLAN2_SIZE)
#define V_INIT3_EP_VLAN2_SIZE(x) _DD_MAKEVALUE(x,S_INIT3_EP_VLAN2_SIZE)
#define G_INIT3_EP_VLAN2_SIZE(x) _DD_GETVALUE(x,S_INIT3_EP_VLAN2_SIZE,M_INIT3_EP_VLAN2_SIZE)

#define S_INIT3_EP_MC_SIZE       5
#define M_INIT3_EP_MC_SIZE       _DD_MAKEMASK(6,S_INIT3_EP_MC_SIZE)
#define V_INIT3_EP_MC_SIZE(x)    _DD_MAKEVALUE(x,S_INIT3_EP_MC_SIZE)
#define G_INIT3_EP_MC_SIZE(x)    _DD_GETVALUE(x,S_INIT3_EP_MC_SIZE,M_INIT3_EP_MC_SIZE)


/* PCI: PCI Setup Register                       (0x005C) */

#define M_PCI_REV_MII_ENABLE     _DD_MAKEMASK1(1)
#define M_PCI_MAXLEN_9K          _DD_MAKEMASK1(5)
#define M_PCI_TAG_ENABLE         _DD_MAKEMASK1(6)
#define M_PCI_BYTE_SWAP          _DD_MAKEMASK1(12)

#define S_PCI_MAXLEN_SELECT       13
#define M_PCI_MAXLEN_SELECT       _DD_MAKEMASK(2,S_PCI_MAXLEN_SELECT)
#define V_PCI_MAXLEN_SELECT(x)    _DD_MAKEVALUE(x,S_PCI_MAXLEN_SELECT)
#define G_PCI_MAXLEN_SELECT(x)    _DD_GETVALUE(x,S_PCI_MAXLEN_SELECT,M_PCI_MAXLEN_SELECT)
#define K_MAXLEN_SELECT_1518      0x0
#define K_MAXLEN_SELECT_1522      0x1
#define K_MAXLEN_SELECT_1526      0x2
#define K_MAXLEN_SELECT_1548      0x3


/* PHYAD: PHY Address Register                     (0x0060) */

#define S_AS_PHYAD_START          10
#define M_AS_PHYAD_START          _DD_MAKEMASK(5,S_AS_PHYAD_START)
#define V_AS_PHYAD_START(x)       _DD_MAKEVALUE(x,S_AS_PHYAD_START)
#define G_AS_PHYAD_START(x)       _DD_GETVALUE(x,S_AS_PHYAD_START,M_AS_PHYAD_START)

#define M_AS_PHYAD_DIR            _DD_MAKEMASK1(15)
#define M_AS_PHYAD_UP             0
#define M_AS_PHYAD_DOWN           M_AS_PHYAD_DIR



/* ... */



/* L2CTL: Search Engine Control Register           (0x0074) */

#define M_L2CTL_FAST_AGE_TRIGGER  _DD_MAKEMASK1(1)

#define S_L2CTL_HKSEL             2
#define M_L2CTL_HKSEL             _DD_MAKEMASK(2,S_L2CTL_HKSEL)
#define V_L2CTL_HKSEL(x)          _DD_MAKEVALUE(x,S_L2CTL_HKSEL)
#define G_L2CTL_HKSEL(x)          _DD_GETVALUE(x,S_L2CTL_HKSEL,M_L2CTL_HKSEL)

#define M_L2CTL_FILTER_UNKNOWN_MC _DD_MAKEMASK1(4)
#define M_L2CTL_MULTI_VLAN_ST     _DD_MAKEMASK1(5)
#define M_L2CTL_FAIL_OVER_EN      _DD_MAKEMASK1(6)
#define M_L2CTL_VLAN_GMC          _DD_MAKEMASK1(7)
#define M_L2CTL_GMC               _DD_MAKEMASK1(8)
#define M_L2CTL_NO_CPU_VLAN       _DD_MAKEMASK1(10)
#define M_L2CTL_IVL               _DD_MAKEMASK1(11)
#define M_L2CTL_AGE_EN            _DD_MAKEMASK1(14)
#define M_L2CTL_CHIP_SECURITY     _DD_MAKEMASK1(13)
#define M_L2CTL_NO_CPU_FLOOD      _DD_MAKEMASK1(14)
#define M_L2CTL_Q_ON              _DD_MAKEMASK1(15)


/* L2P: L2 Port Configuration Registers 1-25       (0x013C-0x19C) */

#define M_L2P_PST_1X             _DD_MAKEMASK1(2)

#define S_L2P_PORT_ST            3
#define M_L2P_PORT_ST            _DD_MAKEMASK(2,S_L2P_PORT_ST)
#define V_L2P_PORT_ST(x)         _DD_MAKEVALUE(x,S_L2P_PORT_ST)
#define G_L2P_PORT_ST(x)         _DD_GETVALUE(x,S_L2P_PORT_ST,M_L2P_PORT_ST)

#define M_L2P_LM_DIS             _DD_MAKEMASK1(5)
#define M_L2P_VLAN_INGRESS       _DD_MAKEMASK1(6)
#define M_L2P_PORT_SECURITY      _DD_MAKEMASK1(7)
#define M_L2P_FLOOD_CONTROL      _DD_MAKEMASK1(8)
#define M_L2P_FLOOD_LOOPBACK     _DD_MAKEMASK1(9)

#define S_L2P_UPLINK_ID          10
#define M_L2P_UPLINK_ID          _DD_MAKEMASK(5,S_L2P_UPLINK_ID)
#define V_L2P_UPLINK_ID(x)       _DD_MAKEVALUE(x,S_L2P_UPLINK_ID)
#define G_L2P_UPLINK_ID(x)       _DD_GETVALUE(x,S_L2P_UPLINK_ID,M_L2P_UPLINK_ID)



/* ... */



/* GECTL1: GE Port Control Register 1              (0x0200) */


/* GECTL2: GE Port Control Register 2              (0x0204) */


/* PQA: Priority Queue Assignemnt Register         (0x0208) */


/* DQA: DiffServ Queue Assignment Registers        (0x020C-0x0228) */


/* PHYCFG: Vendor-Specific PHY Config Register     (0x022C) */

#define S_PHYCFG_PHY_OP_MODE      0
#define M_PHYCFG_PHY_OP_MODE      _DD_MAKEMASK(4,S_PHYCFG_PHY_OP_MODE)
#define V_PHYCFG_PHY_OP_MODE(x)   _DD_MAKEVALUE(x,S_PHYCFG_PHY_OP_MODE)
#define G_PHYCFG_PHY_OP_MODE(x)   _DD_GETVALUE(x,S_PHYCFG_PHY_OP_MODE,M_PHYCFG_PHY_OP_MODE)

#define S_PHYCFG_PHY_OP_SP        4
#define M_PHYCFG_PHY_OP_SP        _DD_MAKEMASK(4,S_PHYCFG_PHY_OP_SP)
#define V_PHYCFG_PHY_OP_SP(x)     _DD_MAKEVALUE(x,S_PHYCFG_PHY_OP_SP)
#define G_PHYCFG_PHY_OP_SP(x)     _DD_GETVALUE(x,S_PHYCFG_PHY_OP_SP,M_PHYCFG_PHY_OP_SP)

#define S_PHYCFG_PHY_OP_REG       8
#define M_PHYCFG_PHY_OP_REG       _DD_MAKEMASK(5,S_PHYCFG_PHY_OP_REG)
#define V_PHYCFG_PHY_OP_REG(x)    _DD_MAKEVALUE(x,S_PHYCFG_PHY_OP_REG)
#define G_PHYCFG_PHY_OP_REG(x)    _DD_GETVALUE(x,S_PHYCFG_PHY_OP_REG,M_PHYCFG_PHY_OP_REG)

#define M_PHYCFG_RXFIFO_OVF_PROT  _DD_MAKEMASK1(15)


/* MACCFG: 1000Base-T 10/100 MAC Config Register   (0x0230) */

#define S_MACCFG_BP_IPG_SEL       3
#define M_MACCFG_BP_IPG_SEL       _DD_MAKEMASK(2,S_MACCFG_BP_IPG_SEL)
#define V_MACCFG_BP_IPG_SEL(x)    _DD_MAKEVALUE(x,S_MACCFG_BP_IPG_SEL)
#define G_MACCFG_BP_IPG_SEL(x)    _DD_GETVALUE(x,S_MACCFG_BP_IPG_SEL,M_MACCFG_BP_IPG_SEL)

#define M_MACCFG_BEB_SEL          _DD_MAKEMASK1(8)

#define S_MACCFG_BP_RATE          9
#define M_MACCFG_BP_RATE          _DD_MAKEMASK(2,S_MACCFG_BP_RATE)
#define V_MACCFG_BP_RATE(x)       _DD_MAKEVALUE(x,S_MACCFG_BP_RATE)
#define G_MACCFG_BP_RATE(x)       _DD_GETVALUE(x,S_MACCFG_BP_RATE,M_MACCFG_BP_RATE)

#define M_MACCFG_BP_IPG64         _DD_MAKEMASK1(11)
#define M_MACCFG_IPG64            _DD_MAKEMASK1(12)
#define M_MACCFG_BP_COL           _DD_MAKEMASK1(13)
#define M_MACCFG_ULTRA_MAC        _DD_MAKEMASK1(14)
#define M_MACCFG_SUPER_MAC        _DD_MAKEMASK1(15)


/* TRAP: Trap/Snoop Register                       (0x0238) */

#define M_TRAP_LLDP               _DD_MAKEMASK1(0)
#define M_TRAP_8021X              _DD_MAKEMASK1(1)
#define M_TRAP_BGMA               _DD_MAKEMASK1(2)
#define M_TRAP_AD_BPDU_DIS        _DD_MAKEMASK1(3)
#define M_TRAP_BOOT_SNOOP         _DD_MAKEMASK1(4)
#define M_TRAP_RARP_SNOOP         _DD_MAKEMASK1(5)
#define M_TRAP_ARP_SNOOP          _DD_MAKEMASK1(6)
#define M_TRAP_RARP               _DD_MAKEMASK1(7)
#define M_TRAP_BPDU2              _DD_MAKEMASK1(8)
#define M_TRAP_BPDU1              _DD_MAKEMASK1(9)
#define M_TRAP_ICMP               _DD_MAKEMASK1(10)
#define M_TRAP_802AD              _DD_MAKEMASK1(11)
#define M_TRAP_ARP                _DD_MAKEMASK1(12)
#define M_TRAP_GARP               _DD_MAKEMASK1(13)
#define M_TRAP_IGMP               _DD_MAKEMASK1(14)
#define M_TRAP_IPMC               _DD_MAKEMASK1(15)



/* PCFG1: Port Configuration Register 1            (0x0100 + 0x8*port) */


#define S_PCFG1_PORT_ST           0
#define M_PCFG1_PORT_ST           _DD_MAKEMASK(2,S_PCFG1_PORT_ST)
#define V_PCFG1_PORT_ST(x)        _DD_MAKEVALUE(x,S_PCFG1_PORT_ST)
#define G_PCFG1_PORT_ST(x)        _DD_GETVALUE(x,S_PCFG1_PORT_ST,M_PCFG1_PORT_ST)
#define K_PORT_DISABLE            0x0
#define K_PORT_LISTENING          0x1
#define K_PORT_LEARNING           0x2
#define K_PORT_FORWARDING         0x3

#define S_PCFG1_IPG_WD            5
#define M_PCFG1_IPG_WD            _DD_MAKEMASK(4,S_PCFG1_IPG_WD)
#define V_PCFG1_IPG_WD(x)         _DD_MAKEVALUE(x,S_PCFG1_IPG_WD)
#define G_PCFG1_IPG_WD(x)         _DD_GETVALUE(x,S_PCFG1_IPG_WD,M_PCFG1_IPG_WD)

#define S_PCFG1_PREAMBLE_WD       9
#define M_PCFG1_PREAMBLE_WD       _DD_MAKEMASK(3,S_PCFG1_PREAMBLE_WD)
#define V_PCFG1_PREAMBLE_WD(x)    _DD_MAKEVALUE(x,S_PCFG1_PREAMBLE_WD)
#define G_PCFG1_PREAMBLE_WD(x)    _DD_GETVALUE(x,S_PCFG1_PREAMBLE_WD,M_PCFG1_PREAMBLE_WD)

#define M_PCFG1_CRC_EGRESS_RECAL  _DD_MAKEMASK1(12)
#define M_PCFG1_STORM_CONTROL     _DD_MAKEMASK1(13)
#define M_PCFG1_DROP_TAG          _DD_MAKEMASK1(14)
#define M_PCFG1_DROP_UNTAG        _DD_MAKEMASK1(15)


/* PCFG2: Port Configuration Register 2            (0x0101 + 0x8*port) */

#define S_PCFG2_RATE               0
#define M_PCFG2_RATE               _DD_MAKEMASK(4,S_PCFG2_RATE)
#define V_PCFG2_RATE(x)            _DD_MAKEVALUE(x,S_PCFG2_RATE)
#define G_PCFG2_RATE(x)            _DD_GETVALUE(x,S_PCFG2_RATE,M_PCFG2_RATE)

#define M_PCFG2_RATE_CONTROL      _DD_MAKEMASK1(4)
#define M_PCFG2_JUMBO_EN          _DD_MAKEMASK1(5)
#define M_PCFG2_FIBER_AUTONEG     _DD_MAKEMASK1(6)
#define M_PCFG2_BACK_JAM_EN       _DD_MAKEMASK1(7)
#define M_PCFG2_OFFLINE           _DD_MAKEMASK1(8)
#define M_PCFG2_RX_PAUSE          _DD_MAKEMASK1(9)
#define M_PCFG2_TX_PAUSE          _DD_MAKEMASK1(10)
#define M_PCFG2_ASM_DIR           _DD_MAKEMASK1(11)
#define M_PCFG2_PAUSE             _DD_MAKEMASK1(12)
#define M_PCFG2_LINK_UP           _DD_MAKEMASK1(13)
#define M_PCFG2_ANEG_ENB          _DD_MAKEMASK1(14)
#define M_PCFG2_RST_ANEG          _DD_MAKEMASK1(15)


/* PCFG3: Port Configuration Register 3            (0x0102 + 0x8*port) */

#define S_PCFG3_MASTER_MODE       0
#define M_PCFG3_MASTER_MODE       _DD_MAKEMASK(4,S_PCFG3_MASTER_MODE)
#define V_PCFG3_MASTER_MODE(x)    _DD_MAKEVALUE(x,S_PCFG3_MASTER_MODE)
#define G_PCFG3_MASTER_MODE(x)    _DD_GETVALUE(x,S_PCFG3_MASTER_MODE,M_PCFG3_MASTER_MODE)

#define M_PCFG3_10_HALF           _DD_MAKEMASK1(4)
#define M_PCFG3_10_FULL           _DD_MAKEMASK1(5)
#define M_PCFG3_100_HALF          _DD_MAKEMASK1(6)
#define M_PCFG3_100_FULL          _DD_MAKEMASK1(7)
#define M_PCFG3_1000_FULL         _DD_MAKEMASK1(8)
#define M_PCFG3_KEEP_DEFAULT      _DD_MAKEMASK1(9)
#define M_PCFG3_DIS_PHY_RESET     _DD_MAKEMASK1(10)
#define M_PCFG3_M_S_PTYPE         _DD_MAKEMASK1(11)
#define M_PCFG3_SKIP_EXPAN        _DD_MAKEMASK1(12)
#define M_PCFG3_EN_TX_EX_PAUSE    _DD_MAKEMASK1(13)
#define M_PCFG3_M_S_VAL           _DD_MAKEMASK1(14)
#define M_PCFG3_M_S_CFG           _DD_MAKEMASK1(15)


/* PCFG3: Port Configuration Register 3            (0x0103 + 0x8*port) */

#define M_PCFG3_TIMING_SEL        _DD_MAKEMASK1(0)
#define M_PCFG3_RGMII_DLL_BYPASS  _DD_MAKEMAKS1(13)


/* PVLAN: Default Port Priority/VLAN ID Register   (0x0105 + 0x8*port) */

#define S_PVLAN_VLAN_ID           0
#define M_PVLAN_VLAN_ID           _DD_MAKEMASK(12,S_PVLAN_VLAN_ID)
#define V_PVLAN_VLAN_ID(x)        _DD_MAKEVALUE(x,S_PVLAN_VLAN_ID)
#define G_PVLAN_VLAN_ID(x)        _DD_GETVALUE(x,S_PVLAN_VLAN_ID,M_PVLAN_VLAN_ID)

#define S_PVLAN_PRIORITY          12
#define M_PVLAN_PRIORITY          _DD_MAKEMASK(3,S_PVLAN_PRIORITY)
#define V_PVLAN_PRIORITY(x)       _DD_MAKEVALUE(x,S_PVLAN_PRIORITY)
#define G_PVLAN_PRIORITY(x)       _DD_GETVALUE(x,S_PVLAN_PRIORITY,M_PVLAN_PRIORITY)


/* PSTAT2: Port Status Register 2                  (0x0107 + 0x8*port) */

#define M_PSTAT2_DUPLEX           _DD_MAKEMASK1(0)
#define M_PSTAT2_HDX              0
#define M_PSTAT2_FDX              M_PSTAT2_DUPLEX

#define S_PSTAT2_LINK_SPEED       1
#define M_PSTAT2_LINK_SPEED       _DD_MAKEMASK(2,S_PSTAT2_LINK_SPEED)
#define V_PSTAT2_LINK_SPEED(x)    _DD_MAKEVALUE(x,S_PSTAT2_LINK_SPEED)
#define G_PSTAT2_LINK_SPEED(x)    _DD_GETVALUE(x,S_PSTAT2_LINK_SPEED,M_PSTAT2_LINK_SPEED)
#define K_PSTAT2_LINK_SPEED_10    0x0
#define K_PSTAT2_LINK_SPEED_100   0x1
#define K_PSTAT2_LINK_SPEED_1000  0x2

#define M_PSTAT2_DIS_RX_PAUSE     _DD_MAKEMASK1(3)
#define M_PSTAT2_DIS_TX_PAUSE     _DD_MAKEMASK1(4)
#define M_PSTAT2_SECURITY         _DD_MAKEMASK1(6)
#define M_PSTAT2_ANEG_PAGE_RVD    _DD_MAKEMASK1(7)
#define M_PSTAT2_ANEG_FAIL        _DD_MAKEMASK1(8)
#define M_PSTAT2_TBL_UNAVL        _DD_MAKEMASK1(9)
#define M_PSTAT2_IN_B_FULL        _DD_MAKEMASK1(10)
#define M_PSTAT2_ALL_QUEUE_DROP   _DD_MAKEMASK1(11)
#define M_PSTAT2_D_VLAN_VIOLATION _DD_MAKEMASK1(12)
#define M_PSTAT2_S_VLAN_VIOLATION _DD_MAKEMASK1(13)
#define M_PSTAT2_ANEG_COMPT       _DD_MAKEMASK1(14)
#define M_PSTAT2_LINK_FAIL        _DD_MAKEMASK1(15)



/* DMA channels */

#define N_CHANNELS               4


/* DMA buffer prefixes for FIFO control words.  This is undocumented
   and extracted from the SDK code. */

/* Transmit (CPU to switch, prefix is a command) */

#define S_DMAT0_LEN              0                  /* frame length */
#define M_DMAT0_LEN              _DD_MAKEMASK(14,S_DMAT0_LEN)
#define V_DMAT0_LEN(x)           _DD_MAKEVALUE(x,S_DMAT0_LEN)
#define G_DMAT0_LEN(x)           _DD_GETVALUE(x,S_DMAT0_LEN,M_DMAT0_LEN)

#define M_DMAT0_CRC_REGEN        _DD_MAKEMASK1(14)  /* update CRC */

#define S_DMAT0_PTAG             15                 /* priority */
#define M_DMAT0_PTAG             _DD_MAKEMASK(3,S_DMAT0_PTAG)
#define V_DMAT0_PTAG(x)          _DD_MAKEVALUE(x,S_DMAT0_PTAG)
#define G_DMAT0_PTAG(x)          _DD_GETVALUE(x,S_DMAT0_PTAG,M_DMAT0_PTAG)

#define S_DMAT0_VTAG             18                 /* VLAN */
#define M_DMAT0_VTAG             _DD_MAKEMASK(12,S_DMAT0_VTAG)
#define V_DMAT0_VTAG(x)          _DD_MAKEVALUE(x,S_DMAT0_VTAG)
#define G_DMAT0_VTAG(x)          _DD_GETVALUE(x,S_DMAT0_VTAG,M_DMAT0_VTAG)

#define M_DMAT0_ITAG             _DD_MAKEMASK1(30)  /* tag on input */

#define M_DMAT0_CMD              _DD_MAKEMASK1(31)
#define V_DMAT0_DATA             0
#define V_DMAT0_CMD              M_DMAT0_CMD


#define S_DMAT1_QUEUE            0
#define M_DMAT1_QUEUE            _DD_MAKEMASK(2,S_DMAT1_QUEUE)
#define V_DMAT1_QUEUE(x)         _DD_MAKEVALUE(x,S_DMAT1_QUEUE)
#define G_DMAT1_QUEUE(x)         _DD_GETVALUE(x,S_DMAT1_QUEUE,M_DMAT1_QUEUE)

#define S_DMAT1_BITMAP           2
#define M_DMAT1_BITMAP           _DD_MAKEMASK(25,S_DMAT1_BITMAP)
#define V_DMAT1_BITMAP(x)        _DD_MAKEVALUE(x,S_DMAT1_BITMAP)
#define G_DMAT1_BITMAP(x)        _DD_GETVALUE(x,S_DMAT1_BITMAP,M_DMAT1_BITMAP)


#define S_DMAT2_OTAG             0                  /* untagged egress ports */
#define M_DMAT2_OTAG             _DD_MAKEMASK(25,S_DMAT2_OTAG)
#define V_DMAT2_OTAG(x)          _DD_MAKEVALUE(x,S_DMAT2_OTAG)
#define G_DMAT2_OTAG(x)          _DD_GETVALUE(x,S_DMAT2_OTAG,M_DMAT2_OTAG)

#define M_DMAT2_CMD              _DD_MAKEMASK1(25)
#define V_DMAT2_DATA             0
#define V_DMAT2_CMD              M_DMAT2_CMD

#define DMAT_LEN                 (3*sizeof(uint32_t))


/* Receive (switch to CPU, prefix is status) */

#define S_DMAR0_LEN              0                  /* frame length */
#define M_DMAR0_LEN              _DD_MAKEMASK(14,S_DMAR0_LEN)
#define V_DMAR0_LEN(x)           _DD_MAKEVALUE(x,S_DMAR0_LEN)
#define G_DMAR0_LEN(x)           _DD_GETVALUE(x,S_DMAR0_LEN,M_DMAR0_LEN)

#define M_DMAR0_CMD              _DD_MAKEMASK1(31)


#define S_DMAR1_PTAG             0                  /* priority */
#define M_DMAR1_PTAG             _DD_MAKEMASK(3,S_DMAR1_PTAG)
#define V_DMAR1_PTAG(x)          _DD_MAKEVALUE(x,S_DMAR1_PTAG)
#define G_DMAR1_PTAG(x)          _DD_GETVALUE(x,S_DMAR1_PTAG,M_DMAR1_PTAG)

#define S_DMAR1_VTAG             3                  /* VLAN */
#define M_DMAR1_VTAG             _DD_MAKEMASK(12,S_DMAR1_VTAG)
#define V_DMAR1_VTAG(x)          _DD_MAKEVALUE(x,S_DMAR1_VTAG)
#define G_DMAR1_VTAG(x)          _DD_GETVALUE(x,S_DMAR1_VTAG,M_DMAR1_VTAG)

#define M_DMAR1_OTAG             _DD_MAKEMASK1(15)
#define M_DMAR1_ITAG             _DD_MAKEMASK1(16)

#define S_DMAR1_ID               17                 /* ingress port */
#define M_DMAR1_ID               _DD_MAKEMASK(6,S_DMAR1_ID)
#define V_DMAR1_ID(x)            _DD_MAKEVALUE(x,S_DMAR1_ID)
#define G_DMAR1_ID(x)            _DD_GETVALUE(x,S_DMAR1_ID,M_DMAR1_ID)

#define S_DMAR1_CLASS            23                 /* frame type */
#define M_DMAR1_CLASS            _DD_MAKEMASK(4,S_DMAR1_CLASS)
#define V_DMAR1_CLASS(x)         _DD_MAKEVALUE(x,S_DMAR1_CLASS)
#define G_DMAR1_CLASS(x)         _DD_GETVALUE(x,S_DMAR1_CLASS,M_DMAR1_CLASS)
#define K_CLASS_NORMAL           0
#define K_CLASS_BPDU             1
#define K_CLASS_GARP             2
#define K_CLASS_802AD            3
#define K_CLASS_ARP              4
#define K_CLASS_IP_MCAST         5
#define K_CLASS_IGMP             6
#define K_CLASS_ICMP             7
#define K_CLASS_BPDU1            9
#define K_CLASS_BPDU2            10
#define K_CLASS_RARP             11
#define K_CLASS_BMGA             12
#define K_CLASS_BOOTP            13
#define K_CLASS_8021X            14
#define K_CLASS_LLDP             15

#define M_DMAR1_CRC              _DD_MAKEMASK1(27)


#define DMAR_LEN                 (2*sizeof(uint32_t))

#endif /* _BCM5345_H_ */
