/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Flash memory definitions			File: dev_sflash.h
    *  
    *  Stuff we use when manipulating serial flash memory devices.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003,2005
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#include "cfe.h"
#include "dev_sflash.h"
#include "bspi_flash.h"

#define DBG_MSG(x)	((void)0)

#define isaligned(x, y) (((x) % (y)) == 0)
#define min(a,b) ((a) < (b) ? (a) : (b))
#define max(a,b) ((a) > (b) ? (a) : (b))

#define ENABLE_SFLASH_PROBE 0

static int sflashidx = 0;

static int
sflash_cfe_open(cfe_devctx_t *ctx)
{
	return 0;
}

static int
sflash_cfe_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
	sflashpart_t *part = (sflashpart_t *) ctx->dev_softc;
	int offset = buffer->buf_offset + part->fp_offset;
	int blen = buffer->buf_length;
	uint8_t *buf = (uint8_t *) buffer->buf_ptr;

	int i;
    
    if ((offset + blen) > part->fp_size) {
        blen = part->fp_size - offset;
	}

    buffer->buf_retlen = 0;
    
    for (i = 0; i < blen; ++i)
	{
		if (bspi_read(0, offset + i, &buf[i]) != CFE_OK)
		{
			DBG_MSG(("%s:%d(0x%08x,0x%02x,%d)\n",__FUNCTION__,__LINE__,offset+i,data[i],1 ));
			return CFE_ERR_IOERR;
		}
	}
	
	buffer->buf_retlen = blen;
	return 0;
}

static int
sflash_cfe_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
	inpstat->inp_status = 1;
	return 0;
}

static int
sflash_cfe_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
	sflashpart_t *part = (sflashpart_t *) ctx->dev_softc;
	sflashdev_t *softc = (sflashdev_t *) part->fp_dev;
	int offset = buffer->buf_offset + part->fp_offset;
	int blen = buffer->buf_length;
	uint8_t *buf = (uint8_t *) buffer->buf_ptr;
	uint8_t *buf2;
	uint8_t *block = NULL;
	uint32_t sectorsize = 0, mask;
	iocb_buffer_t cur;
	int i, ret = 0;

	buffer->buf_retlen = 0;
    
    if ((offset + blen) > part->fp_size) {
        blen = part->fp_size - offset;
	}

    if (blen == 0) {
        return 0;
	}

	sectorsize = softc->sectorsize;
	mask = sectorsize - 1;

	if (block)
		KFREE(block);
	if (!(block = KMALLOC(sectorsize, 0)))
		return CFE_ERR_NOMEM;

	/* Backup and erase one block at a time */
	while (blen) {
		/* Align offset */
		cur.buf_offset = offset & ~mask;
		cur.buf_length = sectorsize;
		cur.buf_ptr = (hsaddr_t)block;
        buf2 = (uint8_t *)cur.buf_ptr;
        DBG_MSG(("Program at 0x%x, len 0x%x, remaining len 0x%x\n",(int)cur.buf_offset, (int)cur.buf_length, blen));
		/* Copy existing data into holding block if necessary */
		if (!isaligned(offset, sectorsize) || (blen < sectorsize)) {
			cur.buf_offset -= part->fp_offset;
			if (sflash_cfe_read(ctx, &cur) < 0)
				goto done;
			cur.buf_offset += part->fp_offset;
		}

		/* Copy input data into holding block */
		cur.buf_retlen = min(blen, sectorsize - (offset & mask));
		memcpy(buf2 + (offset & mask), buf, cur.buf_retlen);

		/* Erase block */
		if ((ret = bspi_sector_erase(0, (uint32_t)cur.buf_offset)) < 0) {
			goto done;
		}

		/* Write holding block */
		for (i = 0; i < cur.buf_length; i += 4) {
            if (bspi_page_program(0, (unsigned int)cur.buf_offset+i, buf2+i, 4) != CFE_OK) {
			    DBG_MSG(("%s:%d failed to write at 0x%08x\n",__FUNCTION__,__LINE__,(int)cur.buf_offset + i));
		        return CFE_ERR_IOERR;
		    }
		    if ((i % 512) == 0)
		    {
			    DBG_MSG(("+"));
		    }
        }
		offset += cur.buf_retlen;
		blen -= cur.buf_retlen;
		buf += cur.buf_retlen;
		buffer->buf_retlen += cur.buf_retlen;
	}

 done:
	if (block)
		KFREE(block);
	return ret;
}

static int
sflash_cfe_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
	sflashpart_t *part = (sflashpart_t *) ctx->dev_softc;
	sflashdev_t *softc = (sflashdev_t *) part->fp_dev;
	flash_info_t *info;

	switch (buffer->buf_ioctlcmd) {
	case IOCTL_FLASH_WRITE_ALL:
		sflash_cfe_write(ctx, buffer);
		break;
	case IOCTL_FLASH_GETINFO:
		info = (flash_info_t *) buffer->buf_ptr;
		info->flash_base = 0;
		info->flash_size = softc->size;
		info->flash_type = softc->type;
		info->flash_flags = FLASH_FLAG_NOERASE;
		break;
	default:
		return CFE_ERR_INV_COMMAND;
	}

	return 0;
}

static int
sflash_cfe_close(cfe_devctx_t *ctx)
{
	return 0;
}

static const cfe_devdisp_t sflash_cfe_dispatch = {
	sflash_cfe_open,
	sflash_cfe_read,
	sflash_cfe_inpstat,
	sflash_cfe_write,
	sflash_cfe_ioctl,
	sflash_cfe_close,	
	NULL,
	NULL
};

static void
sflash_do_parts(sflashdev_t *softc)
{
	int idx;
	int middlepart = -1;
	int lobound = 0;
	newflash_probe_t *probe = &(softc->fd_probe);
	sflashpart_t *parts = softc->parts;
	int hibound = softc->size;

	for (idx = 0; idx < probe->flash_nparts; idx++) {
		if (probe->flash_parts[idx].fp_size == 0) {
			middlepart = idx;
			break;
		}
		parts[idx].fp_offset = lobound;
		parts[idx].fp_size = probe->flash_parts[idx].fp_size;
		lobound += probe->flash_parts[idx].fp_size;
	}

	if (idx != probe->flash_nparts) {
		for (idx = probe->flash_nparts - 1; idx > middlepart; idx--) {
			parts[idx].fp_size = probe->flash_parts[idx].fp_size;
			hibound -= probe->flash_parts[idx].fp_size;
			parts[idx].fp_offset = hibound;
		}
	}

	if (middlepart != -1) {
		parts[middlepart].fp_offset = lobound;
		parts[middlepart].fp_size = hibound - lobound;
	}
}

static
int sflash_do_probe(sflashdev_t *softc)
{
#if ENABLE_SFLASH_PROBE
    unsigned int vendor, dev;
	
	bspi_probe(0, &vendor, &dev);

	switch (vendor) {
        case SFLASH_VENDOR_MXIC:
            switch (dev) {
            	case SFLASH_TYPE_MX25L512:
            	    softc->blocksize = 4;
                    softc->sectorsize = (4 * 1024); /* in bytes */;
                    softc->type = FLASH_TYPE_SFLASH;
                    softc->size = (64 * 1024); /* in bytes */
                    break;
                }
             break;
    }
#else
    softc->blocksize = 4;
    softc->sectorsize = (4 * 1024); /* in bytes */;
    softc->type = FLASH_TYPE_SFLASH;
    softc->size = (64 * 1024); /* in bytes */
#endif
	return softc->type;
}

static void
sflash_cfe_probe(cfe_driver_t *drv,
		 unsigned long probe_a, unsigned long probe_b, 
		 void *probe_ptr)
{
	newflash_probe_t *probe = (newflash_probe_t *) probe_ptr;
	sflashdev_t *softc;
	char descr[80], name[80];
	int idx;

	softc = (sflashdev_t *) KMALLOC(sizeof(sflashdev_t), 0);
	if (!softc) {
	    return;
	}
	memset(softc, 0, sizeof(sflashdev_t));

	/* Initialize serial flash access */
	sflash_do_probe(softc);
    
    if (probe) {
	    /* Passed probe structure, do fancy stuff */
	    memcpy(&(softc->fd_probe),probe,sizeof(newflash_probe_t));
	    if (softc->fd_probe.flash_nchips == 0) {
		    softc->fd_probe.flash_nchips = 1;
		}
	}

	if (probe->flash_nparts == 0) {
		/* Just instantiate one device */
		softc->parts[0].fp_dev = (sflashdev_t *) softc;
		softc->parts[0].fp_offset = 0;
		softc->parts[0].fp_size = softc->size;
		sprintf(descr, "%s at %08X size %uKB",
			drv->drv_description,
			softc->fd_probe.flash_phys,
			(softc->size + 1023) / 1024);
		cfe_attach(drv, &softc->parts[0], NULL, descr);
	} else {
		/* Partition flash into chunks */
		sflash_do_parts(softc);

		/* Instantiate devices for each piece */
		for (idx = 0; idx < probe->flash_nparts; idx++) {
			sprintf(descr, "%s at %08X offset %08X size %uKB",
				drv->drv_description,
				softc->fd_probe.flash_phys,
				softc->parts[idx].fp_offset,
				(softc->parts[idx].fp_size + 1023) / 1024);
			softc->parts[idx].fp_dev = (sflashdev_t *) softc;
			if (probe->flash_parts[idx].fp_name)
				strcpy(name, probe->flash_parts[idx].fp_name);
			else
				sprintf(name, "%d", idx);
			cfe_attach_idx(drv, sflashidx, &softc->parts[idx], name, descr);
		}
	}

	sflashidx++;
}

const cfe_driver_t sflashdrv = {
    "Serial flash",
	"sflash",
	CFE_DEV_FLASH,
	&sflash_cfe_dispatch,
	sflash_cfe_probe
};
