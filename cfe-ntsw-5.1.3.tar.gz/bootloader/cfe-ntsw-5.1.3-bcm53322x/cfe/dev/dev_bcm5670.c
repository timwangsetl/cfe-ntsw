/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5670 XGS HiGig Switch Fabric	     File: dev_bcm5670.c
    *  
    *  Author: Ed Satterthwaite
    *
    *********************************************************************  
    *
    *  Copyright 2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

/*
    CFE interface and MAC driver for the BCM5670 and BCM5671
    XGS Multi-port HiGig Switch Fabric.  This driver treats the
    switch as a MAC implemented by the 567x CMIC port.  It is not
    a general switch/fabric controller, but as a side-effect the
    device is configured as an unmanaged fabric and that logic
    remains enabled after the MAC is closed.

    Reference:
       BCM5670/BCM5671 Programmer's Reference Guide
       Document 5670_5671-PG01-R (08/26/03)
       Broadcom Corp., 1625 Alton Parkway, Irvine CA.
*/

#include "cfe.h"
#include "lib_physio.h"

#include "cfe_irq.h"

#include "net_enet.h"

#include "pcivar.h"
#include "pcireg.h"

#include "bcm5670.h"
#include "mii.h"

#ifndef XGS_DEBUG
#define XGS_DEBUG 0
#endif

#if ((ENDIAN_BIG + ENDIAN_LITTLE) != 1)
#error "dev_bcm5670: system endian not set"
#endif


/* Temporary, until configs supply MATCH_BYTES */
#if defined(MPC824X)  /* any machine without preserve-bits for PIO */
#define MATCH_BYTES  1
#else
#define MATCH_BYTES  0
#endif

/* Set IPOLL to drive processing through the pseudo-interrupt
   dispatcher.  Set XPOLL to drive processing by an external polling
   agent.  One must be set; setting both is ok. */

#ifndef IPOLL
#define IPOLL 0
#endif
#ifndef XPOLL
#define XPOLL 1
#endif

#define MIN_ETHER_PACK  (ENET_MIN_PKT+ENET_CRC_SIZE)   /* size of min packet */
#define MAX_ETHER_PACK  (ENET_MAX_PKT+ENET_CRC_SIZE)   /* size of max packet */
#define VLAN_DEFAULT    1
#define MAX_XGS_PACK    (MAX_ETHER_PACK+XGS_HDR_LEN)

/* Packet buffers.  For the XGS CMIC, packet buffer alignment is to a
   4-byte boundary for reads and arbitrary for writes.  We would like
   it aligned to a cache line boundary for performance, although there
   is a trade-off with IP/TCP header alignment, and to facilitate
   cache flushing on hosts requiring that.  */

#define ETH_PKTBUF_LEN      (((MAX_XGS_PACK+31)/32)*32)

typedef struct eth_pkt_s {
    queue_t next;			/*  8 */
    uint8_t *buffer;			/*  4 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint32_t unused[3];			/* 12 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;

#define CACHE_ALIGN       32
#define ETH_PKTBUF_LINES  ((sizeof(eth_pkt_t) + (CACHE_ALIGN-1))/CACHE_ALIGN)
#define ETH_PKTBUF_SIZE   (ETH_PKTBUF_LINES*CACHE_ALIGN)
#define ETH_PKTBUF_OFFSET (offsetof(eth_pkt_t, data))

#define ETH_PKT_BASE(data) ((eth_pkt_t *)((data) - ETH_PKTBUF_OFFSET))

static void
show_packet(char c, eth_pkt_t *pkt)
{
    int i;
    int n = (pkt->length < 128 ? pkt->length : 128);

    for (i = 0; i < n; i++) {
	if (i % 32 == 0) {
	    if (i == 0)
		xprintf("%c[%4d]:", c, pkt->length);
	    else
		xprintf("\n        ");
	    }
	if (i % 4 == 0)
	    xprintf(" ");
	xprintf("%02x", pkt->buffer[i]);
	}
    xprintf("\n");
}


static void bcm5670_probe(cfe_driver_t *drv,
			  unsigned long probe_a, unsigned long probe_b, 
			  void *probe_ptr);


/* BCM567x Hardware Common Data Structures */

typedef uint32_t portmap_t;        /* wide enough for a bit per port */

/* DMA Control Block as a struct.  See DCBn_ definitions for word n. */

typedef struct dcb_s {
    uint32_t mem_addr;             /* buffer or chain address */
    uint32_t w1;
    uint32_t w2;
    uint32_t w3;
    uint32_t w4;
    uint32_t w5;
    uint32_t w6;
    uint32_t w7;
} dcb_t;


typedef enum {
    eth_state_uninit,
    eth_state_off,
    eth_state_on, 
    eth_state_switch,
} eth_state_t;

typedef struct bcm5670_state_s {

    /* PCI access information */
    uint32_t  regbase;
    uint8_t   irq;
    pcitag_t  tag;		   /* tag for configuration registers */

    uint8_t   hwaddr[ENET_ADDR_LEN];
    uint16_t  device;              /* chip device code */
    uint8_t   revision;            /* chip revision */
    uint16_t  asic_revision;       /* mask revision */
    uint32_t  higig_port_mask;

    eth_state_t state;             /* current state */
    uint32_t intmask;              /* interrupt mask */

    /* packet free lists */
    queue_t freelist;
    uint8_t *pktpool;
    queue_t rxqueue;

    /* rings */
    dcb_t *dcbs[4];

    /* rx pointers and state */
    dcb_t *rx_start;               /* beginning of ring */
    dcb_t *rx_end;                 /* wrap point */
    volatile dcb_t *rx_add;
    volatile dcb_t *rx_remove;
    volatile dcb_t *rx_last;
    unsigned int rx_onring;

    /* tx pointers and state */
    int txbusy;

    cfe_devctx_t *devctx;

    /* ports */
    unsigned int module;           /* local mod_id */
    portmap_t    portmap;          /* map of connected ports */

    /* additional driver statistics */
    uint32_t inpkts;
    uint32_t outpkts;
    uint32_t interrupts;
    uint32_t rx_interrupts;
    uint32_t tx_interrupts;
} bcm5670_state_t;


/* Driver parameterization */

#define TX_CH                    0
#define RX_CH1                   1
#define RX_CH2                   2
#define RX_CH3                   3

/* RX_RING_SIZE determines the number of descriptors.  MIN_RX_BUFFERS
   is the target value for the number of available receive buffers.
   It must be less than RX_RING_SIZE, and a value of 1 doesn't exploit
   hardware chaining. */
#define RX_RING_SIZE             8
#define MIN_RX_BUFFERS           7


/* Address mapping macros */

#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((uint8_t *)KERNADDR(a))

#define PCI_TO_PTR(a)  (PHYS_TO_PTR(PCI_TO_PHYS(a)))
#define PTR_TO_PCI(x)  (PHYS_TO_PCI(PTR_TO_PHYS(x)))


/* Address mapping macros */

#if (ENDIAN_BIG && MATCH_BYTES)
#define CSR_MATCH_MODE       PCI_MATCH_BYTES
#define READCSR(sc,csr)      (phys_read32_swapped((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32_swapped((sc)->regbase + (csr), (val)))
#else
#define CSR_MATCH_MODE       PCI_MATCH_BITS
#define READCSR(sc,csr)      (phys_read32((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->regbase + (csr), (val)))
#endif


/* Entry to and exit from critical sections (currently relative to
   interrupts only, not SMP) */

#if CFG_INTERRUPTS
#define CS_ENTER(sc) cfe_disable_irq(sc->irq)
#define CS_EXIT(sc)  cfe_enable_irq(sc->irq)
#else
#define CS_ENTER(sc) ((void)0)
#define CS_EXIT(sc)  ((void)0)
#endif


/* Utilities */

static const char *
xgs_devname(bcm5670_state_t *sc)
{
    return (sc->devctx != NULL ? cfe_device_name(sc->devctx) : "eth?");
}


/* MII/PHY Access Routines. */

static int
mii_poll(bcm5670_state_t *sc)
{
    int timeout;
    uint32_t status;

    cfe_usleep(100);
    for (timeout = 10000; timeout > 0; timeout -= 100) {
	status = READCSR(sc, R_CMIC_SCHAN_CTRL);
	if ((status & M_SCTL_MIIM_OP_DONE) != 0)
	    break;
	cfe_usleep(100);
	}

    return (timeout > 0 ? CFE_OK : CFE_ERR_TIMEOUT);
}

static uint16_t
mii_read(bcm5670_state_t *sc, int phy_addr, int reg)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);
    
    cmd = V_MIIMP_PHY_ID(phy_addr) | V_MIIMP_PHY_REG(reg);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_1);

    if (mii_poll(sc) != CFE_OK) {
	xprintf("* ext rd %d:%x\n", phy_addr, reg);
	return 0xFFFF;
	}

    return G_MIIMRD_DATA(READCSR(sc, R_CMIC_MIIM_READ_DATA));
}

static void
mii_write(bcm5670_state_t *sc, int phy_addr, int reg, uint16_t value)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = V_MIIMP_PHY_ID(phy_addr) | V_MIIMP_PHY_REG(reg)
        | V_MIIMP_PHY_DATA(value);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_1);

    if (mii_poll(sc) != CFE_OK) {
	xprintf("* ext wr %d:%x\n", phy_addr, reg);
	}
}


/* S-Bus Access Routines.  Note that the 567x restrict register
   transactions to 8 bytes and memory transactions to 4 bytes. */

#define R_CMIC_SCHAN_D(word)    (R_CMIC_SCHAN_MESSAGE+4*(word))

static int
schan_transact(bcm5670_state_t *sc)
{
    int i;
    uint32_t ctrl;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
	cfe_usleep(100);
	ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
	if (ctrl & M_SCTL_MSG_DONE)
	    break;
	}
    return (i < 1000 ? CFE_OK : CFE_ERR_TIMEOUT);
}

#if NYI  /* not currently used */
static uint32_t
schan_read_reg(bcm5670_state_t *sc, unsigned int reg)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_REG_CMD)
	       | V_SMHDR_SRC_PORT(SC_PORT_CMIC)
	       | V_SMHDR_DATA_LEN(8));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);

    if (schan_transact(sc) != CFE_OK) xprintf("* schan rd %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    return READCSR(sc, R_CMIC_SCHAN_D(1));
}
#endif /* NYI */

static void
schan_write_reg(bcm5670_state_t *sc, unsigned int reg, uint32_t value)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_REG_CMD)
	       | V_SMHDR_SRC_PORT(SC_PORT_CMIC)
	       | V_SMHDR_DATA_LEN(8));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), value);
    WRITECSR(sc, R_CMIC_SCHAN_D(3), 0);

    if (schan_transact(sc) != CFE_OK) xprintf("* schan wr %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


static uint64_t
schan_read_reg64(bcm5670_state_t *sc, unsigned int reg)
{
    uint32_t msg_hdr;
    uint64_t value;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_REG_CMD)
	       | V_SMHDR_SRC_PORT(SC_PORT_CMIC)
	       | V_SMHDR_DATA_LEN(8));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);

    if (schan_transact(sc) != CFE_OK) xprintf("* schan rd64 %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    value = ((uint64_t)READCSR(sc, R_CMIC_SCHAN_D(1)) |
	     ((uint64_t)READCSR(sc, R_CMIC_SCHAN_D(2)) << 32));
    return value;
}

static void
schan_write_reg64(bcm5670_state_t *sc, unsigned int reg, uint64_t value)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_REG_CMD)
	       | V_SMHDR_SRC_PORT(SC_PORT_CMIC)
	       | V_SMHDR_DATA_LEN(8));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), (uint32_t)(value & 0xFFFFFFFF));
    WRITECSR(sc, R_CMIC_SCHAN_D(3), (uint32_t)(value >> 32));

    if (schan_transact(sc) != CFE_OK) xprintf("* schan wr64 %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


static void
schan_read_mem(bcm5670_state_t *sc, unsigned int addr, uint32_t *dest)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_MEM_CMD)
	       | V_SMHDR_SRC_PORT(SC_PORT_CMIC)
	       | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);

    if (schan_transact(sc) != CFE_OK) xprintf("* mem rd %x\n", addr);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    dest[0] = READCSR(sc, R_CMIC_SCHAN_D(1));
}

static void
schan_write_mem(bcm5670_state_t *sc, unsigned int addr,	uint32_t *src)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_MEM_CMD)
	       | V_SMHDR_SRC_PORT(SC_PORT_CMIC)
	       | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), src[0]);

    if (schan_transact(sc) != CFE_OK) xprintf("* mem wr %x\n", addr);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


/* HiGig (XGXS) MII/PHY Management */

/* Since the Strata chips at each end of a HiGig link are initialized
   in unknown order, we require only a plausible PHY, not an
   established link.  Empirically, the PHY registers for an
   unconnected XGXS port read as 0s. */

#if XGS_DEBUG
static void
xgxs_phy_dump(bcm5670_state_t *sc, unsigned int port, const char *label)
{
    int i;
    uint16_t  r;
    uint16_t  id1, id2;
    uint32_t  phy_vendor;
    uint16_t  phy_device;

    xprintf("%s, MII(%d):\n", label, port);

    mii_write(sc, port, R_XGXS_BLKNO, 0);

    id1 = mii_read(sc, port, MII_PHYIDR1);
    id2 = mii_read(sc, port, MII_PHYIDR2);
    phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
    phy_device = (id2 >> 4) & 0x3F;

    /* Required registers (all blocks) */
    for (i = 0x0; i <= 0x3; ++i) {
	r = mii_read(sc, port, i);
	xprintf(" REG%02X: %04X", i, r);
	}
    xprintf("\n");

    /* Block 0 */
    for (i = 0x10; i <= 0x16; ++i) {
	r = mii_read(sc, port, i);
	xprintf(" REG%02X: %04X", i, r);
	if (i == 0x13) xprintf("\n");
	}
    xprintf("\n");
    for (i = 0x19; i <= 0x1D; ++i) {
	r = mii_read(sc, port, i);
	xprintf(" REG%02X: %04X", i, r);
	if (i == 0x1B) xprintf("\n");
	}
    xprintf("\n");
    r = mii_read(sc, port, 0x1F);
    xprintf(" REG%02X: %04X\n", 0x1F, r);

    /* other blocks here? */
}
#else
#define xgxs_phy_dump(sc,port,label)
#endif

static portmap_t
xgxs_phy_scan(bcm5670_state_t *sc)
{
    unsigned int port;
    portmap_t portmap;
    uint16_t id1, id2;
    uint16_t status;

    portmap = 0;

    for (port = 1; port <= HIGIG_PORTS; port++) {

	if ((sc->higig_port_mask & HIGIG_BIT(port)) != 0) {
	    /* Restore default XGXS block. */
	    mii_write(sc, port, R_XGXS_BLKNO, 0);

	    xgxs_phy_dump(sc, port, "scan");

	    id1 = mii_read(sc, port, R_XGXS_PHY_ID_LO);
	    id2 = mii_read(sc, port, R_XGXS_PHY_ID_HI);
	    if ((id1 != 0x0000 && id1 != 0xFFFF) ||
		(id2 != 0x0000 && id2 != 0xFFFF)) {
		if (id1 != id2) {
		    portmap |= HIGIG_BIT(port);
		    xprintf("port %2d", port);
		    if (1 /*XGS_DEBUG*/) {
			uint32_t phy_vendor;
			uint16_t phy_device;
			phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
			phy_device = (id2 >> 4) & 0x3F;
			xprintf(" (phy vendor %06X part %02X)",
				phy_vendor, phy_device);
			}
		    xprintf(": ");
		    status = mii_read(sc, port, R_XGXS_IEEE_STAT);
		    if (status & (1 << 4))
			xprintf("10000 FDX\n");
		    else
			xprintf("not linked\n");
		    }
		}
	    }
	}

    return portmap;
}


/* 10 Gigabit MAC management */

static void
xmac_init(bcm5670_state_t *sc, unsigned int port)
{
    uint64_t ctrl;
    uint64_t rx_ctrl, tx_ctrl;
    uint64_t xgxs_ctrl, xgsx_stat;
    int i;

    /* See the port initialization sequence suggested in the
       programmer's reference, p 67. */
    ctrl = schan_read_reg64(sc, R_MAC_CTRL(port));
    rx_ctrl = schan_read_reg64(sc, R_MAC_RXCTRL(port));
    tx_ctrl = schan_read_reg64(sc, R_MAC_TXCTRL(port));

    tx_ctrl &= ~(M_TXCTRL_HDR_MODE | M_TXCTRL_CRC_MODE);
    tx_ctrl |= (V_TXCTRL_HDR_MODE(K_HDR_MODE_HIGIG) |
		V_TXCTRL_CRC_MODE(K_CRC_MODE_KEEP));
    schan_write_reg64(sc, R_MAC_TXCTRL(port), tx_ctrl);
    rx_ctrl &= ~M_RXCTRL_HDR_MODE;
    rx_ctrl |= (V_RXCTRL_HDR_MODE(K_HDR_MODE_HIGIG) | M_RXCTRL_STRIP_CRC);
    schan_write_reg64(sc, R_MAC_RXCTRL(port), rx_ctrl);

    xgxs_ctrl = schan_read_reg64(sc, R_MAC_XGXS_CTRL(port));
    xgxs_ctrl &= ~(M_XGXSCTRL_IDDQ | M_XGXSCTRL_PWR_DWN);
    schan_write_reg64(sc, R_MAC_XGXS_CTRL(port), xgxs_ctrl);
    cfe_usleep(100);
    xgxs_ctrl |= M_XGXSCTRL_HW_RST_L;
    schan_write_reg64(sc, R_MAC_XGXS_CTRL(port), xgxs_ctrl);

    for (i = 10; i > 0; i--) {
	xgsx_stat = schan_read_reg64(sc, R_MAC_XGXS_STAT(port));
	if ((xgsx_stat & M_XGXSSTAT_TXPLL_LOCK) != 0)
	    break;
	cfe_usleep(1000);
	}
    if (i == 0)
	xprintf("bcm5670: port %d XGXS PLL failed to lock\n", port);

    /* XXX The addition of 8 bytes here is empirical but necessary. */
    schan_write_reg64(sc, R_MAC_TXMAXSZ(port), MAX_XGS_PACK+8);
    schan_write_reg64(sc, R_MAC_RXMAXSZ(port), MAX_XGS_PACK+8);
}

static void
xmac_start(bcm5670_state_t *sc, unsigned int port)
{
    uint64_t ctrl;

    ctrl = schan_read_reg64(sc, R_MAC_CTRL(port));
    ctrl |= (M_MACCTRL_RX_EN | M_MACCTRL_TX_EN);
    schan_write_reg64(sc, R_MAC_CTRL(port), ctrl);
}

static void
xmac_stop(bcm5670_state_t *sc, unsigned int port)
{
}


static void
xgxs_stat_init(bcm5670_state_t *sc, unsigned int port)
{
    uint32_t base = (0x00000000 + (port << 20));
    unsigned int offset;
	       
    /* Zero the port statistics (36- or 42-bit registers) */
    for (offset = I_MIB_TX_FIRST; offset <= I_MIB_TX_LAST; offset++)
	schan_write_reg64(sc, base + offset, 0);
    for (offset = I_MIB_RX_FIRST; offset <= I_MIB_RX_LAST; offset++)
	schan_write_reg64(sc, base + offset, 0);
}

static void
xgxs_stat_dump(bcm5670_state_t *sc, unsigned int port)
{
    uint32_t base = (0x00000000 + (port << 20));
    uint32_t count;

    xprintf("--- ipic: %d ---\n", port);
    xprintf("ITPKT:   %08llx   ITBYT:   %08llx\n",
	    schan_read_reg64(sc, base + I_MIB_ITPKT),
	    schan_read_reg64(sc, base + I_MIB_ITBYT));
    xprintf("IRPKT:   %08llx   IRBYT:   %08llx\n",
	    schan_read_reg64(sc, base + I_MIB_IRPKT),
	    schan_read_reg64(sc, base + I_MIB_IRBYT));
    xprintf("IRMCA:   %08llx   IRBCA:   %08llx\n",
	    schan_read_reg64(sc, base + I_MIB_IRMCA),
	    schan_read_reg64(sc, base + I_MIB_IRBCA));

    /* Print error counts if non-zero. */
    count = schan_read_reg64(sc, base + I_MIB_IRUND);
    if (count != 0) xprintf("IRUND:   %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_IRFRG);
    if (count != 0) xprintf("IRFRG:   %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_IRFCS);
    if (count != 0) xprintf("IRFCS:   %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_IROVR);
    if (count != 0) xprintf("IROVR:   %08llx\n", count);

    xprintf("-----------------\n");
}


static portmap_t
xgxs_port_scan(bcm5670_state_t *sc)
{
    unsigned int port;

    for (port = 1; port <= HIGIG_PORTS; port++)
	xmac_init(sc, port);

    return xgxs_phy_scan(sc);
}

static void
xgxs_port_init(bcm5670_state_t *sc)
{
    unsigned int port;

    for (port = 1; port <= HIGIG_PORTS; port++) {
	if ((sc->portmap & HIGIG_BIT(port)) != 0) {
	    xgxs_stat_init(sc, port);
	    xmac_start(sc, port);
	    }
	}
}

static void
xgxs_port_stop(bcm5670_state_t *sc)
{
    unsigned int port;

    for (port = 1; port <= HIGIG_PORTS; port++) {
	if ((sc->portmap & HIGIG_BIT(port)) != 0) {
	    xmac_stop(sc, port);
	    if (1 || XGS_DEBUG) xgxs_stat_dump(sc, port);
	    }
	}
}


/* Switch management */

/* Initialize buffer memory. */
static void
lla_init(bcm5670_state_t *sc, portmap_t portmap)
{
    /* Is this needed?  Evidently, Rev A1 chips needed something like
       this, but perhaps it is only changing the timing. */
    unsigned int port;

    for (port = 0; port <= HIGIG_PORTS; port++) {
	if ((portmap & PORT_BIT(port)) != 0) {
	    int i;

	    for (i = 0; i < 1640; i++) {
		uint32_t entry[1];

		schan_read_mem(sc, M_LLA(port) + i, entry);
		entry[0] &= 0xFFF;
		schan_write_mem(sc, M_LLA(port) + i, entry);
		}
	    cfe_usleep(1000);
	    }
	}
}

/* Initialize memory management (all ports) */
static void
mmu_init(bcm5670_state_t *sc, portmap_t portmap)
{
    unsigned int port;
    unsigned int cos, ing;

    for (port = 0; port <= HIGIG_PORTS; port++) {
	if ((portmap & PORT_BIT(port)) != 0) {
	    schan_write_reg(sc, R_MMU_CELLLMTTOTAL(port), 1600);

	    for (cos = 0; cos < 8; cos++) {
		schan_write_reg(sc, R_MMU_PKTLMTCOS(port) + cos, 255);
		schan_write_reg(sc, R_MMU_CELLLMTCOS(port) + cos, 1639);
		}

	    for (ing = 0; ing <= HIGIG_PORTS; ing++) {
		schan_write_reg(sc, R_MMU_PKTLMTING(port) + ing, 2047);
		schan_write_reg(sc, R_MMU_CELLLMTING(port) + ing, 1636);
		}
	    }
	}
}

/* Initialize ingress and egress (HiGig ports only) */
static void
ingress_init(bcm5670_state_t *sc, portmap_t portmap)
{
    unsigned int port;

    for (port = 1; port <= HIGIG_PORTS; port++) {
	if ((portmap & PORT_BIT(port)) != 0) {
	    schan_write_reg(sc, R_ING_EGRMSKBMAP(port), portmap);
	    schan_write_reg(sc, R_ING_CPUTOBMAP(port), CMIC_BIT);
	    schan_write_reg(sc, R_ING_EPC_LNKBMAP(port), portmap);
	    }
	}
}


/* Initialize auxiliary forwarding tables (HiGig ports only).  */
static void
table_init(bcm5670_state_t *sc, portmap_t portmap)
{
    unsigned int port;
    uint32_t bitmap[1], nullmap[1], cpumap[1];
    int i;

    bitmap[0] = portmap;
    cpumap[0] = CMIC_BIT;

    for (port = 1; port <= HIGIG_PORTS; port++) {
	if ((portmap & PORT_BIT(port)) != 0) {

	    for (i = 0; i < 32; i++)
		schan_write_mem(sc, M_UC(port) + i, nullmap);
	    schan_write_mem(sc, M_UC(port) + 0, bitmap);
	    schan_write_mem(sc, M_UC(port) + 1, bitmap);
	    schan_write_mem(sc, M_UC(port) + sc->module, cpumap);

	    for (i = 0; i < 512; i++)
		schan_write_mem(sc, M_MC(port) + i, nullmap);
	    /* XXX for broadcast? */
	    schan_write_mem(sc, M_MC(port) + 0, bitmap);

	    for (i = 0; i < 4096; i++)
		schan_write_mem(sc, M_VID(port) + i, nullmap);
	    schan_write_mem(sc, M_VID(port) + 0, bitmap);
	    schan_write_mem(sc, M_VID(port) + 1, bitmap);
	    }
	}
}


/* Address management */

/* Do brute-force lookups and simple FIFO table management for now.  */

typedef struct host_s {
    uint8_t addr[ENET_ADDR_LEN];
    uint8_t module;
    uint8_t port;
    uint16_t portmap;    /* bit map for the local egress port(s) */
} host_t;

#define HOST_TAB_SIZE   16

static host_t hosts[HOST_TAB_SIZE];
static unsigned int last_host, next_host;

static void
host_init(bcm5670_state_t *sc)
{
    memset(hosts, 0, sizeof(hosts));
    last_host = next_host = 0;
}

static int
host_lookup (bcm5670_state_t *sc, uint8_t addr[])
{
    unsigned int i;

    i = last_host;
    do {
	if (memcmp(&hosts[i].addr, addr, ENET_ADDR_LEN) == 0) {
	    last_host = i;
	    return i;
	    }
	i = (i + 1) % HOST_TAB_SIZE;
    } while (i != last_host);

    return -1;
}

static void
host_add (bcm5670_state_t *sc, uint8_t addr[],
	  uint8_t module, uint8_t port, uint16_t map)
{
    if (host_lookup(sc, addr) == -1) {
	memcpy(&hosts[next_host].addr, addr, ENET_ADDR_LEN);
	hosts[next_host].module = module;
	hosts[next_host].port = port;
	hosts[next_host].portmap = map;

	if (XGS_DEBUG) xprintf("learn host %d: %a at %02x/%02x %04x\n",
			       next_host, addr, module, port, map);

	next_host = (next_host + 1) % HOST_TAB_SIZE;
	}
}


/* Packet management */

#define ETH_PKTPOOL_SIZE  16

static eth_pkt_t *
eth_alloc_pkt(bcm5670_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *) q_deqnext(&sc->freelist);
    CS_EXIT(sc);
    if (!pkt) return NULL;

    pkt->buffer = pkt->data;
    pkt->length = ETH_PKTBUF_LEN;
    pkt->flags = 0;

    return pkt;
}

static void
eth_free_pkt(bcm5670_state_t *sc, eth_pkt_t *pkt)
{
    CS_ENTER(sc);
    q_enqueue(&sc->freelist, &pkt->next);
    CS_EXIT(sc);
}

static void
eth_initfreelist(bcm5670_state_t *sc)
{
    int idx;
    uint8_t *ptr;
    eth_pkt_t *pkt;

    q_init(&sc->freelist);

    ptr = sc->pktpool;
    for (idx = 0; idx < ETH_PKTPOOL_SIZE; idx++) {
	pkt = (eth_pkt_t *) ptr;
	eth_free_pkt(sc, pkt);
	ptr += ETH_PKTBUF_SIZE;
	}
}



/* Packet DMA Service */

#define V_BIT_POS_RX1_EN         (V_DMA_BIT_POS(S_CH_DMA_EN(RX_CH1)))
#define V_BIT_POS_RX1_DESC_DONE  (V_DMA_BIT_POS(S_CH_DESC_DONE(RX_CH1)))
#define V_BIT_POS_RX1_CHAIN_DONE (V_DMA_BIT_POS(S_CH_CHAIN_DONE(RX_CH1)))

static int
xgs_add_rcvbuf(bcm5670_state_t *sc, eth_pkt_t *pkt)
{
    volatile dcb_t *dcb;
    volatile dcb_t *next;
    volatile dcb_t *last;
    uint32_t w1;

    dcb = sc->rx_add;

    next = dcb+1;
    if (next == sc->rx_end)
	next = sc->rx_start;

    /* If the next is the same as our remove pointer, the ring is
       considered full.  */
    if (next == sc->rx_remove)
	return -1;

    /* Add a descriptor with its chain bit off */
    memset((void *)dcb, 0, sizeof(dcb_t));
    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = (V_DCB1_BYTE_COUNT(ETH_PKTBUF_LEN)
	       | V_DCB1_COS(0));
    
    CACHE_DMA_INVAL(pkt->buffer, pkt->length);
    CACHE_DMA_SYNC(dcb, sizeof(dcb_t));

    /* Turn on the chain bit for the previous descriptor */

    /* XXX Chaining from last to first via the terminal RLD DCB
       appears to lose pending interrupts.  For now, cause an
       end-of-chain interrupt and restart instead. */
    if (dcb != sc->rx_start) {
	last = sc->rx_last;
	w1 = last->w1 | M_DCB1_C;
	last->w1 = w1;
	CACHE_DMA_SYNC(last, sizeof(dcb_t));   /* XXX or just write uncached? */
	}
    
    sc->rx_last = dcb;
    sc->rx_add = next;
    return 0;
}

static void
xgs_fillrxring(bcm5670_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    while (1) {
	if (sc->rx_onring >= MIN_RX_BUFFERS) {
	    CS_EXIT(sc);
	    break;
	    }
	CS_EXIT(sc);
	pkt = eth_alloc_pkt(sc);
	if (pkt == NULL) {
	    /* could not allocate a buffer */
	    break;
	    }
	if (xgs_add_rcvbuf(sc, pkt) != 0) {
	    /* could not add buffer to ring */
	    eth_free_pkt(sc, pkt);
	    break;
	    }
	CS_ENTER(sc);
	sc->rx_onring++;
	}
}

static void
xgs_rx_callback(bcm5670_state_t *sc, eth_pkt_t *pkt)
{
    if (XGS_DEBUG) show_packet('>', pkt);   /* debug */

    CS_ENTER(sc);
    q_enqueue(&sc->rxqueue, &pkt->next);
    CS_EXIT(sc);
    sc->inpkts++;
}

static void
xgs_procrxring(bcm5670_state_t *sc)
{
    volatile dcb_t *dcb;
    eth_pkt_t *pkt;
    eth_pkt_t *new_pkt;

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_DESC_DONE | V_DMA_BIT_0);

    while (1) {
	dcb = sc->rx_remove;
	CACHE_DMA_INVAL(dcb, sizeof(dcb_t));

	if (dcb == sc->rx_add || (dcb->w6 & M_DCB6_DONE) == 0)
	    break;
    
#if XGS_DEBUG
	xprintf("recv: dcb %08x %08x %08x %08x\n"
		"          %08x %08x %08x %08x\n",
		dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
		dcb->w4, dcb->w5, dcb->w6, dcb->w7);
#endif

	pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));
	pkt->length = G_DCB5_RCV_COUNT(dcb->w5) - ENET_CRC_SIZE;
	CACHE_DMA_INVAL(pkt->buffer, pkt->length);

	/* Learn src addresses only from unicast.  This assumes that
	   the appropriate egress port is the same as the ingress
	   port.  In an interrupt-driven system, it would be better to
	   defer this, but the descriptor information must be saved in
	   that case.  */
	if ((pkt->buffer[XGS_HDR_LEN+0] & 0x01) == 0)
	    host_add(sc, &pkt->buffer[XGS_HDR_LEN+ENET_ADDR_LEN],
		     (pkt->buffer[4] >> 3) & 0x1F,
		     (pkt->buffer[5] >> 0) & 0x1F,
		     PORT_BIT(G_DCB6_SRC_PORT(dcb->w6)));

	xgs_rx_callback(sc, (eth_pkt_t *)pkt);
    
	/* update the remove pointer */
	dcb++;
	if (dcb == sc->rx_end)
	    dcb = sc->rx_start;
	sc->rx_remove = dcb;

	new_pkt = eth_alloc_pkt(sc);
	if (new_pkt) {
	    /* The ring must have space now. */
	    xgs_add_rcvbuf(sc, new_pkt);
	    }
	else {
	    CS_ENTER(sc);
	    sc->rx_onring--;
	    CS_EXIT(sc);
	    }
	}
}

static void
xgs_procrxdone(bcm5670_state_t *sc)
{
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_CHAIN_DONE | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_DESC(RX_CH1), PTR_TO_PCI(sc->rx_remove));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_1);
}


#define V_BIT_POS_TX_EN          (V_DMA_BIT_POS(S_CH_DMA_EN(TX_CH)))
#define V_BIT_POS_TX_DESC_DONE   (V_DMA_BIT_POS(S_CH_DESC_DONE(TX_CH)))
#define V_BIT_POS_TX_CHAIN_DONE  (V_DMA_BIT_POS(S_CH_CHAIN_DONE(TX_CH)))

static int
xgs_transmit(bcm5670_state_t *sc, eth_pkt_t *pkt)
{
    portmap_t portmap;
    /*volatile*/ dcb_t *dcb;

    if (sc->txbusy)
	return -1;

    sc->txbusy = 1;

    /* Fill in the XGS-format header (reserved and zeroed by caller) */
    pkt->buffer[0] = K_HIGIG_START;
    pkt->buffer[1] = K_HIGIG_HGI;
    pkt->buffer[2] = VLAN_DEFAULT >> 8; pkt->buffer[3] = VLAN_DEFAULT & 0xFF;
    pkt->buffer[4] = (sc->module << 3);
    pkt->buffer[5] = (CMIC_PORT << 0);

    /* For unicast destinations, use the learned mod/port address if any,
       otherwise broadcast.  */
    if ((pkt->buffer[XGS_HDR_LEN+0] & 0x01) == 0) {
	int i = host_lookup(sc, &pkt->buffer[XGS_HDR_LEN+0]);

	if (i != -1) {
	    pkt->buffer[4] |= (K_HIGIG_OP_UC << 0);  /* Unicast */
	    pkt->buffer[6] = (hosts[i].port << 3);
	    pkt->buffer[7] = (hosts[i].module << 0);
	    portmap = hosts[i].portmap;
	    }
	else {
	    if (XGS_DEBUG) xprintf("DLF host %a\n", &pkt->buffer[XGS_HDR_LEN]);
	    pkt->buffer[4] |= (K_HIGIG_OP_BC << 0);  /* DLF */
	    portmap = sc->portmap;
	    }
	}
    else {
	pkt->buffer[4] |= (K_HIGIG_OP_BC << 0);      /* Broadcast */
	portmap = sc->portmap;
#if 1 /* XXX from rx trace. Magic or arbitrary ??? */
	pkt->buffer[6] = 0xE0;
	pkt->buffer[7] = 0x00;
#endif
        }

    if (XGS_DEBUG) show_packet('<', pkt);

    /* The CMIC "recomputes" the CRC, does not append it. */
    pkt->length += ENET_CRC_SIZE;

    dcb = sc->dcbs[TX_CH];
    memset(dcb, 0, sizeof(dcb_t));
    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = (V_DCB1_BYTE_COUNT(pkt->length)
	       | V_DCB1_CRC_REGEN(1)
	       | V_DCB1_COS(0));
    dcb->w2 = V_DCB2_PORT_MAP(portmap);
    
    CACHE_DMA_SYNC(pkt->buffer, pkt->length);
    CACHE_DMA_SYNC(dcb, sizeof(dcb_t));

    WRITECSR(sc, R_CMIC_DMA_DESC(TX_CH), PTR_TO_PCI(dcb));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_1);

    sc->outpkts++;
    return 0;
}

static void
xgs_proctxchain(bcm5670_state_t *sc)
{
    /*volatile*/ dcb_t *dcb;
    eth_pkt_t *pkt;

    if (!sc->txbusy)
	return;

    dcb = sc->dcbs[TX_CH];
    CACHE_DMA_INVAL(dcb, sizeof(dcb_t));

    if ((dcb->w6 & M_DCB6_DONE) == 0)
	return;

#if XGS_DEBUG
    xprintf("xmit: dcb %08x %08x %08x %08x\n          %08x %08x %08x %08x\n",
	    dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
	    dcb->w4, dcb->w5, dcb->w6, dcb->w7);
#endif

    /* Just free the packet */
    pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));
    eth_free_pkt(sc, pkt);

    /* Evidently, the channel will not restart until CHAIN_DONE is
       clear, and empirically, CHAIN_DONE cannot reliably be cleared
       until DMA_EN is cleared. */

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_DESC_DONE | V_DMA_BIT_0);
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_CHAIN_DONE | V_DMA_BIT_0);

    sc->txbusy = 0;
}


static void
xgs_initrings(bcm5670_state_t *sc)
{
    dcb_t *rxd;

    /* Initialize the ring control bits */
    for (rxd = sc->rx_start; rxd != sc->rx_end; rxd++) {
	memset(rxd, 0, sizeof(dcb_t));
	rxd->w1 = 0;    /* Clear S/G, RLD, C */
	CACHE_DMA_SYNC(rxd, sizeof(dcb_t));
	}

    /* The final descriptor is used just to close the ring (RLD). It
       is never read or updated again by software and can safely share
       a cache line with the preceding descriptor.
       XXX This feature is (temporarily?) not used; see above.  */
    rxd = sc->rx_end;
    memset(rxd, 0, sizeof(dcb_t));
    rxd->mem_addr = PTR_TO_PCI(sc->rx_start);
    rxd->w1 = M_DCB1_RLD | M_DCB1_C;
    CACHE_DMA_SYNC(rxd, sizeof(dcb_t));

    sc->rx_add = sc->rx_remove = sc->rx_start;
    sc->rx_last = sc->rx_end;
    sc->rx_onring = 0;

    /* Precharge the receive ring. */
    xgs_fillrxring(sc);

    /* Start DMA.  XXX Make this a function? */
    WRITECSR(sc, R_CMIC_DMA_DESC(RX_CH1), PTR_TO_PCI(sc->rx_remove));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_1);
}

static void
xgs_init(bcm5670_state_t *sc)
{
    /* Allocate buffer pool */
    sc->pktpool = KMALLOC(ETH_PKTPOOL_SIZE*ETH_PKTBUF_SIZE, CACHE_ALIGN);
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);

    sc->dcbs[TX_CH] = KMALLOC(sizeof(dcb_t), CACHE_ALIGN);
    sc->txbusy = 0;

    /* The final rx DCB is used just for chaining. */
    sc->dcbs[RX_CH1] = KMALLOC((RX_RING_SIZE+1) * sizeof(dcb_t), CACHE_ALIGN);

    sc->rx_start = sc->dcbs[RX_CH1];
    sc->rx_end = sc->rx_start + RX_RING_SIZE;

    xgs_initrings(sc);
}

static void
xgs_reinit(bcm5670_state_t *sc)
{
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);

    /* XXX Initialize descriptor lists */
}


static void
xgs_hwinit(bcm5670_state_t *sc)
{
    if (sc->state != eth_state_on) {
	uint32_t config;

#if ENDIAN_BIG
	/* Documentation is confusing/misleading here.  For 47xx and 1250: */
	WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x02020202);
#else
	WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x00000000);
#endif
	WRITECSR(sc, R_CMIC_PKT_HEADER, K_HDR_MODE_HIGIG);

	/* Clear S-channel bits */
	WRITECSR(sc, R_CMIC_SCHAN_CTRL,
		 V_SCTL_BIT_POS(S_SCTL_MIIM_OP_DONE) | V_SCTL_BIT_0);
	WRITECSR(sc, R_CMIC_SCHAN_CTRL,
		 V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_0);

	config = READCSR(sc, R_CMIC_CONFIG);
	/* PCI interface options. */
	config |= M_RD_BRST_EN | M_WR_BRST_EN | M_MSTR_Q_MAX_EN;
	/* DMA options */
	config |= M_MIS_ALIGN_DMA_MRD_ADDR_EN | M_EN_SG_OPN | M_EN_RLD_OPN;
	WRITECSR(sc, R_CMIC_CONFIG, config);

	/* Configure DMA channels. */
	WRITECSR(sc, R_CMIC_DMA_CTRL, M_CH_DIRECTION(TX_CH));

	sc->portmap = xgxs_port_scan(sc);
	xprintf("enabled port map: %04X\n", sc->portmap);

	lla_init(sc, sc->portmap | CMIC_BIT);
	//lla_init(sc, sc->portmap | CMIC_BIT);

	mmu_init(sc, sc->portmap | CMIC_BIT);
	ingress_init(sc, sc->portmap | CMIC_BIT);
	table_init(sc, sc->portmap | CMIC_BIT);

	xgxs_port_init(sc);

	sc->state = eth_state_off;
	}
}


static void
xgs_isr(void *arg)
{
    bcm5670_state_t *sc = (bcm5670_state_t *)arg;
    uint32_t irqstat = READCSR(sc, R_CMIC_IRQ_STAT);

    if (IPOLL) sc->interrupts++;

    /* XGS DMA does not guarantee the order in which the DESC_DONE and
       CHAIN_DONE interrupts are delivered.  The following code does
       assume that the DONE bits of all completed descriptors are set
       before either interrupt is asserted. */

    if (irqstat & M_IRQ_CHAIN_DONE(RX_CH1)) {
	if (IPOLL) sc->rx_interrupts++;
        xgs_procrxring(sc);
	xgs_procrxdone(sc);
	}
    else if (irqstat & M_IRQ_DESC_DONE(RX_CH1)) {
	if (IPOLL) sc->rx_interrupts++;
        xgs_procrxring(sc);
	}

    if (irqstat & M_IRQ_CHAIN_DONE(TX_CH)) {
	if (IPOLL) sc->tx_interrupts++;
        xgs_proctxchain(sc);
	}
}

static void
xgs_start(bcm5670_state_t *sc)
{
    uint32_t pending;

    if (sc->state == eth_state_switch) {
	/* XXX Reconnect the CMIC port here. */
	}
    else {
	host_init(sc);

	xgs_hwinit(sc);

	sc->intmask = 0;
	WRITECSR(sc, R_CMIC_IRQ_MASK, 0);
	pending = READCSR(sc, R_CMIC_IRQ_STAT);
	WRITECSR(sc, R_CMIC_IRQ_STAT, pending);
	(void)READCSR(sc, R_CMIC_IRQ_STAT);   /* push */
	}

    sc->intmask = (M_IRQ_CHAIN_DONE(RX_CH1) | M_IRQ_DESC_DONE(RX_CH1)
		   | M_IRQ_CHAIN_DONE(TX_CH));

#if IPOLL
    cfe_request_irq(sc->irq, xgs_isr, sc, CFE_IRQ_FLAGS_SHARED, 0);
    WRITECSR(sc, R_CMIC_IRQ_MASK, sc->intmask);
#endif

    sc->state = eth_state_on;
}

static void
xgs_stop(bcm5670_state_t *sc)
{
    xgxs_port_stop(sc);

    if (sc->state == eth_state_on) {
	sc->intmask = 0;
	WRITECSR(sc, R_CMIC_IRQ_MASK, 0);
	(void)READCSR(sc, R_CMIC_IRQ_MASK);   /* push */
#if IPOLL
	cfe_free_irq(sc->irq, 0);
#endif

	/* XXX Shut down the CPU interface here. */

	xgs_reinit(sc);
	sc->state = eth_state_switch;
	}
}


static int bcm5670_open(cfe_devctx_t *ctx);
static int bcm5670_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5670_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat);
static int bcm5670_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5670_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5670_close(cfe_devctx_t *ctx);
static void bcm5670_poll(cfe_devctx_t *ctx, int64_t ticks);
static void bcm5670_reset(void *softc);

const static cfe_devdisp_t bcm5670_dispatch = {
    bcm5670_open,
    bcm5670_read,
    bcm5670_inpstat,
    bcm5670_write,
    bcm5670_ioctl,
    bcm5670_close,	
    bcm5670_poll,
    bcm5670_reset
};

cfe_driver_t bcm5670drv = {
    "BCM567x fabric",
    "eth",
    CFE_DEV_NETWORK,
    &bcm5670_dispatch,
    bcm5670_probe
};


static int
bcm5670_attach(cfe_driver_t *drv, pcitag_t tag, uint8_t hwaddr[])
{
    bcm5670_state_t *sc;
    char descr[80];
    phys_addr_t pa;
    pcireg_t device, class;
    uint32_t cmic_id;

    pci_map_mem(tag, PCI_MAPREG(0), CSR_MATCH_MODE, &pa);

    sc = (bcm5670_state_t *) KMALLOC(sizeof(bcm5670_state_t), 0);
    if (sc == NULL) {
	xprintf("BCM569x: No memory to complete probe\n");
	return 0;
	}
    memset(sc, 0, sizeof(*sc));

    sc->regbase = (uint32_t)pa;
    sc->irq = pci_conf_read(tag, PCI_BPARAM_INTERRUPT_REG) & 0xFF;

    device = pci_conf_read(tag, PCI_ID_REG);
    class = pci_conf_read(tag, PCI_CLASS_REG);
    sc->tag = tag;
    sc->device = PCI_PRODUCT(device);
    sc->revision = PCI_REVISION(class);
    switch (sc->device) {
	case K_PCI_ID_BCM5670:
	default:
	    sc->higig_port_mask = (0xFF << 1);
	    break;
	case K_PCI_ID_BCM5671:
	    sc->higig_port_mask = (0xA5 << 1);
	    break;
	}

    cmic_id = READCSR(sc, R_CMIC_DEVICE_ID);
    sc->module = 2;   /* XXX Get from environment or GPIO? */

    sc->devctx = NULL;

    /* Always use the MAC address that was passed in. */
    memcpy(sc->hwaddr, hwaddr, ENET_ADDR_LEN);

    xgs_init(sc);
    sc->state = eth_state_uninit;

    xsprintf(descr, "BCM%04X XGS Switch Fabric (mod %02X) at 0x%08X",
	     sc->device, sc->module, sc->regbase);
    cfe_attach(drv, sc, NULL, descr);

    return 1;
}

static void
bcm5670_probe(cfe_driver_t *drv,
	      unsigned long probe_a, unsigned long probe_b, 
	      void *probe_ptr)
{
    int index;
    uint8_t hwaddr[ENET_ADDR_LEN];

    if (probe_ptr)
	enet_parse_hwaddr((char *)probe_ptr, hwaddr);
    else {
	/* Use default address 02-10-18-56-70-01 */
	hwaddr[0] = 0x02;  hwaddr[1] = 0x10;  hwaddr[2] = 0x18;
	hwaddr[3] = 0x56;  hwaddr[4] = 0x70;  hwaddr[5] = 0x01;
	}

    index = 0;
    for (;;) {
	pcitag_t tag;
	pcireg_t device;

	if (pci_find_class(PCI_CLASS_NETWORK, index, &tag) != 0)
	   break;

	index++;

	device = pci_conf_read(tag, PCI_ID_REG);
	if (PCI_VENDOR(device) == K_PCI_VENDOR_BROADCOM) {
	    switch (PCI_PRODUCT(device)) {
		case K_PCI_ID_BCM5670:
		case K_PCI_ID_BCM5671:
		    bcm5670_attach(drv, tag, hwaddr);
		    enet_incr_hwaddr(hwaddr, 1);
		    break;
		default:
		    break;
		}
	    }
	}
}


/* The functions below are called via the dispatch vector for the XGS switch */

static int
bcm5670_open(cfe_devctx_t *ctx)
{
    bcm5670_state_t *sc = ctx->dev_softc;

    if (sc->state == eth_state_on)
	xgs_stop(sc);

    sc->devctx = ctx;

    sc->inpkts = sc->outpkts = 0;
    sc->interrupts = 0;
    sc->rx_interrupts = sc->tx_interrupts = 0;

    xgs_start(sc);

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm5670_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm5670_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *)q_deqnext(&(sc->rxqueue));
    CS_EXIT(sc);

    if (pkt == NULL) {
	buffer->buf_retlen = 0;
	return 0;
	}

    blen = buffer->buf_length - XGS_HDR_LEN;
    if (blen > pkt->length) blen = pkt->length;

    /* Remove the XGS header. */
    hs_memcpy_to_hs(buffer->buf_ptr, pkt->buffer + XGS_HDR_LEN, blen);
    buffer->buf_retlen = blen;

    eth_free_pkt(sc, pkt);

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm5670_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    bcm5670_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    /* We avoid an interlock here because the result is a hint and an
       interrupt cannot turn a non-empty queue into an empty one. */
    inpstat->inp_status = (q_isempty(&(sc->rxqueue))) ? 0 : 1;

    return 0;
}

static int
bcm5670_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm5670_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    pkt = eth_alloc_pkt(sc);
    if (!pkt) return CFE_ERR_NOMEM;

    blen = buffer->buf_length;
    if (blen > pkt->length - XGS_HDR_LEN)
	blen = pkt->length - XGS_HDR_LEN;

    /* Reserve space for an XGS-format header as a prefix. */
    memset(pkt->buffer, 0, XGS_HDR_LEN);
    hs_memcpy_from_hs(pkt->buffer+XGS_HDR_LEN, buffer->buf_ptr, blen);

    /* The CMIC apparently does not correctly auto-pad short packets. */
    if (blen < ENET_MIN_PKT) {
	memset(pkt->buffer + XGS_HDR_LEN + blen, 0, ENET_MIN_PKT - blen);
	blen = ENET_MIN_PKT;
	}

    pkt->length = blen + XGS_HDR_LEN;

    if (xgs_transmit(sc, pkt) != 0) {
	eth_free_pkt(sc,pkt);
	return CFE_ERR_IOERR;
	}

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm5670_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    bcm5670_state_t *sc = ctx->dev_softc;

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_ETHER_GETHWADDR:
	    hs_memcpy_to_hs(buffer->buf_ptr, sc->hwaddr, sizeof(sc->hwaddr));
	    return 0;

	default:
	    return -1;
	}
}

static int
bcm5670_close(cfe_devctx_t *ctx)
{
    bcm5670_state_t *sc = ctx->dev_softc;

    xgs_stop(sc);

    xprintf("%s: %d sent, %d received",
	    xgs_devname(sc), sc->outpkts, sc->inpkts);
    if (IPOLL) {
	xprintf(", %d interrupts\n", sc->interrupts);
	xprintf("  %d tx interrupts, %d rx interrupts",
		sc->tx_interrupts, sc->rx_interrupts);
	}
    xprintf("\n");

    sc->devctx = NULL;
    return 0;
}

static void
bcm5670_poll(cfe_devctx_t *ctx, int64_t ticks)
{
    bcm5670_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);
}

static void
bcm5670_reset(void *softc)
{
    bcm5670_state_t *sc = (bcm5670_state_t *)softc;

    /* Turn off the Ethernet interface. */

    if (sc->state == eth_state_on)
	xgs_stop(sc);

    sc->state = eth_state_uninit;
}
