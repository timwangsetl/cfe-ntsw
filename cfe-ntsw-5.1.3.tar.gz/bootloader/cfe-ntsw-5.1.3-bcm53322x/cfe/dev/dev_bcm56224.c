/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM56224 Ethernet Switch	     File: dev_bcm56224.c
    *  
    *  Author: Sanjay Gupta
    *
    *********************************************************************  
    *
    *  Copyright 2007
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */
#include "cfe.h"
#include "bcmnvram.h"
#include "lib_physio.h"
#include "cfe_irq.h"
#include "net_enet.h"
#include "pcivar.h"
#include "pcireg.h"
#include "mii.h"
#include "bcm_cmn.h"
#include "env_subr.h"
#include "dev_bcm56224.h"

#ifdef CPUCFG_MEMCPY
extern void *CPUCFG_MEMCPY(void *dest, const void *src, size_t cnt);
#define blockcopy(d, s, l) CPUCFG_MEMCPY((void*)a, (void*)b, l)
#else
#define blockcopy(d, s, l) memcpy((void*)d, (void*)s, l)
#endif

#define XGS_DEBUG               0
#define ETH_DRV_ENABLE_GE       1

#define PORTS_PER_BLOCK         12

#define M_EGRESS_MASK_SIZE      1024 /* Egress mask table size  */
#define M_VLAN_SIZE             4096 /* Vlan table size         */
#define M_STG_SIZE              256  /* STG table size          */
#define M_MAC_BLOCK_SIZE        32
#define M_L2X_SIZE              16384

#define PORT_BASE                1
#define CMIC_PORT                0

#define GPIC_BIT(port)           (1 << (port))
#define CMIC_BIT                 (1 << CMIC_PORT)

#define ICS_CMIC_BASE               0xa8000000

#define WRITE_EPC_LINK_MAP(sc, MAP, MAP1) \
        schan_write_reg(sc, R_EPC_LINK_BMAP, MAP);        \
        schan_write_reg(sc, R_EPC_LINK_BMAP_HI, MAP1);

#define BLOCK_ID(port)  \
    (port < 6) ? ((port == 0) ? 0 : 1) : ((port - 6)/PORTS_PER_BLOCK + 2)
    
#define PORT_IDX(port)  \
        (port < 6) ?    \
        ((port == 0) ? 0 : ((port - 1) % 5)) : ((port-6) % PORTS_PER_BLOCK) 


#define K_PCI_ID_BCM56224       0xb224

/* Boards supported */
typedef struct brd_info_s {
    char            *name;
    int             num_port;
    uint32_t        gmii_mask;
    uint32_t        gmii_mask_hi;
    uint32_t        ge_capable_mask;
    uint32_t        ge_capable_mask_hi;
    uint32_t        int_phy_mask;
    uint32_t        int_phy_mask_hi;
    uint32_t        download_mask;
    uint32_t        download_mask_hi;
    uint32_t        (*get_phy_addr)(int unit, int p);
    uint32_t        (*get_int_phy_addr)(int p);
    uint32_t        (*get_default_speed)(int unit,int p);
    uint8_t         *led_code;
    uint8_t         led_code_size;
} brd_info_t;

static brd_info_t * board_info;

#define IS_GMII_PORT(p)     \
            (((p) < 32) ? ((1 << (p)) & board_info->gmii_mask) : \
                         ((1 << ((p) - 32)) & board_info->gmii_mask_hi))

#define IS_INT_PHY_PRESENT(p)     \
            (((p) < 32) ? ((1 << (p)) & board_info->int_phy_mask) : \
                         ((1 << ((p) - 32)) & board_info->int_phy_mask_hi))

#define IS_GE_CAP(p)     \
            (((p) < 32) ? ((1 << (p)) & board_info->ge_capable_mask) : \
                 ((1 << ((p) - 32)) & board_info->ge_capable_mask_hi))

#define GPIC_PORTS  board_info->num_port

#define IS_DOWNLOAD_PORT(sc, p) \
            (((p) < 32) ? ((1 << (p)) & sc->download_mask) : \
                 ((1 << ((p) - 32)) & sc->download_mask_hi))

#define PORT_TO_PHY_ADDR(u, p) board_info->get_phy_addr(u, p)
#define PORT_TO_PHY_ADDR_INT(p) board_info->get_int_phy_addr(p)
#define GET_DEFAULT_PORT_SPEED(u, p) board_info->get_default_speed(u, p)

#define GET_LED_CODE(u)     board_info->led_code
#define GET_LED_CODE_SIZE(u)     board_info->led_code_size

#define PHY_LINK_UP 0x1
#define LED_PORT_STATUS_OFFSET(p)       R_CMIC_LEDUP_DATA_RAM_D(0xa0 + (p))

#if ((ENDIAN_BIG + ENDIAN_LITTLE) != 1)
#error "dev_bcm56224: system endian not set"
#endif

static int ndevs = 0;

static uint32_t IS_ST_PORT(int p)
{
#define RAVEN_ST_MAP    0x36
    return ((1<<p) & RAVEN_ST_MAP) ? 1 : 0;
}

static uint32_t PORT_TO_PHY_ADDR_INT_DEFAULT(int p)
{
    return (p + ((p > 29) ? (0xc0 - 30) : (0x80)));
}

static uint32_t PORT_TO_PHY_ADDR_DEFAULT(int unit, int p)
{
    if (IS_ST_PORT(p)) {
        return PORT_TO_PHY_ADDR_INT_DEFAULT(p);
    }

    return (p + ((p > 29) ? (0x40 - 29) : (1)));
}

#define BCM956224R50T_LINK_GMII_PORT         1
#define BCM956224R50T_LINK_UPLINK_PORT       2
#define BCM956224R50T_LINK_STACK_PORT        3
#define BCM956224R50T_LINK_SELECT        BCM956224R50T_LINK_GMII_PORT

static uint32_t PORT_TO_PHY_ADDR_956224R50T(int unit, int p)
{
#if (BCM956224R50T_LINK_SELECT == BCM956224R50T_LINK_GMII_PORT)
    if ((p == 3) || (p == 4) || (p == 1)) {
        return 0;
    }
#elif (BCM956224R50T_LINK_SELECT == BCM956224R50T_LINK_UPLINK_PORT) || \
      (BCM956224R50T_LINK_SELECT == BCM956224R50T_LINK_STACK_PORT)

    if ((p == 4) || (p == 1)) {
        return PORT_TO_PHY_ADDR_INT(p);
    }
    if (p == 3) {
        return 0;
    }
#else
#error "No link selected between master and slave unit for BCM956224R50T platform.";
#endif

    if (p == 5)
        return (unit == 0) ? 6 : 5;
    return (p + ((p > 29) ? (0x40 - 29) : (1)));
}

static uint32_t PORT_DEFAULT_SPEED_956224R50T(int unit, int p)
{
#if (BCM956224R50T_LINK_SELECT == BCM956224R50T_LINK_GMII_PORT)
    if (p == 3) {
        return ETHER_SPEED_100FDX;
    }
    if ((p == 1) || (p == 4)) {
        return (unit == 0) ? ETHER_SPEED_100FDX : ETHER_SPEED_1000FDX;
    }
#elif (BCM956224R50T_LINK_SELECT == BCM956224R50T_LINK_UPLINK_PORT)
    if (p == 4) {
        return ETHER_SPEED_1000FDX;
    }
    if ((p == 1) || (p == 3)) {
        return (unit == 0) ? ETHER_SPEED_100FDX : ETHER_SPEED_1000FDX;
    }
#elif (BCM956224R50T_LINK_SELECT == BCM956224R50T_LINK_STACK_PORT)
    if (p == 1) {
        return ETHER_SPEED_1000FDX;
    }
    if ((p == 3) || (p == 4)) {
        return (unit == 0) ? ETHER_SPEED_100FDX : ETHER_SPEED_1000FDX;
    }
#else
#error "No link selected between master and slave unit for BCM956024P48 platform.";
#endif

    return ETHER_SPEED_UNKNOWN; 
}


static uint32_t PORT_DEFAULT_SPEED(int unit, int p)
{
    return ETHER_SPEED_UNKNOWN;
}

/* led program data from bcm956024p48ref.hex */
static uint8_t bcm956224_eb_led_program[] = {
 0x02,0x06,0x28,0x60,0xC3,0x67,0x30,0x67,0x6C,0x06,0xC3,0x80,0xD2,0x1E,0x74,0x02,
 0x12,0xC2,0x85,0x05,0xD2,0x0F,0x71,0x1A,0x52,0x00,0x12,0xC1,0x85,0x05,0xD2,0x1F,
 0x71,0x24,0x52,0x00,0x12,0xC0,0x85,0x05,0xD2,0x05,0x71,0x2E,0x52,0x00,0x3A,0x60,
 0x32,0x00,0x97,0x75,0x3C,0x12,0xC0,0xFE,0xC3,0x02,0x0A,0x50,0x32,0x01,0x97,0x75,
 0x48,0x12,0xE0,0xFE,0xC3,0x02,0x0A,0x50,0x12,0xE0,0xFE,0xC3,0x95,0x75,0x5A,0x85,
 0x12,0xC0,0xFE,0xC3,0x95,0x75,0xA9,0x85,0x77,0x9B,0x12,0xC0,0xFE,0xC3,0x95,0x75,
 0x64,0x85,0x77,0xA2,0x16,0xC0,0xDA,0x02,0x71,0xA2,0x77,0xA9,0x32,0x05,0x97,0x71,
 0x7C,0x32,0x02,0x97,0x71,0x9B,0x06,0xC1,0xD2,0x01,0x71,0x9B,0x06,0xC3,0x67,0x94,
 0x75,0x9B,0x32,0x03,0x97,0x71,0xA9,0x32,0x04,0x97,0x75,0xA2,0x06,0xC2,0xD2,0x07,
 0x71,0xA2,0x77,0xA9,0x12,0xA0,0xF8,0x15,0x1A,0x00,0x57,0x32,0x0E,0x87,0x32,0x0E,
 0x87,0x57,0x32,0x0E,0x87,0x32,0x0F,0x87,0x57,0x32,0x0F,0x87,0x32,0x0E,0x87,0x57
};

static brd_info_t _brd_info[] = {
    { "BCM956224K24", 30, 
       0x00000008, 0x00000000, /* GMII *    */
       0x3ffffffe, 0x00000000, /* GE CAP    */
       0x3ffffff6, 0x00000000, /* INT PHY   */
       0x3ffffffe, 0x00000000, /* Download port */
       PORT_TO_PHY_ADDR_DEFAULT,
       PORT_TO_PHY_ADDR_INT_DEFAULT,
       PORT_DEFAULT_SPEED,
       NULL, 0
    },
    { "BCM956024K24", 30, 
       0x00000008, 0x00000000, /* GMII *    */
       0x0000003e, 0x00000000, /* GE CAP    */
       0x00000036, 0x00000000, /* INT PHY   */
       0x3ffffffe, 0x00000000, /* Download port */
       PORT_TO_PHY_ADDR_DEFAULT,
       PORT_TO_PHY_ADDR_INT_DEFAULT,
       PORT_DEFAULT_SPEED,
       NULL, 0
    },
    { "BCM956224R50T", 30, 
       0x00000008, 0x00000000, /* GMII *    */
       0x3ffffffe, 0x00000000, /* GE CAP    */
       0x3ffffff6, 0x00000000, /* INT PHY   */
       0x3ffffffe, 0x00000000, /* Download port */
       PORT_TO_PHY_ADDR_956224R50T,
       PORT_TO_PHY_ADDR_INT_DEFAULT,
       PORT_DEFAULT_SPEED_956224R50T,
       bcm956224_eb_led_program, sizeof(bcm956224_eb_led_program) 
    },
    { "BCM956024R50T", 30, 
       0x00000008, 0x00000000, /* GMII *    */
       0x0000003e, 0x00000000, /* GE CAP    */
       0x00000036, 0x00000000, /* INT PHY   */
       0x3ffffffe, 0x00000000, /* Download port */
       PORT_TO_PHY_ADDR_956224R50T,
       PORT_TO_PHY_ADDR_INT_DEFAULT,
       PORT_DEFAULT_SPEED_956224R50T,
       bcm956224_eb_led_program, sizeof(bcm956224_eb_led_program) 
    },
    { "BCM953724R26GWS", 30, 
       0x00000008, 0x00000000, /* GMII *    */
       0x3ffffffe, 0x00000000, /* GE CAP    */
       0x3ffffff6, 0x00000000, /* INT PHY   */
       0x3ffffffe, 0x00000000, /* Download port */
       PORT_TO_PHY_ADDR_DEFAULT,
       PORT_TO_PHY_ADDR_INT_DEFAULT,
       PORT_DEFAULT_SPEED,
       NULL, 0
    },
    { NULL, -1  },
};


/* Set IPOLL to drive processing through the pseudo-interrupt
   dispatcher.  Set XPOLL to drive processing by an external polling
   agent.  One must be set; setting both is ok. */
  
#ifndef IPOLL
#define IPOLL 0
#endif
#ifndef XPOLL
#define XPOLL 1
#endif

#define MIN_ETHER_PACK  (ENET_MIN_PKT+ENET_CRC_SIZE)   /* size of min packet */
#define MAX_ETHER_PACK  (ENET_MAX_PKT+ENET_CRC_SIZE)   /* size of max packet */
#define VLAN_TAG_LEN    4                              /* VLAN type plus tag */
#define VLAN_TYPE       0x8100
#define VLAN_DEFAULT    1
#define STG_DEFAULT    1
#define MAX_VLAN_PACK   (MAX_ETHER_PACK+VLAN_TAG_LEN)

#define BLOCK_BP                    20     /* it is for XGS3 */

/* define MACRO for multi-chips on platform */
#define MAX_UNIT_NUM            2
#define TX_UNIT_NUM             0

/* Packet buffers.  For the XGS CMIC, packet buffer alignment is
   arbitrary and can be to any byte boundary.  We would like it
   aligned to a cache line boundary for performance, although there is
   a trade-off with IP/TCP header alignment, and to facilitate cache
   flushing on hosts requiring that.  */
#define ETH_PKTBUF_LEN      (((MAX_VLAN_PACK+31)/32)*32)

#if __long64
typedef struct eth_pkt_s {
    queue_t next;			/* 16 */
    uint8_t *buffer;			/*  8 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;
#else
typedef struct eth_pkt_s {
    queue_t next;			/*  8 */
    uint8_t *buffer;			/*  4 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint32_t unused[3];			/* 12 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;
#endif

#define BCM_CACHE_DMA_INVAL(d, l)   \
        { CACHE_DMA_INVAL(d, l); }

#define BCM_CACHE_DMA_SYNC(d, l)   \
        { CACHE_DMA_SYNC(d, l);  }

#define CACHE_ALIGN       32
#define ETH_PKTBUF_LINES  ((sizeof(eth_pkt_t) + (CACHE_ALIGN-1))/CACHE_ALIGN)
#define ETH_PKTBUF_SIZE   (ETH_PKTBUF_LINES*CACHE_ALIGN)
#define ETH_PKTBUF_OFFSET (offsetof(eth_pkt_t, data))

#define ETH_PKT_BASE(data) ((eth_pkt_t *)((data) - ETH_PKTBUF_OFFSET))

/* BCM56224 Hardware Common Data Structures */
/* DMA Control Block as a struct.  See DCBn_ definitions for word n. */
typedef struct dcb_s {
    uint32_t mem_addr;                /* buffer or chain address */
    uint32_t w1;
    uint32_t w2;
    uint32_t w3;
    uint32_t w4;
    uint32_t w5;
    uint32_t w6;
    uint32_t w7;
    uint32_t w8;
    uint32_t w9;
    uint32_t w10;
    uint32_t pading[1];
} dcb_t;

typedef enum {
    eth_state_uninit,
    eth_state_off,
    eth_state_on, 
} eth_state_t;

typedef struct phy_info_s {
    uint8_t  addr;                /* external PHY */
    uint8_t  linkspeed;
} phy_info_t;

typedef struct bcm56224_state_s {

    /* PCI access information */
    uint32_t  regbase;
    uint8_t   irq;
    pcitag_t  tag;		   /* tag for configuration registers */

#define XGS_BUS_CAP_DMA         1
#define XGS_DEVICE_SLAVE        0x10
#define XGS_DEVICE_RD_16BIT     0x10000
#define XGS_DEVICE_WR_16BIT     0x20000
    uint32_t  bus_flag;

    uint8_t   hwaddr[ENET_ADDR_LEN];
    uint16_t  device;              /* chip device code */
    uint8_t   revision;            /* chip revision */
    uint16_t  asic_revision;       /* mask revision */
    int       higig;
    int       modid;

    eth_state_t state;             /* current state */
    uint32_t intmask;              /* interrupt mask */

    /* packet free lists */
    queue_t freelist;
    uint8_t *pktpool;
    queue_t rxqueue;

    /* rings */
    dcb_t *dcbs[4];
    int txbusy;

    int restartrx;

    cfe_devctx_t *devctx;

    struct bcm56224_state_s * slv_dev;

    /* ports */
    unsigned int unit;           /* local mod_id */
    unsigned int portmap;          /* map of connected ports */
    unsigned int portmap1;          /* //map of connected ports */
    uint32_t        download_mask;
    uint32_t        download_mask_hi;
    phy_info_t   phy_info[64];

    /* additional driver statistics */
    uint32_t inpkts;
    uint32_t outpkts;
    uint32_t interrupts;
    uint32_t rx_interrupts;
    uint32_t tx_interrupts;
} bcm56224_state_t;

#define TX_CH                    0
#define RX_CH1                   1
#define RX_CH2                   2
#define RX_CH3                   3

/* Address mapping macros */
#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((uint8_t *)KERNADDR(a))
#define PCI_TO_PTR(a)  (PHYS_TO_PTR(PCI_TO_PHYS(a)))
#define PTR_TO_PCI(x)  (PHYS_TO_PCI(PTR_TO_PHYS(x)))

static uint32_t _read32(bcm56224_state_t *sc, uint32_t addr)
{
    uint32_t val;
    uint16_t  msb, lsb;

    if (sc->bus_flag & XGS_DEVICE_RD_16BIT) {
        addr = (addr & 0xffff0000) + ((addr & 0xffff) << 1);
        lsb = phys_read16(addr); 
        msb = phys_read16(addr); 
        val = (msb << 16) | lsb;
    } else {
        val = phys_read32(addr);  
    } 

    return val;
}

static void _write32(bcm56224_state_t *sc, uint32_t addr, uint32_t val)
{
    if (sc->bus_flag & XGS_DEVICE_WR_16BIT) {
        addr = (addr & 0xffff0000) + ((addr & 0xffff) << 1);
        phys_write16(addr, (val & 0xffff)); 
        phys_write16(addr, (val >> 16)); 
    } else {
        phys_write32(addr, val);  
    } 
}

/* Address mapping macros */
#define CSR_MATCH_MODE       PCI_MATCH_BITS
#define READCSR(sc,csr)      (_read32((sc), (sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (_write32((sc), (sc)->regbase + (csr), (val)))


/* Entry to and exit from critical sections (currently relative to
   interrupts only, not SMP) */

#if CFG_INTERRUPTS
#define CS_ENTER(sc) cfe_disable_irq(sc->irq)
#define CS_EXIT(sc)  cfe_enable_irq(sc->irq)
#else
#define CS_ENTER(sc) ((void)0)
#define CS_EXIT(sc)  ((void)0)
#endif

static bcm56224_state_t *dev_cb[MAX_UNIT_NUM];
int dev_bcm56224_debug_unit = 0;

/* Utilities */
#if XGS_DEBUG
static void
show_packet(char c, eth_pkt_t *pkt)
{
    int i;
    int n = (pkt->length < 128 ? pkt->length : 128);

    for (i = 0; i < n; i++) {
        if (i % 32 == 0) {
            if (i == 0)
                xprintf("%c[%4d]:", c, pkt->length);
            else
                xprintf("\n        ");
            }
        if (i % 4 == 0)
            xprintf(" ");
        xprintf("%02x", pkt->buffer[i]);
    }
    xprintf("\n");
}
#endif

static const char *
xgs_devname(bcm56224_state_t *sc)
{
    return (sc->devctx != NULL ? cfe_device_name(sc->devctx) : "eth?");
}

/* MII/PHY management */
static int
mii_poll(bcm56224_state_t *sc)
{
    int timeout;
    uint32_t status;

    cfe_usleep(10);
    for (timeout = 1000; timeout > 0; timeout -= 100) {
        status = READCSR(sc, R_CMIC_SCHAN_CTRL);
        if ((status & M_SCTL_MIIM_OP_DONE) != 0)
            break;
        cfe_usleep(100);
    }

    return (timeout > 0 ? 0 : -1);
}

static uint16_t
mii_read(bcm56224_state_t *sc, int phy_addr, int reg)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = V_MIIMP_PHY_ID(phy_addr);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
    WRITECSR(sc, R_CMIC_MIIM_ADDRESS, reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_1);

    if (mii_poll(sc) < 0)
        return 0xFFFF;

    return G_MIIMRD_DATA(READCSR(sc, R_CMIC_MIIM_READ_DATA));
}

static void
mii_write(bcm56224_state_t *sc, int phy_addr, int reg, uint16_t value)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = V_MIIMP_PHY_ID(phy_addr) | V_MIIMP_PHY_DATA(value);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
    WRITECSR(sc, R_CMIC_MIIM_ADDRESS, reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_1);

    mii_poll(sc);
}

static int
mii_status(bcm56224_state_t *sc, int port, int phy_addr, int phy_addr_int)
{
    uint16_t  status, remote, xremote;
    int linkspeed;
    uint16_t speed_val = 0;

    linkspeed = ETHER_SPEED_UNKNOWN;

    /* Read twice to clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);
    status = mii_read(sc, phy_addr, MII_BMSR);

    if ((status & (BMSR_AUTONEG | BMSR_LINKSTAT)) != 
                            (BMSR_AUTONEG | BMSR_LINKSTAT)) {
        return ETHER_SPEED_UNKNOWN;
    }

    remote = mii_read(sc, phy_addr, MII_ANLPAR);
    
    if ((status & BMSR_ANCOMPLETE) != 0) {
        /* A link partner was negogiated... */

        if (status & BMSR_1000BT_XSR)
            xremote = mii_read(sc, phy_addr, MII_K1STSR);
        else
            xremote = 0;

        if ((xremote & K1STSR_LP1KFD) != 0) {
#if XGS_DEBUG
            xprintf("1000BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_1000FDX;
            speed_val = 0x140;
        }
        else if ((xremote & K1STSR_LP1KHD) != 0) {
#if XGS_DEBUG
            xprintf("1000BaseT HDX\n");
#endif
            linkspeed = ETHER_SPEED_1000HDX;
        }
        else if ((remote & ANLPAR_TXFD) != 0) {
#if XGS_DEBUG
            xprintf("100BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_100FDX;	 
            speed_val = 0x2100;
        }
        else if ((remote & ANLPAR_TXHD) != 0) {
#if XGS_DEBUG
            xprintf("100BaseT HDX\n");
#endif
            linkspeed = ETHER_SPEED_100HDX;	 
            speed_val = 0x2000;
        }
        else if ((remote & ANLPAR_10FD) != 0) {
#if XGS_DEBUG
            xprintf("10BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_10FDX;	 
            speed_val = 0x100;
        }
        else if ((remote & ANLPAR_10HD) != 0) {
#if XGS_DEBUG
            xprintf("10BaseT HDX\n");
#endif            
            linkspeed = ETHER_SPEED_10HDX;	 
            speed_val = 0x000;
        }
    }
    else {
        /* no link partner convergence */
#if XGS_DEBUG
        xprintf("NC\n");
#endif        
        linkspeed = ETHER_SPEED_UNKNOWN;
        remote = xremote = 0;
    }

    /* clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);

    if (linkspeed != ETHER_SPEED_UNKNOWN) {
        if (IS_INT_PHY_PRESENT(port) && (port < 6)) {
            uint16_t ctrl;
            mii_write(sc, phy_addr_int, 0x1f, 0x8000);
            ctrl = mii_read(sc, phy_addr_int, 0x10);
            mii_write(sc, phy_addr_int, 0x10, (ctrl & 0xdfff));

            mii_write(sc, phy_addr_int, 0x1f, 0xffe0);
            mii_write(sc, phy_addr_int, 0x10, speed_val);

            mii_write(sc, phy_addr_int, 0x1f, 0x8000);
            ctrl = mii_read(sc, phy_addr_int, 0x10);
            mii_write(sc, phy_addr_int, 0x10, (ctrl | 0x2000));
        } else {
            mii_write(sc, phy_addr_int, MII_BMCR, speed_val);
        }
    }

    return linkspeed;
}

static void 
phy_probe(bcm56224_state_t *sc)
{
    unsigned int port;
    uint8_t phy_addr;
    uint16_t id1, id2, ctrl;

    for (port = PORT_BASE; port < GPIC_PORTS; port++) {
        sc->phy_info[port].addr = phy_addr = 
                    PORT_TO_PHY_ADDR(sc->unit,port);

        if (phy_addr == 0) {
            continue;
        }
        id1 = mii_read(sc, phy_addr, MII_PHYIDR1);
        id2 = mii_read(sc, phy_addr, MII_PHYIDR2);

        if ((id1 == 0x0000 || id1 == 0xFFFF) ||
            (id2 == 0x0000 || id2 == 0xFFFF)) {
            printf("Unable to probe PHY for port %d\n", port);
        } else {
#if XGS_DEBUG
            uint32_t phy_vendor;
            uint16_t phy_device;

            phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
            phy_device = (id2 >> 4) & 0x3F;
            xprintf("Found PHY (port:%d) => vendor %06X part %02X \
                    ID1 0x%08x ID2 0x%08x\n",
                    port, phy_vendor, phy_device, id1, id2);
#endif
            /* Reset the PHY */
            ctrl = mii_read(sc, phy_addr, 0);
            mii_write(sc, phy_addr, 0, 0x8000 | ctrl);
        }
    }
}

static void _led_port_status_update(bcm56224_state_t *sc, unsigned int port, 
                                    uint8_t status)
{
    uint32_t    data;

    data = READCSR(sc, LED_PORT_STATUS_OFFSET(port));
    data ^= (status & PHY_LINK_UP) ? 1 : 0;
    WRITECSR(sc, LED_PORT_STATUS_OFFSET(port), data);

}

static unsigned int
phy_link_scan(bcm56224_state_t *master)
{
    unsigned int port;
    uint8_t phy_addr;
    uint16_t found_link_up = 0;
    int linkspeed, retry;
    bcm56224_state_t *sc = NULL;
    unsigned int *pm1, *pm2;

    for (retry = 0; retry < 8; retry++) {
      sc = master;
      while (sc) {
        pm1 = &sc->portmap;
        pm2 = &sc->portmap1;
        for (port = PORT_BASE; port < GPIC_PORTS; port++) {
            phy_addr = PORT_TO_PHY_ADDR(sc->unit,port);
            if (phy_addr == 0) {
                sc->phy_info[port].linkspeed = linkspeed =
                    GET_DEFAULT_PORT_SPEED(sc->unit, port);
#if XGS_DEBUG
                xprintf("setting forced speed to %d on port %d (unit:%d)\n",
                        linkspeed, port, sc->modid);
#endif
                if (linkspeed != ETHER_SPEED_UNKNOWN) {
                    if (port < 32) {
                        *pm1 |= GPIC_BIT(port);
                    } else {
                        *pm2 |= GPIC_BIT(port - 32);
                    }
                }
                continue;
            }

            if (!IS_DOWNLOAD_PORT(sc, port)) {
                continue;
            }

            linkspeed = mii_status(sc, port, phy_addr, 
                                   PORT_TO_PHY_ADDR_INT(port));
            sc->phy_info[port].linkspeed = linkspeed;
            if (linkspeed != ETHER_SPEED_UNKNOWN) {
                found_link_up = 1;
                if (port < 32) {
                    *pm1 |= GPIC_BIT(port);
                } else {
                    *pm2 |= GPIC_BIT(port - 32);
                }
                _led_port_status_update(sc, port, PHY_LINK_UP);
            }
        }
        sc = sc->slv_dev;
      }

      if (found_link_up) {
          return 0;
      }
      cfe_sleep(CFE_HZ*1);
    }

    if (!found_link_up) {
        xprintf("Error: BCM56224 Driver couldn't find link on any of \
                the ports !!\n");
    }
    return -1;
}

/* S-Bus Access Routines */
#define R_CMIC_SCHAN_D(word)    (R_CMIC_SCHAN_MESSAGE+4*(word))

static uint32_t
schan_read_reg(bcm56224_state_t *sc, unsigned int reg)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    /* DEST_BLOCK is for XGS3 */
    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_REG_CMD)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
        | V_SMHDR_DEST_BLOCK((reg >> BLOCK_BP) & 0xf)
        | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
        cfe_usleep(100);
        ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);

        if (ctrl & M_SCTL_MSG_DONE)
            break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    return READCSR(sc, R_CMIC_SCHAN_D(1));
}

static void
schan_write_reg(bcm56224_state_t *sc, unsigned int reg, uint32_t value)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_REG_CMD)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
        | V_SMHDR_DEST_BLOCK((reg >> BLOCK_BP) & 0xf)
        | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), value);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
    cfe_usleep(100);
    ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
    if (ctrl & M_SCTL_MSG_DONE)
        break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


#if XGS_DEBUG
static void
schan_read_mem(bcm56224_state_t *sc, unsigned int addr,
	       uint32_t *dest, int count)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_MEM_CMD)
        | V_SMHDR_DEST_BLOCK((addr >> BLOCK_BP) & 0xf)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
        cfe_usleep(100);
        ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
        if (ctrl & M_SCTL_MSG_DONE)
            break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    for (i = 0; i < count; i++)
        dest[i] = READCSR(sc, R_CMIC_SCHAN_D(1+i));
}
#endif

static void
schan_write_mem(bcm56224_state_t *sc, unsigned int addr,
		uint32_t *src, int count)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_MEM_CMD)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
        | V_SMHDR_DEST_BLOCK((addr >> BLOCK_BP) & 0xf)
        | V_SMHDR_DATA_LEN(4*count));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);
    for (i = 0; i < count; i++)
        WRITECSR(sc, R_CMIC_SCHAN_D(2+i), src[i]);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
        V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
        cfe_usleep(100);
        ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
        if (ctrl & M_SCTL_MSG_DONE)
            break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}

/* Switch management */

static void
mmu_init(bcm56224_state_t *sc)
{

    /* set aging timer */
    schan_write_reg(sc, R_PKTAGINGTIMER, 0x0);
    schan_write_reg(sc, R_PKTAGINGLIMIT, 0x0);

    /* set MMU port enable */
    schan_write_reg(sc, R_MMUPORTENABLE, 0x3fffffff);
}

static int
soc_firebolt_pipe_mem_clear(bcm56224_state_t *sc)
{
    uint32_t              rval;
    int              rv = TRUE;
    int                 pipe_init_usec = 50000; /* timeout = 50 ms */

    /*
     * Reset the IPIPE and EPIPE block
     */
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_1, 0x0);
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_2, 0x34000);
    schan_write_reg(sc, R_EGR_HW_RESET_CONTROL_0, 0x0);
    schan_write_reg(sc, R_EGR_HW_RESET_CONTROL_1, 0x32000);
    
    cfe_usleep(pipe_init_usec);

    rval = schan_read_reg(sc, R_ING_HW_RESET_CONTROL_2);
    if(!(rval & 0x40000)) {
            printf("ING_HW_RESET timeout on unit %d\n", sc->unit);
            rv = FALSE;
    }        

    rval = schan_read_reg(sc, R_EGR_HW_RESET_CONTROL_1);
    if(!(rval & 0x40000)) {
            printf("EGR_HW_RESET timeout on unit %d\n", sc->unit);
            rv = FALSE;
    }        

    rval = 0;
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_1, 0x0);
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_2, 0x0);

    return rv;
}

static void
misc_init(bcm56224_state_t *sc)
{
    int port, blk, i;
    uint32_t  reglist[] ={ R_DSCP_TABLE_PARITY_CONTROL, 
                           R_EGR_L3_INTF_PARITY_CONTROL,
                           R_EGR_MASK_PARITY_CONTROL, 
                           R_EGR_NEXT_HOP_PARITY_CONTROL,
                           R_EGR_VLAN_TABLE_PARITY_CONTROL, 
                           R_FP_POLICY_PARITY_CONTROL,
                           R_ING_L3_NEXT_HOP_PARITY_CONTROL, 
                           R_L2MC_PARITY_CONTROL,
                           R_L3_IPMC_PARITY_CONTROL, 
                           R_VLAN_PARITY_CONTROL};

    /* Clear IPIPE/EIPIE Memories */
    if(!soc_firebolt_pipe_mem_clear(sc)) {
        printf("misc_init : soc_firebolt_pipe_mem_clear failed\n");
    }

    /* Disable parity check and irq */
    for (i = 0; i < sizeof(reglist)/sizeof(uint32_t) ; i++) {
        schan_write_reg(sc, reglist[i], 0x0);
    }

    schan_write_reg(sc, R_SYS_MAC_LIMIT, 0x3fff);    

    /* Enable MMU parity error interrupt */
    schan_write_reg(sc, R_MEMFAILINTSTATUS, 0x0);    

    schan_write_reg(sc, R_MEMFAILINTMASK, 0x3ff);
    schan_write_reg(sc, R_MISCCONFIG, 0x5a05);

    /* Disable parity checks */
    schan_write_reg(sc, R_ING_MISC_CONFIG, 0);

    /*
     * Egress Enable
     */
    for (port = 0; port < GPIC_PORTS; port++) {
         schan_write_reg(sc, R_EGR_ENABLE(port), 0x1);
    }

    schan_write_reg(sc, R_EPC_LINK_BMAP, 0x1);

    /* Clear counters on all the ports */
    for (blk = 1; blk < 4; blk++) {
         schan_write_reg(sc, R_GPORT_CONFIG(blk), 0x3);
         schan_write_reg(sc, R_GPORT_CONFIG(blk), 0x1);
    }

    schan_write_reg(sc, R_ING_CONFIG, 0x0060c00a);
    schan_write_reg(sc, R_EGR_CONFIG, (0x8100 << 14));

}

/* Initialize auxiliary forwarding tables.  */
static void
table_init(bcm56224_state_t *sc)
{
    static uint32_t empty[4] = {0x00000000, 0x00000000, 0x00000000, 0x0};
    static uint32_t port_tab[3] = {0x000e0000, 0x01040000, 0x00000000};
    static uint32_t iport_tab[3] = {0x000e0000, 0x01040000, 0x00000000};
    static uint32_t vlan_tab[2] = {0xffffffff, 0x00000380};
    static uint32_t vlan_profile = 0x00002fe1;
    static uint32_t egr_vlan[3] = {0xfffffff8, 0x1fffffff, 0x00000010};
    static uint32_t stg[2] = {0xfffffffc, 0x0fffffff};
    static uint32_t stg0[2] = {0xf3c, 0x0};
    int i;

    /* l2 table */
    for (i = 0; i < M_L2X_SIZE; i++) {
	schan_write_mem(sc, M_L2_ENTRY + i, empty, 3);
    }

    /* vlan table */
    for (i = 0; i < M_VLAN_SIZE; i++) {
        schan_write_mem(sc, M_VLAN + i, empty, 2);
    }

    /* egr vlan table */
    for (i = 0; i < M_VLAN_SIZE; i++) {
        schan_write_mem(sc, M_EGR_VLAN + i, empty, 3);
    }

    /* Set vlan profile table */
    schan_write_mem(sc, M_VLAN_PROFILE + 7, &vlan_profile, 1);

    for (i = 0; i < M_STG_SIZE; i++) {
	schan_write_mem(sc, M_VLAN_STG + i, empty, 2);
	schan_write_mem(sc, M_EGR_VLAN_STG + i, empty, 2);
    }

    /* port mac block table */
    for (i = 0; i < M_MAC_BLOCK_SIZE; i++) {
	schan_write_mem(sc, M_PORT_MAC_BLOCK + i, empty, 1);
    }

    for (i = 0; i < GPIC_PORTS; i++) {
        schan_write_mem(sc, M_PORT + i, port_tab, 3);
        if (IS_ST_PORT(i)) {
            schan_write_mem(sc, M_IPORT_TABLE + i, iport_tab, 3);
        } 
    }

    /* vlan table */
    schan_write_mem(sc, M_VLAN + VLAN_DEFAULT, vlan_tab, 2);

    /* egr vlan table */
    schan_write_mem(sc, M_EGR_VLAN + VLAN_DEFAULT, egr_vlan, 3);        

    /* egress mask table */
    for (i = 0; i < M_EGRESS_MASK_SIZE; i++) {
	schan_write_mem(sc, M_EGRESS_MASK + i, empty, 1);
    }

    /* stg table */

    /* Force forwarding state for spanning tree. */
    schan_write_mem(sc, M_VLAN_STG + STG_DEFAULT, stg, 2);
    schan_write_mem(sc, M_EGR_VLAN_STG + STG_DEFAULT, stg, 2);

    schan_write_mem(sc, M_VLAN_STG + CMIC_PORT, stg0, 2);
    schan_write_mem(sc, M_EGR_VLAN_STG + CMIC_PORT, stg0, 2);
}


static void
l2_enter(bcm56224_state_t *sc, uint8_t mac_addr[], unsigned int port)
{
    uint32_t l2_entry[3];
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;
  
    /* word 0 : mac addr[5:2] */
    l2_entry[0] = ((mac_addr[5] <<  0) | (mac_addr[4] <<  8) |
                    (mac_addr[3] << 16) | (mac_addr[2] << 24));
    /* word 1 : mac addr [1:0], tocpu=1, prio=7, vid=default_vlan */
    l2_entry[1] = ((mac_addr[1] <<  0) | (mac_addr[0] <<  8) | 
                   (1 << 31) | (7<<28) | (VLAN_DEFAULT << 16));
    /* word 3 : valid=1, static=1, port = port */
    l2_entry[2] = ((1 << 24) | (1 << 21) | (port << 3));
    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_L2_INS_CMD) | 
               V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)  |
               V_SMHDR_DATA_LEN(0xc) | V_SMHDR_DEST_BLOCK(0x7));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), l2_entry[0]);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), l2_entry[1]);
    WRITECSR(sc, R_CMIC_SCHAN_D(3), l2_entry[2]);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
         V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
        cfe_usleep(100);
        ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
        if (ctrl & M_SCTL_MSG_DONE)
            break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}

#if XGS_DEBUG
static void
l2_dump(bcm56224_state_t *sc)
{
    uint32_t l2_entry[3];
    uint8_t status1, status2;
    uint8_t module, port;
    int i;

    for (i = 0; i < M_L2X_SIZE; i++) {
        schan_read_mem(sc, M_L2_ENTRY + i, l2_entry, 3);
        status1 = (l2_entry[2] >> 22) & 0x7;
        if (status1 & 0x04) {    /* valid */
            status2 = ((l2_entry[2] & 0xF) << 4) | ((l2_entry[1] >> 24) & 0xF);
            module = (l2_entry[2] >> 10) & 0x1F;
            port = (l2_entry[2] >> 4) & 0x3F;
            xprintf("  %03x,%1d: %01x %02x %02x/%01x %04x%08x\n",
            i/8, i % 8,
            status1, status2, module, port,
            l2_entry[1] & 0xFFFF, l2_entry[0]);
        }
    }
}
#endif

#define MAC_IGNORE_PAUSE    (1 << 8)
#define MAC_HALF_DUPLEX     (1 << 10)
#define MAC_RESET           (1 << 13)
#define MAC_EXT_CFG         (1 << 22)
#define MAC_SPEED_MASK      (0xc)

static void
port_enable(bcm56224_state_t *sc)
{
    unsigned int port;
    unsigned int block, port_idx;
    int val;

    for (port = PORT_BASE; port < GPIC_PORTS; port++) {
        if (!IS_DOWNLOAD_PORT(sc, port) || 
            (sc->phy_info[port].linkspeed == ETHER_SPEED_UNKNOWN)) {
            continue;
        }

        block = BLOCK_ID(port);
        port_idx = PORT_IDX(port);

        /* Enable MAC RX/TX */
        val = schan_read_reg(sc, R_COMMAND_CONFIG(block, port_idx));
        schan_write_reg(sc, R_COMMAND_CONFIG(block, port_idx), val | MAC_RESET);
        cfe_usleep(10);
        val |= 3; /* Enable RX/TX */
        schan_write_reg(sc, R_COMMAND_CONFIG(block, port_idx), val | MAC_RESET);
        cfe_usleep(10);
        /* Take mac out of reset */
        schan_write_reg(sc, R_COMMAND_CONFIG(block, port_idx), val);
    }
}

static void
gpic_init(bcm56224_state_t *sc, unsigned int port, int linkspeed)
{
    unsigned int block, port_idx;
    uint32_t     val;
    uint32_t     fd;

    block = BLOCK_ID(port);
    port_idx = PORT_IDX(port);

    /* put mac in reset */
    val = schan_read_reg(sc, R_COMMAND_CONFIG(block, port_idx));
    val |= MAC_RESET;

    schan_write_reg(sc, R_COMMAND_CONFIG(block, port_idx), val);

    cfe_usleep(100);

    /* set speed and duplex mode for ports on which auto config is
     * not enabled.
     */
    fd = (linkspeed == ETHER_SPEED_100FDX || linkspeed == ETHER_SPEED_10FDX ||
          linkspeed == ETHER_SPEED_1000FDX); 

    if (fd) {
        val &= ~MAC_HALF_DUPLEX;
    } else {
        val |= MAC_HALF_DUPLEX;
    }

    val &= ~MAC_SPEED_MASK;
    if (linkspeed == ETHER_SPEED_10FDX || linkspeed == ETHER_SPEED_10HDX) {
        val |= (0 << 2);
    } else
    if (linkspeed == ETHER_SPEED_100FDX || linkspeed == ETHER_SPEED_100HDX) {
        val |= (1 << 2);
    } else {
        val |= (2 << 2); /* 1 Gig */
    }
#if 0
    val |= 3; /* Enable TX/RX */
#else
    val &= ~3; /* Disable RX/TX */
#endif
    schan_write_reg(sc, R_COMMAND_CONFIG(block, port_idx), val);

    schan_write_reg(sc, R_GPORT_RSV_MASK(block), 0x78);

    cfe_usleep(100);

    schan_write_reg(sc, R_COMMAND_CONFIG(block, port_idx), (val & ~MAC_RESET));

    /* IPG */
    schan_write_reg(sc, R_TX_IPG_LENGTH(block, port_idx), 12);
    return;
}

static void
gpic_stop(bcm56224_state_t *sc, unsigned int port)
{
    int linkspeed;
    unsigned int block, port_idx;
    uint32_t    val;

    block = BLOCK_ID(port);
    port_idx = (PORT_IDX(port) << 12);

    linkspeed = sc->phy_info[port].linkspeed;

    if (linkspeed != ETHER_SPEED_UNKNOWN) {
        val = schan_read_reg(sc, R_COMMAND_CONFIG(block, port_idx));
        schan_write_reg(sc, R_COMMAND_CONFIG(block, port_idx), (val & ~3));
    }

    xprintf("-----------------\n");
}

static void
port_init(bcm56224_state_t *sc)
{
    unsigned int port;
    int linkspeed;

    for (port = PORT_BASE; port < GPIC_PORTS; port++) {
        if (!IS_DOWNLOAD_PORT(sc, port)) {
            continue;
        } 

        linkspeed = sc->phy_info[port].linkspeed;
        if (linkspeed != ETHER_SPEED_UNKNOWN) {
            gpic_init(sc, port, linkspeed);
        }
    }
}

static void
port_stop(bcm56224_state_t *sc)
{
    unsigned int port;

    for (port = 0; port < GPIC_PORTS; port++) {
        if (port < 32) {
            if ((sc->portmap & GPIC_BIT(port)) != 0) {
                gpic_stop(sc, port);
            }
        } else {
            if ((sc->portmap1 & GPIC_BIT(port-32)) != 0) {
                gpic_stop(sc, port);
            }
        }
    }
}


/* Packet management */

#define ETH_PKTPOOL_SIZE  64

static eth_pkt_t *
eth_alloc_pkt(bcm56224_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *) q_deqnext(&sc->freelist);
    CS_EXIT(sc);
    if (!pkt) return NULL;

    pkt->buffer = pkt->data;
    pkt->length = ETH_PKTBUF_LEN;
    pkt->flags = 0;

    return pkt;
}

static void
eth_free_pkt(bcm56224_state_t *sc, eth_pkt_t *pkt)
{
    CS_ENTER(sc);
    q_enqueue(&sc->freelist, &pkt->next);
    CS_EXIT(sc);
}

static void
eth_initfreelist(bcm56224_state_t *sc)
{
    int idx;
    uint8_t *ptr;
    eth_pkt_t *pkt;

    q_init(&sc->freelist);

    ptr = sc->pktpool;
    for (idx = 0; idx < ETH_PKTPOOL_SIZE; idx++) {
        pkt = (eth_pkt_t *) ptr;
        eth_free_pkt(sc, pkt);
        ptr += ETH_PKTBUF_SIZE;
    }
}

/* Packet DMA Service */
#define R_CMIC_DMA_DESC(ch)      (0x0110+4*(ch))   /* 0 <= ch <= 3 */


#define V_BIT_POS_RX1_EN         (V_DMA_BIT_POS(S_CH_DMA_EN(RX_CH1)))
#define V_BIT_POS_RX1_DESC_DONE  (V_DMA_BIT_POS(S_CH_DESC_DONE(RX_CH1)))
#define V_BIT_POS_RX1_CHAIN_DONE (V_DMA_BIT_POS(S_CH_CHAIN_DONE(RX_CH1)))

static int
xgs_add_rcvbuf(bcm56224_state_t *sc, eth_pkt_t *pkt)
{
    /*volatile*/ dcb_t *dcb;

    dcb = sc->dcbs[RX_CH1];

    memset(dcb, 0, sizeof(dcb_t));
    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = V_DCB1_BYTE_COUNT(ETH_PKTBUF_LEN);

    BCM_CACHE_DMA_INVAL(pkt->buffer, pkt->length);
    BCM_CACHE_DMA_SYNC(dcb, sizeof(dcb_t));

    WRITECSR(sc, R_CMIC_DMA_DESC(RX_CH1), PTR_TO_PCI(dcb));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_1);

    return 0;
}


static void
xgs_rx_callback(bcm56224_state_t *sc, eth_pkt_t *pkt)
{
#if XGS_DEBUG
    show_packet('>', pkt);   /* debug */
#endif

    CS_ENTER(sc);
    q_enqueue(&sc->rxqueue, &pkt->next);
    CS_EXIT(sc);
    sc->inpkts++;

}

static void
xgs_procrxring(bcm56224_state_t *sc)
{
    /*volatile*/ dcb_t *dcb;
    /*volatile*/ eth_pkt_t *pkt;
    eth_pkt_t *new_pkt;

    dcb = sc->dcbs[RX_CH1];
    BCM_CACHE_DMA_INVAL(dcb, sizeof(dcb_t));

#if XGS_DEBUG
#if 0
    xprintf("recv: dcb %08x %08x %08x %08x\n          %08x %08x %08x %08x          %08x %08x\n",
        dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
        dcb->w4, dcb->w5, dcb->w6, dcb->w7, dcb->w8, dcb->w9);
#endif
#endif

    pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));

    pkt->length = G_DCB1_BYTE_COUNT(dcb->w10);
    BCM_CACHE_DMA_INVAL(pkt->buffer, pkt->length);

    xgs_rx_callback(sc, (eth_pkt_t *)pkt);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_DESC_DONE | V_DMA_BIT_0);
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_CHAIN_DONE | V_DMA_BIT_0);

    new_pkt = eth_alloc_pkt(sc);
    if (new_pkt) {
        xgs_add_rcvbuf(sc, new_pkt);
    } else {
        sc->restartrx = 1;
    }
}


#define V_BIT_POS_TX_EN          (V_DMA_BIT_POS(S_CH_DMA_EN(TX_CH)))
#define V_BIT_POS_TX_DESC_DONE   (V_DMA_BIT_POS(S_CH_DESC_DONE(TX_CH)))
#define V_BIT_POS_TX_CHAIN_DONE  (V_DMA_BIT_POS(S_CH_CHAIN_DONE(TX_CH)))

static int
xgs_transmit(bcm56224_state_t *sc, eth_pkt_t *pkt)
{
    /*volatile*/ dcb_t *dcb;

    if (sc->txbusy)
        return -1;

    sc->txbusy = 1;

#if XGS_DEBUG
    show_packet('<', pkt);
#endif

    /* The CMIC "recomputes" the CRC, does not append it. */
    pkt->length += ENET_CRC_SIZE;

    if(pkt->length < 64)
        pkt->length = 64;

    dcb = sc->dcbs[TX_CH];
    memset(dcb, 0, sizeof(dcb_t));

    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = V_DCB1_BYTE_COUNT(pkt->length) | (1 << 20);

    dcb->w2 = 0xff000000;
    dcb->w3 = 0x00000000;
    dcb->w4 = 0x00000006;
    BCM_CACHE_DMA_SYNC(pkt->buffer, pkt->length);
    BCM_CACHE_DMA_SYNC(dcb, sizeof(dcb_t));

    WRITECSR(sc, R_CMIC_DMA_DESC(TX_CH), PTR_TO_PCI(dcb));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_1);

    sc->outpkts++;
    return 0;
}

static void
xgs_proctxchain(bcm56224_state_t *sc)
{
    /*volatile*/ dcb_t *dcb;
    eth_pkt_t *pkt;

    if (!sc->txbusy)
        return;

    dcb = sc->dcbs[TX_CH];
    BCM_CACHE_DMA_INVAL(dcb, sizeof(dcb_t));

    /* if ((dcb->w9 & M_DCB9_DONE) == 0) 
	return; */

#if XGS_DEBUG
#if 0
    xprintf("tx: dcb %08x %08x %08x %08x\n          %08x %08x %08x %08x\n          %08x %08x\n",
        dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
        dcb->w4, dcb->w5, dcb->w6, dcb->w7, dcb->w8, dcb->w9);
#endif
#endif

    /* Just free the packet */
    pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));
    eth_free_pkt(sc, pkt);

    /* Evidently, the channel will not restart until CHAIN_DONE is
       clear, and empirically, CHAIN_DONE cannot reliably be cleared
       until DMA_EN is cleared. */
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_0);
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_DESC_DONE | V_DMA_BIT_0);
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_CHAIN_DONE | V_DMA_BIT_0);

    sc->txbusy = 0;
}


static void
xgs_initrings(bcm56224_state_t *sc)
{
    eth_pkt_t *pkt;

    pkt = eth_alloc_pkt(sc);
    if (pkt != NULL)
        xgs_add_rcvbuf(sc, pkt);
    else 
        printf("unable to alloc pkt \n");
}

static void
xgs_dcb_init(bcm56224_state_t *sc)
{
    /* Allocate buffer pool */
    sc->pktpool = KMALLOC(ETH_PKTPOOL_SIZE*ETH_PKTBUF_SIZE, CACHE_ALIGN);
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);

    sc->dcbs[TX_CH] = KMALLOC(sizeof(dcb_t), CACHE_ALIGN);
    sc->txbusy = 0;

    sc->dcbs[RX_CH1] = KMALLOC(sizeof(dcb_t), CACHE_ALIGN);
    xgs_initrings(sc);

    /* XXX Initialize descriptor lists */
}

static void
xgs_dcb_deinit(bcm56224_state_t *sc)
{
    /* Allocate buffer pool */
    if (sc->pktpool) {
        KFREE(sc->pktpool);
        sc->pktpool = NULL;
    }

    if (sc->dcbs[TX_CH]) {
        KFREE(sc->dcbs[TX_CH]);
        sc->dcbs[TX_CH] = NULL;
    }

    if (sc->dcbs[RX_CH1]) {
        KFREE(sc->dcbs[RX_CH1]);
        sc->dcbs[RX_CH1] = NULL;
    }
    q_init(&sc->rxqueue);
    q_init(&sc->freelist);
}

static void _xgs_fe_mdio_setup(bcm56224_state_t *sc);

static int
xgs_reset(bcm56224_state_t *sc)
{
    uint32_t config, pllr;

#if ENDIAN_BIG
    WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x22222222);
#else
    WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x00000000);
#endif

    WRITECSR(sc, R_CMIC_CONFIG, M_RESET_CPS);
    cfe_usleep(1000);

#if ENDIAN_BIG
    WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x22222222);
#else
    WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x00000000);
#endif

    /* Clear S-channel bits */
    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
             V_SCTL_BIT_POS(S_SCTL_MIIM_OP_DONE) | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
             V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_0);

    WRITECSR(sc, R_CMIC_SOFT_RESET_REG, 0);
    cfe_usleep(100);
    WRITECSR(sc, R_CMIC_SOFT_RESET_REG, 0x00001a34);
    cfe_usleep(300);

    WRITECSR(sc, R_CMIC_SOFT_RESET_REG, 0x00001fff);
    cfe_usleep(10000);
    WRITECSR(sc, R_CMIC_SBUS_RING_MAP, 0x0ad42aaa);

    /* check pll */
    pllr = READCSR(sc, R_CMIC_XGXS_PLL_STATUS);
    if ((pllr & 0x80000000) == 0) {
        printf("PLL not locked on unit %d\n", sc->unit);
    }

    config = READCSR(sc, R_CMIC_CONFIG);
    /* PCI interface options. */
    config |= M_RD_BRST_EN | M_WR_BRST_EN;
    /* DMA options */
    config |= M_IGNORE_ADR_ALIGN_EN;
    /* Normal operation */
    config |= M_EXT_MDIO_MSTR_DIS;
    WRITECSR(sc, R_CMIC_CONFIG, config);

    /* Configure DMA channels. */
    WRITECSR(sc, R_CMIC_DMA_STAT, 0);
    WRITECSR(sc, R_CMIC_DMA_CTRL, M_CH_DIRECTION(TX_CH));

    cfe_usleep(100);
    /* Adjust the MDC output frequency to ~2.6MHz */
    WRITECSR(sc, 0x1b8, ((1<<16) | 27));
    WRITECSR(sc, 0x1bC, ((1<<16) | 27));

    _xgs_fe_mdio_setup(sc);

    return 0;
}

static void
xgs_start_auto_negotiation(bcm56224_state_t *sc)
{
    int port;
    int   phy_addr = 0, phy_addr_int = 0;
    uint16_t    ctrl;

    for (port = PORT_BASE; port < GPIC_PORTS; port++) {
        if (!IS_DOWNLOAD_PORT(sc, port)) {
            continue;
        }

        if (IS_INT_PHY_PRESENT(port)) {
            phy_addr_int = PORT_TO_PHY_ADDR_INT(port);
            if (IS_ST_PORT(port)) {
                mii_write(sc, phy_addr_int, 0x1f, 0xffe0);
                mii_write(sc, phy_addr_int, 0x10, 0x8000);
                cfe_usleep(30000);
                mii_write(sc, phy_addr_int, 0x1f, 0x8000);
                ctrl = mii_read(sc, phy_addr_int, 0x10);
                mii_write(sc, phy_addr_int, 0x10, (ctrl & 0xdfff));

                mii_write(sc, phy_addr_int, 0x1f, 0xffe0);
                mii_write(sc, phy_addr_int, 0x14, 0x0060);
                mii_write(sc, phy_addr_int, 0x10, 0x0140);

                mii_write(sc, phy_addr_int, 0x1f, 0x8300);
                ctrl = mii_read(sc, phy_addr_int, 0x10);
                mii_write(sc, phy_addr_int, 0x10, (ctrl & 0xffee));

                mii_write(sc, phy_addr_int, 0x1f, 0x8000);
                ctrl = mii_read(sc, phy_addr_int, 0x10);
                mii_write(sc, phy_addr_int, 0x10, (ctrl | 0x2000));
                mii_write(sc, phy_addr_int, 0x1f, 0xffe0);
            } else {
                /* Put the internal phy in SGMII mode */
                ctrl = mii_read(sc, phy_addr_int, DDS_1000X_CTRL1_REG);
                ctrl &= ~DDS_1000X_FIBER_MODE;
                mii_write(sc, phy_addr_int, DDS_1000X_CTRL1_REG, ctrl);
            }
        }

        /* For GMII port, if external PHY is present, set it up for
         * GMII mode */
        if (IS_GMII_PORT(port) && 
            ((phy_addr = PORT_TO_PHY_ADDR(sc->unit, port)) > 0)) {

            /* Select GMII interface on BCM5641S PHY */
            mii_write(sc, phy_addr, 0x1c, 0x7c00);
            ctrl = mii_read(sc, phy_addr, 0x1c);
            ctrl &= ~0x0007;
            ctrl |= 0x8000;
            mii_write(sc, phy_addr, 0x1c, ctrl);

            /* Reset PHY */
            ctrl = mii_read(sc, phy_addr, 0x0);
            mii_write(sc, phy_addr, 0x0, (ctrl & ~BMCR_POWERDOWN));
        }
    }

    cfe_sleep(1);

    for (port = PORT_BASE; port < GPIC_PORTS; port++) {
        phy_addr = PORT_TO_PHY_ADDR(sc->unit, port);
        if ((phy_addr == 0) || !IS_DOWNLOAD_PORT(sc, port)) {
            continue;
        }

        if (IS_GE_CAP(port)) {
            ctrl = mii_read(sc, phy_addr, R_1000_BASE_T_CTRL_REG);
#if ETH_DRV_ENABLE_GE
            ctrl |= (R_1000_BASE_T_1000_FULL | R_1000_BASE_T_1000_HALF);
#else
            ctrl &= ~(R_1000_BASE_T_1000_FULL | R_1000_BASE_T_1000_HALF);
#endif
            mii_write(sc, phy_addr, R_1000_BASE_T_CTRL_REG, ctrl);
        }

        ctrl = mii_read(sc, phy_addr, R_AN_ADVERTISE_REG);
        ctrl |= (R_AN_ADVERTISE_100_T_FULL | R_AN_ADVERTISE_100_T_HALF |
                 R_AN_ADVERTISE_10_T_FULL | R_AN_ADVERTISE_10_T_HALF);
        mii_write(sc, phy_addr, R_AN_ADVERTISE_REG, ctrl);

        ctrl = mii_read(sc, phy_addr, MII_BMCR);
        ctrl |= R_BASIC_MODE_CTRL_RESTART_AN;
        mii_write(sc, phy_addr, MII_BMCR, ctrl);
    }
}

static void xgs_init_led_processor(bcm56224_state_t *sc)
{
    uint8_t * led_program = NULL;
    uint32_t   led_code_size = 0, offset = 0, reg;

    while (sc) {
        /* Load LED program */
        if ((led_program = GET_LED_CODE(sc->unit)) != 0) { 
            /* Disable LED processor */
            reg = READCSR(sc, R_CMIC_LEDUP_CTRL);
            WRITECSR(sc, R_CMIC_LEDUP_CTRL, (reg & ~1));

            #define LED_PROGRAM_RAM_SIZE        0x100
            led_code_size = GET_LED_CODE_SIZE(sc->unit);
            for (offset = 0; offset < LED_PROGRAM_RAM_SIZE; offset++) {
                WRITECSR(sc, R_CMIC_LEDUP_PROGRAM_RAM_D(offset), 
                         (offset >= led_code_size) ? 0 : *(led_program + offset));
            }

            #define LED_DATA_RAM_SIZE        0x100
            for (offset = 0; offset < LED_PROGRAM_RAM_SIZE; offset++) {
                WRITECSR(sc, R_CMIC_LEDUP_DATA_RAM_D(offset), 0);
            } 

            /* enable LED processor */
            WRITECSR(sc, R_CMIC_LEDUP_CTRL, (reg | 1));
        } 

        sc = sc->slv_dev;
    }

}

/* WAR GNATS 36759 */
static void
_xgs_fe_mdio_setup(bcm56224_state_t *sc)
{
    uint32_t rval;

    rval = READCSR(sc, R_CMIC_DEV_REV_ID);
    if (((rval & 0xffff) != 0xb024) && ((rval & 0xffff) != 0xb025)) {
        return;
    }
    
    rval = READCSR(sc, R_CMIC_SOFT_RESET_REG);
    rval &= ~(1 << 2);
    WRITECSR(sc, R_CMIC_SOFT_RESET_REG, rval);

    /* 
     * Set SEL_DOZEN_SERDES_0_REF_CLK_SRC=3 
     *     SEL_DOZEN_SERDES_1_REF_CLK_SRC=3 
     *     PROG_DOZEN_SERDES_PLLDIV_CTRL_DEF=3
     */
    rval = READCSR(sc, R_CMIC_GFPORT_CLOCK_CONFIG);
    rval |= ((3 << 2) | (3 << 4) | (3 << 8));
    WRITECSR(sc, R_CMIC_GFPORT_CLOCK_CONFIG, rval);

    cfe_usleep(300);

    /* 
     * Set SEL_DOZEN_SERDES_0_REF_CLK_SRC=1
     *     SEL_DOZEN_SERDES_1_REF_CLK_SRC=1 
     *     PROG_DOZEN_SERDES_PLLDIV_CTRL_DEF=0
     */
    rval = READCSR(sc, R_CMIC_GFPORT_CLOCK_CONFIG);
    rval &= ~((3 << 2) | (3 << 4) | (3 << 8));
    rval |= ((1 << 2) | (1 << 4));
    WRITECSR(sc, R_CMIC_GFPORT_CLOCK_CONFIG, rval);

    return;
}


static void
xgs_hwinit(bcm56224_state_t *sc)
{
    if (sc->state != eth_state_on) {
        if (sc->bus_flag & XGS_BUS_CAP_DMA) {
            /* Configure DMA channels. */
            WRITECSR(sc, R_CMIC_DMA_STAT, 0);
            WRITECSR(sc, R_CMIC_DMA_CTRL, M_CH_DIRECTION(TX_CH));
            xgs_dcb_init(sc);
        }

        misc_init(sc);
        mmu_init(sc);
        table_init(sc);


#if XGS_DEBUG
        xprintf("Link scan front port(s) for unit %d......\n", sc->unit);
#endif
        /* phy scan is called only for master device to speed up phy scan */
        if ((sc->bus_flag & XGS_DEVICE_SLAVE) == 0) {
            xgs_init_led_processor(sc);
            phy_link_scan(sc);
        }
#if XGS_DEBUG
        xprintf("Active port map(unit:%d): %08X:%08X\n", 
                sc->modid, sc->portmap1, sc->portmap);
#endif

        port_init(sc);

        /* EPC link */
        WRITE_EPC_LINK_MAP(sc, sc->portmap | CMIC_BIT, sc->portmap1);

        /* CPU control */
        schan_write_reg(sc, R_CPU_CONTROL_1, 0x0);
        schan_write_reg(sc, R_CPU_CONTROL_2, 0x0);

        if ((sc->bus_flag & XGS_DEVICE_SLAVE) == 0) {
            l2_enter(sc, sc->hwaddr, CMIC_PORT);
        }

        sc->state = eth_state_off;
    }
}

static void
xgs_isr(void *arg)
{
    bcm56224_state_t *sc = (bcm56224_state_t *)arg;
    uint32_t irqstat = READCSR(sc, R_CMIC_IRQ_STAT);

    if ((sc->bus_flag & XGS_BUS_CAP_DMA) == 0) {
        return;
    }

    if (IPOLL) sc->interrupts++;

    if (irqstat & M_IRQ_CHAIN_DONE(RX_CH1)) {
        sc->rx_interrupts++;
        xgs_procrxring(sc);
    }

    if (irqstat & M_IRQ_CHAIN_DONE(TX_CH)) {
        sc->tx_interrupts++;
        xgs_proctxchain(sc);
    }
}

static void
xgs_start(bcm56224_state_t *sc)
{
    uint32_t pending;

    xgs_hwinit(sc);

    sc->intmask = 0;
    WRITECSR(sc, R_CMIC_IRQ_MASK, 0);
    pending = READCSR(sc, R_CMIC_IRQ_STAT);
    WRITECSR(sc, R_CMIC_IRQ_STAT, pending);
    (void)READCSR(sc, R_CMIC_IRQ_STAT);   /* push */

    sc->intmask = M_IRQ_CHAIN_DONE(RX_CH1) | M_IRQ_CHAIN_DONE(TX_CH);

#if IPOLL
    cfe_request_irq(sc->irq, xgs_isr, sc, CFE_IRQ_FLAGS_SHARED, 0);
    WRITECSR(sc, R_CMIC_IRQ_MASK, sc->intmask);
#endif

    sc->state = eth_state_on;
}

static void
xgs_stop(bcm56224_state_t *sc)
{
    eth_pkt_t *pkt;
    bcm56224_state_t *pdev = sc;

#if XGS_DEBUG
    l2_dump(sc);
#endif

    while(pdev) {
        port_stop(pdev);

        if (pdev->bus_flag & XGS_BUS_CAP_DMA) {
            while((pkt = (eth_pkt_t *)q_deqnext(&(pdev->rxqueue)))) {
                eth_free_pkt(pdev, pkt);
            }
        }

        xgs_reset(pdev);
        xgs_dcb_deinit(pdev);
        pdev->state = eth_state_off;
        pdev = pdev->slv_dev;
    }

#if IPOLL
    cfe_free_irq(sc->irq, 0);
#endif

}


static void bcm56224_probe(cfe_driver_t *drv, unsigned long probe_a, 
                    unsigned long probe_b, void *probe_ptr);
static int bcm56224_open(cfe_devctx_t *ctx);
static int bcm56224_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm56224_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat);
static int bcm56224_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm56224_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm56224_close(cfe_devctx_t *ctx);
static void bcm56224_poll(cfe_devctx_t *ctx, int64_t ticks);
static void bcm56224_reset(void *softc);

const static cfe_devdisp_t bcm56224_dispatch = {
    bcm56224_open,
    bcm56224_read,
    bcm56224_inpstat,
    bcm56224_write,
    bcm56224_ioctl,
    bcm56224_close,	
    bcm56224_poll,
    bcm56224_reset
};

cfe_driver_t bcm56224drv = {
    "BCM56224 switch",
    "eth",
    CFE_DEV_NETWORK,
    &bcm56224_dispatch,
    bcm56224_probe
};

static brd_info_t * find_brd_info(char * bname)
{
    brd_info_t  * bp;

    bp = _brd_info;
    while(bp->name && lib_strcmpi(bname, bp->name))
        bp++;
    return (bp->name ? bp : NULL);
}

static int
pbmp_decode(char *s, uint32_t pbmp[2])
{
    char        *e;
    uint32_t     v;
    int          p;

#define PBMP_PORT_MAX 64
#define PBMP_PORT_ADD(_pbmp, _p)  \
    if ((_p) < 32) {(_pbmp)[0] |= 1 << (_p); } \
    else  {(_pbmp)[1] |= 1 << ((_p) - 32); } 

    pbmp[0] = 0;
    pbmp[1] = 0; 
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
        /* get end of string */
        s += 2;
        for (e = s; *e; e++)
            ;
        e -= 1;
        /* back up to beginning of string, setting ports as we go */
        p = 0;
        while (e >= s) {
            if (*e >= '0' && *e <= '9') {
                v = *e - '0';
            } else if (*e >= 'a' && *e <= 'f') {
                v = *e - 'a' + 10;
            } else if (*e >= 'A' && *e <= 'F') {
                v = *e - 'A' + 10;
            } else {
                return -1;              /* error: invalid hex digits */
            }
            e -= 1;
            /* now set a nibble's worth of ports */
            if ((v & 1) && p < PBMP_PORT_MAX) {
                PBMP_PORT_ADD(pbmp, p);
            }
            p += 1;
            if ((v & 2) && p < PBMP_PORT_MAX) {
                PBMP_PORT_ADD(pbmp, p);
            }
            p += 1;
            if ((v & 4) && p < PBMP_PORT_MAX) {
                PBMP_PORT_ADD(pbmp, p);
            }
            p += 1;
            if ((v & 8) && p < PBMP_PORT_MAX) {
                PBMP_PORT_ADD(pbmp, p);
            }
            p += 1;
        }
    } else {
        v = 0;
        while (*s >= '0' && *s <= '9') {
            v = v * 10 + (*s++ - '0');
        }
        if (*s != '\0') {
            return -1;                  /* error: invalid decimal digits */
        }
        p = 0;
        while (v) {
            if ((v & 1) && p < PBMP_PORT_MAX) {
                PBMP_PORT_ADD(pbmp, p);
            }
            v >>= 1;
            p += 1;
        }
    }
    return 0;
}

static char *
bcm56224_get_download_map(int unit)
{
    char     *pbmp_string = NULL;
    char      env_string[33];

    sprintf(env_string, "PBMP_DOWNLOAD.%d", unit);

    if (unit == 0) {
        pbmp_string = env_getenv("PBMP_DOWNLOAD");
    }

    if (!pbmp_string) {
        return env_getenv(env_string);
    }

    return pbmp_string;
}

static void 
bcm56224_override_port(bcm56224_state_t *sc, brd_info_t *bp)
{
    char     *pbmp_string;
    uint32_t  pbmp[2];

    if ((pbmp_string = bcm56224_get_download_map(sc->unit))) {
        if (pbmp_decode(pbmp_string, pbmp) < 0) {
            printf("ERROR: Invalid PBMP_DOWNLOAD %s\n", pbmp_string);
        } else {
            sc->download_mask      = bp->download_mask & pbmp[0];
            sc->download_mask_hi   = bp->download_mask_hi & pbmp[1];
            printf("WARNING: Download port restricted to %s unit %d\n", 
                   pbmp_string, sc->unit);
        }
    }
}

static int
bcm56224_attach(cfe_driver_t *drv, pcitag_t tag, uint8_t hwaddr[])
{
    int         device;
    char        descr[80];
    bcm56224_state_t    *sc;

    for (device=0; device<ndevs; device++) {
        sc = dev_cb[device];
        sc->state = eth_state_uninit;

        /* Always use the MAC address that was passed in. */
        memcpy(sc->hwaddr, hwaddr, ENET_ADDR_LEN);

        sc->download_mask      = board_info->download_mask;
        sc->download_mask_hi   = board_info->download_mask_hi;

        /* Check for environment variable override to restrict download ports*/
        bcm56224_override_port(sc, board_info);

        if ((sc->bus_flag & XGS_DEVICE_SLAVE) == 0) {
            xsprintf(descr, "BCM562XX StrataXGS Switch (mod %02X) at 0x%08X",
                     sc->unit, sc->regbase);
            cfe_attach(drv, sc, NULL, descr);
        }

        xgs_reset(sc);
        cfe_usleep(300);
        phy_probe(sc);
        cfe_usleep(300);
        xgs_start_auto_negotiation(sc);
    }

    return 0;
}

#if CFG_EB_BUS
static void
dev_add_slave(bcm56224_state_t  * m, bcm56224_state_t  * sl)
{
    bcm56224_state_t  **t = &m->slv_dev;

    while(*t)
        t = &((*t)->slv_dev);

    *t = sl;
}
#endif

static bcm56224_state_t  *
dev_create(uint32_t device, uint32_t rev, uint32_t ba, uint32_t flags)
{
    bcm56224_state_t  *sc;

    sc = (bcm56224_state_t *) KMALLOC(sizeof(bcm56224_state_t), 0);
    if (sc == NULL) {
        xprintf("BCM56XXX: No memory to complete probe\n");
        return NULL;
    }
    memset(sc, 0, sizeof(*sc));

    sc->device = device;
    sc->revision = rev;
    sc->bus_flag = flags;
    sc->regbase = ba;
    sc->irq = 0;
    sc->unit = ndevs;
    sc->devctx  = NULL;
    sc->slv_dev  = NULL;

    sc->modid = ndevs;
    sc->portmap = 0;
    sc->portmap1 = 0;

    dev_cb[ndevs] = sc;

    ndevs++;
    return sc;
}

#if CFG_PCI
static int _probe_bus(void)
{
    phys_addr_t     pa;
    pcitag_t        tag;
    pcireg_t        device;
    int             index = 0;

    for (;;) {
        if (pci_find_class(PCI_CLASS_NETWORK, index, &tag) != 0)
            break;
        index++;
        device = pci_conf_read(tag, PCI_ID_REG);
        if (PCI_VENDOR(device) == K_PCI_VENDOR_BROADCOM) {
            /* Base address used by read/write functions */
            pci_map_mem(tag, PCI_MAPREG(0), CSR_MATCH_MODE, &pa);
            switch (PCI_PRODUCT(device)) {
                case K_PCI_ID_BCM56224:
                    dev_create(PCI_PRODUCT(device), 1, pa, XGS_BUS_CAP_DMA);
                    break;
                default:
                    break;
            }
        }
    }

    return ndevs;
}

#else

static int _probe_bus(void)
{
    uint32_t device;
    bcm56224_state_t  *m = NULL;

    device = *(volatile uint32_t *)PHYS_TO_K1(ICS_CMIC_BASE+0x178);
    if ((device & 0xffff)) {
        m = dev_create(device, 1, 0xa8000000, XGS_BUS_CAP_DMA);
    }

#if CFG_EB_BUS
    
    {
        bcm56224_state_t  *sl;
        /* 
         * Add platform specific additional devices over EB bus.
         */
        if (m) {
            sl = dev_create(device, 1, CFG_EB_BASE_ADDR, 
                 XGS_DEVICE_SLAVE
#ifdef CFG_EB_BUS_16BIT_WR
                            | XGS_DEVICE_WR_16BIT 
#endif
#ifdef CFG_EB_BUS_16BIT_RD
                            | XGS_DEVICE_RD_16BIT
#endif
                            );
            dev_add_slave(m, sl);
        }
    }
#endif

    return ndevs;
}
#endif /* CFG_PCI */

static void
bcm56224_probe(cfe_driver_t *drv,
	      unsigned long probe_a, unsigned long probe_b, 
	      void *probe_ptr)
{
    uint8_t hwaddr[ENET_ADDR_LEN];
    const char *str_ptr;
    brd_info_t  * bp = NULL;
    char        *bname;

    /* Probe for BCM56XXX devices. */
    if (_probe_bus() == 0) {
        xprintf("bcm56224_probe failed. No valid devices discovered !!");
        return;
    }

    if (probe_ptr)
        enet_parse_hwaddr((char *)probe_ptr, hwaddr);
    else {
        /* get mac address */
        if ((str_ptr = env_getenv("ETH0_HWADDR")) != NULL) {
            if (enet_parse_hwaddr(str_ptr, hwaddr) != 0) {
                printf("Error: Failed to parse mac address (ETH0_HWADDR:%s)\n",
                       str_ptr);
                return;
            }
        } else {
            /* Use default address 00-00-56-22-40-00 */
            hwaddr[0] = 0x00;  hwaddr[1] = 0x00;  hwaddr[2] = 0x56;
            hwaddr[3] = 0x22;  hwaddr[4] = 0x40;  hwaddr[5] = 0x00;
        }
    }

    /* find the board type */
    if ((bname = env_getenv("BOARDNAME"))) {
        bp = find_brd_info(bname);
    }

    if (!bp) { /* No config setting, fall to default */
#if defined (BCM956224R50T)
        bp = find_brd_info("BCM956224R50T");
#elif defined(BCM956224K24)
        bp = find_brd_info("BCM956224K24");
#elif defined(BCM956024K24)
        bp = find_brd_info("BCM956024K24");
#elif defined(BCM956024R50T)
        bp = find_brd_info("BCM956024R50T");
#elif defined(BCM953724R26GWS)
        bp = find_brd_info("BCM953724R26GWS");
#else
#error "No ICS platform specified."
#endif
    }
    if (!bp) {
        bp = find_brd_info("BCM956224K24");
        printf("Invalid board type: configuring it for %s\n", 
               bp->name);
    } else {
        printf("Board : %s\n", bp->name);
    }

    board_info = bp;

    /* Attach the devices discovered. */
    bcm56224_attach(drv, 0, hwaddr);

}


/* The functions below are called via the dispatch vector for the XGS switch */

static int
bcm56224_open(cfe_devctx_t *ctx)
{
    bcm56224_state_t *sc = ctx->dev_softc;
    bcm56224_state_t *tmp = sc;

    if (sc->state == eth_state_on)
        xgs_stop(sc);

    sc->devctx = ctx;

    sc->inpkts = sc->outpkts = 0;
    sc->interrupts = 0;
    sc->rx_interrupts = sc->tx_interrupts = 0;

    while(tmp) {
        xgs_start(tmp);
        port_enable(tmp);
        tmp = tmp->slv_dev;
    }

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm56224_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm56224_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt, *new_pkt;
    int blen;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *)q_deqnext(&(sc->rxqueue));
    CS_EXIT(sc);

    if (pkt == NULL) {
        buffer->buf_retlen = 0;
        return 0;
    }

    blen = buffer->buf_length;
    if (blen > pkt->length) blen = pkt->length;


    /* Remove the VLAN tag. */
    blockcopy(buffer->buf_ptr, pkt->buffer, 12);
    blockcopy(buffer->buf_ptr+12, pkt->buffer+16, blen-16);
    buffer->buf_retlen = blen-4;

    eth_free_pkt(sc, pkt);

    if (XPOLL) xgs_isr(sc);

    if (sc->restartrx) {
        sc->restartrx = 0;
        
        new_pkt = eth_alloc_pkt(sc);
        if (new_pkt) {
            xgs_add_rcvbuf(sc, new_pkt);
        } else {
            sc->restartrx = 1;
        }
    }
    return 0;
}

static int
bcm56224_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    bcm56224_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    /* We avoid an interlock here because the result is a hint and an
       interrupt cannot turn a non-empty queue into an empty one. */
    inpstat->inp_status = (q_isempty(&(sc->rxqueue))) ? 0 : 1;

    return 0;
}

static int
bcm56224_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm56224_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen, retry = 0;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    pkt = eth_alloc_pkt(sc);
    if (!pkt) return CFE_ERR_NOMEM;

    blen = buffer->buf_length;
    if (blen > pkt->length) blen = pkt->length;

    /* Empirically, the logic will unconditionally delete 4 bytes from
        the nominal position of a VLAN tag, so insert something to
        strip. */
    blockcopy(pkt->buffer, buffer->buf_ptr, 12);
    pkt->buffer[12] = VLAN_TYPE >> 8; pkt->buffer[13] = VLAN_TYPE & 0xFF;
    pkt->buffer[14] = VLAN_DEFAULT >> 8; pkt->buffer[15] = VLAN_DEFAULT & 0xFF;
    blockcopy(pkt->buffer+16, buffer->buf_ptr+12, blen-12);

    /* The CMIC apparently does not correctly auto-pad short packets. */
    if (blen < ENET_MIN_PKT) {
	memset(pkt->buffer + blen + VLAN_TAG_LEN, 0, ENET_MIN_PKT - blen);
	blen = ENET_MIN_PKT;
	}

    pkt->length = blen + VLAN_TAG_LEN;

    while((xgs_transmit(sc, pkt) != 0) && (retry++ < 2)) {
        cfe_usleep(100);
        if (XPOLL) xgs_isr(sc);
    }

    if (retry == 10) {
        eth_free_pkt(sc,pkt);
        return CFE_ERR_IOERR;
    }

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm56224_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    bcm56224_state_t *sc = ctx->dev_softc;

    switch ((int)buffer->buf_ioctlcmd) {
        case IOCTL_ETHER_GETHWADDR:
            memcpy((void*)buffer->buf_ptr, sc->hwaddr, sizeof(sc->hwaddr));
            return 0;

        default:
            return -1;
    }
}

static int
bcm56224_close(cfe_devctx_t *ctx)
{
    bcm56224_state_t *sc = ctx->dev_softc;

    xgs_stop(sc);

    xprintf("%s: %d sent, %d received, %d interrupts\n",
        xgs_devname(sc), sc->outpkts, sc->inpkts, sc->interrupts);
    xprintf("  %d tx interrupts, %d rx interrupts\n",
        sc->tx_interrupts, sc->rx_interrupts);

    sc->devctx = NULL;

    return 0;
}

static void
bcm56224_poll(cfe_devctx_t *ctx, int64_t ticks)
{
    bcm56224_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);
}

static void
bcm56224_reset(void *softc)
{
    bcm56224_state_t *sc = (bcm56224_state_t *)softc;

    /* Turn off the Ethernet interface. */

    if (sc->state == eth_state_on)
        xgs_stop(sc);

    sc->state = eth_state_uninit;
}


extern void
do_schan_write_reg(unsigned int reg, uint32_t value);
extern uint32_t
do_schan_read_reg(unsigned int reg, int cnt, int step);

void
do_schan_write_reg(unsigned int reg, uint32_t value)
{
        schan_write_reg(dev_cb[dev_bcm56224_debug_unit], reg, value);
}

uint32_t
do_schan_read_reg(unsigned int reg, int cnt, int step)
{
    int ii = 0;

    while(cnt--) {
        printf("0x%08x : 0x%08x \n", 
               reg+ ii*step, schan_read_reg(dev_cb[dev_bcm56224_debug_unit], reg+ ii*step));
        ii++;
    }

    return 0;
}

uint32_t
do_mii_read_reg(uint32_t phy_addr, unsigned int reg, int cnt);
uint32_t
do_mii_write_reg(uint32_t phy_addr, unsigned int reg, int value);
void dump_eth_stats(void);

uint32_t
do_mii_read_reg(uint32_t phy_addr, unsigned int reg, int cnt)
{
    uint32_t cmd, data;
    bcm56224_state_t *sc = dev_cb[dev_bcm56224_debug_unit];

    while(cnt--) {

        WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_0);
        WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

        cmd = ((phy_addr & 0xff) << 16) ;
        WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
        WRITECSR(sc, R_CMIC_MIIM_ADDRESS, reg);

        WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_1);

        if (mii_poll(sc) < 0)
            return 0xFFFF;

        data = G_MIIMRD_DATA(READCSR(sc, R_CMIC_MIIM_READ_DATA));
        printf("0x%08x : 0x%08x\n", reg, data);
        reg++;
    }

    return 0;
}

uint32_t
do_mii_write_reg(uint32_t phy_addr, unsigned int reg, int value)
{
    uint32_t cmd;
    bcm56224_state_t *sc = dev_cb[dev_bcm56224_debug_unit];

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = ((phy_addr & 0xff) << 16) | V_MIIMP_PHY_DATA(value);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
    WRITECSR(sc, R_CMIC_MIIM_ADDRESS, reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_1);

    mii_poll(sc);
    return 0;
}

void dump_eth_stats(void)
{
    eth_pkt_t *pkt;
    int ii;
    bcm56224_state_t *sc = dev_cb[dev_bcm56224_debug_unit];

    xprintf("tx : %d txi : %d txbusy: %d\n",
            sc->outpkts, sc->tx_interrupts, sc->txbusy);
    xprintf("rx : %d rxi : %d restartrx : %d rx_empty %d\n",
            sc->inpkts, sc->rx_interrupts, sc->restartrx,
            q_isempty(&(sc->rxqueue)));

    /* dump rx q */
    ii = 0;
    while((pkt = (eth_pkt_t *)q_deqnext(&(sc->rxqueue)))) {
        xprintf("rx_q�pkt%d : 0x%08x\n", ii, pkt);
    }

}

