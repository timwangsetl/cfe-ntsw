/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5690 StrataXGS Ethernet Switch		File: bcm5690.h
    *  
    *  Author: Ed Satterthwaite
    *
    *********************************************************************  
    *
    *  Copyright 2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef _BCM5690_H_
#define _BCM5690_H_

/* Register and field definitions for the Broadcom BCM569x family of
   StrataXGS Gigabit Ethernet Multilayer Switch (aka Draco).

   Support is primarily for the CPU interface (CMIC) and its
   associated DMA.

   Reference:

       StrataXGS BCM5690/BCM5691/BCM5692/BCM5693 Programmer's Reference
          Guide
       Document 569x-PG100-R (4/24/03)
       Broadcom Corp., 1625 Alton Parkway, Irvine CA.
*/

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))


/* Known devices. */

#define K_PCI_VENDOR_BROADCOM    0x14e4
#define K_PCI_ID_BCM5690         0x5690
#define K_PCI_ID_BCM5691         0x5691
#define K_PCI_ID_BCM5692         0x5692
#define K_PCI_ID_BCM5693         0x5693


/* Basic Switch Geometry */

#define GPIC_PORTS               12
#define IPIC_PORT                12      /* 5690, 5692 only */
#define CMIC_PORT                13

/* Various bit maps have a standard bit position for each relevant port. */
#define GPIC_BIT(port)           (1 << (port))
#define IPIC_BIT                 (1 << IPIC_PORT)
#define CMIC_BIT                 (1 << CMIC_PORT)


/* HiGig header formats. */

#define K_HDR_MODE_HIGIG         0x1


/* PCI-accessible CSRs and their fields. */

/* Extensions to PCI configuration registers */

#define PCI_TIMEOUT_REG          0x40

#define PCI_TRDY_SHIFT           0
#define PCI_TRDY_MASK            0xff

#define PCI_RETRY_SHIFT          8
#define PCI_RETRY_MASK           0xff


/* CMIC Registers in PCI Memory Space (Section 4) */

#define R_CMIC_SCHAN_MESSAGE     0x0000
#define R_CMIC_SCHAN_CTRL        0x0050
#define R_CMIC_TABLE_DMA_ADDR    0x0054
#define R_CMIC_TABLE_DMA_SIZE    0x0058
#define R_CMIC_SCHAN_ERR         0x005C
#define R_CMIC_COS_AVAILABLE(cl) (0x0060+4*(cl))   /* 0 <= cl <= 7 */
#define R_CMIC_DMA_CTRL          0x0100
#define R_CMIC_DMA_STAT          0x0104
#define R_CMIC_HOL_STAT          0x0108
#define R_CMIC_CONFIG            0x010C
#define R_CMIC_DMA_DESC(ch)      (0x0110+4*(ch))   /* 0 <= ch <= 3 */

#define R_CMIC_I2C_SLAVE_ADDR    0x0120
#define R_CMIC_I2C_DATA          0x0124
#define R_CMIC_I2C_CTRL          0x0128
#define R_CMIC_I2C_STAT          0x012C
#define R_CMIC_I2C_CCR           0x012C
#define R_CMIC_I2C_SLAVE_XADDR   0x0130
#define R_CMIC_I2C_RESET         0x013C

#define R_CMIC_LINK_STAT         0x0140
#define R_CMIC_IRQ_STAT          0x0144
#define R_CMIC_IRQ_MASK          0x0148
#define R_CMIC_MEM_FAIL          0x014C
#define R_CMIC_IBP_WARN          0x0150
#define R_CMIC_IBP_DISCARD       0x0154
#define R_CMIC_MIIM_PARAM        0x0158
#define R_CMIC_MIIM_READ_DATA    0x015C
#define R_CMIC_SCAN_PORTS        0x0160
#define R_CMIC_STAT_DMA_ADDR     0x0164
#define R_CMIC_STAT_DMA_SETUP    0x0168
#define R_CMIC_STAT_DMA_PORTS    0x016C
#define R_CMIC_STAT_DMA_CURRENT  0x0170
#define R_CMIC_ENDIANESS_SEL     0x0174
#define R_CMIC_DEV_REV_ID        0x0178
#define R_CMIC_COS_CTRL_RX       0x0180
#define R_CMIC_HGTX_CTRL1        0x0184
#define R_CMIC_HGTX_CTRL2        0x0188
#define R_CMIC_MIRRORED_PORTS_TX 0x018C
#define R_CMIC_MIRROR_TO_PORTS   0x0190
#define R_CMIC_64BIT_STATS_CFG   0x0198
#define R_CMIC_TABLE_DMA_START   0x019C

#define R_CMIC_SCHAN_MSG_DMA     0x0800   /* alias */

#define R_LED_CONTROL            0x1000
#define R_LED_STATUS             0x1004
#define R_LED_PROGRAM_RAM_BASE   0x1800
#define R_LED_DATA_RAM_BASE      0x1C00


/* SCTL: Status and Control Register (0x0050) */

/* Bit positions used for set/clear commands. */
#define S_SCTL_MSG_START         0
#define S_SCTL_MSG_DONE          1
#define S_SCTL_TABLE_DMA_EN      6
#define S_SCTL_TABLE_DMA_DONE    7
#define S_SCTL_LINK_STAT_MSG     8
#define S_SCTL_PCI_FATAL_ERR     9
#define S_SCTL_PCI_PARITY_ERR    10
#define S_SCTL_ARL_MSG_RCV_OFF   11
#define S_SCTL_ARL_MSG_DROPPED   12
#define S_SCTL_TABLE_DMA_DONE_1  13
#define S_SCTL_CBP_OK            15
#define S_SCTL_MIIM_RD_START     16
#define S_SCTL_MIIM_WR_START     17
#define S_SCTL_MIIM_OP_DONE      18
#define S_SCTL_MIIM_LINK_SCAN_EN 19

#define M_SCTL_MSG_START         _DD_MAKEMASK1(S_SCTL_MSG_START)
#define M_SCTL_MSG_DONE          _DD_MAKEMASK1(S_SCTL_MSG_DONE)
#define M_SCTL_TABLE_DMA_EN      _DD_MAKEMASK1(S_SCTL_TABLE_DMA_EN)
#define M_SCTL_TABLE_DMA_DONE    _DD_MAKEMASK1(S_SCTL_TABLE_DMA_DONE)
#define M_SCTL_LINK_STAT_MSG     _DD_MAKEMASK1(S_SCTL_LINK_STAT_MSG)
#define M_SCTL_PCI_FATAL_ERR     _DD_MAKEMASK1(S_SCTL_PCI_FATAL_ERR)
#define M_SCTL_PCI_PARITY_ERR    _DD_MAKEMASK1(S_SCTL_PCI_PARITY_ERR)
#define M_SCTL_ARL_MSG_RCV_OFF   _DD_MAKEMASK1(S_SCTL_ARL_MSG_RCV_OFF)
#define M_SCTL_ARL_MSG_DROPPED   _DD_MAKEMASK1(S_SCTL_ARL_MSG_DROPPED)
#define M_SCTL_TABLE_DMA_DONE_1  _DD_MAKEMASK1(S_SCTL_TABLE_DMA_DONE_1)
#define M_SCTL_CBP_OK            _DD_MAKEMASK1(S_SCTL_CBP_OK)
#define M_SCTL_MIIM_RD_START     _DD_MAKEMASK1(S_SCTL_MIIM_RD_START)
#define M_SCTL_MIIM_WR_START     _DD_MAKEMASK1(S_SCTL_MIIM_WR_START)
#define M_SCTL_MIIM_OP_DONE      _DD_MAKEMASK1(S_SCTL_MIIM_OP_DONE)
#define M_SCTL_MIIM_LINK_SCAN_EN _DD_MAKEMASK1(S_SCTL_MIIM_LINK_SCAN_EN)

#define M_SCTL_NACK              _DD_MAKEMASK1(21)

#define S_SCTL_BIT_POS           0
#define M_SCTL_BIT_POS           _DD_MAKEMASK(5,S_SCTL_BIT_POS)
#define V_SCTL_BIT_POS(x)        _DD_MAKEVALUE(x,S_SCTL_BIT_POS)
#define G_SCTL_BIT_POS(x)        _DD_GETVALUE(x,S_SCTL_BIT_POS,M_SCTL_BIT_POS)

#define M_SCTL_BITVAL            _DD_MAKEMASK1(7)
#define V_SCTL_BIT_0             0
#define V_SCTL_BIT_1             M_SCTL_BITVAL

         
/* DMACTL: DMA Control Register (0x0100) */

#define M_CH_DIRECTION(ch)       _DD_MAKEMASK1(0+8*(ch))  /* 0 <= ch <= 3 */
#define M_CH_NO_MOD_PBMP(ch)     _DD_MAKEMASK1(1+8*(ch))
#define M_ABORT_DMA_CH(ch)       _DD_MAKEMASK1(2+8*(ch))
#define M_CH_SEL_INTR(ch)        _DD_MAKEMASK1(3+8*(ch))
#define M_DROP_TX_PRTS0_CH(ch)   _DD_MAKEMASK1(4+8*(ch))

/* DMASTAT: DMA Status Register (0x0104) */

/* Bit positions used for set/clear commands. */

#define S_CH_DMA_EN(ch)          (0+(ch))                 /* 0 <= ch <= 3 */
#define S_CH_CHAIN_DONE(ch)      (4+(ch))
#define S_CH_DESC_DONE(ch)       (8+(ch))
#define S_DMA_RESET              12
#define S_STATA_DMA_OPN_CMPLT    13
#define S_STATS_DMA_ITER_DONE    14
#define S_STATS_DMA_ACTIVE       17
#define S_CH_DMA_ACTIVE(ch)      (18+(ch))

#define M_CH_DMA_EN(ch)          _DD_MAKEMASK1(S_CH_DMA_EN(ch))
#define M_CH_CHAIN_DONE(ch)      _DD_MAKEMASK1(S_CH_CHAIN_DONE(ch))
#define M_CH_DESC_DONE(ch)       _DD_MAKEMASK1(S_CH_DESC_DONE(ch))

#define M_DMA_RESET              _DD_MAKEMASK1(S_DMA_RESET)
#define M_STATA_DMA_OPN_CMPLT    _DD_MAKEMASK1(S_STATA_DMA_OPN_CMPLT)
#define M_STATS_DMA_ITER_DONE    _DD_MAKEMASK1(S_STATS_DMA_ITER_DONE)
#define M_STATS_DMA_ACTIVE       _DD_MAKEMASK1(S_STATS_DMA_ACTIVE)

#define M_CH_DMA_ACTIVE(ch)      _DD_MAKEMASK1(S_CH_DMA_ACTIVE(ch))

#define S_PCI_PARITY_ERR         24
#define M_PCI_PARITY_ERR         _DD_MAKEMASK(2,S_PCI_PARITY_ERR)
#define V_PCI_PARITY_ERR(x)      _DD_MAKEVALUE(x,S_PCI_PARITY_ERR)
#define G_PCI_PARITY_ERR(x)      _DD_GETVALUE(x,S_PCI_PARITY_ERR,M_PCI_PARITY_ERR)

#define S_PCI_FATAL_ERR          29
#define M_PCI_FATAL_ERR          _DD_MAKEMASK(2,S_PCI_FATAL_ERR)
#define V_PCI_FATAL_ERR(x)       _DD_MAKEVALUE(x,S_PCI_FATAL_ERR)
#define G_PCI_FATAL_ERR(x)       _DD_GETVALUE(x,S_PCI_FATAL_ERR,M_PCI_FATAL_ERR)

#define S_DMA_BIT_POS            0
#define M_DMA_BIT_POS            _DD_MAKEMASK(5,S_DMA_BIT_POS)
#define V_DMA_BIT_POS(x)         _DD_MAKEVALUE(x,S_DMA_BIT_POS)
#define G_DMA_BIT_POS(x)         _DD_GETVALUE(x,S_DMA_BIT_POS,M_DMA_BIT_POS)

#define M_DMA_BITVAL             _DD_MAKEMASK1(7)
#define V_DMA_BIT_0              0
#define V_DMA_BIT_1              M_DMA_BITVAL


/* CONFIG: Configuration Register (0x010C) */

#define M_RD_BRST_EN             _DD_MAKEMASK1(0)
#define M_WR_BRST_EN             _DD_MAKEMASK1(1)
#define M_BE_CHECK_EN            _DD_MAKEMASK1(2)
#define M_MSTR_Q_MAX_EN          _DD_MAKEMASK1(3)
#define M_LINK_STAT_EN           _DD_MAKEMASK1(4)
#define M_RESET_CPS              _DD_MAKEMASK1(5)
#define M_ACT_LOW_INT            _DD_MAKEMASK1(6)
#define M_SCHAN_ABORT            _DD_MAKEMASK1(7)
#define M_STACK_ARCH_EN          _DD_MAKEMASK1(8)
#define M_UNTAG_EN               _DD_MAKEMASK1(9)
#define M_LE_DMA_EN              _DD_MAKEMASK1(10)
#define M_I2C_EN                 _DD_MAKEMASK1(11)
#define M_LINK_SCAN_GIG          _DD_MAKEMASK1(12)
#define M_IGNORE_ADR_ALIGN_EN    _DD_MAKEMASK1(13)
#define M_DMA_GARBAGE_COLLECT_EN _DD_MAKEMASK1(15)
#define M_RESET_PCI_EN           _DD_MAKEMASK1(16)
#define M_TIME_STAMP_UPD_DIS     _DD_MAKEMASK1(17)
#define M_SG_ENABLE              _DD_MAKEMASK1(18)
#define M_SG_RELOAD_ENABLE       _DD_MAKEMASK1(19)
#define M_RLD_STS_UPD_DIS        _DD_MAKEMASK1(20)
#define M_STOP_LS_ON_CHANGE      _DD_MAKEMASK1(21)
#define M_ABORT_STAT_DMA         _DD_MAKEMASK1(22)
#define M_LS_START_ID0           _DD_MAKEMASK1(23)
#define M_COS_RX_EN              _DD_MAKEMASK1(24)
#define M_ABORT_TBL_DMA          _DD_MAKEMASK1(25)
#define M_EXT_MDIO_MSTR_DIS      _DD_MAKEMASK1(26)


/* IRQSTAT: Interrupt Status Register (0x0144) */
/* IRQMASK: Interrupt Mask Register (0x0148) */

#define M_IRQ_SCH_MSG_DONE       _DD_MAKEMASK1(0)
#define M_IRQ_CBP_FULL           _DD_MAKEMASK1(3)
#define M_IRQ_LINK_STAT_MOD      _DD_MAKEMASK1(4)
#define M_IRQ_TABLE_DMA_CNT0     _DD_MAKEMASK1(6)
#define M_IRQ_DESC_DONE(ch)      _DD_MAKEMASK1(7+2*(ch))  /* 0 <= ch <= 3 */
#define M_IRQ_CHAIN_DONE(ch)     _DD_MAKEMASK1(8+2*(ch))
#define M_IRQ_PCI_PARITY_ERR     _DD_MAKEMASK1(15)
#define M_IRQ_PCI_FATAL_ERR      _DD_MAKEMASK1(16)
#define M_IRQ_SCHAN_ERR          _DD_MAKEMASK1(17)
#define M_IRQ_I2C_INTR           _DD_MAKEMASK1(18)
#define M_IRQ_MIIM_OP_DONE       _DD_MAKEMASK1(19)
#define M_IRQ_STATS_DMA_ITER_DONE _DD_MAKEMASK1(20)
#define M_IRQ_ARL_BUCKET_OVR     _DD_MAKEMASK1(21)


/* MIIMP: MIIM Parameter Register (0x0158) */

#define S_MIIMP_PHY_DATA          0
#define M_MIIMP_PHY_DATA          _DD_MAKEMASK(16,S_MIIMP_PHY_DATA)
#define V_MIIMP_PHY_DATA(x)       _DD_MAKEVALUE(x,S_MIIMP_PHY_DATA)
#define G_MIIMP_PHY_DATA(x)       _DD_GETVALUE(x,S_MIIMP_PHY_DATA,M_MIIMP_PHY_DATA)

#define S_MIIMP_PHY_ID            16
#define M_MIIMP_PHY_ID            _DD_MAKEMASK(7,S_MIIMP_PHY_ID)
#define V_MIIMP_PHY_ID(x)         _DD_MAKEVALUE(x,S_MIIMP_PHY_ID)
#define G_MIIMP_PHY_ID(x)         _DD_GETVALUE(x,S_MIIMP_PHY_ID,M_MIIMP_PHY_ID)

#define M_MIIMP_INTERNAL_SEL      _DD_MAKEMASK1(23)

#define S_MIIMP_PHY_REG           24
#define M_MIIMP_PHY_REG           _DD_MAKEMASK(8,S_MIIMP_PHY_REG)
#define V_MIIMP_PHY_REG(x)        _DD_MAKEVALUE(x,S_MIIMP_PHY_REG)
#define G_MIIMP_PHY_REG(x)        _DD_GETVALUE(x,S_MIIMP_PHY_REG,M_MIIMP_PHY_REG)

/* MIIMRD: MIIM Read Data Register (0x015C) */

#define S_MIIMRD_DATA             0
#define M_MIIMRD_DATA             _DD_MAKEMASK(16,S_MIIMRD_DATA)
#define V_MIIMRD_DATA(x)          _DD_MAKEVALUE(x,S_MIIMRD_DATA)
#define G_MIIMRD_DATA(x)          _DD_GETVALUE(x,S_MIIMP_PHY_DATA,M_MIIMP_PHY_DATA)


/* ID: Device/Revision Module ID Register (0x0178) */

#define S_ID_DEV_ID               0
#define M_ID_DEV_ID               _DD_MAKEMASK(16,S_ID_DEV_ID)
#define V_ID_DEV_ID(x)            _DD_MAKEVALUE(x,S_ID_DEV_ID)
#define G_ID_DEV_ID(x)            _DD_GETVALUE(x,S_ID_DEV_ID,M_ID_DEV_ID)

#define S_ID_REV_ID               16
#define M_ID_REV_ID               _DD_MAKEMASK(8,S_ID_REV_ID)
#define V_ID_REV_ID(x)            _DD_MAKEVALUE(x,S_ID_REV_ID)
#define G_ID_REV_ID(x)            _DD_GETVALUE(x,S_ID_REV_ID,M_ID_REV_ID)

#define S_ID_MOD_ID               24
#define M_ID_MOD_ID               _DD_MAKEMASK(8,S_ID_MOD_ID)
#define V_ID_MOD_ID(x)            _DD_MAKEVALUE(x,S_ID_MOD_ID)
#define G_ID_MOD_ID(x)            _DD_GETVALUE(x,S_ID_MOD_ID,M_ID_MOD_ID)


/* DMA Control Block (DCB) Format (Section 18). */

/* Each DCB is 8 32-bit words.  The fields are defined below by word
   offset.  */

#define S_DCB0_MEM_ADDR          0
#define M_DCB0_MEM_ADDR          _DD_MAKEMASK(32,S_DCB0_MEM_ADDR)
#define V_DCB0_MEM_ADDR(x)       _DD_MAKEVALUE(x,S_DCB0_MEM_ADDR)
#define G_DCB0_MEM_ADDR(x)       _DD_GETVALUE(x,S_DCB0_MEM_ADDR,M_DCB0_MEM_ADDR)

#define S_DCB1_BYTE_COUNT        0
#define M_DCB1_BYTE_COUNT        _DD_MAKEMASK(15,S_DCB1_BYTE_COUNT)
#define V_DCB1_BYTE_COUNT(x)     _DD_MAKEVALUE(x,S_DCB1_BYTE_COUNT)
#define G_DCB1_BYTE_COUNT(x)     _DD_GETVALUE(x,S_DCB1_BYTE_COUNT,M_DCB1_BYTE_COUNT)


#define M_DCB1_CRC_REGEN         _DD_MAKEMASK1(15)
#define M_DCB1_DST_PORT_4        _DD_MAKEMASK1(16)
#define M_DCB1_RLD               _DD_MAKEMASK1(17)
#define M_DCB1_SG                _DD_MAKEMASK1(18)

#define S_DCB1_DST_PORT_30       19
#define M_DCB1_DST_PORT_30       _DD_MAKEMASK(4,S_DCB1_DST_PORT_30)
#define V_DCB1_DST_PORT_30(x)    _DD_MAKEVALUE(x,S_DCB1_DST_PORT_30)
#define G_DCB1_DST_PORT_30(x)    _DD_GETVALUE(x,S_DCB1_DST_PORT_30,M_DCB1_DST_PORT_30)

#define V_DCB1_DST_PORT(x)       ((((x) & 0x80) ? M_DCB1_DST_PORT_4 : 0) | \
                                  V_DCB1_DST_PORT_30((x) & 0x0F))
#define G_DCB1_DST_PORT(x)       (G_DCB1_DST_PORT_30(x) + \
                                  ((x) & M_DCB1_DST_PORT4) >> (S_DCB1_DST_PORT_4-4))

#define S_DCB1_DST_MOD_ID        23
#define M_DCB1_DST_MOD_ID        _DD_MAKEMASK(5,S_DCB1_DST_MOD_ID)
#define V_DCB1_DST_MOD_ID(x)     _DD_MAKEVALUE(x,S_DCB1_DST_MOD_ID)
#define G_DCB1_DST_MOD_ID(x)     _DD_GETVALUE(x,S_DCB1_DST_MOD_ID,M_DCB1_DST_MOD_ID)

#define S_DCB1_COS               28
#define M_DCB1_COS               _DD_MAKEMASK(3,S_DCB1_COS)
#define V_DCB1_COS(x)            _DD_MAKEVALUE(x,S_DCB1_COS)
#define G_DCB1_COS(x)            _DD_GETVALUE(x,S_DCB1_COS,M_DCB1_COS)

#define M_DCB1_C                 _DD_MAKEMASK1(31)

#define S_DCB2_PORT_MAP          0
#define M_DCB2_PORT_MAP          _DD_MAKEMASK(31,S_DCB2_PORT_MAP)
#define V_DCB2_PORT_MAP(x)       _DD_MAKEVALUE(x,S_DCB2_PORT_MAP)
#define G_DCB2_PORT_MAP(x)       _DD_GETVALUE(x,S_DCB2_PORT_MAP,M_DCB2_PORT_MAP)

#define M_DCB2_MH_OPCODE_0       _DD_MAKEMASK1(31)

#define S_DCB3_UNTAGGED_MAP      0
#define M_DCB3_UNTAGGED_MAP      _DD_MAKEMASK(31,S_DCB3_UNTAGGED_MAP)
#define V_DCB3_UNTAGGED_MAP(x)   _DD_MAKEVALUE(x,S_DCB3_UNTAGGED_MAP)
#define G_DCB3_UNTAGGED_MAP(x)   _DD_GETVALUE(x,S_DCB3_UNTAGGED_MAP,M_DCB3_UNTAGGED_MAP)

#define M_DCB3_MH_OPCODE_1       _DD_MAKEMASK1(31)

#define S_DCB4_L3_MAP            0
#define M_DCB4_L3_MAP            _DD_MAKEMASK(31,S_DCB4_L3_MAP)
#define V_DCB4_L3_MAP(x)         _DD_MAKEVALUE(x,S_DCB4_L3_MAP)
#define G_DCB4_L3_MAP(x)         _DD_GETVALUE(x,S_DCB4_L3_MAP,M_DCB4_L3_MAP)

#define M_DCB4_MH_OPCODE_2       _DD_MAKEMASK1(31)

#define S_DCB5_RCV_COUNT         0
#define M_DCB5_RCV_COUNT         _DD_MAKEMASK(16,S_DCB5_RCV_COUNT)
#define V_DCB5_RCV_COUNT(x)      _DD_MAKEVALUE(x,S_DCB5_RCV_COUNT)
#define G_DCB5_RCV_COUNT(x)      _DD_GETVALUE(x,S_DCB5_RCV_COUNT,M_DCB5_RCV_COUNT)

#define M_DCB5_CRC_REGEN_P       _DD_MAKEMASK1(16)
#define M_DCB5_ING_TAGGED        _DD_MAKEMASK1(17)
#define M_DCB5_SRC_PORT_TGID     _DD_MAKEMASK1(18)
#define M_DCB5_L3_BITMAP         _DD_MAKEMASK1(19)
#define M_DCB5_SW                _DD_MAKEMASK1(20)

#define S_DCB5_COSW              21
#define M_DCB5_COSW              _DD_MAKEMASK(3,S_DCB5_COSW)
#define V_DCB5_COSW(x)           _DD_MAKEVALUE(x,S_DCB5_COSW)
#define G_DCB5_COSW(x)           _DD_GETVALUE(x,S_DCB5_COSW,M_DCB5_COSW)

#define S_DCB5_SRC_PORT_ID       24
#define M_DCB5_SRC_PORT_ID       _DD_MAKEMASK(5,S_DCB5_SRC_PORT_ID)
#define V_DCB5_SRC_PORT_ID(x)    _DD_MAKEVALUE(x,S_DCB5_SRC_PORT_ID)
#define G_DCB5_SRC_PORT_ID(x)    _DD_GETVALUE(x,S_DCB5_SRC_PORT_ID,M_DCB5_SRC_PORT_ID)

#define S_DCB5_SRC_PORT_TGID     18
#define G_DCB5_SRC_PORT_TGID(x)  (G_DCB5_SRC_PORT_ID(x) + \
                                  (((x) & M_DCB5_SRC_PORT_TGID) >> (S_DCB5_SRC_PORT_TGID-5)))

#define M_DCB5_ER                _DD_MAKEMASK1(29)
#define M_DCB5_EW                _DD_MAKEMASK1(30)
#define M_DCB5_DONE              _DD_MAKEMASK1(31)

#define S_DCB6_SRC_PORT          0
#define M_DCB6_SRC_PORT          _DD_MAKEMASK(4,S_DCB6_SRC_PORT)
#define V_DCB6_SRC_PORT(x)       _DD_MAKEVALUE(x,S_DCB6_SRC_PORT)
#define G_DCB6_SRC_PORT(x)       _DD_GETVALUE(x,S_DCB6_SRC_PORT,M_DCB6_SRC_PORT)

#define S_DCB6_MH_OPCODE         4
#define M_DCB6_MH_OPCODE         _DD_MAKEMASK(3,S_DCB6_MH_OPCODE)
#define V_DCB6_MH_OPCODE(x)      _DD_MAKEVALUE(x,S_DCB6_MH_OPCODE)
#define G_DCB6_MH_OPCODE(x)      _DD_GETVALUE(x,S_DCB6_MH_OPCODE,M_DCB6_MH_OPCODE)

#define M_DCB6_MH_PRIORITY_0     _DD_MAKEMASK1(7)
#define M_DCB6_DONE              _DD_MAKEMASK1(8)

#define S_DCB6_MH_PRIORITY_21    9
#define M_DCB6_MH_PRIORITY_21    _DD_MAKEMASK(2,S_DCB6_MH_PRIORITY_21)
#define V_DCB6_MH_PRIORITY_21(x) _DD_MAKEVALUE(x,S_DCB6_MH_PRIORITY_21)
#define G_DCB6_MH_PRIORITY_21(x) _DD_GETVALUE(x,S_DCB6_MH_PRIORITY_21,M_DCB6_MH_PRIORITY_21)

#define S_DCB6_SRC_MOD_ID        11
#define M_DCB6_SRC_MOD_ID        _DD_MAKEMASK(5,S_DCB6_SRC_MOD_ID)
#define V_DCB6_SRC_MOD_ID(x)     _DD_MAKEVALUE(x,S_DCB6_SRC_MOD_ID)
#define G_DCB6_SRC_MOD_ID(x)     _DD_GETVALUE(x,S_DCB6_SRC_MOD_ID,M_DCB6_SRC_MOD_ID)

#define S_DCB6_CPU_OPCODES       16
#define M_DCB6_CPU_OPCODES       _DD_MAKEMASK(16,S_DCB6_CPU_OPCODES)
#define V_DCB6_CPU_OPCODES(x)    _DD_MAKEVALUE(x,S_DCB6_CPU_OPCODES)
#define G_DCB6_CPU_OPCODES(x)    _DD_GETVALUE(x,S_DCB6_CPU_OPCODES,M_DCB6_CPU_OPCODES)

#define M_OPC_CPU_UVLAN          _DD_MAKEMASK1(0)
#define M_OPC_CPU_SLF            _DD_MAKEMASK1(1)
#define M_OPC_CPU_DLF            _DD_MAKEMASK1(2)
#define M_OPC_CPU_L2MOVE         _DD_MAKEMASK1(3)
#define M_OPC_CPU_L2CPU          _DD_MAKEMASK1(4)
#define M_OPC_CPU_L3SRC_MISS     _DD_MAKEMASK1(7)
#define M_OPC_CPU_L3DST_MISS     _DD_MAKEMASK1(8)
#define M_OPC_CPU_L3SRC_MOVE     _DD_MAKEMASK1(9)
#define M_OPC_CPU_MC_MISS        _DD_MAKEMASK1(10)
#define M_OPC_CPU_IPMC_MISS      _DD_MAKEMASK1(11)
#define M_OPC_CPU_FFP            _DD_MAKEMASK1(12)
#define M_OPC_CPU_L3HDR_ERR      _DD_MAKEMASK1(13)
#define M_OPC_CPU_PROTO_PKT      _DD_MAKEMASK1(14)

/* DCB7 used for testing only */


/* S-Channel Message Formats and Codes */

#define SC_BLOCK_GPIC(n)         (0x0+(n))            /* 0 <= n < 12 */
#define SC_BLOCK_IPIC            0xC
#define SC_BLOCK_MMU             0xD
#define SC_BLOCK_CMIC            0xF

#define M_SMHDR_C                _DD_MAKEMASK1(0)

#define S_SMHDR_COS              1
#define M_SMHDR_COS              _DD_MAKEMASK(3,S_SMHDR_COS)
#define V_SMHDR_COS(x)           _DD_MAKEVALUE(x,S_SMHDR_COS)
#define G_SMHDR_COS(x)           _DD_GETVALUE(x,S_SMHDR_COS,M_SMHDR_COS)

#define S_SMHDR_ECODE            4
#define M_SMHDR_ECODE            _DD_MAKEMASK(2,S_SMHDR_ECODE)
#define V_SMHDR_ECODE(x)         _DD_MAKEVALUE(x,S_SMHDR_ECODE)
#define G_SMHDR_ECODE(x)         _DD_GETVALUE(x,S_SMHDR_ECODE,M_SMHDR_ECODE)

#define M_SMHDR_E                _DD_MAKEMASK1(6)

#define S_SMHDR_DATA_LEN         7
#define M_SMHDR_DATA_LEN         _DD_MAKEMASK(7,S_SMHDR_DATA_LEN)
#define V_SMHDR_DATA_LEN(x)      _DD_MAKEVALUE(x,S_SMHDR_DATA_LEN)
#define G_SMHDR_DATA_LEN(x)      _DD_GETVALUE(x,S_SMHDR_DATA_LEN,M_SMHDR_DATA_LEN)

#define S_SMHDR_SRC_BLOCK        14
#define M_SMHDR_SRC_BLOCK        _DD_MAKEMASK(6,S_SMHDR_SRC_BLOCK)
#define V_SMHDR_SRC_BLOCK(x)     _DD_MAKEVALUE(x,S_SMHDR_SRC_BLOCK)
#define G_SMHDR_SRC_BLOCK(x)     _DD_GETVALUE(x,S_SMHDR_SRC_BLOCK,M_SMHDR_SRC_BLOCK)

#define S_SMHDR_DEST_BLOCK       20
#define M_SMHDR_DEST_BLOCK       _DD_MAKEMASK(6,S_SMHDR_DEST_BLOCK)
#define V_SMHDR_DEST_BLOCK(x)    _DD_MAKEVALUE(x,S_SMHDR_DEST_BLOCK)
#define G_SMHDR_DEST_BLOCK(x)    _DD_GETVALUE(x,S_SMHDR_DEST_BLOCK,M_SMHDR_DEST_BLOCK)

#define S_SMHDR_OP_CODE          26
#define M_SMHDR_OP_CODE          _DD_MAKEMASK(6,S_SMHDR_OP_CODE)
#define V_SMHDR_OP_CODE(x)       _DD_MAKEVALUE(x,S_SMHDR_OP_CODE)
#define G_SMHDR_OP_CODE(x)       _DD_GETVALUE(x,S_SMHDR_OP_CODE,M_SMHDR_OP_CODE)

#define SC_OP_RD_MEM_CMD         0x07
#define SC_OP_RD_MEM_ACK         0x08
#define SC_OP_WR_MEM_CMD         0x09
#define SC_OP_RD_REG_CMD         0x0B
#define SC_OP_RD_REG_ACK         0x0C
#define SC_OP_WR_REG_CMD         0x0D
#define SC_OP_L2_INS_CMD         0x0F
#define SC_OP_L2_DEL_CMD         0x11


/* ARL Register S-Channel Addresses */

#define R_HASH_CONTROL           0x00E80026
#define R_ARL_CONTROL            0x00E80028

/* HASHCTL: ARL Hashing Control Register (0x00E80026) */

#define S_HASHCTL_HASH_SELECT    0
#define M_HASHCTL_HASH_SELECT    _DD_MAKEMASK(2,S_HASHCTL_HASH_SELECT)
#define V_HASHCTL_HASH_SELECT(x) _DD_MAKEVALUE(x,S_HASHCTL_HASH_SELECT)
#define G_HASHCTL_HASH_SELECT(x) _DD_GETVALUE(x,S_HASHCTL_HASH_SELECT,M_HASHCTL_HASH_SELECT)
#define K_HASH_CRC16_UPPER       0
#define K_HASH_CRC16_LOWER       1
#define K_HASH_LSB_KEY           2
#define K_HASH_ZERO              3
#define K_HASH_CRC32_UPPER       4
#define K_HASH_CRC32_LOWER       5

/* ARLCTL: ARL Control Register (0x00E80028) */

#define M_ARLCTL_ARL_INIT        _DD_MAKEMASK1(0)

#define S_ARLCTL_CLK_GRAN        1
#define M_ARLCTL_CLK_GRAN        _DD_MAKEMASK(4,S_ARLCTL_CLK_GRAN)
#define V_ARLCTL_CLK_GRAN(x)     _DD_MAKEVALUE(x,S_ARLCTL_CLK_GRAN)
#define G_ARLCTL_CLK_GRAN(x)     _DD_GETVALUE(x,S_ARLCTL_CLK_GRAN,M_ARLCTL_CLK_GRAN)

/* Other defined fields are Reserved. */


/* GPIC Register S-Channel Addresses */

#define R_GPIC(g,offset)         (((g) << 20) | offset)

#define R_EGR_FLOWCTL_CFG(g)     R_GPIC(g,0x00080)
#define R_EGR_IPMC_CFG0(g)       R_GPIC(g,0x00081)
#define R_EGR_IPMC_CFG1(g)       R_GPIC(g,0x00082)
#define R_EGR_IPMC_CFG2(g)       R_GPIC(g,0x00083)
#define R_HOLSTATUS(g)           R_GPIC(g,0x4C000)
#define R_CONFIG(g)              R_GPIC(g,0x80000)
#define R_GEGR_ENABLE(g)         R_GPIC(g,0x80001)
#define R_VLAN_CONTROL(g)        R_GPIC(g,0x80002)
#define R_EPC_LINK(g)            R_GPIC(g,0x80003)
#define R_BKP_DISC(g)            R_GPIC(g,0x80004)
#define R_MIRROR_CONTROL(g)      R_GPIC(g,0x80005)
#define R_CPU_CONTROL(g)         R_GPIC(g,0x80006)
#define R_COS_SEL(g)             R_GPIC(g,0x80007)
#define R_GPC_BPDU_LO(g,n)       R_GPIC(g,0x80009+2*(n))   /* 0 <= n <= 5 */
#define R_GPC_BPDU_HI(g,n)       R_GPIC(g,0x8000A+2*(n))
#define R_DLF_TRUNK_BLOCK_MASK(g)     R_GPIC(g,0x80018)
#define R_MC_TRUNK_BLOCK_MASK(g)      R_GPIC(g,0x80019)
#define R_IMPC_TRUNK_BLOCK_MASK(g)    R_GPIC(g,0x8001A)
#define R_UNKNOWN_UCAST_BLOCK_MASK(g) R_GPIC(g,0x8001D)
#define R_UNKNOWN_MCAST_BLOCK_MASK(g) R_GPIC(g,0x8001E)
#define R_BCAST_BLOCK_MASK(g)         R_GPIC(g,0x8001F)
#define R_PAUSE_CONTROL(g)       R_GPIC(g,0x80020)
#define R_PRTABLE_DEFAULT(g)     R_GPIC(g,0x80021)
#define R_PRTABLE_ENTRY(g,n)     R_GPIC(g,0x80022+(n))    /* 0 <= n <= 6 */
#define R_MODPORT_7_0(g)         R_GPIC(g,0x8002B)
#define R_MODPORT_15_8(g)        R_GPIC(g,0x8002C)
#define R_MODPORT_23_16(g)       R_GPIC(g,0x8002D)
#define R_MODPORT_31_24(g)       R_GPIC(g,0x8002E)
#define R_LLC_MATCH(g)           R_GPIC(g,0x80030)


/* Gigabit MAC Register S-Channel Addresses */

#define R_GMAC(g,offset)         (((g) << 20) | offset)

#define R_GMACC0(g)              R_GMAC(g,0x00000)
#define R_GMACC1(g)              R_GMAC(g,0x00001)
#define R_GMACC2(g)              R_GMAC(g,0x00002)
#define R_GPCSC(g)               R_GMAC(g,0x00003)
#define R_GSA0(g)                R_GMAC(g,0x00004)
#define R_GSA1(g)                R_GMAC(g,0x00005)
#define R_MAXFR(g)               R_GMAC(g,0x00008)
#define R_GTH_FE_MAC1(g)         R_GMAC(g,0x00100)
#define R_GTH_FE_MAC2(g)         R_GMAC(g,0x00101)
#define R_GTH_FE_IPGT(g)         R_GMAC(g,0x00102)
#define R_GTH_FE_IPGR(g)         R_GMAC(g,0x00103)
#define R_GTH_FE_CLRT(g)         R_GMAC(g,0x00104)
#define R_GTH_FE_MAXF(g)         R_GMAC(g,0x00105)
#define R_GTH_ESA0(g)            R_GMAC(g,0x00110)
#define R_GTH_ESA1(g)            R_GMAC(g,0x00111)
#define R_GTH_ESA2(g)            R_GMAC(g,0x00112)


/* IPIC Register S-Channel Addresses */

#define R_IPIC(offset)           (0x00C0000 | offset)

#define R_IHOLSTATUS(c)          (0x00C40000+((cl)<<12))  /* 0 <= cl <= 7 */
#define R_ICONFIG                0x00C80000
#define R_IEGR_ENABLE            0x00C80001
#define R_IVLAN_CONTROL          0x00C80002
#define R_ILINK                  0x00C80003
#define R_IBKP_DISC              0x00C80004
#define R_IMIRROR_CONTROL        0x00C80005
#define R_ICPU_CONTROL           0x00C80006
#define R_ICOS_SEL               0x00C80007
#define R_IDLF_TRUNK_BLOCK_MASK  0x00C80018
#define R_IMC_TRUNK_BLOCK_MASK   0x00C80019
#define R_IIPMC_TRUNK_BLOCK_MASK 0x00C8001A
#define R_IUNKNOWN_UCAST_BLOCK_MASK 0x00C8001D
#define R_IUNKNOWN_MCAST_BLOCK_MASK 0x00C8001E
#define R_IBCAST_BLOCK_MASK      0x00C8001F
#define R_IMODPORT_7_0           0x00C8002B
#define R_IMODPORT_15_8          0x00C8002C
#define R_IMODPORT_23_16         0x00C8002D
#define R_IMODPORT_31_24         0x00C8002E
#define R_IBKP_WARN              0x00C80030
#define R_ICBP_FULL              0x00C80031


/* HiGig MAC Register S-Channel Addresses (64 bits) */

#define R_MAC_CTRL(port)         (0x00000020 + ((port)<<20))
#define R_MAC_XGXS_CTRL(port)    (0x00000021 + ((port)<<20))
#define R_MAC_XGXS_STAT(port)    (0x00000022 + ((port)<<20))
#define R_MAC_TXCTRL(port)       (0x00000025 + ((port)<<20))
#define R_MAC_TXMACSA(port)      (0x00000026 + ((port)<<20))
#define R_MAC_TXMAXSZ(port)      (0x00000027 + ((port)<<20))
#define R_MAC_TXPSETHR(port)     (0x00000028 + ((port)<<20))
#define R_MAC_RXCTRL(port)       (0x00000033 + ((port)<<20))
#define R_MAC_RXMACSA(port)      (0x00000034 + ((port)<<20))
#define R_MAC_RXMAXSZ(port)      (0x00000035 + ((port)<<20))


/* MACCTRL: 10G MAC Control Register (0x00C00020) */

#define M_MACCTRL_TX_EN          _DD_MAKEMASK1(0)
#define M_MACCTRL_RX_EN          _DD_MAKEMASK1(1)
#define M_MACCTRL_LCL_LOOP       _DD_MAKEMASK1(2)
#define M_MACCTRL_RMT_LOOP       _DD_MAKEMASK1(3)


/* XGXSCTRL: XGXS_IP Control Register (0x00C00021) */

#define S_XGXSCTRL_MODE          0
#define M_XGXSCTRL_MODE          _DD_MAKEMASK(4,S_XGXSCTRL_MODE)
#define V_XGXSCTRL_MODE(x)       _DD_MAKEVALUE(x,S_XGXSCTRL_MODE)
#define G_XGXSCTRL_MODE(x)       _DD_GETVALUE(x,S_XGXSCTRL_MODE,M_XGXSCTRL_MODE)

#define M_XGXSCTRL_HW_RST_L      _DD_MAKEMASK1(4)
#define M_XGXSCTRL_PWR_DWN       _DD_MAKEMASK1(5)
#define M_XGXSCTRL_IDDQ          _DD_MAKEMASK1(6)
#define M_XGXSCTRL_TXFIFO_RST_L  _DD_MAKEMASK1(7)
#define M_XGXSCTRL_AFIFO_RST     _DD_MAKEMASK1(8)
#define M_XGXSCTRL_RMT_LOOP      _DD_MAKEMASK1(9)
#define M_XGXSCTRL_PLL_BYP       _DD_MAKEMASK1(10)


/* XGSXSTAT: XGXS_IP Status Register (0x00C00022) */

#define M_XGXSSTAT_LINK          _DD_MAKEMASK1(0)
#define M_XGXSSTAT_RX_ACT        _DD_MAKEMASK1(1)
#define M_XGXSSTAT_SEQ_DONE      _DD_MAKEMASK1(2)
#define M_XGXSSTAT_TXPLL_LOCK    _DD_MAKEMASK1(3)
#define M_XGXSSTAT_TX_ACT        _DD_MAKEMASK1(4)
#define M_XGXSSTAT_TXFIFO_ERR    _DD_MAKEMASK1(5)
#define M_XGXSSTAT_RMT_FLT       _DD_MAKEMASK1(6)
#define M_XGXSSTAT_BRK_LINKS     _DD_MAKEMASK1(7)


/* TXCTRL: Transmit Control Register (0x00C00025) */

#define S_TXCTRL_HDR_MODE        0
#define M_TXCTRL_HDR_MODE        _DD_MAKEMASK(2,S_TXCTRL_HDR_MODE)
#define V_TXCTRL_HDR_MODE(x)     _DD_MAKEVALUE(x,S_TXCTRL_HDR_MODE)
#define G_TXCTRL_HDR_MODE(x)     _DD_GETVALUE(x,S_TXCTRL_HDR_MODE,M_TXCTRL_HDR_MODE)

#define S_TXCTRL_CRC_MODE        2
#define M_TXCTRL_CRC_MODE        _DD_MAKEMASK(2,S_TXCTRL_CRC_MODE)
#define V_TXCTRL_CRC_MODE(x)     _DD_MAKEVALUE(x,S_TXCTRL_CRC_MODE)
#define G_TXCTRL_CRC_MODE(x)     _DD_GETVALUE(x,S_TXCTRL_CRC_MODE,M_TXCTRL_CRC_MODE)
#define K_CRC_MODE_APPEND        0
#define K_CRC_MODE_KEEP          1
#define K_CRC_MODE_REPLACE       2

#define S_TXCTRL_AVG_IPG         4
#define M_TXCTRL_AVG_IPG         _DD_MAKEMASK(5,S_TXCTRL_AVG_IPG)
#define V_TXCTRL_AVG_IPG(x)      _DD_MAKEVALUE(x,S_TXCTRL_AVG_IPG)
#define G_TXCTRL_AVG_IPG(x)      _DD_GETVALUE(x,S_TXCTRL_AVG_IPG,M_TXCTRL_AVG_IPG)

#define S_TXCTRL_THROT_NUM       9
#define M_TXCTRL_THROT_NUM       _DD_MAKEMASK(6,S_TXCTRL_THROT_NUM)
#define V_TXCTRL_THROT_NUM(x)    _DD_MAKEVALUE(x,S_TXCTRL_THROT_NUM)
#define G_TXCTRL_THROT_NUM(x)    _DD_GETVALUE(x,S_TXCTRL_THROT_NUM,M_TXCTRL_THROT_NUM)

#define S_TXCTRL_THROT_DENOM     15
#define M_TXCTRL_THROT_DENOM     _DD_MAKEMASK(8,S_TXCTRL_THROT_DENOM)
#define V_TXCTRL_THROT_DENOM(x)  _DD_MAKEVALUE(x,S_TXCTRL_THROT_DENOM)
#define G_TXCTRL_THROT_DENOM(x)  _DD_GETVALUE(x,S_TXCTRL_THROT_DENOM,M_TXCTRL_THROT_DENOM)

#define M_TXCTRL_PAUSE_EN        _DD_MAKEMASK1(23)
#define M_TXCTRL_DISCARD         _DD_MAKEMASK1(24)
#define M_TXCTRL_ANY_START       _DD_MAKEMASK1(25)


/* RXCTRL: Receive Control Register (0x00C00033) */

#define S_RXCTRL_HDR_MODE        0
#define M_RXCTRL_HDR_MODE        _DD_MAKEMASK(2,S_RXCTRL_HDR_MODE)
#define V_RXCTRL_HDR_MODE(x)     _DD_MAKEVALUE(x,S_RXCTRL_HDR_MODE)
#define G_RXCTRL_HDR_MODE(x)     _DD_GETVALUE(x,S_RXCTRL_HDR_MODE,M_RXCTRL_HDR_MODE)

#define M_RXCTRL_STRIP_CRC       _DD_MAKEMASK1(2)
#define M_RXCTRL_IGNORE_CRC      _DD_MAKEMASK1(3)
#define M_RXCTRL_STRICT_PRMBL    _DD_MAKEMASK1(4)
#define M_RXCTRL_RX_PAUSE_EN     _DD_MAKEMASK1(5)
#define M_RXCTRL_RX_PASS_CTRL    _DD_MAKEMASK1(6)
#define M_RXCTRL_ANY_START       _DD_MAKEMASK1(7)


/* MMU Register S-Channel Addresses */

#define R_MMUPORTENABLE          0x00D8001E


/* Table S-Channel Base Addresses */

#define M_L2_TABLE               0x01E00000
#define M_L2_HIT_BITS            0x01E10000
#define M_L2_STATIC_BITS         0x01E20000
#define M_L2_VALID_BITS          0x01E30000
#define M_L2MC_TABLE             0x01E40000
#define M_L2_ENTRY               0x01E50000

#define M_PORT                   0x02E00000
#define M_EGRESS_MASK            0x02E10000
#define M_PORT_TRUNK_EGRESS      0x02E20000
#define M_PORT_MAC_BLOCK         0x02E30000

#define M_VLAN                   0x03E00000
#define M_VLAN_STG               0x03E10000

#define M_TRUNK_GROUP            0x04E00000
#define M_TRUNK_BITMAP           0x04E10000


/* SGMII/SerDes PHY Registers (16 bits) */

#define R_MII_CONTROL            0x00
#define R_MII_STATUS             0x01
#define R_AN_ADV                 0x04
#define R_AN_LP_ABILITY          0x05
#define R_AN_EXPANSION           0x06
#define R_SGMII_CONTROL          0x0B
#define R_SGMII_STATUS           0x0C
#define R_SGMII_MISC             0x0E
#define R_SGMII_CONTROL_2        0x0F
#define R_SERDES_TX_CONTROL      0x10
#define R_SERDES_RX_CONTROL      0x11
#define R_SERDES_PHASE_CONTROL   0x12
#define R_MISC_CONTROL           0x14
#define R_MISC_STATUS            0x15
#define R_SERDES_PLL_CONTROL     0x16
#define R_SERDES_MUX_CONTROL     0x17
#define R_SERDES_PRBS_CONTROL    0x18
#define R_SERDES_PRBS_STATUS     0x19
#define R_SERDES_BERT_IPG        0x1A
#define R_SERDES_BERT_CONTROL    0x1B
#define R_SERDES_BERT_OVFL       0x1C
#define R_SERDES_BERT_MDIO_CTRL  0x1D
#define R_SERDES_BERT_MDIO_DATA  0x1E


/* SGMII: SGMII Control Register (0x0B) */

#define M_SGMII_TBI_LOOPBACK     _DD_MAKEMASK1(0)
#define M_SGMII_REMOTE_LPBK      _DD_MAKEMASK1(1)
#define M_SGMII_SG_AN_ENABLE     _DD_MAKEMASK1(2)
#define M_SGMII_AN_TEST_MODE     _DD_MAKEMASK1(3)
#define M_SGMII_CDET_EN          _DD_MAKEMASK1(4)
#define M_SGMII_SHORT_LATENCY_EN _DD_MAKEMASK1(5)
#define M_SGMII_EXT_CTRL         _DD_MAKEMASK1(6)
#define M_SGMII_REV_PHASE        _DD_MAKEMASK1(7)
#define M_SGMII_ERR_TIMER_EN     _DD_MAKEMASK1(8)
#define M_SGMII_AN_SEL           _DD_MAKEMASK1(10)

#define S_SGMII_PAUSE            11
#define M_SGMII_PAUSE            _DD_MAKEMASK(2,S_SGMII_PAUSE)
#define V_SGMII_PAUSE(x)         _DD_MAKEVALUE(x,S_SGMII_PAUSE)
#define G_SGMII_PAUSE(x)         _DD_GETVALUE(x,S_SGMII_PAUSE,M_SGMII_PAUSE)

#define S_SGMII_REMOTE_FAULT     13
#define M_SGMII_REMOTE_FAULT     _DD_MAKEMASK(2,S_SGMII_REMOTE_FAULT)
#define V_SGMII_REMOTE_FAULT(x)  _DD_MAKEVALUE(x,S_SGMII_REMOTE_FAULT)
#define G_SGMII_REMOTE_FAULT(x)  _DD_GETVALUE(x,S_SGMII_REMOTE_FAULT,M_SGMII_REMOTE_FAULT)

#define M_SGMII_FORCE_DATA_MODE  _DD_MAKEMASK1(15)


/* SGMII_MISC: SGMII Misc Register (0x0E) */

#define M_SGMII_RESTART_AN       _DD_MAKEMASK1(0)


/* SGMII2: SGMII Control Register 2 (0x0F) */

#define M_SGMII2_FIBER_MODE      _DD_MAKEMASK1(0)
#define M_SGMII2_EN10B           _DD_MAKEMASK1(1)


/* MISC: Misc Control Register (0x14) */

#define M_MISC_LINK_STATUS       _DD_MAKEMASK1(0)
#define M_MISC_MAC_MODE          _DD_MAKEMASK1(1)
#define M_MISC_SGMII_ENABLE      _DD_MAKEMASK1(2)
#define M_MISC_SIGNAL_DETECT     _DD_MAKEMASK1(3)
#define M_MISC_SGMII_STATUS_CLR  _DD_MAKEMASK1(4)
#define M_MISC_IDDQ_MODE         _DD_MAKEMASK1(5)


/* HiGig (XGXS) PHY Registers (16 bits) */

/* Registers accessible in all blocks */
#define R_XGXS_IEEE_CONTROL       0x00
#define R_XGXS_IEEE_STAT          0x01
#define R_XGXS_PHY_ID_LO          0x02
#define R_XGXS_PHY_ID_HI          0x03
#define R_XGXS_BLKNO              0x1F

/* Registers accessible in block 0 */

#define R_XGXS_CTRL               0x10
#define R_XGXS_STAT               0x11
#define R_XGXS_XGMII_IDLE         0x12
#define R_XGXS_XGMII_SYNC         0x13
#define R_XGXS_XGMII_SKIP         0x14
#define R_XGXS_XGMII_SOPEOP       0x15
#define R_XGXS_XGMII_ALIGN        0x16
#define R_XGXS_XGMII_SWAP         0x19
#define R_XGXS_LSS_LSS_ID         0x1A
#define R_XGXS_LSS_TXINFO         0x1B
#define R_XGXS_LSS_WINDOW         0x1D


/* Counter Register Indices (Section 15) (36 or 42 bits)
   Note that the 569x counter base adds 0x20 to generate the address. */

#define I_MIB_ITPKT              0x0009
#define I_MIB_ITXPF              0x000A
#define I_MIB_ITFCS              0x000B
#define I_MIB_ITMCA              0x000C
#define I_MIB_ITBCA              0x000D
#define I_MIB_ITFRG              0x000E
#define I_MIB_ITOVR              0x000F
#define I_MIB_ITUFL              0x0010
#define I_MIB_ITERR              0x0011
#define I_MIB_ITBYT              0x0012

#define I_MIB_ITR64              0x0016
#define I_MIB_ITR127             0x0017
#define I_MIB_ITR255             0x0018
#define I_MIB_ITR511             0x0019
#define I_MIB_ITR1023            0x001A
#define I_MIB_ITR1522            0x001B
#define I_MIB_IRMAX              0x001C
#define I_MIB_IRPKT              0x001D
#define I_MIB_IRFCS              0x001E
#define I_MIB_IRMCA              0x001F
#define I_MIB_IRBCA              0x0020
#define I_MIB_IRXCF              0x0021
#define I_MIB_IRXPF              0x0022
#define I_MIB_IRXUO              0x0023
#define I_MIB_IRJBR              0x0024
#define I_MIB_IROVR              0x0025
#define I_MIB_IRFLR              0x0026
#define I_MIB_IRBYT              0x0027
#define I_MIB_IRUND              0x0028
#define I_MIB_IRFRG              0x0029
#define I_MIB_IRERBYT            0x002A
#define I_MIB_IRERPKT            0x002B
#define I_MIB_IRJUNK             0x002C

/* 569x only */
#define I_MIB_ITAGE              0x002D
#define I_MIB_ITIP               0x002E
#define I_MIB_ITIPD              0x002F
#define I_MIB_ITABRT             0x0030
#define I_MIB_IRDISC             0x0031
#define I_MIB_ISDISC             0x0032
#define I_MIB_IPDISC             0x0033
#define I_MIB_IIMBP              0x0034
#define I_MIB_IIMRP              0x0035
#define I_MIB_IRUC               0x0036
#define I_MIB_IHOLD              0x0037

#define I_MIB_TX_FIRST           I_MIB_ITPKT
#define I_MIB_TX_LAST            I_MIB_ITBYT
#define I_MIB_RX_FIRST           I_MIB_ITR64
#define I_MIB_RX_LAST            I_MIB_IRJUNK

#endif /* _BCM5690_H_ */
