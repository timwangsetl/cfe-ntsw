
/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  RoboSwitch SPI driver            File: dev_robo_spi.c
    *  
    *  This is a simple driver for accessing RoboSwitch registers
    *  using the Motorola SPI serial protocol.  
    *  
    *********************************************************************  
    *
    *  Copyright 2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"

#include "cfe_spi.h"

#undef _ROBOSPI_DEBUG_

#ifndef CFG_ROBO_FAST_SPI
#ifdef BCM53000
/* Since the Keystone's SPI is very fast, use the Normal Read without Fast Read mode */
#define CFG_ROBO_FAST_SPI 0
#else
#define CFG_ROBO_FAST_SPI 1
#endif
#endif

/*  *********************************************************************
    *  Robo definitions
    ********************************************************************* */

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))

/* Global Robo registers */
#define R_ROBOSPI_SPI_DATA      0xf0
#define R_ROBOSPI_SPI_STATUS    0xfe
#define R_ROBOSPI_PAGE          0xff

/* Robo SPI Status registers */
#define M_SPISTAT_TXRDY         _DD_MAKEMASK1(0)
#define M_SPISTAT_RXRDY         _DD_MAKEMASK1(1)
#define M_SPISTAT_MDIO_START    _DD_MAKEMASK1(2)
#define M_SPISTAT_RACK          _DD_MAKEMASK1(5)
#define M_SPISTAT_WCOL          _DD_MAKEMASK1(6)
#define M_SPISTAT_SPIF          _DD_MAKEMASK1(7)

/* Robo Fast SPI read response */
#define M_SPISTAT_FAST_RACK     _DD_MAKEMASK1(0)

#define POLL_DELAY()            cfe_usleep(10)

/* Convenience macro for writing a single byte */
#define SPI_WRITE8(c,b) do { uint8_t _d8 = b; SPI_WRITE(c,&_d8,1); } while (0)

/*  *********************************************************************
    *  Forward declarations
    ********************************************************************* */
#if defined(EBBUS_BIT16) || defined(EBBUS_BIT8)
#define CFG_EB_BUS_SUPPORT      1
#else
#define CFG_EB_BUS_SUPPORT      0
#endif

#if CFG_EB_BUS_SUPPORT
void
robo_read_EB(void *base, uint8_t addr, uint8_t * buf, uint8_t len);
void
robo_write_EB(void *base, uint8_t addr, uint8_t *buf, uint8_t len);
void
robo_read_EB16(void *base, uint8_t addr, uint8_t * buf, uint8_t len);
void
robo_write_EB16(void *base, uint8_t addr, uint8_t *buf, uint8_t len);
#endif /* CFG_EB_BUS_SUPPORT */

static void robo_probe(cfe_driver_t * drv,
      unsigned long probe_a, unsigned long probe_b, void *probe_ptr);
static int robo_open(cfe_devctx_t * ctx);
static int robo_read(cfe_devctx_t * ctx, iocb_buffer_t * buffer);
static int robo_write(cfe_devctx_t * ctx, iocb_buffer_t * buffer);
static int robo_ioctl(cfe_devctx_t * ctx, iocb_buffer_t * buffer);
static int robo_close(cfe_devctx_t * ctx);


/*  *********************************************************************
    *  Device Dispatch
    ********************************************************************* */

static cfe_devdisp_t robo_dispatch = {
    robo_open,
    robo_read,
    NULL,
    robo_write,
    robo_ioctl,
    robo_close,
    NULL,
    NULL
};

const cfe_driver_t spi_robo = {
    "Robo Management",
    "robo",
    CFE_DEV_OTHER,
    &robo_dispatch,
    robo_probe
};

typedef struct robo_s {
    cfe_spi_channel_t *spi_channel;
    int cur_page;
    int fast_spi;
    void *ebbase;
    uint8_t  bustype;
} robo_spi_t;

#if CFG_EB_BUS_SUPPORT

#define READCSR(x)    \
  (*(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BASE+(x)))
#define WRITECSR(x,v) \
  (*(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BASE+(x)) = (v))

#endif /* CFG_EB_BUS_SUPPORT */

/*  *********************************************************************
    *  Robo SPI Protocol
    *  
    ********************************************************************* */

static int
robo_system_reset(robo_spi_t * softc)
{
    cfe_spi_channel_t *chan = softc->spi_channel;

    /*
     * Use special slave 0xfe to control board system reset.
     * For systems with 8051 uC this loads strap pin setting
     * from 8051 to switch.
     */
    SPI_DISABLE(chan, 0xfe);
    cfe_usleep(10);
    SPI_ENABLE(chan, 0xfe);
    cfe_usleep(10);
    SPI_DISABLE(chan, 0xfe);
    cfe_usleep(10);

    return 0;
}

static int
robo_spi_slow_freq_enable(robo_spi_t * softc, int slow)
{
    cfe_spi_channel_t *chan = softc->spi_channel;

    /* Use special slave 0xff to control SPI frequency */
    if (slow) {
        SPI_ENABLE(chan, 0xff);
    } else {
        SPI_DISABLE(chan, 0xff);
    }

    return 0;
}

static int
robo_read_reg(robo_spi_t * softc, int cid,int reg, uint8_t * buf, int len)
{
    cfe_spi_channel_t *chan = softc->spi_channel;

    SPI_ENABLE(chan, 0);

    SPI_WRITE8(chan, 0x60|((cid&0x7)<<1));
    SPI_WRITE8(chan, reg);
    SPI_READ(chan, buf, len, 0);

    SPI_DISABLE(chan, 0);

    return 0;
}

static int
robo_write_reg(robo_spi_t * softc, int cid, int reg, uint8_t * buf, int len)
{
    cfe_spi_channel_t *chan = softc->spi_channel;

    SPI_ENABLE(chan, 0);

    SPI_WRITE8(chan, 0x61|((cid&0x7)<<1));
    SPI_WRITE8(chan, reg);
    SPI_WRITE(chan, buf, len);

    SPI_DISABLE(chan, 0);

    return 0;
}

#if CFG_ROBO_FAST_SPI
static int
robo_fast_rack_poll(robo_spi_t * softc)
{
    cfe_spi_channel_t *chan = softc->spi_channel;
    uint8_t status;
    int timeout = 10;

    while(timeout-- > 0) {

        SPI_READ(chan, &status, 1, 0);

        if (status & M_SPISTAT_FAST_RACK) {
            return 0;
        }

        POLL_DELAY();
    }
#ifdef _ROBOSPI_DEBUG_
    printf("SPI: fast RACK poll FAILED status=0x%02X cid %d\n", status,cid);
#endif

    return -1;
}
#endif

static int
robo_status_poll(robo_spi_t * softc, int cid,uint8_t mask, uint8_t val)
{
    uint8_t status;
    int timeout = 1000;

    while(timeout-- > 0) {

        robo_read_reg(softc, cid, R_ROBOSPI_SPI_STATUS, &status, 1);

        if ((status & mask) == val) {
            return 0;
        }

        POLL_DELAY();
    }
#ifdef _ROBOSPI_DEBUG_
    printf("SPI: poll status FAILED status=0x%02X cid %d\n", status,cid);
#endif

    return -1;
}

static int
robo_select_page(robo_spi_t * softc, int cid,int page)
{
    uint8_t data;

    if (softc->cur_page == page) {
        return 0;
    }
    softc->cur_page = page;

    data = page;
    robo_write_reg(softc, cid, R_ROBOSPI_PAGE, &data, 1);

    return 0;
}

static int
robo_reset(robo_spi_t * softc, int cid)
{
    /* Force page change */
    softc->cur_page = -1;
    robo_select_page(softc, cid, 0);
    softc->cur_page = -1;

    return 0;
}

#if CFG_EB_BUS_SUPPORT
void
robo_read_EB(void *base, uint8_t addr, uint8_t * buf, uint8_t len)
{
    volatile uint8_t *ptr;
    uint8_t   i;

#if ENDIAN_BIG
    ptr = (uint8_t *)((uint32_t)base + (addr^0x3));
#else
    ptr = (uint8_t*)((uint32_t)base +addr);    
#endif

    for(i=0;i<len;i++){
        buf[i] =  *ptr;
        ptr = (volatile uint8_t *)((uint32_t)ptr+1);
    }

}
void
robo_write_EB(void *base, uint8_t addr, uint8_t *buf, uint8_t len)
{
    volatile uint8_t *ptr;
    uint8_t i;
#if ENDIAN_BIG
    ptr = (volatile uint8_t *)((uint32_t)base + (addr^0x3));
#else
    ptr = (volatile uint8_t*)((uint32_t)base +addr);    
#endif

    for(i=0;i<len;i++){
       *ptr = buf[i];
        ptr = (volatile uint8_t *)((uint32_t)ptr+1);
    }
}

void
robo_read_EB16(void *base, uint8_t addr, uint8_t * buf, uint8_t len)
{
    volatile uint16_t *ptr;
    uint8_t   i;
    uint16_t  temp=0;
#if ENDIAN_BIG
    ptr = (uint16_t *)((uint32_t)base + (addr^0x2));
#else
    ptr = (uint16_t *)((uint32_t)base +addr);    
#endif

    for(i=0;i<len;i++){
        if(i%2==0){
#if ENDIAN_BIG
            ptr = (uint16_t *)((uint32_t)base + ((addr+i)^0x2));
#else
            ptr = (uint16_t *)((uint32_t)base + (addr+i));
#endif
            temp = *ptr;
            buf[i]= (uint8_t)(temp&0x00ff);
        }else{
             buf[i]= (uint8_t)((temp&0xff00)>>8);        
        }
    }


}
void
robo_write_EB16(void *base, uint8_t addr, uint8_t *buf, uint8_t len)
{
    volatile uint16_t *ptr;
    uint8_t i;
    uint16_t temp=0;
#if ENDIAN_BIG
    ptr = (volatile uint16_t *)((uint32_t)base + (addr^0x2));
#else
    ptr = (volatile uint16_t *)((uint32_t)base +addr);    
#endif

    for(i=0;i<len;i++){        
        if(i%2==0){
#if ENDIAN_BIG
            ptr = (uint16_t *)((uint32_t)base + ((addr+i)^0x2));
#else
            ptr = (uint16_t *)((uint32_t)base + (addr+i));
#endif
            temp = (uint16_t)buf[i]; 
        }else{
            temp |= (uint16_t)(buf[i] << 8);
         }

        if(( i%2) || (i == len-1)){
            *ptr = temp;
        }
    }
}
#endif /* CFG_EB_BUS_SUPPORT */



/*  *********************************************************************
    *  robo_probe(drv,probe_a,probe_b,probe_ptr)
    *  
    *  Our probe routine.  Attach a SPI device to the firmware.
    *  
    *  Input parameters: 
    *      drv - driver structure
    *      probe_a - SPI channel
    *      probe_b - slave id (currently not used)
    *      probe_ptr - not used
    *      
    *  Return value:
    *      nothing
    ********************************************************************* */

static void
robo_probe(cfe_driver_t * drv,
      unsigned long probe_a, unsigned long probe_b, void *probe_ptr)
{
    robo_spi_t *softc;
    char descr[80];

    softc = (robo_spi_t *) KMALLOC(sizeof(robo_spi_t), 0);

    if (!softc)
        return;

    /* 
     * Probe_a is the SPI channel number
     * Probe_b is unused
     * Probe_ptr is unused.
     */

    softc->spi_channel = SPI_CHANNEL((int)probe_a);
    softc->cur_page = -1;

#if CFG_EB_BUS_SUPPORT

#if defined(EBBUS_BIT16)
    WRITECSR(0x100,0x11);
#elif defined(EBBUS_BIT8)
    WRITECSR(0x100,0x1);
#endif
    WRITECSR(0x104,0x1f1f1f3f);
    /* default use ebbus*/ 
    softc->bustype = 1;
    softc->ebbase = (void*)PHYS_TO_K1(SB_EXTIF_SPACE);

#else /* !CFG_EB_BUS_SUPPORT */

    /* Use SPI bus by default if EB bus not supported */
    softc->bustype = 0;

#endif /* CFG_EB_BUS_SUPPORT */

    xsprintf(descr, "%s on SPI channel %d",
          drv->drv_description, (int)probe_a);
    cfe_attach(drv, softc, NULL, descr);
}

/*  *********************************************************************
    *  robo_open(ctx)
    *  
    *  Open this device. 
    *  
    *  Input parameters: 
    *      ctx - device context (can obtain our softc here)
    *      
    *  Return value:
    *      0 if ok
    *      else error code
    ********************************************************************* */

static int
robo_open(cfe_devctx_t * ctx)
{
    robo_spi_t *softc = ctx->dev_softc;

    if (softc->spi_channel) {
#if CFG_EB_BUS_SUPPORT
        /* Check if EB Bus is ok */
        if (softc->bustype != 0) {
            iocb_buffer_t iocb_buffer;
            uint16_t  temp;
            iocb_buffer.buf_offset = 0x1004;
            iocb_buffer.buf_ptr = PTR2HSADDR(&temp);
            iocb_buffer.buf_length = sizeof(uint16_t);
            robo_read(ctx, &iocb_buffer);    
            if(temp==0xffff || temp==0) {
                /* If failing to access EB bus, try SPI */
                softc->bustype = 0;
            }
        }
#endif /* CFG_EB_BUS_SUPPORT */
        return 0;
    } else {
        return -1;
    }
}

/*  *********************************************************************
    *  robo_read(ctx,buffer)
    *  
    *  Read bytes from the device.
    *  
    *  Input parameters: 
    *      ctx - device context (can obtain our softc here)
    *      buffer - buffer descriptor (target buffer, length, offset)
    *      
    *  Return value:
    *      number of bytes read
    *      -1 if an error occured
    ********************************************************************* */

static int
robo_read(cfe_devctx_t * ctx, iocb_buffer_t * buffer)
{
    robo_spi_t *softc = ctx->dev_softc;
#if CFG_ROBO_FAST_SPI
    cfe_spi_channel_t *chan = softc->spi_channel;
#endif
    unsigned char *bptr;
    int blen;
    int page;
    int reg;
    int cid;

    bptr = HSADDR2PTR(buffer->buf_ptr);
    blen = buffer->buf_length;

    cid = (buffer->buf_offset>>16) & 0xFF;
    page = (buffer->buf_offset >> 8) & 0xFF;
    reg = (buffer->buf_offset) & 0xFF;

#ifdef _ROBOSPI_DEBUG_
    xprintf("robo_read: cid %x page=0x%02X reg=0x%02X bustype(1:EB, 0:SPI) %x\n",
            cid, page, reg, softc->bustype);
#endif

    if (blen > 8) {
        return -1;
    }

    if (!softc->bustype) {
        if (robo_status_poll(softc, cid, M_SPISTAT_SPIF, 0) < 0) {
            /* Timeout */
            robo_reset(softc, cid);
            return -1;
        }

        robo_select_page(softc, cid, page);

#if CFG_ROBO_FAST_SPI

        SPI_ENABLE(chan, 0);

        SPI_WRITE8(chan, 0x10|((cid&0x7)<<1));
        SPI_WRITE8(chan, reg);

        if (robo_fast_rack_poll(softc) < 0) {
            /* Timeout */
            SPI_DISABLE(chan, 0);
            robo_reset(softc,cid);
            return -3;
        }

        /* Read registers */
        SPI_READ(chan, bptr, blen, 0);

        SPI_DISABLE(chan, 0);

#else

        /* Discard first read */
        robo_read_reg(softc, cid, reg, bptr, 1);

        if (robo_status_poll(softc, cid, M_SPISTAT_RACK, M_SPISTAT_RACK) < 0) {
            /* Timeout */
            robo_reset(softc,cid);
            return -2;
        }

        /* Read registers from dataport */
        robo_read_reg(softc, cid, R_ROBOSPI_SPI_DATA, bptr, blen);

#endif       
    } else {
#ifdef EBBUS_BIT8
        uint8_t temp,length,i, cmd;
        uint16_t  time_out;
        uint8_t tbuf[8];  
        /* Page /Offse*/
        robo_write_EB(softc->ebbase,0x8,(uint8_t *)&page,1);
        robo_write_EB(softc->ebbase,0x9,(uint8_t *)&reg,1);

        /* READ */
        cmd = 1;
        robo_write_EB(softc->ebbase,0xA,&cmd,1);

        time_out = 0;
        temp = 1;
        while (temp){
            time_out ++;
            robo_read_EB(softc->ebbase,0xB,&temp,1);
            if (time_out  > 200){
                printf("read op time out %x %x\n",page,reg);                    
                cmd = 0;
                robo_write_EB(softc->ebbase,0xA,&cmd,1);
                return -1;
            }
        }

        robo_read_EB(softc->ebbase,0xc,&length,1);

        if (length != (0x1 << (blen-1))){
            for(i=0;i<blen;i++){            
                *bptr = 0;
                bptr ++;
            }
            return -1;
        }
        for(i=0;i<blen;i++){
            robo_read_EB(softc->ebbase,i,(uint8_t *)&tbuf[i],1);
        }
        memcpy(bptr, tbuf, blen);
#elif defined(EBBUS_BIT16)
        /* READ EB bus 16-bit*/
        /*  PAGE & OFFSET */
        uint8_t temp,length,i, cmd;
        uint16_t  time_out;
        uint8_t  temp16[2];

        temp16[0] = page;
        temp16[1] = reg;
        robo_write_EB16(softc->ebbase,0x8,(uint8_t *)&temp16,2);

        /* READ */
        cmd = 0x1;
        robo_write_EB(softc->ebbase,0xA,&cmd,1);
        time_out = 0;
        temp = 1;
        while (temp){
            time_out ++;
            robo_read_EB(softc->ebbase,0xB,&temp,1);
            if (time_out > 200){
                cmd = 0x0;
                robo_write_EB(softc->ebbase,0xA,&cmd,1);

                return -1;
            }
        }

        robo_read_EB16(softc->ebbase,0xc,&length,1);
        
        if (length != (0x1 << (blen-1))){
            for(i=0;i<blen;i++){            
                *bptr = 0;
                bptr ++;
            }
            return -1;
        }
        robo_read_EB16(softc->ebbase,0,bptr,blen);
#endif
    }

    return 0;
}

/*  *********************************************************************
    *  robo_write(ctx,buffer)
    *  
    *  Write bytes from the device.
    *  
    *  Input parameters: 
    *      ctx - device context (can obtain our softc here)
    *      buffer - buffer descriptor (target buffer, length, offset)
    *      
    *  Return value:
    *      number of bytes read
    *      -1 if an error occured
    ********************************************************************* */

static int
robo_write(cfe_devctx_t * ctx, iocb_buffer_t * buffer)
{
    robo_spi_t *softc = ctx->dev_softc;
    unsigned char *bptr;
    int blen;
    int page;
    int reg;
    int cid;

    bptr = HSADDR2PTR(buffer->buf_ptr);
    blen = buffer->buf_length;

    cid = (buffer->buf_offset>>16) & 0xFF;
    page = (buffer->buf_offset >> 8) & 0xFF;
    reg = (buffer->buf_offset) & 0xFF;
#ifdef _ROBOSPI_DEBUG_
    printf("robo_write: cid %x page=0x%02X reg=0x%02X\n", cid, page, reg);
#endif

    if (blen > 8) {
        return -1;
    }

    if (!softc->bustype){
        if (robo_status_poll(softc, cid, M_SPISTAT_SPIF, 0) < 0) {
            /* Timeout */
            robo_reset(softc, cid);
            return -1;
        }
    
        robo_select_page(softc, cid, page);
    
        robo_write_reg(softc, cid, reg, bptr, blen);
    } else {        
#ifdef EBBUS_BIT8
        uint8_t temp, cmd;
        uint32_t  time_out;
        uint8_t i;
        /* Page /Offse*/
       robo_write_EB(softc->ebbase,0x8,(uint8_t *)&page,1);

       robo_write_EB(softc->ebbase,0x9,(uint8_t *)&reg,1);

       for(i=0;i<blen;i++){
            robo_write_EB(softc->ebbase, i, bptr,1);		
            bptr ++;
        }
        /* WRITE */
        cmd = 0x2;
        robo_write_EB(softc->ebbase, 0xA, &cmd,1);
        temp = 1;
        time_out = 0;

        while(temp){
            time_out ++;
            robo_read_EB(softc->ebbase, 0xB, &temp, 1);

            if(time_out  > 200){
                printf(
                    "write op time out reg %x %x\n",page,reg); 
                cmd = 0x0;
                robo_write_EB(softc->ebbase,0xA,&cmd,1);
                break;
            }
        }
#elif defined(EBBUS_BIT16)
        /*  PAGE & OFFSET */
        uint8_t temp, cmd;
        uint32_t  time_out;
        uint8_t  temp16[2];
        temp16[0] = page;
        temp16[1] = reg;

        robo_write_EB16(softc->ebbase,0x8,(uint8_t *)&temp16,2);
        robo_write_EB16(softc->ebbase,0x8,(uint8_t *)&temp16,2);

        /* DATA */
        robo_write_EB16(softc->ebbase, 0, bptr,blen);		

        /* Write */
        cmd = 0x2;
        robo_write_EB(softc->ebbase,0xA,&cmd,1);
        time_out = 0;
        temp = 1;
    
        while(temp){
            time_out ++;
            robo_read_EB(softc->ebbase,0xB,&temp,1);
            if(time_out > 200){
                printf(
                    "write op time out reg %x %x\n",page,reg);
                cmd = 0x0;
                robo_write_EB(softc->ebbase,0xA,&cmd,1);
                break;
            }
        }
#endif
    }
    return 0;
}

/*  *********************************************************************
    *  robo_ioctl(ctx,buffer)
    *  
    *  Perform miscellaneous I/O control operations on the device.
    *  
    *  Input parameters: 
    *      ctx - device context (can obtain our softc here)
    *      buffer - buffer descriptor (target buffer, length, offset)
    *      
    *  Return value:
    *      number of bytes read
    *      -1 if an error occured
    ********************************************************************* */

static int
robo_ioctl(cfe_devctx_t * ctx, iocb_buffer_t * buffer)
{
    robo_spi_t *softc = ctx->dev_softc;
    int slow;

    switch ((int)buffer->buf_ioctlcmd) {
    case 0:
        /* Perform board system reset */
        robo_system_reset(softc);
        return 0;

    case 1:
        /* Enable/disable slow SPI frequency */
        hs_memcpy_from_hs(&slow,buffer->buf_ptr,sizeof(int));
        robo_spi_slow_freq_enable(softc, slow);
        return 0;

    default:
        break;
    }
    return -1;
}

/*  *********************************************************************
    *  robo_close(ctx,buffer)
    *  
    *  Close the device.
    *  
    *  Input parameters: 
    *      ctx - device context (can obtain our softc here)
    *      
    *  Return value:
    *      0 if ok
    *      -1 if an error occured
    ********************************************************************* */

static int
robo_close(cfe_devctx_t * ctx)
{
    return 0;
}
