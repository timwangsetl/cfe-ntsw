/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM43xx Internal UART driver			File:dev_sio43xx.c
    *  
    *  Author:   James F Dougherty
    *            Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"

#include "lib_physio.h"


/* Memory base address of COM1 / Console */
#define UART_BASE  0xb8000300

/* Serial input clock */
#define UART_CLOCK 2000000

/* Base baudrate */
#define BASE_BAUD  9600

/* Divisor latch hi/lo */
#define DIV_LO     ((UART_CLOCK/16)/BASE_BAUD)
#define DIV_HI     (DIV_LO>>8)	

/* 16550-like register definitions */

#define UART_THR        0x00	/* Transmitter holding reg. */
#define UART_RDR        0x00	/* Receiver data reg.       */
#define UART_BRDL       0x00	/* Baud rate divisor (LSB)  */
#define UART_BRDH       0x01	/* Baud rate divisor (MSB)  */
#define UART_IER        0x01	/* Interrupt enable reg.    */
#define UART_IID        0x02	/* Interrupt ID reg.        */
#define UART_LCR        0x03	/* Line control reg.        */
#define UART_MDC        0x04	/* Modem control reg.       */
#define UART_LST        0x05	/* Line status reg.         */
#define UART_MSR        0x06	/* Modem status reg.        */

/* Accessors */
#define UART_REG(reg) 	(UART_BASE + reg)

/* #define UART_REG (reg)          (softc->uart_base + (reg)) */



static unsigned char pio_uart_inb(int addr);
static void pio_uart_outb(int addr, unsigned char c);
static void pio_uart_delay(void);

static unsigned char
pio_uart_inb(int addr)
{
    return *(unsigned char *) addr;
}

static void
pio_uart_outb(int addr, unsigned char c)
{
    *(unsigned char *) addr = c;
}


static void
pio_uart_putc(int c)
{
    int i = 10000;
    while (!(pio_uart_inb(UART_REG(UART_LST)) & 0x40) && i--)
        ;
    pio_uart_outb(UART_REG(UART_THR), c);
}

static int
pio_uart_getc(void)
{
    while (!(pio_uart_inb(UART_REG(UART_LST)) & 0x01))
        ;
    return pio_uart_inb(UART_REG(UART_RDR));
}

static void
pio_uart_delay(void)
{
    volatile int i;
    for (i = 0; i < 0x10000; i++)
	;
}

#define WRITECSR(p,v)  pio_uart_outb((p),(v))
#define READCSR(p)     pio_uart_inb((p))


static int sio43xx_uart_open(cfe_devctx_t *ctx);
static int sio43xx_uart_read(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int sio43xx_uart_inpstat(cfe_devctx_t *ctx,iocb_inpstat_t *inpstat);
static int sio43xx_uart_write(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int sio43xx_uart_ioctl(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int sio43xx_uart_close(cfe_devctx_t *ctx);

void sio43xx_uart_probe(cfe_driver_t *drv,
			unsigned long probe_a, unsigned long probe_b, 
			void *probe_ptr);


const cfe_devdisp_t sio43xx_uart_dispatch = {
    sio43xx_uart_open,
    sio43xx_uart_read,
    sio43xx_uart_inpstat,
    sio43xx_uart_write,
    sio43xx_uart_ioctl,
    sio43xx_uart_close,	
    NULL,
    NULL
};

const cfe_driver_t sio43xx_uart = {
    "43XX Internal UART",
    "uart",
    CFE_DEV_SERIAL,
    &sio43xx_uart_dispatch,
    sio43xx_uart_probe
};

typedef struct sio43xx_uart_s {
    physaddr_t uart_base;
    int uart_flowcontrol;
    int uart_speed;
} sio43xx_uart_t;


extern void pio_uart_puts(char*);
void pio_uart_puthex(unsigned int value, int cr);

/* 
 * SIO43XX-compatible UART.
 * probe_a: physical address of UART
 */

void sio43xx_uart_probe(cfe_driver_t *drv,
			unsigned long probe_a, unsigned long probe_b, 
			void *probe_ptr)
{
    sio43xx_uart_t *softc;
    char descr[80];
    softc = (sio43xx_uart_t *) KMALLOC(sizeof(sio43xx_uart_t),0);
    if (softc) {
	softc->uart_base = probe_a;
	softc->uart_speed = CFG_SERIAL_BAUD_RATE;
	softc->uart_flowcontrol = SERIAL_FLOW_NONE;
	xsprintf(descr, "%s at 0x%X", drv->drv_description, (uint32_t)probe_a);
	cfe_attach(drv, softc, NULL, descr);
    }
}


static void
sio43xx_uart_setflow(sio43xx_uart_t *softc)
{
    /* noop for now */
}



static int
sio43xx_uart_open(cfe_devctx_t *ctx)
{
    sio43xx_uart_t *softc = ctx->dev_softc;

    pio_uart_outb(UART_REG(UART_LCR),  0x83); /* 0x80 */
    pio_uart_outb(UART_REG(UART_BRDL), DIV_LO);
    pio_uart_outb(UART_REG(UART_BRDH), DIV_HI);
    pio_uart_outb(UART_REG(UART_LCR),  0x03);
    pio_uart_outb(UART_REG(UART_MDC), 0xb);

    sio43xx_uart_setflow(softc);

    return 0;
}

static int
sio43xx_uart_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    unsigned char *bptr;
    int blen;

    bptr = buffer->buf_ptr;
    blen = buffer->buf_length;

    while (blen > 0){
	*bptr++ = pio_uart_getc();
	blen--;
    }

    buffer->buf_retlen = buffer->buf_length - blen;
    return 0;
}

static int
sio43xx_uart_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    sio43xx_uart_t *softc = ctx->dev_softc;

    inpstat->inp_status = (pio_uart_inb(softc->uart_base + UART_LST) & 0x01) ? 1 : 0;

    return 0;
}

static int
sio43xx_uart_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    unsigned char *bptr;
    int blen;

    bptr = buffer->buf_ptr;
    blen = buffer->buf_length;
    while (blen > 0) {
	pio_uart_putc(*bptr++);
	blen--;
    }

    buffer->buf_retlen = buffer->buf_length - blen;
    pio_uart_delay();	/* Allow last char to flush */
    return 0;
}

static int
sio43xx_uart_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    sio43xx_uart_t *softc = ctx->dev_softc;

    unsigned int *info = (unsigned int *) buffer->buf_ptr;

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_SERIAL_GETSPEED:
	    *info = softc->uart_speed;
	    break;
	case IOCTL_SERIAL_SETSPEED:
	    softc->uart_speed = *info;
	    /* NYI */
	    break;
	case IOCTL_SERIAL_GETFLOW:
	    *info = softc->uart_flowcontrol;
	    break;
	case IOCTL_SERIAL_SETFLOW:
	    softc->uart_flowcontrol = *info;
	    sio43xx_uart_setflow(softc);
	    break;
	default:
	    return -1;
	}

    return 0;
}

static int sio43xx_uart_close(cfe_devctx_t *ctx)
{
    sio43xx_uart_t *softc = ctx->dev_softc;
    pio_uart_outb(softc->uart_base + UART_MDC, 0);

    return 0;
}


