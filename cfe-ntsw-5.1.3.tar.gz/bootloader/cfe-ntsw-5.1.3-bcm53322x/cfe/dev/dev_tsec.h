/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  MPC8548 TSEC register definitions            File: dev_tsec.h
    *  
    *  Register and bit definitions for the mpc8548 TSEC controller
    *  
    *  Author:  Sanjay Gupta
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef __TSEC_H
#define __TSEC_H

#include "mpc854x.h"

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))

#define CFG_TSEC1_OFFSET	(0x24000)

#define TSEC_REG_SPACE_SICE	0x01000

#define TSEC_BASE_ADDR	(CCSRBAR + CFG_TSEC1_OFFSET)

#define MAC_ADDR_LEN 6

/* Default Attribute fields */
#define ATTR_INIT_SETTINGS     0x000000c0
#define ATTRELI_INIT_SETTINGS  0x00000000

/* TxBD status field bits */
#define TXBD_READY		_DD_MAKEMASK1(15)
#define TXBD_PADCRC		_DD_MAKEMASK1(14)
#define TXBD_WRAP		_DD_MAKEMASK1(13)
#define TXBD_INTERRUPT		_DD_MAKEMASK1(12)
#define TXBD_LAST		_DD_MAKEMASK1(11)
#define TXBD_CRC		_DD_MAKEMASK1(10)
#define TXBD_DEF		_DD_MAKEMASK1(9)
#define TXBD_RETRYLIMIT		_DD_MAKEMASK1(6)
#define TXBD_ERROR_MASK         _DD_MAKEMASK(10, 0)

/* RxBD status field bits */
#define RXBD_EMPTY		_DD_MAKEMASK1(15)
#define RXBD_RO1		_DD_MAKEMASK1(14)
#define RXBD_WRAP		_DD_MAKEMASK1(13)
#define RXBD_INTERRUPT		_DD_MAKEMASK1(12)
#define RXBD_LAST		_DD_MAKEMASK1(11)
#define RXBD_FIRST		_DD_MAKEMASK1(10)
#define RXBD_MISS		_DD_MAKEMASK1(8)
#define RXBD_BROADCAST		_DD_MAKEMASK1(7)
#define RXBD_MULTICAST		_DD_MAKEMASK1(6)
#define RXBD_LARGE		_DD_MAKEMASK1(5)
#define RXBD_NONOCTET		_DD_MAKEMASK1(4)
#define RXBD_SHORT		_DD_MAKEMASK1(3)
#define RXBD_CRCERR		_DD_MAKEMASK1(2)
#define RXBD_OVERRUN		_DD_MAKEMASK1(1)
#define RXBD_TRUNCATED		_DD_MAKEMASK1(0)
#define RXBD_ERROR_MASK		_DD_MAKEMASK(6, 0)

typedef struct txbd8
{
    uint16_t       status;         /* Status Fields */
    uint16_t       length;         /* Buffer length */
    uint32_t       bufPtr;         /* Buffer Pointer */
} tsec_txbd_t;

#define TSEC_TX_BD_SIZE             8

typedef struct rxbd8
{
    uint16_t       status;         /* Status Fields */
    uint16_t       length;         /* Buffer Length */
    uint32_t       bufPtr;         /* Buffer Pointer */
} tsec_rxbd_t;

#define TSEC_RX_BD_SIZE             8

/* Interrupt Event */
#define R_TSEC_IEVENT_OFFSET    (0x00000010)

#define V_IEVENT_INIT_CLEAR	0xffffffff
#define V_IEVENT_BABR		_DD_MAKEMASK1(31)
#define V_IEVENT_RXC		_DD_MAKEMASK1(30)
#define V_IEVENT_BSY		_DD_MAKEMASK1(29)
#define V_IEVENT_EBERR		_DD_MAKEMASK1(28)
#define V_IEVENT_MSRO		_DD_MAKEMASK1(26)
#define V_IEVENT_GTSC		_DD_MAKEMASK1(25)
#define V_IEVENT_BABT		_DD_MAKEMASK1(24)
#define V_IEVENT_TXC		_DD_MAKEMASK1(23)
#define V_IEVENT_TXE		_DD_MAKEMASK1(22)
#define V_IEVENT_TXB		_DD_MAKEMASK1(21)
#define V_IEVENT_TXF		_DD_MAKEMASK1(20)
#define V_IEVENT_IE		_DD_MAKEMASK1(19)
#define V_IEVENT_LC		_DD_MAKEMASK1(18)
#define V_IEVENT_CRL		_DD_MAKEMASK1(17)
#define V_IEVENT_XFUN		_DD_MAKEMASK1(16)
#define V_IEVENT_RXB0		_DD_MAKEMASK1(15)
#define V_IEVENT_GRSC		_DD_MAKEMASK1(8)
#define V_IEVENT_RXF0		_DD_MAKEMASK1(7)


/* Interrupt Mask */
#define R_TSEC_IMASK_OFFSET    (0x00000014)

#define V_IMASK_INIT_CLEAR	0x00000000
#define V_IMASK_TXEEN		_DD_MAKEMASK1(22)
#define V_IMASK_TXBEN		_DD_MAKEMASK1(21)
#define V_IMASK_TXFEN           _DD_MAKEMASK1(20)
#define V_IMASK_RXFEN0		_DD_MAKEMASK1(7)

/* Error Disabled */
#define R_TSEC_EDIS_OFFSET    (0x00000018)

/* Ethernet Control */
#define R_TSEC_ECNTRL_OFFSET    (0x00000020)

#define V_ECNTRL_STATS_EN       _DD_MAKEMASK1(12)
#define V_ECNTRL_GMII_MODE      _DD_MAKEMASK1(6)
#define V_ECNTRL_TBI_MODE       _DD_MAKEMASK1(5)
#define V_ECNTRL_RPM		_DD_MAKEMASK1(4)
#define V_ECNTRL_R100		_DD_MAKEMASK1(3)

#define V_ECNTRL_INIT_SETTINGS    (V_ECNTRL_STATS_EN)


/* Minimum Frame Length */
#define R_TSEC_MINFLR_OFFSET    (0x00000024)

/* Pause Time Value */
#define R_TSEC_PTV_OFFSET    (0x00000028)

/* DMA Control */
#define R_TSEC_DMACTRL_OFFSET    (0x0000002c)

#define V_DMACTRL_GRS             _DD_MAKEMASK1(4)
#define V_DMACTRL_GTS             _DD_MAKEMASK1(3)
#define V_DMACTRL_TDSEN           _DD_MAKEMASK1(7)
#define V_DMACTRL_TBDSEN          _DD_MAKEMASK1(6)

#define V_DMACTRL_INIT_SETTINGS   (V_DMACTRL_TDSEN | V_DMACTRL_TBDSEN | 0x3)

/* TBI PHY Address */
#define R_TSEC_TBIPA_OFFSET    (0x00000030)

/* Transmit Control */
#define R_TSEC_TCTRL_OFFSET    (0x00000100)

/* Transmit Status */
#define R_TSEC_TSTAT_OFFSET    (0x00000104)

#define V_TSTAT_CLEAR_THALT       _DD_MAKEMASK1(31)

/* Tx BD Data Length */
#define R_TSEC_TBDLEN_OFFSET    (0x0000010c)

/* Current TxBD Pointer */
#define R_TSEC_CTBPTR_OFFSET    (0x00000124)

/* TxBD Pointer */
#define R_TSEC_TBPTR_OFFSET    (0x00000184)

/* TxBD Base Address */
#define R_TSEC_TBASE_OFFSET    (0x00000204)

/* Out of Sequence TxBD */
#define R_TSEC_OSTBD_OFFSET    (0x000002b0)

/* Out of Sequence Tx Data Buffer Pointer */
#define R_TSEC_OSTBDP_OFFSET    (0x000002b4)

/* Receive Control */
#define R_TSEC_RCTRL_OFFSET    (0x00000300)

/* Receive Status */
#define R_TSEC_RSTAT_OFFSET    (0x00000304)

#define V_RSTAT_CLEAR_RHALT       _DD_MAKEMASK1(23)

/* RxBD Data Length */
#define R_TSEC_RBDLEN_OFFSET    (0x0000030c)

/* Current Receive Buffer Pointer */
#define R_TSEC_CRBPTR_OFFSET    (0x00000324)

/* Maximum Receive Buffer Length */
#define R_TSEC_MRBLR_OFFSET    (0x00000340)

/* RxBD Pointer */
#define R_TSEC_RBPTR_OFFSET    (0x00000384)

/* RxBD Base Address */
#define R_TSEC_RBASE_OFFSET    (0x00000404)

/* MAC Configuration #1 */
#define R_TSEC_MACCFG1_OFFSET    (0x00000500)

#define V_MACCFG1_SOFT_RESET	_DD_MAKEMASK1(31)
#define V_MACCFG1_RESET_RX_MC	_DD_MAKEMASK1(19)
#define V_MACCFG1_RESET_TX_MC	_DD_MAKEMASK1(18)
#define V_MACCFG1_RESET_RX_FUN	_DD_MAKEMASK1(17)
#define V_MACCFG1_RESET_TX_FUN	_DD_MAKEMASK1(16)
#define V_MACCFG1_LOOPBACK	_DD_MAKEMASK1(8)
#define V_MACCFG1_RX_FLOW	_DD_MAKEMASK1(5)
#define V_MACCFG1_TX_FLOW	_DD_MAKEMASK1(4)
#define V_MACCFG1_SYNCD_RX_EN	_DD_MAKEMASK1(3)
#define V_MACCFG1_RX_EN		_DD_MAKEMASK1(2)
#define V_MACCFG1_SYNCD_TX_EN	_DD_MAKEMASK1(1)
#define V_MACCFG1_TX_EN		_DD_MAKEMASK1(0)

/* MAC Configuration #2 */
#define R_TSEC_MACCFG2_OFFSET    (0x00000504)

/* MAC register bits */
#define M_MACCFG2_FULL_DUPLEX	  _DD_MAKEMASK1(0)
#define M_MACCFG2_ADD_CRC         _DD_MAKEMASK1(1)
#define M_MACCFG2_PAD_CRC         _DD_MAKEMASK1(2)
#define M_MACCFG2_IF              _DD_MAKEMASK(2,8)
#define V_MACCFG2_GMII		  _DD_MAKEVALUE(2, 8)
#define V_MACCFG2_MII             _DD_MAKEVALUE(1, 8)
#define V_MACCFG2_PREAMBLE_LEN    _DD_MAKEVALUE(7, 12)

#define V_MACCFG2_INIT_SETTINGS	(V_MACCFG2_PREAMBLE_LEN | \
                                 M_MACCFG2_FULL_DUPLEX  | \
                                 M_MACCFG2_PAD_CRC)

/* Inter Packet Gap/Inter Frame Gap */
#define R_TSEC_IPGIFG_OFFSET    (0x00000508)

/* Half-duplex */
#define R_TSEC_HAFDUP_OFFSET    (0x0000050c)

/* Maximum Frame */
#define R_TSEC_MAXFRM_OFFSET    (0x00000510)

/* MII Management: Configuration */
#define R_TSEC_MIIMCFG_OFFSET    (0x00000520)

#define V_MIIMCFG_INIT_VALUE	0x00000003
#define V_MIIMCFG_RESET		_DD_MAKEMASK1(31)

#define V_MIIM_READ_COMMAND     _DD_MAKEVALUE(1, 0)

#define V_MRBLR_INIT_SETTINGS	1536

#define V_MINFLR_INIT_SETTINGS	0x00000040

/* MII Management: Command */
#define R_TSEC_MIIMCOM_OFFSET    (0x00000524)

/* MII Management: Address */
#define R_TSEC_MIIMADD_OFFSET    (0x00000528)

/* MII Management: Control */
#define R_TSEC_MIIMCON_OFFSET    (0x0000052c)

/* MII Management: Status */
#define R_TSEC_MIIMSTAT_OFFSET    (0x00000530)

/* MII Management: Indicators */
#define R_TSEC_MIIMIND_OFFSET    (0x00000534)

#define V_MIIMIND_BUSY            _DD_MAKEMASK1(0)
#define V_MIIMIND_NOTVALID        _DD_MAKEMASK1(2)

/* Interface Status */
#define R_TSEC_IFSTAT_OFFSET    (0x0000053c)

/* Station Address, part 1 */
#define R_TSEC_MACSTNADDR1_OFFSET    (0x00000540)

/* Station Address, part 2 */
#define R_TSEC_MACSTNADDR2_OFFSET    (0x00000544)

#define R_TSEC_HASH_IADDR0_OFFSET     (0x00000800)
#define R_TSEC_HASH_IADDR1_OFFSET     (0x00000804)
#define R_TSEC_HASH_IADDR2_OFFSET     (0x00000808)
#define R_TSEC_HASH_IADDR3_OFFSET     (0x0000080c)
#define R_TSEC_HASH_IADDR4_OFFSET     (0x00000810)
#define R_TSEC_HASH_IADDR5_OFFSET     (0x00000814)
#define R_TSEC_HASH_IADDR6_OFFSET     (0x00000818)
#define R_TSEC_HASH_IADDR7_OFFSET     (0x0000081c)

/* Default Attribute Register */
#define R_TSEC_ATTR_OFFSET    (0x00000bf8)

/* Default Attribute Extract Length and Index */
#define R_TSEC_ATTRELI_OFFSET    (0x00000bfc)

#define R_TSEC_HASH_GADDR0_OFFSET     (0x00000880)
#define R_TSEC_HASH_GADDR1_OFFSET     (0x00000884)
#define R_TSEC_HASH_GADDR2_OFFSET     (0x00000888)
#define R_TSEC_HASH_GADDR3_OFFSET     (0x0000088c)
#define R_TSEC_HASH_GADDR4_OFFSET     (0x00000890)
#define R_TSEC_HASH_GADDR5_OFFSET     (0x00000894)
#define R_TSEC_HASH_GADDR6_OFFSET     (0x00000898)
#define R_TSEC_HASH_GADDR7_OFFSET     (0x0000089c)

#define TSEC_GIGABIT (1)

#define TSEC_IF_MODE_MII        1
#define TSEC_IF_MODE_RMII       2
#define TSEC_IF_MODE_GMII       3
#define TSEC_IF_MODE_RGMII       4
#define TSEC_IF_MODE_TBI        5

#define TSEC_FLAGS(i,p) (((i) << 8) | ((p)))

#define TSEC_IF_TYPE(f)     (((f) >> 8) & 0xff)
#define TSEC_PHY_ADDR(f)    ((f) & 0xff)

#define TSEC_IF_GE_CAP(i)   \
        (((i) == TSEC_IF_MODE_GMII) ||  \
         ((i) == TSEC_IF_MODE_RGMII) || \
         ((i) == TSEC_IF_MODE_TBI))

#endif /* __TSEC_H */
