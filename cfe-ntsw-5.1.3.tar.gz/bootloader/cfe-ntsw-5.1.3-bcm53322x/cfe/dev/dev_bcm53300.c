/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM53300 StrataXGS Ethernet Switch	     File: dev_bcm53300.c
    *  
    *  Author: 
    *
    *********************************************************************  
    *
    *  Copyright 2005
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

/* Register and field definitions for the Broadcom BCM53300.

   Support is primarily for the CPU interface (CMIC) and its
   associated DMA.

   Reference:

       StrataXGS BCM56300 Programmer's Reference
          Guide
       Document 
*/

#include "cfe.h"
#include "bcmnvram.h"

#include "lib_physio.h"
#ifdef CPUCFG_MEMCPY
extern void *CPUCFG_MEMCPY(void *dest, const void *src, size_t cnt);
#define blockcopy(d, s, l) CPUCFG_MEMCPY((void*)a, (void*)b, l)
#else
#define blockcopy(d, s, l) memcpy((void*)d, (void*)s, l)
#endif

#include "cfe_irq.h"

#include "net_enet.h"

#include "pcivar.h"
#include "pcireg.h"

#include "bcm53300.h"
#include "mii.h"
#include "factory_config.h"

#define XGS_DEBUG 0

#if ((ENDIAN_BIG + ENDIAN_LITTLE) != 1)
#error "dev_bcm53300: system endian not set"
#endif

#if CPUCFG_COHERENT_DMA
# define sync_range(base,len)  ((void)0)
# define inval_range(base,len) ((void)0)
#else   /* XXX need more-generic names */
  extern void bcmcore_sync_range(volatile void *base, int len);
  extern void bcmcore_inval_range(volatile void *base, int len);
# define sync_range(base,len) bcmcore_sync_range(base,len)
# define inval_range(base,len) bcmcore_inval_range(base,len)
#endif

/* Temporary, until configs supply MATCH_BYTES */
#if defined(_MOUSSE_)  /* any machine without preserve-bits for PIO */
#define MATCH_BYTES  1
#else
#define MATCH_BYTES  0
#endif

/* Set IPOLL to drive processing through the pseudo-interrupt
   dispatcher.  Set XPOLL to drive processing by an external polling
   agent.  One must be set; setting both is ok. */

#ifndef IPOLL
#define IPOLL 0
#endif
#ifndef XPOLL
#define XPOLL 1
#endif

#define MIN_ETHER_PACK  (ENET_MIN_PKT+ENET_CRC_SIZE)   /* size of min packet */
#define MAX_ETHER_PACK  (ENET_MAX_PKT+ENET_CRC_SIZE)   /* size of max packet */
#define VLAN_TAG_LEN    4                              /* VLAN type plus tag */
#define VLAN_TYPE       0x8100
#define VLAN_DEFAULT    1
#define STG_DEFAULT    1
#define MAX_VLAN_PACK   (MAX_ETHER_PACK+VLAN_TAG_LEN)

#define BLOCK_BP                    20     /* it is for XGS3 */

/* define MACRO for multi-chips on platform */
#define MAX_UNIT_NUM            2
#define TX_UNIT_NUM             0

/* define phy address */
#define PHY_ADDR    0xda

/* Packet buffers.  For the XGS CMIC, packet buffer alignment is
   arbitrary and can be to any byte boundary.  We would like it
   aligned to a cache line boundary for performance, although there is
   a trade-off with IP/TCP header alignment, and to facilitate cache
   flushing on hosts requiring that.  */
#define ETH_PKTBUF_LEN      (((MAX_VLAN_PACK+31)/32)*32)

#if __long64
typedef struct eth_pkt_s {
    queue_t next;			/* 16 */
    uint8_t *buffer;			/*  8 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;
#else
typedef struct eth_pkt_s {
    queue_t next;			/*  8 */
    uint8_t *buffer;			/*  4 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint32_t unused[3];			/* 12 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;
#endif

#define CACHE_ALIGN       32
#define ETH_PKTBUF_LINES  ((sizeof(eth_pkt_t) + (CACHE_ALIGN-1))/CACHE_ALIGN)
#define ETH_PKTBUF_SIZE   (ETH_PKTBUF_LINES*CACHE_ALIGN)
#define ETH_PKTBUF_OFFSET (offsetof(eth_pkt_t, data))

#define ETH_PKT_BASE(data) ((eth_pkt_t *)((data) - ETH_PKTBUF_OFFSET))

/* BCM53300 Hardware Common Data Structures */
/* DMA Control Block as a struct.  See DCBn_ definitions for word n. */
typedef struct dcb_s {
    uint32_t mem_addr;                /* buffer or chain address */
    uint32_t w1;
    uint32_t w2;
    uint32_t w3;
    uint32_t w4;
    uint32_t w5;
    uint32_t w6;
    uint32_t w7;
    uint32_t w8;
    uint32_t w9;
    uint32_t pading[2];
} dcb_t;

typedef enum {
    eth_state_uninit,
    eth_state_off,
    eth_state_on, 
} eth_state_t;

typedef struct phy_info_s {
    uint8_t  addr;                /* external PHY */
    uint8_t  linkspeed;
} phy_info_t;

typedef struct bcm53300_state_s {

    /* PCI access information */
    uint32_t  regbase;
    uint8_t   irq;
    pcitag_t  tag;		   /* tag for configuration registers */

    uint8_t   hwaddr[ENET_ADDR_LEN];
    uint16_t  device;              /* chip device code */
    uint8_t   revision;            /* chip revision */
    uint16_t  asic_revision;       /* mask revision */
    int       higig;

    eth_state_t state;             /* current state */
    uint32_t intmask;              /* interrupt mask */

    /* packet free lists */
    queue_t freelist;
    uint8_t *pktpool;
    queue_t rxqueue;

    /* rings */
    dcb_t *dcbs[4];
    int txbusy;

    cfe_devctx_t *devctx;

    /* ports */
    unsigned int module;           /* local mod_id */
    unsigned int portmap;          /* map of connected ports */
    phy_info_t   phy_info[GPIC_PORTS];

    /* additional driver statistics */
    uint32_t inpkts;
    uint32_t outpkts;
    uint32_t interrupts;
    uint32_t rx_interrupts;
    uint32_t tx_interrupts;
} bcm53300_state_t;

#define TX_CH                    0
#define RX_CH1                   1
#define RX_CH2                   2
#define RX_CH3                   3

/* Address mapping macros */
#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((uint8_t *)KERNADDR(a))
#define PCI_TO_PTR(a)  (PHYS_TO_PTR(PCI_TO_PHYS(a)))
#define PTR_TO_PCI(x)  (PHYS_TO_PCI(PTR_TO_PHYS(x)))


/* Address mapping macros */
#if (ENDIAN_BIG && MATCH_BYTES)
#define CSR_MATCH_MODE       PCI_MATCH_BYTES
#define READCSR(sc,csr)      (phys_read32_swapped((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32_swapped((sc)->regbase + (csr), (val)))
#else
#define CSR_MATCH_MODE       PCI_MATCH_BITS
#define READCSR(sc,csr)      (phys_read32((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->regbase + (csr), (val)))
#endif


/* Entry to and exit from critical sections (currently relative to
   interrupts only, not SMP) */

#if CFG_INTERRUPTS
#define CS_ENTER(sc) cfe_disable_irq(sc->irq)
#define CS_EXIT(sc)  cfe_enable_irq(sc->irq)
#else
#define CS_ENTER(sc) ((void)0)
#define CS_EXIT(sc)  ((void)0)
#endif

static bcm53300_state_t *sc_temp[MAX_UNIT_NUM];
static int unit_num=0;
/* Utilities */
#if XGS_DEBUG
static void
show_packet(char c, eth_pkt_t *pkt)
{
    int i;
    int n = (pkt->length < 128 ? pkt->length : 128);

    for (i = 0; i < n; i++) {
        if (i % 32 == 0) {
            if (i == 0)
                xprintf("%c[%4d]:", c, pkt->length);
            else
                xprintf("\n        ");
            }
        if (i % 4 == 0)
            xprintf(" ");
        xprintf("%02x", pkt->buffer[i]);
    }
    xprintf("\n");
}
#endif

static const char *
xgs_devname(bcm53300_state_t *sc)
{
    return (sc->devctx != NULL ? cfe_device_name(sc->devctx) : "eth?");
}

/* MII/PHY management */
static int
mii_poll(bcm53300_state_t *sc)
{
    int timeout;
    uint32_t status;

    cfe_usleep(10);
    for (timeout = 1000; timeout > 0; timeout -= 100) {
        status = READCSR(sc, R_CMIC_SCHAN_CTRL);
        if ((status & M_SCTL_MIIM_OP_DONE) != 0)
            break;
        cfe_usleep(100);
    }

    return (timeout > 0 ? 0 : -1);
}

static uint16_t
mii_read(bcm53300_state_t *sc, int phy_addr, int reg)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = V_MIIMP_PHY_ID(phy_addr);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
    WRITECSR(sc, R_CMIC_MII_ADDRESS, reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_1);
#if 0 /* FIXME */
    cfe_sleep(1);   /* XXX 1250 needs this, 4702 doesn't.  Why? */
#endif

    if (mii_poll(sc) < 0)
        return 0xFFFF;

    return G_MIIMRD_DATA(READCSR(sc, R_CMIC_MIIM_READ_DATA));
}

static void
mii_write(bcm53300_state_t *sc, int phy_addr, int reg, uint16_t value)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = V_MIIMP_PHY_ID(phy_addr) | V_MIIMP_PHY_DATA(value);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
    WRITECSR(sc, R_CMIC_MII_ADDRESS, reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_1);
#if 0 /* FIXME */
    cfe_sleep(1);   /* XXX 1250 needs this, 4702 doesn't.  Why? */
#endif

    mii_poll(sc);
}

static int
mii_status(bcm53300_state_t *sc, int phy_addr)
{
    uint16_t  status, remote, xremote;
    int linkspeed;

    linkspeed = ETHER_SPEED_UNKNOWN;

    /* Read twice to clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);
    status = mii_read(sc, phy_addr, MII_BMSR);

#if 0
    if ((status & (BMSR_AUTONEG | BMSR_LINKSTAT))
	!= (BMSR_AUTONEG | BMSR_LINKSTAT)) {
	int  timeout;

	for (timeout = CFE_HZ/4; timeout > 0; timeout -= CFE_HZ/8) {
	    status = mii_read(sc, phy_addr, MII_BMSR);
	    if ((status & BMSR_ANCOMPLETE) != 0)
		break;
	    cfe_sleep(CFE_HZ/8);
	    }
	}
#endif

    remote = mii_read(sc, phy_addr, MII_ANLPAR);
    
    if ((status & BMSR_ANCOMPLETE) != 0) {
        /* A link partner was negogiated... */

        if (status & BMSR_1000BT_XSR)
            xremote = mii_read(sc, phy_addr, MII_K1STSR);
        else
            xremote = 0;

        if ((xremote & K1STSR_LP1KFD) != 0) {
#if XGS_DEBUG
            xprintf("1000BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_1000FDX;
        }
        else if ((xremote & K1STSR_LP1KHD) != 0) {
#if XGS_DEBUG
            xprintf("1000BaseT HDX\n");
#endif
            linkspeed = ETHER_SPEED_1000HDX;
        }
        else if ((remote & ANLPAR_TXFD) != 0) {
#if XGS_DEBUG
            xprintf("100BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_100FDX;	 
        }
        else if ((remote & ANLPAR_TXHD) != 0) {
#if XGS_DEBUG
            xprintf("100BaseT HDX\n");
#endif
            linkspeed = ETHER_SPEED_100HDX;	 
        }
        else if ((remote & ANLPAR_10FD) != 0) {
#if XGS_DEBUG
            xprintf("10BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_10FDX;	 
        }
        else if ((remote & ANLPAR_10HD) != 0) {
#if XGS_DEBUG
            xprintf("10BaseT HDX\n");
#endif            
            linkspeed = ETHER_SPEED_10HDX;	 
        }
    }
    else {
        /* no link partner convergence */
#if XGS_DEBUG
        xprintf("NC\n");
#endif        
        linkspeed = ETHER_SPEED_UNKNOWN;
        remote = xremote = 0;
    }

    /* clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);

    return linkspeed;
}

static uint16_t
mii_read_internal(bcm53300_state_t *sc, int phy_addr, int reg)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = M_MIIMP_INTERNAL_SEL | V_MIIMP_PHY_ID(phy_addr);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
    WRITECSR(sc, R_CMIC_MII_ADDRESS, reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_1);
    //cfe_sleep(1);

    if (mii_poll(sc) < 0)
        return 0xFFFF;

    return G_MIIMRD_DATA(READCSR(sc, R_CMIC_MIIM_READ_DATA));
}

static void
mii_write_internal(bcm53300_state_t *sc, int phy_addr, int reg, uint16_t value)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = M_MIIMP_INTERNAL_SEL
        | V_MIIMP_PHY_ID(phy_addr) 
        | V_MIIMP_PHY_DATA(value);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);
    WRITECSR(sc, R_CMIC_MII_ADDRESS, reg);


    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_1);
    //cfe_sleep(1);

    mii_poll(sc);
}

static unsigned int
phy_scan(bcm53300_state_t *sc)
{
    unsigned int port;
    unsigned int portmap;
    uint8_t phy_addr;
    uint16_t id1, id2;
    int linkspeed;

    portmap = 0;

    for (port = 0; port < GPIC_PORTS; port++) {
        /* The addresses of external PHYs depend on pin strapping.  The
        following mapping is the conventional one (used on eval
        boards); the PHYs are programmed 1-12, in port order. */
        sc->phy_info[port].addr = phy_addr = port+1;

        id1 = mii_read(sc, phy_addr, MII_PHYIDR1);
        id2 = mii_read(sc, phy_addr, MII_PHYIDR2);
        if ((id1 != 0x0000 && id1 != 0xFFFF) ||
                (id2 != 0x0000 && id2 != 0xFFFF)) {
            if (id1 != id2) {
#if XGS_DEBUG
                {
                    uint32_t phy_vendor;
                    uint16_t phy_device;
                    xprintf("port %2d", port);
                    phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
                    phy_device = (id2 >> 4) & 0x3F;
                    xprintf(" (phy vendor %06X part %02X)",
                    phy_vendor, phy_device);
                    xprintf(": ");
                }
#endif
                linkspeed = mii_status(sc, phy_addr);
                sc->phy_info[port].linkspeed = linkspeed;
                if (linkspeed != ETHER_SPEED_UNKNOWN)
                    portmap |= GPIC_BIT(port);
            }
        }
    }
    return portmap;
}

/* S-Bus Access Routines */

#define R_CMIC_SCHAN_D(word)    (R_CMIC_SCHAN_MESSAGES+4*(word))

static uint32_t
schan_read_reg(bcm53300_state_t *sc, unsigned int reg)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    /* DEST_BLOCK is for XGS3 */
    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_REG_CMD)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
        | V_SMHDR_DEST_BLOCK((reg >> BLOCK_BP) & 0xf)
        | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
        cfe_usleep(100);
        ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);

        if (ctrl & M_SCTL_MSG_DONE)
            break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    return READCSR(sc, R_CMIC_SCHAN_D(1));
}

static void
schan_write_reg(bcm53300_state_t *sc, unsigned int reg, uint32_t value)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_REG_CMD)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
        | V_SMHDR_DEST_BLOCK((reg >> BLOCK_BP) & 0xf)
        | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), value);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
    cfe_usleep(100);
    ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
    if (ctrl & M_SCTL_MSG_DONE)
        break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


static void
schan_read_mem(bcm53300_state_t *sc, unsigned int addr,
	       uint32_t *dest, int count)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_MEM_CMD)
        | V_SMHDR_DEST_BLOCK((addr >> BLOCK_BP) & 0xf)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
        cfe_usleep(100);
        ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
        if (ctrl & M_SCTL_MSG_DONE)
            break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    for (i = 0; i < count; i++)
        dest[i] = READCSR(sc, R_CMIC_SCHAN_D(1+i));
}

static void
schan_write_mem(bcm53300_state_t *sc, unsigned int addr,
		uint32_t *src, int count)
{
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_MEM_CMD)
        | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
        | V_SMHDR_DEST_BLOCK((addr >> BLOCK_BP) & 0xf)
        | V_SMHDR_DATA_LEN(4*count));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);
    for (i = 0; i < count; i++)
        WRITECSR(sc, R_CMIC_SCHAN_D(2+i), src[i]);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
        V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
        cfe_usleep(100);
        ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
        if (ctrl & M_SCTL_MSG_DONE)
            break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


/* Switch management */

static void
arl_init(bcm53300_state_t *sc)
{
}

#define FB_NUM_COS 8

static void
mmu_init(bcm53300_state_t *sc, uint32_t portmap)
{
    int         cos, port;

    /* set CFAP */
    schan_write_reg(sc, R_CFAPCONFIG, 0x3fff);
   /*  schan_write_reg(sc, R_CFAPREADPINTER, 0x41); */
    schan_write_reg(sc, R_CFAPFULLTHRESHOLD, 0xf803f70);

    /* set HOL threshold */
    for (port = 0 ; port < GPIC_PORTS ; port++) {
        for (cos = 0 ; cos < FB_NUM_COS ; cos++) {
            schan_write_reg(sc, R_HOLCOSPKTSETLIMIT(port)+cos, 0xa00);
        }
    }

    /* set hol threshold for higig port */
    if (sc->higig) {        
        for (cos = 0 ; cos < FB_NUM_COS ; cos++) {
            schan_write_reg(sc, R_HOLCOSPKTSETLIMIT(IPIC_PORT)+cos, 0xa00);
        }
    }

    /* set hol threshold for CPU */
    for (cos = 0 ; cos < FB_NUM_COS ; cos++) {
        schan_write_reg(sc, R_HOLCOSPKTSETLIMIT(CMIC_PORT)+cos, 0x900);
    }

    /* set aging timer */
    schan_write_reg(sc, R_PKTAGINGTIMER, 0x0);

    /* set MMU port enable */
    schan_write_reg(sc, R_MMUPORTENABLE, portmap);
}

static int
soc_firebolt_pipe_mem_clear(bcm53300_state_t *sc)
{
    uint32_t              rval;
    int              rv = TRUE;
    int                 pipe_init_usec = 50000; /* timeout = 50 ms */
    /* soc_timeout_t       to; */

    /*
     * Reset the IPIPE and EPIPE block
     */
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_1, 0x0);
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_2, 0x34000);
    schan_write_reg(sc, R_EGR_HW_RESET_CONTROL_0, 0x0);
    schan_write_reg(sc, R_EGR_HW_RESET_CONTROL_1, 0x32000);
    
    /* FIXME : mark by kevinwu. Add this line, otherwise ING_HW_RESET timeout */
    cfe_usleep(pipe_init_usec);

    rval = schan_read_reg(sc, R_ING_HW_RESET_CONTROL_2);
    if(!(rval & 0x40000)) {
            printf("ING_HW_RESET timeout\n");
            rv = FALSE;
    }        

    rval = schan_read_reg(sc, R_EGR_HW_RESET_CONTROL_1);
    if(!(rval & 0x40000)) {
            printf("EGR_HW_RESET timeout\n");
            rv = FALSE;
    }        

    rval = 0;
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_1, 0x0);
    schan_write_reg(sc, R_ING_HW_RESET_CONTROL_2, 0x0);

    return rv;
}

static void
soc_firebolt_cam_sam_config(bcm53300_state_t *sc)
{
    /* L2_USER_ENTRY_CAM_CONTROL */
    schan_write_reg(sc, 0x6780001, 0x6);

    /* L3_TUNNEL_CAM_CONTROL */
    schan_write_reg(sc, 0x2880018, 0x6);

    /* VLAN_SUBNET_CAM_CONTROL */
    schan_write_reg(sc, 0x4780000, 0xc);

    /* L3_DEFIP_CAM_CONTROL0 */
    schan_write_reg(sc, 0x8780000, 0x1b6db);

    /* FP_CAM_CONTROL_LOWER */
    schan_write_reg(sc, 0xc78000b, 0x6db6db);

    /* FP_CAM_CONTROL_UPPER */
    schan_write_reg(sc, 0xc78000a, 0x6db6db);

    return;
}

static void
misc_init(bcm53300_state_t *sc, uint32_t portmap)
{
    int port;


    /* Only on FB */
    soc_firebolt_cam_sam_config(sc);

    /* Only on FB */
    /* Clear IPIPE/EIPIE Memories */
    if(!soc_firebolt_pipe_mem_clear(sc)) {
        printf("misc_init : soc_firebolt_pipe_mem_clear failed\n");
    }

    /* Enable MMU parity error interrupt */
    schan_write_reg(sc, R_MEMFAILINTSTATUS, 0x0);    
    schan_write_reg(sc, R_MEMFAILINTMASK, 0x3ff);
    schan_write_reg(sc, R_MISCCONFIG, 0x1000);

    /*
     * Egress Enable
     */
    for (port = 0; port < GPIC_PORTS; port++) {
         schan_write_reg(sc, R_GEGR_ENABLE(port), 0x1);
    }

    /*
     * Egress Enable for higig port
     */
    if (sc->higig) {
        schan_write_reg(sc, R_GEGR_ENABLE(IPIC_PORT), 0x1);
    }

    /*
     * Egress Enable for CPU port
     */
    schan_write_reg(sc, R_GEGR_ENABLE(CMIC_PORT), 0x1);
    
    /*
     * ING_CONFIG
     */
    schan_write_reg(sc, R_ING_CONFIG, 0xe);
}

/* Initialize auxiliary forwarding tables.  */
static void
table_init(bcm53300_state_t *sc, uint32_t portmap)
{
    static uint32_t port0[3] = {0x1c00000, 0x10200000, 0x0};
    static uint32_t port1[3] = {0x1c00000, 0x10200080, 0x0};
    static uint32_t higig_port0[3] = {0x1c00000, 0x10200010, 0x0};
    static uint32_t higig_port1[3] = {0x1c00000, 0x10200090, 0x0};
    static uint32_t empty3[3] = {0x00000000, 0x00000000, 0x00000000};
    static uint32_t empty2[2] = {0x00000000, 0x00000000};
    static uint32_t empty1[1] = {0x00000000};
    static uint32_t vlan0[2] = {0x9fffffff, 0x101};
    static uint32_t egr_vlan0[3] = {0xf0ffffff, 0x3ffffff, 0x2};
    static uint32_t vlan1[2] = {0x8fffffff, 0x101};
    static uint32_t egr_vlan1[3] = {0xf0ffffff, 0x2ffffff, 0x2};
    static uint32_t stg[2] = {0xffffffff, 0xffffff};
    static uint32_t modport_map = 0x4;
    int i;

    /* l2 table */
    for (i = 0; i < 8192; i++) {
	schan_write_mem(sc, M_L2_ENTRY + i, empty3, 3);
    }

    /* vlan table */
    for (i = 0; i < M_VLAN_SIZE; i++) {
        schan_write_mem(sc, M_VLAN + i, empty2, 2);
    }

    /* egr vlan table */
    for (i = 0; i < M_VLAN_SIZE; i++) {
        schan_write_mem(sc, M_EGR_VLAN + i, empty3, 3);
    }


    if(sc->module == 0) {
        /* port table */
        for (i = 0; i < GPIC_PORTS; i++) {
        	schan_write_mem(sc, M_PORT + i, port0, 3);
        }

        if (sc->higig) {
            /* port table for higig port */
            schan_write_mem(sc, M_PORT + IPIC_PORT, higig_port0, 3);
        }

        /* port table for cpu port */
        schan_write_mem(sc, M_PORT + CMIC_PORT, port0, 3);

        /* modport_map table for cpu port */
        schan_write_mem(sc, M_MODPORT_MAP + 1, &modport_map, 1);

        /* vlan table */
        schan_write_mem(sc, M_VLAN + VLAN_DEFAULT, vlan0, 2);

         /* egr vlan table */
        schan_write_mem(sc, M_EGR_VLAN + VLAN_DEFAULT, egr_vlan0, 3);        
    } else if(sc->module == 1) {
        /* port table */
        for (i = 0; i < GPIC_PORTS; i++) {
        	schan_write_mem(sc, M_PORT + i, port1, 3);
        }

        if (sc->higig) {
            /* port table for higig port */
            schan_write_mem(sc, M_PORT + IPIC_PORT, higig_port1, 3);
        }

        /* modport_map table for cpu port */
        schan_write_mem(sc, M_MODPORT_MAP + 0, &modport_map, 1);

        /* vlan table */
        schan_write_mem(sc, M_VLAN + VLAN_DEFAULT, vlan1, 2);

        /* egr vlan table */
        schan_write_mem(sc, M_EGR_VLAN + VLAN_DEFAULT, egr_vlan1, 3);
    }

    /* egress mask table */
    for (i = 0; i < M_EGRESS_MASK_SIZE; i++) {
	schan_write_mem(sc, M_EGRESS_MASK + i, empty1, 1);
    }

    /* stg table */
    /* Force forwarding state for spanning tree. */
    for (i = 0; i < M_STG_SIZE; i++) {
	schan_write_mem(sc, M_VLAN_STG + i, empty2, 2);
	schan_write_mem(sc, M_EGR_VLAN_STG + i, empty2, 2);
    }
    schan_write_mem(sc, M_VLAN_STG + STG_DEFAULT, stg, 2);
    schan_write_mem(sc, M_EGR_VLAN_STG + STG_DEFAULT, stg, 2);

    /* port mac block table */
    for (i = 0; i < M_MAC_BLOCK_SIZE; i++) {
	schan_write_mem(sc, M_PORT_MAC_BLOCK + i, empty1, 1);
    }

    cfe_sleep(CFE_HZ/5);
}


static void
l2_enter(bcm53300_state_t *sc, uint8_t mac_addr[], unsigned int port)
{
    uint32_t l2_entry[3];
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;
  
    l2_entry[0] = ((mac_addr[5] <<  0) |
        (mac_addr[4] <<  8) |
        (mac_addr[3] << 16) |
        (mac_addr[2] << 24));
    l2_entry[1] = ((mac_addr[1] <<  0) | (1 << 31) | (7<<28) |
        (mac_addr[0] <<  8) |
        (VLAN_DEFAULT << 16));
    l2_entry[2] = ((1 << 25) | (1 << 22) |
        (TX_UNIT_NUM << 9) |
        (port << 3));
    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_L2_INS_CMD) | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC) 
        | V_SMHDR_DATA_LEN(0xc) | V_SMHDR_DEST_BLOCK(0x7));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), l2_entry[0]);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), l2_entry[1]);
    WRITECSR(sc, R_CMIC_SCHAN_D(3), l2_entry[2]);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
         V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
    cfe_usleep(100);
    ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
    if (ctrl & M_SCTL_MSG_DONE)
        break;
    }

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}

static void
l2_dump(bcm53300_state_t *sc)
{
    uint32_t l2_entry[3];
    uint8_t status1, status2;
    uint8_t module, port;
    int i;

    for (i = 0; i < 8192; i++) {
        schan_read_mem(sc, M_L2_ENTRY + i, l2_entry, 3);
        status1 = (l2_entry[2] >> 22) & 0x7;
        if (status1 & 0x04) {    /* valid */
            status2 = ((l2_entry[2] & 0xF) << 4) | ((l2_entry[1] >> 24) & 0xF);
            module = (l2_entry[2] >> 10) & 0x1F;
            port = (l2_entry[2] >> 4) & 0x3F;
            xprintf("  %03x,%1d: %01x %02x %02x/%01x %04x%08x\n",
            i/8, i % 8,
            status1, status2, module, port,
            l2_entry[1] & 0xFFFF, l2_entry[0]);
        }
    }
}


/* Gigabit MAC management */
#if XGS_DEBUG
static void
dump_gpic(bcm53300_state_t *sc, unsigned int port)
{
    unsigned int block, port_with_block;

    block = port/PORTS_PER_BLOCK;
    port_with_block = port%PORTS_PER_BLOCK;

    xprintf("--- gpic: %d ---\n", port);
    xprintf("MAXFR:       %08x   GTH_FE_MAXF: %08x\n",
        schan_read_reg(sc, R_MAXFR(block, port_with_block)),
        schan_read_reg(sc, R_GTH_FE_MAXF(block, port_with_block)));
    xprintf("CONFIG:      %08x   GEGR_ENABLE: %08x\n",
        schan_read_reg(sc, R_GE_PORT_CONFIG(block, port_with_block)),
        schan_read_reg(sc, R_GEGR_ENABLE(port)));
    xprintf("R_CPU_CONTROL_1: %08x   R_CPU_CONTROL_2: %08x   EPC_LINK:    %08x\n",
        schan_read_reg(sc, R_CPU_CONTROL_1), schan_read_reg(sc, R_CPU_CONTROL_2),
        schan_read_reg(sc, R_EPC_LINK_BMAP));
    xprintf("-----------------\n");
 }
#endif

static void
port_enable(bcm53300_state_t *sc)
{
    unsigned int port;
    int linkspeed;
    unsigned int block, port_with_block;
    int gmac;

    schan_write_reg(sc, R_GPORT_CONFIG(0), 1);
    schan_write_reg(sc, R_GPORT_CONFIG(1), 1);

    for (port = 0; port < GPIC_PORTS; port++) {
        block = port/PORTS_PER_BLOCK;
        port_with_block = port%PORTS_PER_BLOCK;

        linkspeed = sc->phy_info[port].linkspeed;

        gmac = (linkspeed == ETHER_SPEED_1000FDX || linkspeed == ETHER_SPEED_1000HDX);
        if (linkspeed != ETHER_SPEED_UNKNOWN) {
            if(gmac) {
                schan_write_reg(sc, R_GMACC1(block, port_with_block), 0x500A1001); 
            } else {
                schan_write_reg(sc, R_GTH_FE_MAC1(block, port_with_block), 0x800d);
            }
        }
    }
}

static void
gpic_init(bcm53300_state_t *sc, unsigned int port, int linkspeed)
{
    uint32_t config;
    unsigned int offset;
    int gmac;
    unsigned int block, port_with_block;

    block = port/PORTS_PER_BLOCK;
    port_with_block = port%PORTS_PER_BLOCK;

    /* Zero the port statistics */
    for (offset = 0x0; offset < 0x37; offset++) {
        schan_write_reg(sc, R_GPORT_W_BLOCK(block, port_with_block, offset), 0);
    }

    /* egress enable */
    schan_write_reg(sc, R_GEGR_ENABLE(port), 0x1);

    /* speed duplex */
    gmac = (linkspeed == ETHER_SPEED_1000FDX || linkspeed == ETHER_SPEED_1000HDX);
    if (gmac) {
        config = (0x02 << 1);
    } else if (linkspeed == ETHER_SPEED_100FDX || linkspeed == ETHER_SPEED_100HDX){
        config = (0x01 << 1);
    } else {
        config = (0x02 << 1);        
    }

    config = config | 0x20;
    schan_write_reg(sc, R_GE_PORT_CONFIG(block, port_with_block), config);

    /* BCAST block mask */
    schan_write_reg(sc, R_BCAST_BLOCK_MASK(port), 0);

    /* CPU has a static L2 entry, so don't send unknown unicast there. */
    schan_write_reg(sc, R_UNKNOWN_UCAST_BLOCK_MASK(port), CMIC_BIT);

    if (gmac) {
        schan_write_reg(sc, R_GMACC2(block, port_with_block), 0x0C);
        schan_write_reg(sc, R_GMACC1(block, port_with_block), 0x000A1001);
        schan_write_reg(sc, R_GMACC0(block, port_with_block), 0x0);
        schan_write_reg(sc, R_MAXFR(block, port_with_block), MAX_VLAN_PACK);
        cfe_usleep(10);

        schan_write_reg(sc, R_GMACC0(block, port_with_block), 0x1);
        schan_write_reg(sc, R_GPCSC(block, port_with_block), 0x4);
        cfe_usleep(10);
    }
    else {
        schan_write_reg(sc, R_GTH_FE_MAC1(block, port_with_block), 0x0);
        if (linkspeed == ETHER_SPEED_100HDX || linkspeed == ETHER_SPEED_10HDX)
            schan_write_reg(sc, R_GTH_FE_MAC2(block, port_with_block), 0x4000);
        else
            schan_write_reg(sc, R_GTH_FE_MAC2(block, port_with_block), 0x4001);

        schan_write_reg(sc, R_GTH_FE_IPGT(block, port_with_block), 0x15);
        schan_write_reg(sc, R_GTH_FE_IPGR(block, port_with_block), 0x060f);
        schan_write_reg(sc, R_GTH_FE_MAXF(block, port_with_block), 0x5ef);
        cfe_usleep(10);
        schan_write_reg(sc, R_GTH_FE_MAC1(block, port_with_block), 0x800c);
        schan_write_reg(sc, R_PAUSE_CONTROL(block, port_with_block), 0x3ffff);
    }
}

static void
gpic_stop(bcm53300_state_t *sc, unsigned int port)
{
    uint32_t k, g;
    uint32_t count;
    int linkspeed;
    unsigned int block, port_with_block;
    int gmac;

    k = ((port/PORTS_PER_BLOCK) << 20);
    g = ((port%PORTS_PER_BLOCK) << 12);

    /* clean the counter related to this port */
    xprintf("--- GE port: %d ---\n", port);
    xprintf("GTPKT:   %08x   GTBYT:   %08x\n",
        schan_read_reg(sc, k | g | 0x00027),
        schan_read_reg(sc, k | g | 0x00037));
    xprintf("GRPKT:   %08x   GRBYT:   %08x\n",
        schan_read_reg(sc, k | g | 0x0000A),
        schan_read_reg(sc, k | g | 0x0000B));
    xprintf("GRMCA:   %08x   GRBCA:   %08x\n",
        schan_read_reg(sc, k | g | 0x0000C),
        schan_read_reg(sc, k | g | 0x0000D));

    /* Print error counts if non-zero. */
    count = schan_read_reg(sc, k | g | 0x0001A);
    if (count != 0) xprintf("GRUND:   %08x\n", count);
    count = schan_read_reg(sc, k | g | 0x0001B);
    if (count != 0) xprintf("GRFRG:   %08x\n", count);
    count = schan_read_reg(sc, k | g | 0x0000E);
    if (count != 0) xprintf("GRFCS:   %08x\n", count);
    count = schan_read_reg(sc, k | g | 0x00012);
    if (count != 0) xprintf("GRALN:   %08x\n", count);
    count = schan_read_reg(sc, k | g | 0x00014);
    if (count != 0) xprintf("GRCDE:   %08x\n", count);
    count = schan_read_reg(sc, k | g | 0x00015);
    if (count != 0) xprintf("GRFCR:   %08x\n", count);
    count = schan_read_reg(sc, k | g | 0x00016);
    if (count != 0) xprintf("GROVR:   %08x\n", count);
    count = schan_read_reg(sc, k | g | 0x00017);
    if (count != 0) xprintf("GRJBR:   %08x\n", count);

    block = port/PORTS_PER_BLOCK;
    port_with_block = port%PORTS_PER_BLOCK;

    linkspeed = sc->phy_info[port].linkspeed;

    gmac = (linkspeed == ETHER_SPEED_1000FDX || linkspeed == ETHER_SPEED_1000HDX);
    if (linkspeed != ETHER_SPEED_UNKNOWN) {
        if(gmac) {
            schan_write_reg(sc, R_GMACC1(block, port_with_block), 0x000A1001); 
        } else {
            schan_write_reg(sc, R_GTH_FE_MAC1(block, port_with_block), 0x800c);
        }
    }

    xprintf("-----------------\n");
}


static void
port_init(bcm53300_state_t *sc)
{
    unsigned int port;
    int linkspeed;

    for (port = 0; port < GPIC_PORTS; port++) {
        /* init phy 56xxx */
        {
            int   phy_addr_int = (port| 0x80);
            uint16_t      ctrl;

            ctrl = mii_read(sc, phy_addr_int, DDS_1000X_CTRL1_REG);
            /*
             * Put the Serdes in SGMII mode
             */
            ctrl &= ~DDS_1000X_FIBER_MODE;
            mii_write(sc, phy_addr_int, DDS_1000X_CTRL1_REG, ctrl);
        }

        linkspeed = sc->phy_info[port].linkspeed;
        if (linkspeed != ETHER_SPEED_UNKNOWN) {
            gpic_init(sc, port, linkspeed);
#if XGS_DEBUG
            dump_gpic(sc, port);
#endif            
        }
    }
}

static void
port_stop(bcm53300_state_t *sc)
{
    unsigned int port;

    for (port = 0; port < GPIC_PORTS; port++) {
        if ((sc->portmap & GPIC_BIT(port)) != 0) {
#if XGS_DEBUG            
            dump_gpic(sc, port);
#endif
            gpic_stop(sc, port);
        }
    }
}

static void
fusioncore_reset(bcm53300_state_t *sc, unsigned int port) {
    uint16_t	mreg_val;
    int phy_addr=PHY_ADDR;

    mii_write_internal(sc, phy_addr, 0x1f, 0x0010);

    mreg_val = mii_read_internal(sc, phy_addr, 0x1a);
    mreg_val |= (1 << 10);
    mii_write_internal(sc, phy_addr, 0x1a, mreg_val);

    /* Select block 0x5 */
    mii_write_internal(sc, phy_addr, 0x1f, 0x0050);
    /* Disable PLL state machine */
    mii_write_internal(sc, phy_addr, 0x11, 0x5006);
    /* Turn off slowdn_xor */
    mii_write_internal(sc, phy_addr, 0x15, 0x0000);

    /* Select block 0x0 */
    mii_write_internal(sc, phy_addr, 0x1f, 0x0000);

    /* Enable DTE mdio reg mapping */
    mii_write_internal(sc, phy_addr, 0x1e, 0x1e);

    /* Select block 0x5 */
    mii_write_internal(sc, phy_addr, 0x1f, 0x0050);
    /* Enable PLL state machine */
    mii_write_internal(sc, phy_addr, 0x11, 0xd006);

    /* Select block 0xa */
    mii_write_internal(sc, phy_addr, 0x1f, 0x00a0);

    /* TX pre-emphasis */
    mreg_val = mii_read_internal(sc, phy_addr, 0x17);
    mreg_val = (mreg_val & 0x0fff) | ((0x0 & 0xf) << 12);
    /* TX pre-emphasis */
    mii_write_internal(sc, phy_addr, 0x17, mreg_val);

    /* Select block 0x0 */
    mii_write_internal(sc, phy_addr, 0x1f, 0x0000);            
}

/* 10 Gigabit MAC management */
static void
ipic_init(bcm53300_state_t *sc, unsigned int port)
{
    WRITECSR(sc, R_CMIC_XGXS_MDIO_CONFIG_2, 0x3);
    WRITECSR(sc, R_CMIC_XGXS_PLL_CONTROL_1, 0x0);

    /* CPU has a static L2 entry, so don't send unknown unicast there. */
    schan_write_reg(sc, R_UNKNOWN_UCAST_BLOCK_MASK(IPIC_PORT), CMIC_BIT);

    schan_write_reg(sc, R_MAC_CTRL, 0x3);  

    schan_write_reg(sc, R_MAC_TXCTRL, 0x89);    
    schan_write_reg(sc, R_MAC_RXCTRL, 0x11);    

    schan_write_reg(sc, R_MAC_XGXS_CTRL, 0x801e1);    
    schan_write_reg(sc, R_MAC_XGXS_CTRL, 0x80191);    
    schan_write_reg(sc, R_MAC_XGXS_CTRL, 0x801e1);    
    schan_write_reg(sc, R_MAC_XGXS_CTRL, 0x80181); 
    schan_write_reg(sc, R_MAC_XGXS_CTRL, 0x80191);    

    fusioncore_reset(sc, IPIC_PORT);

    cfe_sleep(5);

    schan_write_reg(sc, R_MAC_TXMAXSE, 0x3fe8);    
    schan_write_reg(sc, R_MAC_RXCTRL, 0x30);    
    schan_write_reg(sc, R_MAC_RXMAXSE, 0x3fe8);    

    if(sc->module == 0) {
        schan_write_reg(sc, R_XPORT_CONFIG, 0x3);    
    } else if(sc->module == 1) {
        schan_write_reg(sc, R_XPORT_CONFIG, 0x23);    
    } 
    
    schan_write_reg(sc, R_EGR_PORT(IPIC_PORT), 0x1);    

    /* egress enable */
    schan_write_reg(sc, R_GEGR_ENABLE(IPIC_PORT), 0x1);    
}

static void
ipic_stop(bcm53300_state_t *sc, unsigned int port)
{
}

static void
xgxs_port_init(bcm53300_state_t *sc)
{
    ipic_init(sc, IPIC_PORT);
}

static void
xgxs_port_stop(bcm53300_state_t *sc)
{
    ipic_stop(sc, IPIC_PORT);
}

/* Packet management */

#define ETH_PKTPOOL_SIZE  16

static eth_pkt_t *
eth_alloc_pkt(bcm53300_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *) q_deqnext(&sc->freelist);
    CS_EXIT(sc);
    if (!pkt) return NULL;

    pkt->buffer = pkt->data;
    pkt->length = ETH_PKTBUF_LEN;
    pkt->flags = 0;

    return pkt;
}

static void
eth_free_pkt(bcm53300_state_t *sc, eth_pkt_t *pkt)
{
    CS_ENTER(sc);
    q_enqueue(&sc->freelist, &pkt->next);
    CS_EXIT(sc);
}

static void
eth_initfreelist(bcm53300_state_t *sc)
{
    int idx;
    uint8_t *ptr;
    eth_pkt_t *pkt;

    q_init(&sc->freelist);

    ptr = sc->pktpool;
    for (idx = 0; idx < ETH_PKTPOOL_SIZE; idx++) {
        pkt = (eth_pkt_t *) ptr;
        eth_free_pkt(sc, pkt);
        ptr += ETH_PKTBUF_SIZE;
    }
}

/* Packet DMA Service */

#define V_BIT_POS_RX1_EN         (V_DMA_BIT_POS(S_CH_DMA_EN(RX_CH1)))
#define V_BIT_POS_RX1_DESC_DONE  (V_DMA_BIT_POS(S_CH_DESC_DONE(RX_CH1)))
#define V_BIT_POS_RX1_CHAIN_DONE (V_DMA_BIT_POS(S_CH_CHAIN_DONE(RX_CH1)))

static int
xgs_add_rcvbuf(bcm53300_state_t *sc, eth_pkt_t *pkt)
{
    /*volatile*/ dcb_t *dcb;

    dcb = sc->dcbs[RX_CH1];

    memset(dcb, 0, sizeof(dcb_t));
    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = (V_DCB1_BYTE_COUNT(ETH_PKTBUF_LEN)
	       | V_DCB1_COS(0));

    inval_range(pkt->buffer, pkt->length);
    sync_range(dcb, sizeof(dcb_t));

    WRITECSR(sc, R_CMIC_DMA_DESC(RX_CH1), PTR_TO_PCI(dcb));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_1);

    return 0;
}


static void
xgs_rx_callback(bcm53300_state_t *sc, eth_pkt_t *pkt)
{
#if XGS_DEBUG
    show_packet('>', pkt);   /* debug */
#endif

    CS_ENTER(sc);
    q_enqueue(&sc->rxqueue, &pkt->next);
    CS_EXIT(sc);
    sc->inpkts++;
}

static void
xgs_procrxring(bcm53300_state_t *sc)
{
    /*volatile*/ dcb_t *dcb;
    /*volatile*/ eth_pkt_t *pkt;
    eth_pkt_t *new_pkt;

    dcb = sc->dcbs[RX_CH1];
    inval_range(dcb, sizeof(dcb_t));

    /* FIXME : don't need to check DONE bit, it wasn't set
    if ((dcb->w9 & M_DCB9_DONE) == 0)
	return; */
    
#if XGS_DEBUG
    xprintf("recv: dcb %08x %08x %08x %08x\n          %08x %08x %08x %08x          %08x %08x\n",
        dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
        dcb->w4, dcb->w5, dcb->w6, dcb->w7, dcb->w8, dcb->w9);
#endif

    pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));

#if 0 /* FIXME, don't use DCB6's count, it is 0 */
    pkt->length = G_DCB6_RCV_COUNT(dcb->w6) - ENET_CRC_SIZE;
#else
    pkt->length = V_DCB1_BYTE_COUNT(dcb->w1);
#endif
    inval_range(pkt->buffer, pkt->length);

    xgs_rx_callback(sc, (eth_pkt_t *)pkt);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_DESC_DONE | V_DMA_BIT_0);
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_CHAIN_DONE | V_DMA_BIT_0);

    new_pkt = eth_alloc_pkt(sc);
    if (new_pkt) {
        xgs_add_rcvbuf(sc, new_pkt);
    }
}


#define V_BIT_POS_TX_EN          (V_DMA_BIT_POS(S_CH_DMA_EN(TX_CH)))
#define V_BIT_POS_TX_DESC_DONE   (V_DMA_BIT_POS(S_CH_DESC_DONE(TX_CH)))
#define V_BIT_POS_TX_CHAIN_DONE  (V_DMA_BIT_POS(S_CH_CHAIN_DONE(TX_CH)))

static int
xgs_transmit(bcm53300_state_t *sc, eth_pkt_t *pkt)
{
    /*volatile*/ dcb_t *dcb;

    if (sc->txbusy)
        return -1;

    sc->txbusy = 1;

#if XGS_DEBUG
    show_packet('<', pkt);
#endif

    /* The CMIC "recomputes" the CRC, does not append it. */
    pkt->length += ENET_CRC_SIZE;

    if(pkt->length < 64)
        pkt->length = 64;

    dcb = sc->dcbs[TX_CH];
    memset(dcb, 0, sizeof(dcb_t));

    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = (V_DCB1_BYTE_COUNT(pkt->length)
        | V_DCB1_MH_OPCODE(1)
        | V_DCB1_COS(0)); 

    sync_range(pkt->buffer, pkt->length);
    sync_range(dcb, sizeof(dcb_t));

    WRITECSR(sc, R_CMIC_DMA_DESC(TX_CH), PTR_TO_PCI(dcb));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_1);

    sc->outpkts++;
    return 0;
}

static void
xgs_proctxchain(bcm53300_state_t *sc)
{
    /*volatile*/ dcb_t *dcb;
    eth_pkt_t *pkt;

    if (!sc->txbusy)
        return;

    dcb = sc->dcbs[TX_CH];
    inval_range(dcb, sizeof(dcb_t));

    /* if ((dcb->w9 & M_DCB9_DONE) == 0) 
	return; */

#if XGS_DEBUG
    xprintf("tx: dcb %08x %08x %08x %08x\n          %08x %08x %08x %08x\n          %08x %08x\n",
        dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
        dcb->w4, dcb->w5, dcb->w6, dcb->w7, dcb->w8, dcb->w9);
#endif

    /* Just free the packet */
    pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));
    eth_free_pkt(sc, pkt);

    /* Evidently, the channel will not restart until CHAIN_DONE is
       clear, and empirically, CHAIN_DONE cannot reliably be cleared
       until DMA_EN is cleared. */

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_DESC_DONE | V_DMA_BIT_0);
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_CHAIN_DONE | V_DMA_BIT_0);

    sc->txbusy = 0;
}


static void
xgs_initrings(bcm53300_state_t *sc)
{
    eth_pkt_t *pkt;

    pkt = eth_alloc_pkt(sc);
    if (pkt != NULL)
        xgs_add_rcvbuf(sc, pkt);
}

static void
xgs_init(bcm53300_state_t *sc)
{
    /* Allocate buffer pool */
    sc->pktpool = KMALLOC(ETH_PKTPOOL_SIZE*ETH_PKTBUF_SIZE, CACHE_ALIGN);
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);

    sc->dcbs[TX_CH] = KMALLOC(sizeof(dcb_t), CACHE_ALIGN);
    sc->txbusy = 0;

    sc->dcbs[RX_CH1] = KMALLOC(sizeof(dcb_t), CACHE_ALIGN);
    xgs_initrings(sc);

    /* XXX Initialize descriptor lists */
}

static void
xgs_reinit(bcm53300_state_t *sc)
{
    KFREE(sc->pktpool);

    xgs_init(sc);
}

static void
xgs_hwinit_disable_1000(bcm53300_state_t *sc)
{
    int port;
#if ENDIAN_BIG
        /* Documentation is confusing/misleading here.  For 47xx and 1250: */
        WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x02020202);
#else
        WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x00000000);
#endif
        /* Clear S-channel bits */
        WRITECSR(sc, R_CMIC_SCHAN_CTRL,
             V_SCTL_BIT_POS(S_SCTL_MIIM_OP_DONE) | V_SCTL_BIT_0);
        WRITECSR(sc, R_CMIC_SCHAN_CTRL,
             V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_0);

        /* Before scan port, disable 1000 capability, enable 10, 100 capability only */
        for (port = 0; port < GPIC_PORTS; port++) {
            int   phy_addr = port + 1;
            uint16_t      ctrl;

            ctrl = mii_read(sc, phy_addr, R_1000_BASE_T_CTRL_REG);
            ctrl &= ~(R_1000_BASE_T_1000_FULL | R_1000_BASE_T_1000_HALF);
            mii_write(sc, phy_addr, R_1000_BASE_T_CTRL_REG, ctrl);

            ctrl = mii_read(sc, phy_addr, R_AN_ADVERTISE_REG);
            ctrl |= (R_AN_ADVERTISE_100_T_FULL | R_AN_ADVERTISE_100_T_HALF |
                        R_AN_ADVERTISE_10_T_FULL | R_AN_ADVERTISE_10_T_HALF);
            mii_write(sc, phy_addr, R_AN_ADVERTISE_REG, ctrl);

            ctrl = mii_read(sc, phy_addr, R_BASIC_MODE_CTRL_REG);
            ctrl |= R_BASIC_MODE_CTRL_RESTART_AN;
            mii_write(sc, phy_addr, R_BASIC_MODE_CTRL_REG, ctrl);
        }
        cfe_sleep(2);
}

static void
xgs_hwinit(bcm53300_state_t *sc)
{
    uint32_t config;
    /* int port; */

    if (sc->state != eth_state_on) {
	
#if ENDIAN_BIG
        /* Documentation is confusing/misleading here.  For 47xx and 1250: */
        WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x02020202);
#else
        WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x00000000);
#endif

        /* Clear S-channel bits */
        WRITECSR(sc, R_CMIC_SCHAN_CTRL,
             V_SCTL_BIT_POS(S_SCTL_MIIM_OP_DONE) | V_SCTL_BIT_0);
        WRITECSR(sc, R_CMIC_SCHAN_CTRL,
             V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_0);

        xprintf("Link scan front port(s) for unit %d......\n", sc->module);        
        if(sc->module == TX_UNIT_NUM) {
            cfe_sleep(20);
        }

        sc->portmap = phy_scan(sc);
        xprintf("Active port map: %06X\n", sc->portmap);

        config = READCSR(sc, R_CMIC_CONFIG);
        /* PCI interface options. */
        config |= M_RD_BRST_EN | M_WR_BRST_EN | M_MSTR_Q_MAX_EN;
        /* DMA options */
        config |= M_IGNORE_ADR_ALIGN_EN | M_SG_ENABLE | M_SG_RELOAD_ENABLE;
        /* Normal operation */
        config |= M_EXT_MDIO_MSTR_DIS;
        WRITECSR(sc, R_CMIC_CONFIG, config);

        /* Configure DMA channels. */
        WRITECSR(sc, R_CMIC_DMA_CTRL, M_CH_DIRECTION(TX_CH));

        port_init(sc);

        if (sc->higig) {
            xgxs_port_init(sc);
        }

        arl_init(sc);
        misc_init(sc, sc->portmap | CMIC_BIT | IPIC_BIT);
        mmu_init(sc, sc->portmap | CMIC_BIT | IPIC_BIT);
        table_init(sc, sc->portmap | CMIC_BIT | IPIC_BIT);

        /* clear counter */
        schan_write_reg(sc, R_GPORT_CONFIG(0), 3);
        schan_write_reg(sc, R_GPORT_CONFIG(1), 3);

        /* EPC link */
        schan_write_reg(sc, R_EPC_LINK_BMAP, sc->portmap | CMIC_BIT | IPIC_BIT);

        /* CPU control */
        schan_write_reg(sc, R_CPU_CONTROL_1, 0);
        schan_write_reg(sc, R_CPU_CONTROL_2, 0);

        /* VLAN */
        schan_write_reg(sc, R_VLAN_CTRL, VLAN_DEFAULT);    

        l2_enter(sc, sc->hwaddr, CMIC_PORT);

        sc->state = eth_state_off;
    }
}

static void
xgs_isr(void *arg)
{
    bcm53300_state_t *sc = (bcm53300_state_t *)arg;
    uint32_t irqstat = READCSR(sc, R_CMIC_IRQ_STAT);

    if (IPOLL) sc->interrupts++;

    if (irqstat & M_IRQ_CHAIN_DONE(RX_CH1)) {
        if (IPOLL) sc->rx_interrupts++;
        xgs_procrxring(sc);
    }

    if (irqstat & M_IRQ_CHAIN_DONE(TX_CH)) {
        if (IPOLL) sc->tx_interrupts++;
        xgs_proctxchain(sc);
    }
}

static void
xgs_start(bcm53300_state_t *sc)
{
    uint32_t pending;

    xgs_hwinit(sc);

    sc->intmask = 0;
    WRITECSR(sc, R_CMIC_IRQ_MASK, 0);
    pending = READCSR(sc, R_CMIC_IRQ_STAT);
    WRITECSR(sc, R_CMIC_IRQ_STAT, pending);
    (void)READCSR(sc, R_CMIC_IRQ_STAT);   /* push */

    sc->intmask = M_IRQ_CHAIN_DONE(RX_CH1) | M_IRQ_CHAIN_DONE(TX_CH);

#if IPOLL
    cfe_request_irq(sc->irq, xgs_isr, sc, CFE_IRQ_FLAGS_SHARED, 0);
    WRITECSR(sc, R_CMIC_IRQ_MASK, sc->intmask);
#endif

    sc->state = eth_state_on;
}

static void
xgs_stop(bcm53300_state_t *sc)
{
    uint32_t pending;

    l2_dump(sc);

    if (sc->higig)
        xgxs_port_stop(sc);

    port_stop(sc);

    sc->intmask = 0;
    WRITECSR(sc, R_CMIC_IRQ_MASK, 0);
    pending = READCSR(sc, R_CMIC_IRQ_STAT);
    WRITECSR(sc, R_CMIC_IRQ_STAT, pending);
    (void)READCSR(sc, R_CMIC_IRQ_STAT);   /* push */
#if IPOLL
    cfe_free_irq(sc->irq, 0);
#endif

    if (sc->state == eth_state_on) {
        sc->state = eth_state_off;
        /* XXX Shutdown the chip */
        xgs_reinit(sc);

        if (unit_num == MAX_UNIT_NUM) {
            if(sc->module == TX_UNIT_NUM) {
                sc_temp[MAX_UNIT_NUM-1]->state = eth_state_off;
            }        
        }
    }
}


static void bcm53300_probe(cfe_driver_t *drv, unsigned long probe_a, 
                    unsigned long probe_b, void *probe_ptr);
static int bcm53300_open(cfe_devctx_t *ctx);
static int bcm53300_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm53300_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat);
static int bcm53300_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm53300_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm53300_close(cfe_devctx_t *ctx);
static void bcm53300_poll(cfe_devctx_t *ctx, int64_t ticks);
static void bcm53300_reset(void *softc);

const static cfe_devdisp_t bcm53300_dispatch = {
    bcm53300_open,
    bcm53300_read,
    bcm53300_inpstat,
    bcm53300_write,
    bcm53300_ioctl,
    bcm53300_close,	
    bcm53300_poll,
    bcm53300_reset
};

cfe_driver_t bcm53300drv = {
    "BCM56330 switch",
    "eth",
    CFE_DEV_NETWORK,
    &bcm53300_dispatch,
    bcm53300_probe
};


static int
bcm53300_attach(cfe_driver_t *drv, pcitag_t tag, uint8_t hwaddr[])
{
    bcm53300_state_t *sc;
    char descr[80];
    phys_addr_t pa;
    pcireg_t device, class;
    //uint32_t cmic_id;

    pci_map_mem(tag, PCI_MAPREG(0), CSR_MATCH_MODE, &pa);

    sc = (bcm53300_state_t *) KMALLOC(sizeof(bcm53300_state_t), 0);
    if (sc == NULL) {
        xprintf("BCM569x: No memory to complete probe\n");
        return 0;
    }
    memset(sc, 0, sizeof(*sc));

    sc->regbase = (uint32_t)pa;
    sc->irq = pci_conf_read(tag, PCI_BPARAM_INTERRUPT_REG) & 0xFF;

    device = pci_conf_read(tag, PCI_ID_REG);
    class = pci_conf_read(tag, PCI_CLASS_REG);
    sc->tag = tag;
    sc->device = PCI_PRODUCT(device);
    sc->revision = PCI_REVISION(class);
    switch (sc->device) {
        case K_PCI_ID_BCM56304:
        case K_PCI_ID_BCM53302:
            sc->higig = 1;
            break;

        case K_PCI_ID_BCM53300:
        case K_PCI_ID_BCM53301:            
        default:
            sc->higig = 0;
            break;
    }

    sc->module = unit_num;

    sc->devctx = NULL;

    /* Always use the MAC address that was passed in. */
    memcpy(sc->hwaddr, hwaddr, ENET_ADDR_LEN);

    /* FIX bug : switch's register can't read/write */
    {
        /* WRITECSR(sc, 0x10c, 0xc2043); */
        WRITECSR(sc, 0x400, 0xad42aaa);
        WRITECSR(sc, 0x580, 0x21adb);
    }

    xgs_init(sc);
    sc->state = eth_state_uninit;

    xsprintf(descr, "BCM%04X StrataXGS Switch (mod %02X) at 0x%08X",
        sc->device, sc->module, sc->regbase);
    cfe_attach(drv, sc, NULL, descr);

    xgs_hwinit_disable_1000(sc);
    sc_temp[unit_num] = sc;
    unit_num++;

    return 1;
}

static void
bcm53300_probe(cfe_driver_t *drv,
	      unsigned long probe_a, unsigned long probe_b, 
	      void *probe_ptr)
{
    int index;
    uint8_t hwaddr[ENET_ADDR_LEN];
    const char *str_ptr;

    if (probe_ptr)
        enet_parse_hwaddr((char *)probe_ptr, hwaddr);
    else {
        /* get mac address */
        str_ptr = nvram_get("et1macaddr");
        if (str_ptr == NULL) {

            /*
             * eth1 MAC address should be unique for each board:
             * - check "factory configurables" block.
             */
            FACTORYCFG_H handle;
            handle = factory_config_open();
            if (handle) {
                str_ptr = (char *)factory_config_get(handle, "macaddr");
                factory_config_close(handle, FALSE);
            }
        }
        if (str_ptr != NULL) {
            if (enet_parse_hwaddr(str_ptr, hwaddr) != 0) {
                printf("enet_parse_hwaddr failed : str_ptr=%s mac=0x%x-0x%x-0x%x-0x%x-0x%x-0x%x", 
                    str_ptr,  hwaddr[0],  hwaddr[1],  hwaddr[2],  hwaddr[3],  hwaddr[4],  hwaddr[5]);
                return;
            }
#if XGS_DEBUG
            printf("bcm53300_probe : str_ptr=%s mac=0x%x-0x%x-0x%x-0x%x-0x%x-0x%x", 
                    str_ptr,  hwaddr[0],  hwaddr[1],  hwaddr[2],  hwaddr[3],  hwaddr[4],  hwaddr[5]);
#endif
        } else {
            /* Use default address 00-10-18-53-30-01 */
            hwaddr[0] = 0x00;  hwaddr[1] = 0x10;  hwaddr[2] = 0x18;
            hwaddr[3] = 0x53;  hwaddr[4] = 0x30;  hwaddr[5] = 0x01;
        }
    }

    index = 0;
    for (;;) {
        pcitag_t tag;
        pcireg_t device;

        if (pci_find_class(PCI_CLASS_NETWORK, index, &tag) != 0)
            break;

        index++;

	 device = pci_conf_read(tag, PCI_ID_REG);
#if XGS_DEBUG
        xprintf("bcm53300_probe : device = 0x%x\n", device);
#endif
        if (PCI_VENDOR(device) == K_PCI_VENDOR_BROADCOM) {
            switch (PCI_PRODUCT(device)) {
                case K_PCI_ID_BCM56304:
                case K_PCI_ID_BCM53300:
                case K_PCI_ID_BCM53301:
                case K_PCI_ID_BCM53302:
                    bcm53300_attach(drv, tag, hwaddr);
                    break;
                default:
                    break;
            }
        }
    }
}


/* The functions below are called via the dispatch vector for the XGS switch */

static int
bcm53300_open(cfe_devctx_t *ctx)
{
    bcm53300_state_t *sc = ctx->dev_softc;

    if (sc->state == eth_state_on)
        xgs_stop(sc);

    sc->devctx = ctx;

    sc->inpkts = sc->outpkts = 0;
    sc->interrupts = 0;
    sc->rx_interrupts = sc->tx_interrupts = 0;

    xgs_start(sc);

    if (unit_num == MAX_UNIT_NUM) {
        if(sc->module == TX_UNIT_NUM) {
            xgs_start(sc_temp[MAX_UNIT_NUM-1]);
        }    
        cfe_sleep(10);
    }

    port_enable(sc);

    if (unit_num == MAX_UNIT_NUM) {
        if(sc->module == TX_UNIT_NUM) {
            port_enable(sc_temp[MAX_UNIT_NUM-1]);
        }      
    }

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm53300_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm53300_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *)q_deqnext(&(sc->rxqueue));
    CS_EXIT(sc);

    if (pkt == NULL) {
        buffer->buf_retlen = 0;
        return 0;
    }

    blen = buffer->buf_length;
    if (blen > pkt->length) blen = pkt->length;

    /* Remove the VLAN tag. */
    blockcopy(buffer->buf_ptr, pkt->buffer, 12);
    blockcopy(buffer->buf_ptr+12, pkt->buffer+16, blen-16);
    buffer->buf_retlen = blen-4;

    eth_free_pkt(sc, pkt);

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm53300_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    bcm53300_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    /* We avoid an interlock here because the result is a hint and an
       interrupt cannot turn a non-empty queue into an empty one. */
    inpstat->inp_status = (q_isempty(&(sc->rxqueue))) ? 0 : 1;

    return 0;
}

static int
bcm53300_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm53300_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    pkt = eth_alloc_pkt(sc);
    if (!pkt) return CFE_ERR_NOMEM;

    blen = buffer->buf_length;
    if (blen > pkt->length) blen = pkt->length;

    /* Empirically, the logic will unconditionally delete 4 bytes from
        the nominal position of a VLAN tag, so insert something to
        strip. */
    blockcopy(pkt->buffer, buffer->buf_ptr, 12);
    pkt->buffer[12] = VLAN_TYPE >> 8; pkt->buffer[13] = VLAN_TYPE & 0xFF;
    pkt->buffer[14] = VLAN_DEFAULT >> 8; pkt->buffer[15] = VLAN_DEFAULT & 0xFF;
    blockcopy(pkt->buffer+16, buffer->buf_ptr+12, blen-12);

    /* The CMIC apparently does not correctly auto-pad short packets. */
    if (blen < ENET_MIN_PKT) {
	memset(pkt->buffer + blen + VLAN_TAG_LEN, 0, ENET_MIN_PKT - blen);
	blen = ENET_MIN_PKT;
	}

    pkt->length = blen + VLAN_TAG_LEN;

    if (xgs_transmit(sc, pkt) != 0) {
        eth_free_pkt(sc,pkt);
        return CFE_ERR_IOERR;
    }

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm53300_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    bcm53300_state_t *sc = ctx->dev_softc;

    switch ((int)buffer->buf_ioctlcmd) {
        case IOCTL_ETHER_GETHWADDR:
            memcpy(HSADDR2PTR(buffer->buf_ptr), sc->hwaddr, sizeof(sc->hwaddr));
            return 0;

        default:
            return -1;
    }
}

static int
bcm53300_close(cfe_devctx_t *ctx)
{
    bcm53300_state_t *sc = ctx->dev_softc;

    xgs_stop(sc);

    xprintf("%s: %d sent, %d received, %d interrupts\n",
        xgs_devname(sc), sc->outpkts, sc->inpkts, sc->interrupts);
    xprintf("  %d tx interrupts, %d rx interrupts\n",
        sc->tx_interrupts, sc->rx_interrupts);

    sc->devctx = NULL;
    return 0;
}

static void
bcm53300_poll(cfe_devctx_t *ctx, int64_t ticks)
{
    bcm53300_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);
}

static void
bcm53300_reset(void *softc)
{
    bcm53300_state_t *sc = (bcm53300_state_t *)softc;

    /* Turn off the Ethernet interface. */

    if (sc->state == eth_state_on)
        xgs_stop(sc);

    sc->state = eth_state_uninit;
}
