/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5345 Gigabit Switching Processor	     File: dev_bcm5345.c
    *  
    *  Author: Ed Satterthwaite
    *
    *********************************************************************  
    *
    *  Copyright 2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

/*
    CFE interface and MAC driver for the BCM5345M, BCM5346M, and
    similar Broadcom RoboSwitch-HS gigabit ethernet managed switches.
    Reference:
       BCM5345M 24-Gigabit Switching Processor Data Sheet
       Document 5345M-DS01-R (10/21/03)
       Broadcom Corp., 1625 Alton Parkway, Irvine CA.
*/

#include "cfe.h"
#include "lib_physio.h"
#include "cfe_irq.h"

#include "net_enet.h"

#include "pcivar.h"
#include "pcireg.h"

#include "bcm5345.h"
#include "mii.h"


#ifndef ROBO_DEBUG
#define ROBO_DEBUG 0
#endif

/* Port to dump for stats (debug only) */
#define LINK_PORT 12

#if ((ENDIAN_BIG + ENDIAN_LITTLE) != 1)
#error "dev_bcm5345: system endian not set"
#endif


/* Temporary, until configs supply MATCH_BYTES */
#if defined(MPC824X)  /* any machine without preserve-bits for PIO */
#define MATCH_BYTES  1
#else
#define MATCH_BYTES  0
#endif

/* Set IPOLL to drive processing through the pseudo-interrupt
   dispatcher.  Set XPOLL to drive processing by an external polling
   agent.  One must be set; setting both is ok. */

#ifndef IPOLL
#define IPOLL 0
#endif
#ifndef XPOLL
#define XPOLL 1
#endif

#define MIN_ETHER_PACK  (ENET_MIN_PKT+ENET_CRC_SIZE)   /* size of min packet */
#define MAX_ETHER_PACK  (ENET_MAX_PKT+ENET_CRC_SIZE)   /* size of max packet */

#define VLAN_TAG_LEN    4                              /* VLAN type plus tag */
#define VLAN_TYPE       0x8100
#define VLAN_DEFAULT    1


#define DMA_RX_HDR_LEN  DMAR_LEN
#define DMA_TX_HDR_LEN  DMAT_LEN
#define DMA_MAX_HDR_LEN (3*sizeof(uint32_t))   /* MAX(DMA_{TX,RX}_HDR_LEN) */
#define MAX_DMA_PACK    (MAX_ETHER_PACK+DMA_MAX_HDR_LEN)

/* Packet buffers.  For the CPU port, packet buffer alignment is
   probably to a word boundary (undocumented).  We would like it
   aligned to a cache line boundary for performance, although there is
   a trade-off with IP/TCP header alignment, and to facilitate cache
   flushing on hosts requiring that.  */

#define ETH_PKTBUF_LEN      (((MAX_DMA_PACK+31)/32)*32)

typedef struct eth_pkt_s {
    queue_t next;			/*  8 */
    uint8_t *buffer;			/*  4 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint32_t unused[3];			/* 12 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;

#define CACHE_ALIGN       32
#define ETH_PKTBUF_LINES  ((sizeof(eth_pkt_t) + (CACHE_ALIGN-1))/CACHE_ALIGN)
#define ETH_PKTBUF_SIZE   (ETH_PKTBUF_LINES*CACHE_ALIGN)
#define ETH_PKTBUF_OFFSET (offsetof(eth_pkt_t, data))

#define ETH_PKT_BASE(data) ((eth_pkt_t *)((data) - ETH_PKTBUF_OFFSET))

static void
show_packet(char c, eth_pkt_t *pkt)
{
    int i;
    int n = (pkt->length < 128 ? pkt->length : 128);

    for (i = 0; i < n; i++) {
	if (i % 32 == 0) {
	    if (i == 0)
		xprintf("%c[%4d]:", c, pkt->length);
	    else
		xprintf("\n        ");
	    }
	if (i % 4 == 0)
	    xprintf(" ");
	xprintf("%02x", pkt->buffer[i]);
	}
    xprintf("\n");
}


static void bcm5345_probe(cfe_driver_t *drv,
			  unsigned long probe_a, unsigned long probe_b, 
			  void *probe_ptr);


/* State information. */

typedef uint32_t portmap_t;       /* wide enough for a bit per port */

typedef enum {
    eth_state_uninit,
    eth_state_off,
    eth_state_on, 
} eth_state_t;

typedef struct phy_info_s {
    uint8_t  addr;                /* external PHY */
    uint8_t  linkspeed;
} phy_info_t;

typedef struct bcm5345_state_s {

    /* PCI access information */
    uint32_t  regbase;
    uint8_t   irq;
    pcitag_t  tag;		   /* tag for configuration registers */

    uint8_t   hwaddr[ENET_ADDR_LEN];
    uint16_t  device;              /* chip device code */
    uint8_t   revision;            /* chip revision */

    eth_state_t state;             /* current state */
    uint32_t intmask;              /* interrupt mask */

    /* packet free lists */
    queue_t freelist;
    uint8_t *pktpool;
    queue_t rxqueue;

    /* rings */
    eth_pkt_t *rx_buffers[N_CHANNELS];
    unsigned int rx_pp, rx_cp;
    unsigned int rx_onring;
    eth_pkt_t *tx_buffers[N_CHANNELS];
    unsigned int tx_pp, tx_cp;

    cfe_devctx_t *devctx;

    /* ports */
    portmap_t  portmap;          /* map of connected ports */
    phy_info_t phy_info[GE_PORTS];

    /* additional driver statistics */
    uint32_t inpkts;
    uint32_t outpkts;
    uint32_t interrupts;
    uint32_t rx_interrupts;
    uint32_t tx_interrupts;

    uint32_t rx_np;
    uint32_t tx_np;
} bcm5345_state_t;


/* Address mapping macros */

#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((uint8_t *)KERNADDR(a))

#define PCI_TO_PTR(a)  (PHYS_TO_PTR(PCI_TO_PHYS(a)))
#define PTR_TO_PCI(x)  (PHYS_TO_PCI(PTR_TO_PHYS(x)))


/* Address mapping macros */

#if (ENDIAN_BIG && MATCH_BYTES)
#define CSR_MATCH_MODE       PCI_MATCH_BYTES
#define READCSR(sc,csr)      (phys_read32_swapped((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32_swapped((sc)->regbase + (csr), (val)))
#else
#define CSR_MATCH_MODE       PCI_MATCH_BITS
#define READCSR(sc,csr)      (phys_read32((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->regbase + (csr), (val)))
#endif


/* Entry to and exit from critical sections (currently relative to
   interrupts only, not SMP) */

#if CFG_INTERRUPTS
#define CS_ENTER(sc) cfe_disable_irq(sc->irq)
#define CS_EXIT(sc)  cfe_enable_irq(sc->irq)
#else
#define CS_ENTER(sc) ((void)0)
#define CS_EXIT(sc)  ((void)0)
#endif


/* Utilities */

static uint32_t
swap32(uint32_t x)
{
    uint32_t t;

    t = ((x & 0xFF00FF00) >> 8) | ((x & 0x00FF00FF) << 8);
    return (t >> 16) | ((t & 0xFFFF) << 16);
}

#if ENDIAN_BIG
static void
swap_buffer(uint32_t *base, size_t len)
{
    unsigned int i;

    len = (len + 3)/4;      /* works on 32-bit words only */
    for (i = 0; i < len; i++) {
	*base = swap32(*base);
	base++;
	}
}
#else
#define swap_buffer(base,len) 
#endif

static const char *
bcm5345_devname(bcm5345_state_t *sc)
{
    return (sc->devctx != NULL ? cfe_device_name(sc->devctx) : "eth?");
}


/* Table access */

static int
table_wait_ready(bcm5345_state_t *sc)
{
    int i;
    uint32_t stat;

    for (i = 1000; i > 0; i--) {
	stat = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
	if ((stat & M_IRQ_TBL_CMD_DONE) == 0)
	    break;
	WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, M_IRQ_TBL_CMD_DONE);
	cfe_usleep(10);
    }
    return (i > 0 ? CFE_OK : CFE_ERR_TIMEOUT);
}

static int
table_wait_done(bcm5345_state_t *sc)
{
    int i;
    uint32_t stat;

    for (i = 1000; i > 0; i--) {
	stat = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
	if ((stat & M_IRQ_TBL_CMD_DONE) != 0)
	    break;
	cfe_usleep(10);
    }
    WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, M_IRQ_TBL_CMD_DONE);
    return (i > 0 ? CFE_OK : CFE_ERR_TIMEOUT);
}


/* MII/PHY management */

static uint16_t
mii_read(bcm5345_state_t *sc, int phy_addr, int reg)
{
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ mii rd %x\n", reg);
	return 0xFFFF;
	}

    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, (phy_addr << 5) | reg);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_MDIO) | V_TBL_MGMT_CMD(K_TBL_READ));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* mii rd %x\n", reg);
	return 0xFFFF;
	}

    return READCSR(sc, R_TABLE_DATA_BUFFER_0);
}

static void
mii_write(bcm5345_state_t *sc, int phy_addr, int reg, uint16_t value)
{
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ mii wr %x\n", reg);
	return;
	}

    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, (phy_addr << 5) | reg);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_0, value);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_MDIO) | V_TBL_MGMT_CMD(K_TBL_WRITE));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* mii wr %x\n", reg);
	return;
	}
}

static int
mii_status(bcm5345_state_t *sc, int phy_addr)
{
    uint16_t  status, remote, xremote;
    int linkspeed;

    linkspeed = ETHER_SPEED_UNKNOWN;

    /* Read twice to clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);
    status = mii_read(sc, phy_addr, MII_BMSR);

    remote = mii_read(sc, phy_addr, MII_ANLPAR);
    
    if ((status & BMSR_ANCOMPLETE) != 0) {
	/* A link partner was negogiated... */

	if (status & BMSR_1000BT_XSR)
	    xremote = mii_read(sc, phy_addr, MII_K1STSR);
	else
	    xremote = 0;

	if ((xremote & K1STSR_LP1KFD) != 0) {
	    xprintf("1000BaseT FDX\n");
	    linkspeed = ETHER_SPEED_1000FDX;
	    }
	else if ((xremote & K1STSR_LP1KHD) != 0) {
	    xprintf("1000BaseT HDX\n");
	    linkspeed = ETHER_SPEED_1000HDX;
	    }
	else if ((remote & ANLPAR_TXFD) != 0) {
	    xprintf("100BaseT FDX\n");
	    linkspeed = ETHER_SPEED_100FDX;	 
	    }
	else if ((remote & ANLPAR_TXHD) != 0) {
	    xprintf("100BaseT HDX\n");
	    linkspeed = ETHER_SPEED_100HDX;	 
	    }
	else if ((remote & ANLPAR_10FD) != 0) {
	    xprintf("10BaseT FDX\n");
	    linkspeed = ETHER_SPEED_10FDX;	 
	    }
	else if ((remote & ANLPAR_10HD) != 0) {
	    xprintf("10BaseT HDX\n");
	    linkspeed = ETHER_SPEED_10HDX;	 
	    }
	}
    else {
	/* no link partner convergence */
	xprintf("NC\n");
	linkspeed = ETHER_SPEED_UNKNOWN;
	}

    /* clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);

    return linkspeed;
}


#if 0 /*ROBO_DEBUG*/
static void
phy_dump(bcm5345_state_t *sc, unsigned int phy_addr, const char *label)
{
    int i;
    uint16_t  r, r1;
    uint16_t  id1, id2;
    uint32_t  phy_vendor;
    uint16_t  phy_device;

    xprintf("%s, MII(%d):\n", label, phy_addr);

    id1 = mii_read(sc, phy_addr, MII_PHYIDR1);
    id2 = mii_read(sc, phy_addr, MII_PHYIDR2);
    phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
    phy_device = (id2 >> 4) & 0x3F;

    /* Required registers */
    for (i = 0x0; i <= 0x6; ++i) {
	r = mii_read(sc, phy_addr, i);
	r1 = mii_read(sc, phy_addr, i);
	xprintf(" REG%02X: %04X", i, r);
	if (r1 != r)
	    xprintf("/%04X", r1);
	if (i == 3 || i == 6)
	    xprintf("\n");
	}

    /* GMII extensions */
    for (i = 0x9; i <= 0xA; ++i) {
	r = mii_read(sc, phy_addr, i);
	xprintf(" REG%02X: %04X", i, r);
	}
    r = mii_read(sc, phy_addr, 0xF);
    xprintf(" REG%02X: %04X\n", 0xF, r);

    /* Broadcom extensions (54xx family) */
    if (phy_vendor == OUI_BCM) {
	for (i = 0x10; i <= 0x14; i++) {
	    r = mii_read(sc, phy_addr, i);
	    xprintf(" REG%02X: %04X", i, r);
	    }
	xprintf("\n");
	for (i = 0x18; i <= 0x1A; i++) {
	    r = mii_read(sc, phy_addr, i);
	    xprintf(" REG%02X: %04X", i, r);
	    }
	xprintf("\n");

	if (phy_device == DEV_BCM5464) {
	    uint16_t shadow, shadow1;

	    xprintf(" REG1C/\n");

	    for (i = 0x18; i <= 0x1F; i++) {
		shadow = (i << 10);
		mii_write(sc, phy_addr, 0x1C, shadow);
		shadow = mii_read(sc, phy_addr, 0x1C);
		shadow1 = mii_read(sc, phy_addr, 0x1C);
		xprintf(" %02X: %04X", i, shadow);
		if (shadow1 != shadow)
		    xprintf("/%04X", shadow1);
		if (i % 4 == 3) xprintf("\n");
		}
	    }
	}
}
#else
/* Keep compiler happy. */
#define phy_dump(sc,phy_addr,label)  ((void)mii_write)
#endif

static portmap_t
phy_scan(bcm5345_state_t *sc)
{
    unsigned int port;
    portmap_t portmap;
    uint8_t phy_addr;
    uint16_t id1, id2;
    int linkspeed;

    portmap = 0;

    for (port = 0; port < GE_PORTS; port++) {

	/* The addresses of external PHYs depend on pin strapping.  The
	   following mapping is the conventional one (used on eval
	   boards); the PHYs are programmed 1-24, in port order. */
	sc->phy_info[port].addr = phy_addr = port+1;

        id1 = mii_read(sc, phy_addr, MII_PHYIDR1);
	id2 = mii_read(sc, phy_addr, MII_PHYIDR2);
	if ((id1 != 0x0000 && id1 != 0xFFFF) ||
	    (id2 != 0x0000 && id2 != 0xFFFF)) {
	    if (id1 != id2) {
		xprintf("port %2d", port);
		if (ROBO_DEBUG) {
		    uint32_t phy_vendor;
		    uint16_t phy_device;
		    phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
		    phy_device = (id2 >> 4) & 0x3F;
		    xprintf(" (phy vendor %06X part %02X)",
			    phy_vendor, phy_device);
		    }
		xprintf(": ");
		linkspeed = mii_status(sc, phy_addr);
		sc->phy_info[port].linkspeed = linkspeed;
		if (linkspeed != ETHER_SPEED_UNKNOWN) {
		    portmap |= GE_BIT(port);
		    phy_dump(sc, phy_addr, "scan");
		    }
		}
	    }
	}
    return portmap;
}


/* Port register access. These are "distributed registers." */

static uint16_t
port_reg_read(bcm5345_state_t *sc, unsigned int reg)
{
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ reg rd %x\n", reg);
	return 0xFFFF;
	}

    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, reg);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_DIST_REGISTER) | V_TBL_MGMT_CMD(K_TBL_READ));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* reg rd %x\n", reg);
	return 0xFFFF;
	}

    return READCSR(sc, R_TABLE_DATA_BUFFER_0);
}

static void
port_reg_write(bcm5345_state_t *sc, unsigned int reg, uint16_t value)
{
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ reg wr %x\n", reg);
	return;
	}

    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, reg);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_0, value);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_DIST_REGISTER) | V_TBL_MGMT_CMD(K_TBL_WRITE));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* reg wr %x\n", reg);
	return;
	}
}

static void
port_dump(bcm5345_state_t *sc, unsigned int port, const char* label)
{
    uint16_t r;

    xprintf("%s, PORT(%d)\n", label, port);

    r = port_reg_read(sc, R_PORT_CONFIG_1(port));
    xprintf(" CFG1: %04x ", r);
    r = port_reg_read(sc, R_PORT_CONFIG_2(port));
    xprintf(" CFG2: %04x ", r);
    r = port_reg_read(sc, R_PORT_CONFIG_3(port));
    xprintf(" CFG3: %04x ", r);
    r = port_reg_read(sc, R_PORT_CONFIG_4(port));
    xprintf(" CFG4: %04x\n", r);

    r = port_reg_read(sc, R_PORT_PRIO_VLAN(port));
    xprintf(" VLAN: %04x ", r);
    r = port_reg_read(sc, R_PORT_STATUS_1(port));
    xprintf(" STS1: %04x ", r);
    port_reg_write(sc, R_PORT_STATUS_2(port), 0);
    r = port_reg_read(sc, R_PORT_STATUS_2(port));
    xprintf(" STS2: %04x\n", r);
}


/* MIB access */

static uint32_t
mib_counter_read(bcm5345_state_t *sc, uint16_t addr)
{
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ mib rd %x\n", addr);
	return 0xFFFF;
	}

    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, addr);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_MIB) | V_TBL_MGMT_CMD(K_TBL_READ));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* mib rd %x\n", addr);
	return 0xFFFF;
	}

    return READCSR(sc, R_TABLE_DATA_BUFFER_0);
}

static void
mib_counter_write(bcm5345_state_t *sc, uint16_t addr, uint32_t value)
{
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ reg wr %x\n", addr);
	return;
	}

    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, addr);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_0, value);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_MIB) | V_TBL_MGMT_CMD(K_TBL_WRITE));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* reg wr %x\n", addr);
	return;
	}
}

#define MIB_ADDR(port,bank,word) ((port)<<8 | (bank)<<4 | (word))

static void
port_stat_zero(bcm5345_state_t *sc, unsigned int port)
{
    unsigned int word;
   
    /* Initialize selected banks, avoiding reserved registers. */
    for (word = 0; word <= 6; word++)
	mib_counter_write(sc, MIB_ADDR(port, 0, word), 0);
    for (word = 0; word <= 3; word++)
	mib_counter_write(sc, MIB_ADDR(port, 1, word), 0);
    for (word = 0; word <= 7; word++)
	mib_counter_write(sc, MIB_ADDR(port, 4, word), 0);
    for (word = 0; word <= 3; word++)
	mib_counter_write(sc, MIB_ADDR(port, 5, word), 0);
}

static void
port_stat_dump(bcm5345_state_t *sc, unsigned int port)
{
    uint32_t count;
    uint32_t ucount, bcount, mcount;

    xprintf("--- port: %d ---\n", port);

    /* Print basic rx stats */
    ucount = mib_counter_read(sc, MIB_ADDR(port, 0, 0));
    bcount = mib_counter_read(sc, MIB_ADDR(port, 0, 1));
    mcount = mib_counter_read(sc, MIB_ADDR(port, 0, 2));
    count = mib_counter_read(sc, MIB_ADDR(port, 5, 2));
    xprintf("RPKT:  %08x   RBYT:  %08x\n", ucount+bcount+mcount, count);
    xprintf("RUCA:  %08x   RMCA:  %08x   RBCA:  %08x\n",
	    ucount, mcount, bcount);

    /* Print error counts if non-zero. */
    count = mib_counter_read(sc, MIB_ADDR(port, 0, 4));
    if (count != 0) xprintf("RFCS:  %08x\n", count);
    count = mib_counter_read(sc, MIB_ADDR(port, 0, 5));
    if (count != 0) xprintf("RALN:  %08x\n", count);
    count = mib_counter_read(sc, MIB_ADDR(port, 0, 6));
    if (count != 0) xprintf("RSYM:  %08x\n", count);

    /* Print basic tx stats */
    ucount = mib_counter_read(sc, MIB_ADDR(port, 1, 0));
    bcount = mib_counter_read(sc, MIB_ADDR(port, 1, 1));
    mcount = mib_counter_read(sc, MIB_ADDR(port, 1, 2));
    count = mib_counter_read(sc, MIB_ADDR(port, 5, 0));
    xprintf("TPKT:  %08x   TBYT:  %08x\n", ucount+bcount+mcount, count);
    xprintf("TUCA:  %08x   TMCA:  %08x   TBCA:  %08x\n",
	    ucount, mcount, bcount);

    xprintf("FWD:   %08x   FLT:   %08x\n",
	    mib_counter_read(sc, MIB_ADDR(port, 4, 0)),
	    mib_counter_read(sc, MIB_ADDR(port, 4, 1)));
			    
    xprintf("-----------------\n");
}


/* Switch management */

static void
port_init(bcm5345_state_t *sc)
{
    unsigned int port;
    uint16_t stat2;

    if (ROBO_DEBUG) {
	port_dump(sc, LINK_PORT, "pre");
	port_dump(sc, CPU_PORT, "pre");
	}

    for (port = 0; port < GE_PORTS; port++) {
	port_reg_write(sc, R_PORT_CONFIG_2(port), /* 0x5680 */
		       M_PCFG2_RX_PAUSE | M_PCFG2_TX_PAUSE |  M_PCFG2_PAUSE |
#if 0   /* Do not set back_jam_en by default (can hang hub). */
		       M_PCFG2_BACK_JAM_EN |
#endif
		       M_PCFG2_ANEG_ENB);
	port_reg_write(sc, R_PORT_CONFIG_3(port), /* 0x17FB */
		       V_PCFG3_MASTER_MODE(0xB) |
		       M_PCFG3_10_HALF  | M_PCFG3_10_FULL |
		       M_PCFG3_100_HALF | M_PCFG3_100_FULL |
		       M_PCFG3_1000_FULL |
		       M_PCFG3_KEEP_DEFAULT | M_PCFG3_DIS_PHY_RESET |
		       M_PCFG3_SKIP_EXPAN);
	stat2 = port_reg_read(sc, R_PORT_STATUS_2(port));
	stat2 &= ~M_PSTAT2_LINK_FAIL;
	port_reg_write(sc, R_PORT_STATUS_2(port), stat2);
	}
}

static void
port_start(bcm5345_state_t *sc)
{
    unsigned int port;

    for (port = 0; port < GE_PORTS; port++) {
	port_reg_write(sc, R_PORT_CONFIG_1(port), /* 0x0483 */
		       V_PCFG1_PORT_ST(K_PORT_FORWARDING) |
		       V_PCFG1_IPG_WD(0x4) |
		       V_PCFG1_PREAMBLE_WD(0x2));
	port_stat_zero(sc, port);
	}

    if (ROBO_DEBUG) {
	port_dump(sc, LINK_PORT, "post");
	port_dump(sc, CPU_PORT, "post");
	port_stat_dump(sc, LINK_PORT);
	}
}

static void
port_stop(bcm5345_state_t *sc)
{
    if (ROBO_DEBUG) {
	port_dump(sc, LINK_PORT, "stop");
	port_dump(sc, CPU_PORT, "stop");
	}

    port_stat_dump(sc, LINK_PORT);
}


/* Address management */

/* Do brute-force lookups and simple FIFO table management for now.  */

typedef struct host_s {
    uint8_t addr[ENET_ADDR_LEN];
    uint8_t port;
    portmap_t portmap;    /* bit map for the local egress port(s) */
} host_t;

#define HOST_TAB_SIZE   16

static host_t hosts[HOST_TAB_SIZE];
static unsigned int last_host, next_host;

static void
host_init(bcm5345_state_t *sc)
{
    memset(hosts, 0, sizeof(hosts));
    last_host = next_host = 0;
}

static int
host_lookup (bcm5345_state_t *sc, uint8_t addr[])
{
    unsigned int i;

    i = last_host;
    do {
	if (memcmp(&hosts[i].addr, addr, ENET_ADDR_LEN) == 0) {
	    last_host = i;
	    return i;
	    }
	i = (i + 1) % HOST_TAB_SIZE;
    } while (i != last_host);

    return -1;
}

static void
host_add (bcm5345_state_t *sc, uint8_t addr[], uint8_t port, portmap_t map)
{
    int i;

    i = host_lookup(sc, addr);
    if (i == -1) {
	i = next_host;
	memcpy(&hosts[i].addr, addr, ENET_ADDR_LEN);

	if (ROBO_DEBUG) xprintf("learn host %d: %a at %02x %08x\n",
				next_host, addr, port, map);

	next_host = (next_host + 1) % HOST_TAB_SIZE;
	}
    hosts[i].port = port;
    hosts[i].portmap = map;
}


/* Auxiliary forwarding  table management. */

static void
vlan_init(bcm5345_state_t *sc, unsigned int vlan)
{
    uint32_t vlan_entry[2];

    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ vlan wr %x\n", vlan);
	return;
	}

    /* XXX A guess at the bit positions (see Figure 4) */
    vlan_entry[0]  = (0x1FFFFFF << 0);   /* (un)tag all ports */
    vlan_entry[0] |= (0x1FFFFFF << 25);  /* bitmap (split) */
    vlan_entry[1]  = (0x1FFFFFF >> (32 - 25));
    vlan_entry[1] |= (0 << 18);          /* spanning tree index */
    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, vlan);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_0, vlan_entry[0]);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_1, vlan_entry[1]);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_VLAN) | V_TBL_MGMT_CMD(K_TBL_WRITE));
    
    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* vlan wr %x\n", vlan);
	return;
	}
}

static void
table_init(bcm5345_state_t *sc, portmap_t portmap)
{
    vlan_init(sc, 0);
    vlan_init(sc, VLAN_DEFAULT);
}

static void
l2_enter(bcm5345_state_t *sc, uint8_t mac_addr[], unsigned int port)
{
    uint32_t l2_entry[3];
  
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ l2 learn\n");
	return;
	}

    /* XXX A guess at the bit positions (see Figure 3). */
    /* These seem to be correct, but the sample chip appears to have a
       stuck bit problem -- on lookup, bits 4, 1 and 0 of the port
       number track the value entered but bits 2 and 3 are stuck at 1.  */
    l2_entry[0] = ((mac_addr[5] <<  0) |
		   (mac_addr[4] <<  8) |
		   (mac_addr[3] << 16) |
		   (mac_addr[2] << 24));
    l2_entry[1] = ((mac_addr[1] <<  0) |
		   (mac_addr[0] <<  8) |
		   (VLAN_DEFAULT << 16) |
		   (0x1 << 28));             /* (valid, valid, static) */
    l2_entry[2] = ((port << 0) |
		   (0x0 << 6));              /* (act, ref) */
    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, 0);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_0, l2_entry[0]);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_1, l2_entry[1]);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_2, l2_entry[2]);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_L2_MAC_ADDR) | V_TBL_MGMT_CMD(K_TBL_LEARN));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* l2 learn\n");
	return;
	}

#if 0  /* Debug readback */
    if (table_wait_ready(sc) != CFE_OK) {
	xprintf("+ l2 learn\n");
	return;
	}
    l2_entry[0] = ((mac_addr[5] <<  0) |
		   (mac_addr[4] <<  8) |
		   (mac_addr[3] << 16) |
		   (mac_addr[2] << 24));
    l2_entry[1] = ((mac_addr[1] <<  0) |
		   (mac_addr[0] <<  8) |
		   (VLAN_DEFAULT << 16));

    WRITECSR(sc, R_TABLE_ACCESS_ENTRY_ID, 0);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_0, l2_entry[0]);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_1, l2_entry[1]);
    WRITECSR(sc, R_TABLE_DATA_BUFFER_2, 0);
    WRITECSR(sc, R_CPU_COMMAND,
	     V_TBL_SEL(K_TBL_L2_MAC_ADDR) | V_TBL_MGMT_CMD(K_TBL_SEARCH));

    if (table_wait_done(sc) != CFE_OK) {
	xprintf("* l2 learn\n");
	return;
	}
    xprintf("l2 lookup: %08x %08x %08x\n",
	    READCSR(sc, R_TABLE_DATA_BUFFER_0),
	    READCSR(sc, R_TABLE_DATA_BUFFER_1),
	    READCSR(sc, R_TABLE_DATA_BUFFER_2));
#endif
}


/* Packet filtering and forwarding. */

static void
filter_init(bcm5345_state_t *sc)
{
    uint16_t l2ctl;
    uint16_t t;

    /* Set up registers/tables with MAC address. */
    t = (sc->hwaddr[0]<<8) | sc->hwaddr[1];
    WRITECSR(sc, R_CUSTOMER_BPDU_0(2), t);
    WRITECSR(sc, R_STATION_MAC_ADDR(2), t);
    t = (sc->hwaddr[2]<<8) | sc->hwaddr[3];
    WRITECSR(sc, R_CUSTOMER_BPDU_0(1), t);
    WRITECSR(sc, R_STATION_MAC_ADDR(1), t);
    t = (sc->hwaddr[4]<<8) | sc->hwaddr[5];
    WRITECSR(sc, R_CUSTOMER_BPDU_0(0), t);
    WRITECSR(sc, R_STATION_MAC_ADDR(0), t);

    /* Add CPU to all port-based VLANs */
    WRITECSR(sc, R_CPU_VLAN_MEMBER_0, 0xFF);
    WRITECSR(sc, R_CPU_VLAN_MEMBER_1, 0xFFFF);

    l2ctl = READCSR(sc, R_L2_CONTROL);
#if 0
    l2ctl &= ~(M_L2CTL_NO_CPU_FLOOD | M_L2CTL_IVL);  /* XXX needed? */
#else
    l2ctl &= ~M_L2CTL_IVL;
#endif
    l2ctl |=  M_L2CTL_NO_CPU_VLAN;
    WRITECSR(sc, R_L2_CONTROL, l2ctl);

#if 0
    WRITECSR(sc, R_TRAP_SNOOP, M_TRAP_BOOT_SNOOP | M_TRAP_ARP_SNOOP);
#endif
}


/* Packet management */

#define ETH_PKTPOOL_SIZE  16

static eth_pkt_t *
eth_alloc_pkt(bcm5345_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *) q_deqnext(&sc->freelist);
    CS_EXIT(sc);
    if (!pkt) return NULL;

    pkt->buffer = pkt->data;
    pkt->length = ETH_PKTBUF_LEN;
    pkt->flags = 0;

    return pkt;
}

static void
eth_free_pkt(bcm5345_state_t *sc, eth_pkt_t *pkt)
{
    CS_ENTER(sc);
    q_enqueue(&sc->freelist, &pkt->next);
    CS_EXIT(sc);
}

static void
eth_initfreelist(bcm5345_state_t *sc)
{
    int idx;
    uint8_t *ptr;
    eth_pkt_t *pkt;

    q_init(&sc->freelist);

    ptr = sc->pktpool;
    for (idx = 0; idx < ETH_PKTPOOL_SIZE; idx++) {
	pkt = (eth_pkt_t *) ptr;
	eth_free_pkt(sc, pkt);
	ptr += ETH_PKTBUF_SIZE;
	}
}


/* Packet DMA Service */

#define MINRXRING     3

static void
bcm5345_dma_init(bcm5345_state_t *sc)
{
    uint32_t dma_ptrs;

    /* Note that register/field names are switch- (not CPU-) centric. */
    dma_ptrs = READCSR(sc, R_DMA_CHANNEL_POINTERS);
    sc->rx_pp = sc->rx_cp = G_DMA_NXT_TX_CH(dma_ptrs);
    sc->tx_pp = sc->tx_cp = G_DMA_NXT_RX_CH(dma_ptrs);
    sc->rx_onring = 0;
    sc->rx_np = sc->tx_np = 0;
}


static int
bcm5345_add_rcvbuf(bcm5345_state_t *sc, eth_pkt_t *pkt)
{
    uint32_t dma_ptrs;
    unsigned int channel, next;
    uint32_t dma_addr;

    channel = sc->rx_pp;
    next = (channel + 1) % N_CHANNELS;

    /* Check for ring full */
    if (next == sc->rx_cp) {
	return -1;
	}

    sc->rx_buffers[channel] = pkt;

    /* Note: on big-endian 47xx systems, using the byte-swapped DRAM
       addresses does not work, presumably because the DMA engine does
       sub-word PCI accesses. */
    dma_addr = PTR_TO_PCI(pkt->buffer);

    if (ROBO_DEBUG) {
	xprintf("add: buffer[%d] %p\n", channel, pkt);
	xprintf("rx +: %p (%08x)\n", pkt->buffer, dma_addr);
	}

    CACHE_SYNC_RANGE(pkt->buffer, pkt->length);

    /* Note that register/field names are switch- (not CPU-) centric. */
    dma_ptrs = READCSR(sc, R_DMA_CHANNEL_POINTERS);
    dma_ptrs &= ~M_DMA_NXT_ALLOC_TX_CH;
    dma_ptrs |= V_DMA_NXT_ALLOC_TX_CH(next);
    WRITECSR(sc, R_TX_DMA_CHANNEL(channel), dma_addr);

    WRITECSR(sc, R_DMA_CHANNEL_POINTERS, dma_ptrs);
    sc->rx_pp = next;

    return 0;
}

static void
bcm5345_fillrxring(bcm5345_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    while (1) {
	if (sc->rx_onring >= MINRXRING) {
	    CS_EXIT(sc);
	    break;
	    }
	CS_EXIT(sc);
	pkt = eth_alloc_pkt(sc);
	if (pkt == NULL) {
	    /* could not allocate a buffer */
	    break;
	    }
	if (bcm5345_add_rcvbuf(sc, pkt) != 0) {
	    /* could not add buffer to ring */
	    eth_free_pkt(sc, pkt);
	    break;
	    }
	CS_ENTER(sc);
	sc->rx_onring++;
	}
}

static void
bcm5345_rx_callback(bcm5345_state_t *sc, eth_pkt_t *pkt)
{
    if (ROBO_DEBUG) show_packet('>', pkt);   /* debug */

    CS_ENTER(sc);
    q_enqueue(&sc->rxqueue, &pkt->next);
    CS_EXIT(sc);
    sc->inpkts++;
}

static void
bcm5345_procrxring(bcm5345_state_t *sc)
{
    uint32_t dma_ptrs;
    unsigned int next;
    /*volatile*/ eth_pkt_t *pkt;
    eth_pkt_t *new_pkt;
    unsigned int channel;
    uint32_t dmar[DMAR_LEN/sizeof(uint32_t)];
    uint32_t np;

    WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, M_IRQ_TX_PKT | M_IRQ_TX_PKT_LAST);

    dma_ptrs = READCSR(sc, R_DMA_CHANNEL_POINTERS);
    next = G_DMA_NXT_TX_CH(dma_ptrs);
    
    channel = sc->rx_cp;
    np = 0;
    while (channel != next) {
	pkt = sc->rx_buffers[channel];
	sc->rx_buffers[channel] = NULL;

	CACHE_SYNC_RANGE(pkt->buffer, DMAR_LEN);
	memcpy(dmar, pkt->buffer, DMAR_LEN);

	if (ROBO_DEBUG) {
	    xprintf("recv: buf[%d], %p, dmar [%08x, %08x]\n",
		    channel, pkt->buffer, dmar[0], dmar[1]);
	    }

	/* DMA delivers the CRC. */
	pkt->length = DMAR_LEN + G_DMAR0_LEN(dmar[0]) - ENET_CRC_SIZE;
	CACHE_SYNC_RANGE(pkt->buffer, pkt->length);

	if (ROBO_DEBUG)
	    xprintf("receive %d\n", pkt->length - DMAR_LEN);

	/* See note above on 47xx endian.  Swap while copying out. */
	swap_buffer((uint32_t *)&pkt->buffer[DMAR_LEN], pkt->length-DMAR_LEN);

	/* Learn src addresses only from unicast.  This assumes that
	   the appropriate egress port is the same as the ingress
	   port.  In an interrupt-driven system, it would be better to
	   defer this, but the dmar information must be saved in that
	   case.  */
	if ((pkt->buffer[DMAR_LEN+0] & 0x01) == 0)
	    host_add(sc, &pkt->buffer[DMAR_LEN+ENET_ADDR_LEN],
		     G_DMAR1_ID(dmar[1]), 
		     GE_BIT(G_DMAR1_ID(dmar[1])));

	bcm5345_rx_callback(sc, (eth_pkt_t *)pkt);
    
	np++;
	channel = (channel + 1) % N_CHANNELS;

	new_pkt = eth_alloc_pkt(sc);
	if (new_pkt) {
	    /* The ring must have space now. */
	    bcm5345_add_rcvbuf(sc, new_pkt);
	    }
	else {
	    CS_ENTER(sc);
	    sc->rx_onring--;
	    CS_EXIT(sc);
	    }
	}
    sc->rx_cp = channel;
    if (np > sc->rx_np) sc->rx_np = np;
}


static int
bcm5345_transmit(bcm5345_state_t *sc, eth_pkt_t *pkt)
{
    portmap_t portmap;
    uint32_t dma_ptrs;
    unsigned int channel, next;
    uint32_t dmat[DMAT_LEN/sizeof(uint32_t)];
    uint32_t dma_addr;

    /* Apparently, the switch can correctly regenerate a CRC only on a
       32-bit boundary.  XXX Note that this will make a maximum-
       length packet 2 bytes too long. */
    pkt->length = (pkt->length + 3) & ~3;

    /* The switch "recomputes" the CRC, does not append it. */
    pkt->length += ENET_CRC_SIZE;

    /* For unicast destinations, use the learned port address if any,
       otherwise broadcast.  */
    if ((pkt->buffer[DMAT_LEN+0] & 0x01) == 0) {
	int i = host_lookup(sc, &pkt->buffer[DMAT_LEN+0]);

	if (i != -1) {
	    portmap = hosts[i].portmap;
	    }
	else {
	    if (ROBO_DEBUG)
		xprintf("DLF host %a\n", &pkt->buffer[DMAT_LEN+0]);
	    portmap = sc->portmap;
	    }
	}
    else {
	portmap = sc->portmap;
        }

    /* Fill in the DMA FIFO control header (per SDK). */
    dmat[0] = (V_DMAT0_DATA |
	       V_DMAT0_VTAG(VLAN_DEFAULT) |
	       M_DMAT0_CRC_REGEN |
	       V_DMAT0_LEN(pkt->length - DMAT_LEN));
    dmat[1] = (V_DMAT1_BITMAP(portmap) |
	       V_DMAT1_QUEUE(3));
    dmat[2] = (V_DMAT2_DATA |
	       V_DMAT2_OTAG(portmap | CPU_BIT));

    memcpy(pkt->buffer, dmat, DMAT_LEN);

    if (ROBO_DEBUG) show_packet('<', pkt);

    /* XXX See note above on 47xx big-endian.  Swap while copying in. */
    swap_buffer((uint32_t *)&pkt->buffer[DMAT_LEN], pkt->length - DMAT_LEN);

    channel = sc->tx_pp;
    next = (channel + 1) % N_CHANNELS;

    /* Check for ring full. */
    if (next == sc->tx_cp) return -1;

    sc->tx_buffers[channel] = pkt;
    
    sync_range(pkt->buffer, pkt->length);

    dma_addr = PTR_TO_PCI(pkt->buffer);

    if (ROBO_DEBUG) {
	xprintf("transmit: %d at %p (%08x)\n",
		pkt->length - DMAT_LEN, pkt->buffer, dma_addr);
	}

    /* Note that register/field names are switch- (not CPU-) centric. */
    dma_ptrs = READCSR(sc, R_DMA_CHANNEL_POINTERS);
    dma_ptrs &= ~M_DMA_NXT_ALLOC_RX_CH;
    dma_ptrs |= V_DMA_NXT_ALLOC_RX_CH(next);
    WRITECSR(sc, R_RX_DMA_CHANNEL(channel), dma_addr);
    WRITECSR(sc, R_DMA_CHANNEL_POINTERS, dma_ptrs);
    sc->tx_pp = next;

    sc->outpkts++;
    return 0;
}

static void
bcm5345_proctxring(bcm5345_state_t *sc)
{
    uint32_t dma_ptrs;
    unsigned int next;
    unsigned int channel;
    uint32_t np;

    WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, M_IRQ_RX_PKT | M_IRQ_RX_PKT_LAST);

    dma_ptrs = READCSR(sc, R_DMA_CHANNEL_POINTERS);
    next = G_DMA_NXT_RX_CH(dma_ptrs);
    
    
    channel = sc->tx_cp;
    np = 0;
    while (channel != next) {
	eth_free_pkt(sc, sc->tx_buffers[channel]);
	sc->tx_buffers[channel] = NULL;
	np++;
	channel = (channel + 1) % N_CHANNELS;
	}
    sc->tx_cp = channel;
    if (np > sc->tx_np) sc->tx_np = np;
}


static void
bcm5345_initrings(bcm5345_state_t *sc)
{
    /* Precharge the receive ring */
    bcm5345_fillrxring(sc);
}

static void
bcm5345_init(bcm5345_state_t *sc)
{
    int i;

   for (i = 0; i < 4; i++)
	sc->tx_buffers[i] = NULL;

    for (i = 0; i < 4; i++)
	sc->rx_buffers[i] = NULL;

    /* Allocate buffer pool */
    sc->pktpool = KMALLOC(ETH_PKTPOOL_SIZE*ETH_PKTBUF_SIZE, CACHE_ALIGN);
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);
}

static void
bcm5345_reinit(bcm5345_state_t *sc)
{
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);
}


/* Hardware initialization */

static void
bcm5345_dump(bcm5345_state_t *sc)
{
    uint32_t r;
    xprintf("--- bcm5345 ---\n");
    r = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
    if (r != 0) xprintf("INT_VECTOR:     %08x\n", r);
    r = READCSR(sc, R_SYSTEM_STATUS);
    if (r != 0) xprintf("SYS_STATUS:     %08x\n", r);
    xprintf("EEPROM_INIT_1:  %04x\n", READCSR(sc, R_EEPROM_INIT_SETUP_1));
    xprintf("PCI_SETUP:      %04x\n", READCSR(sc, R_PCI_SETUP));
    xprintf("-----------------\n");
}


static void
bcm5345_hwinit(bcm5345_state_t *sc)
{
    if (sc->state != eth_state_on) {
	uint32_t cmd;
	uint32_t stat;
	uint32_t setup;
	int i;

	if (ROBO_DEBUG) bcm5345_dump(sc);

	/* XXX This is evidentally too late (CPU_PRST must be from EEPROM). */
	cmd = READCSR(sc, R_EEPROM_INIT_SETUP_1);
	cmd |= M_INIT1_CPU_PRST;
	WRITECSR(sc, R_EEPROM_INIT_SETUP_1, cmd);

	for (i = 1000; i > 0; i--) {
	    stat = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
	    if ((stat & M_IRQ_BIST_DONE)  && (stat & M_IRQ_MEM_INIT_DONE))
		break;
	    cfe_usleep(100);
	    }
        stat = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
	stat &= (M_IRQ_BIST_DONE | M_IRQ_MEM_INIT_DONE);
	WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, stat);

	if ((stat & M_IRQ_BIST_DONE) == 0)
	    xprintf("%s: bcm5345 BIST did not complete\n",
		    bcm5345_devname(sc));
	if ((stat & M_IRQ_MEM_INIT_DONE) == 0)
	    xprintf("%s: bcm5345 memory initialization did not complete\n",
		    bcm5345_devname(sc));

	/* Evidently CPU-driven initialization can start now, even
           without CPU_INIT_START. */

	/* XXX The manual is hopeless on endian.  Try this. */
	setup = READCSR(sc, R_PCI_SETUP);
#if 1   /* XXX Why? */
	setup |= M_PCI_BYTE_SWAP;
#else
	setup &= ~M_PCI_BYTE_SWAP;
#endif
	WRITECSR(sc, R_PCI_SETUP, setup);
	
	/* Map phy address for each port to (port+1) */
	WRITECSR(sc, R_PHY_ADDR, V_AS_PHYAD_START(1) | M_AS_PHYAD_UP);

	sc->portmap = phy_scan(sc);
	xprintf("active port map: %04X\n", sc->portmap);

	table_init(sc, sc->portmap | CPU_BIT);

#if 0
	/* XXX The available sample switch chip creates a black hole
           for CPU packets if the MAC address is entered into the L2
           table.   Rely on CPU flooding for now.

	   It appears that the chip has stuck bit problems;
           see comment in l2_enter. */
	l2_enter(sc, sc->hwaddr, CPU_PORT);
#else
	(void)l2_enter;
#endif
	filter_init(sc);

	port_init(sc);

	/* Start chip operations. */
	cmd = READCSR(sc, R_EEPROM_INIT_SETUP_1);
	cmd |= M_INIT1_CPU_CFGRDY;
	WRITECSR(sc, R_EEPROM_INIT_SETUP_1, cmd);

	port_start(sc);

	bcm5345_dma_init(sc);

	if (ROBO_DEBUG) bcm5345_dump(sc);

	sc->state = eth_state_off;
	}
}


static void
bcm5345_isr(void *arg)
{
    bcm5345_state_t *sc = (bcm5345_state_t *)arg;
    uint32_t irqstat;

    irqstat = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
    irqstat &= (M_IRQ_RX_PKT | M_IRQ_RX_PKT_LAST |
		M_IRQ_TX_PKT | M_IRQ_TX_PKT_LAST);

    if (irqstat == 0) return;
    WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, irqstat);  /* clear pending */

    if (IPOLL) sc->interrupts++;

    if (irqstat & M_IRQ_TX_PKT) {
	if (IPOLL) sc->rx_interrupts++;
	bcm5345_procrxring(sc);
	}

    if (irqstat & M_IRQ_RX_PKT) {
	if (IPOLL) sc->tx_interrupts++;
	bcm5345_proctxring(sc);
	}
}

static void
bcm5345_start(bcm5345_state_t *sc)
{
    uint32_t pending;

    host_init(sc);

    bcm5345_hwinit(sc);

    sc->intmask = 0;

#if IPOLL
    cfe_request_irq(sc->irq, bcm5345_isr, sc, CFE_IRQ_FLAGS_SHARED, 0);
#endif

    WRITECSR(sc, R_CPU_INTERRUPT_MASK, 0xFFFFFFFF);
    pending = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
#if 0
    WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, pending);
#endif
    (void)READCSR(sc, R_CPU_INTERRUPT_VECTOR);   /* push */

    sc->intmask = M_IRQ_TX_PKT | M_IRQ_RX_PKT;

#if IPOLL
    cfe_request_irq(sc->irq, bcm5345_isr, sc, CFE_IRQ_FLAGS_SHARED, 0);
    WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, sc->intmask);
#endif

    bcm5345_initrings(sc);   /* XXX rethink */

    sc->state = eth_state_on;
}

static void
bcm5345_stop(bcm5345_state_t *sc)
{
    uint32_t pending;

    if (ROBO_DEBUG) {
	xprintf("* stop: %08x\n", READCSR(sc, R_DMA_CHANNEL_POINTERS));
	}

    port_stop(sc);
 
    sc->intmask = 0;
    WRITECSR(sc, R_CPU_INTERRUPT_MASK, 0xFFFFFFFF);
    pending = READCSR(sc, R_CPU_INTERRUPT_VECTOR);
    WRITECSR(sc, R_CPU_INTERRUPT_VECTOR, pending);
    (void)READCSR(sc, R_CPU_INTERRUPT_VECTOR);   /* push */
#if IPOLL
    cfe_free_irq(sc->irq, 0);
#endif

    if (sc->state == eth_state_on) {
	sc->state = eth_state_off;
	/* XXX Shutdown the chip */
	bcm5345_reinit(sc);
	}
}


static int bcm5345_open(cfe_devctx_t *ctx);
static int bcm5345_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5345_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat);
static int bcm5345_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5345_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5345_close(cfe_devctx_t *ctx);
static void bcm5345_poll(cfe_devctx_t *ctx, int64_t ticks);
static void bcm5345_reset(void *softc);

const static cfe_devdisp_t bcm5345_dispatch = {
    bcm5345_open,
    bcm5345_read,
    bcm5345_inpstat,
    bcm5345_write,
    bcm5345_ioctl,
    bcm5345_close,	
    bcm5345_poll,
    bcm5345_reset
};

cfe_driver_t bcm5345drv = {
    "BCM534x switch",
    "eth",
    CFE_DEV_NETWORK,
    &bcm5345_dispatch,
    bcm5345_probe
};


static int
bcm5345_attach(cfe_driver_t *drv, pcitag_t tag, uint8_t hwaddr[])
{
    bcm5345_state_t *sc;
    char descr[80];
    phys_addr_t pa;
    pcireg_t device, class;

    pci_map_mem(tag, PCI_MAPREG(0), CSR_MATCH_MODE, &pa);

    sc = (bcm5345_state_t *) KMALLOC(sizeof(bcm5345_state_t), 0);
    if (sc == NULL) {
	xprintf("BCM543x: No memory to complete probe\n");
	return 0;
	}
    memset(sc, 0, sizeof(*sc));

    sc->regbase = (uint32_t)pa;
    sc->irq = pci_conf_read(tag, PCI_BPARAM_INTERRUPT_REG) & 0xFF;

    device = pci_conf_read(tag, PCI_ID_REG);
    class = pci_conf_read(tag, PCI_CLASS_REG);
    sc->tag = tag;
    sc->device = PCI_PRODUCT(device);
    sc->revision = PCI_REVISION(class);

    sc->devctx = NULL;

    /* Always use the MAC address that was passed in. */
    memcpy(sc->hwaddr, hwaddr, ENET_ADDR_LEN);

    bcm5345_init(sc);
    sc->state = eth_state_uninit;

    xsprintf(descr, "BCM5345 Switching Processor at 0x%08X", sc->regbase);
    cfe_attach(drv, sc, NULL, descr);

    return 1;
}

static void
bcm5345_probe(cfe_driver_t *drv,
	      unsigned long probe_a, unsigned long probe_b, 
	      void *probe_ptr)
{
    int index;
    uint8_t hwaddr[ENET_ADDR_LEN];

    if (probe_ptr)
	enet_parse_hwaddr((char *)probe_ptr, hwaddr);
    else {
	/* Use default base address 02-10-18-53-45-01 */
	hwaddr[0] = 0x02;  hwaddr[1] = 0x10;  hwaddr[2] = 0x18;
	hwaddr[3] = 0x53;  hwaddr[4] = 0x45;  hwaddr[5] = 0x01;
	}

    index = 0;
    for (;;) {
	pcitag_t tag;
	pcireg_t device;

	if (pci_find_class(PCI_CLASS_NETWORK, index, &tag) != 0)
	   break;

	index++;

	device = pci_conf_read(tag, PCI_ID_REG);
	if (PCI_VENDOR(device) == K_PCI_VENDOR_BROADCOM) {
	    switch (PCI_PRODUCT(device)) {
		case K_PCI_ID_BCM5345:
		    bcm5345_attach(drv, tag, hwaddr);
		    enet_incr_hwaddr(hwaddr, 1);
		    break;
		default:
		    break;
		}
	    }
	}
}


/* The functions below are called via the dispatch vector for the switch */

static int
bcm5345_open(cfe_devctx_t *ctx)
{
    bcm5345_state_t *sc = ctx->dev_softc;

    if (sc->state == eth_state_on)
	bcm5345_stop(sc);

    sc->devctx = ctx;

    sc->inpkts = sc->outpkts = 0;
    sc->interrupts = 0;
    sc->rx_interrupts = sc->tx_interrupts = 0;

    bcm5345_start(sc);

    if (XPOLL) bcm5345_isr(sc);
    return 0;
}

static int
bcm5345_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm5345_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) bcm5345_isr(sc);

    if (sc->state != eth_state_on) return -1;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *)q_deqnext(&sc->rxqueue);
    CS_EXIT(sc);

    if (pkt == NULL) {
	buffer->buf_retlen = 0;
	return 0;
	}

    blen = buffer->buf_length - DMA_RX_HDR_LEN;
    if (blen > pkt->length) blen = pkt->length;

    /* Remove the DMA FIFO control header. */
    hs_memcpy_to_hs(buffer->buf_ptr, pkt->buffer + DMA_RX_HDR_LEN, blen);
    buffer->buf_retlen = blen;

    eth_free_pkt(sc, pkt);

    if (XPOLL) bcm5345_isr(sc);
    return 0;
}

static int
bcm5345_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    bcm5345_state_t *sc = ctx->dev_softc;

    if (XPOLL) bcm5345_isr(sc);

    if (sc->state != eth_state_on) return -1;

    /* We avoid an interlock here because the result is a hint and an
       interrupt cannot turn a non-empty queue into an empty one. */
    inpstat->inp_status = (q_isempty(&(sc->rxqueue))) ? 0 : 1;

    return 0;
}

static int
bcm5345_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm5345_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) bcm5345_isr(sc);

    if (sc->state != eth_state_on) return -1;

    pkt = eth_alloc_pkt(sc);
    if (!pkt) return CFE_ERR_NOMEM;

    blen = buffer->buf_length;
    if (blen > pkt->length - DMA_TX_HDR_LEN)
	blen = pkt->length - DMA_TX_HDR_LEN;

    /* Reserve space for the DMA control as a prefix. */
    memset(pkt->buffer, 0, DMA_TX_HDR_LEN);

    hs_memcpy_from_hs(pkt->buffer+DMA_TX_HDR_LEN, buffer->buf_ptr, blen);
    if (blen < ENET_MIN_PKT) {
	memset(pkt->buffer + DMA_TX_HDR_LEN + blen, 0, ENET_MIN_PKT - blen);
	blen = ENET_MIN_PKT;
	}
    pkt->length = blen + DMA_TX_HDR_LEN;

    if (bcm5345_transmit(sc, pkt) != 0) {
	eth_free_pkt(sc, pkt);
	return CFE_ERR_IOERR;
	}

    if (XPOLL) bcm5345_isr(sc);
    return 0;
}

static int
bcm5345_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    bcm5345_state_t *sc = ctx->dev_softc;

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_ETHER_GETHWADDR:
	    hs_memcpy_to_hs(buffer->buf_ptr, sc->hwaddr, sizeof(sc->hwaddr));
	    return 0;

	default:
	    return -1;
	}
}

static int
bcm5345_close(cfe_devctx_t *ctx)
{
    bcm5345_state_t *sc = ctx->dev_softc;

    bcm5345_stop(sc);

    xprintf("%s: %d sent, %d received",
	    bcm5345_devname(sc), sc->outpkts, sc->inpkts);
    if (IPOLL) {
	xprintf(", %d interrupts\n", sc->interrupts);
	xprintf("  %d tx interrupts, %d rx interrupts",
		sc->tx_interrupts, sc->rx_interrupts);

	}
    xprintf(", tx_np %d, rx_np %d", sc->tx_np, sc->rx_np);
    xprintf("\n");

    sc->devctx = NULL;
    return 0;
}

static void
bcm5345_poll(cfe_devctx_t *ctx, int64_t ticks)
{
    bcm5345_state_t *sc = ctx->dev_softc;

    if (XPOLL) bcm5345_isr(sc);
}

static void
bcm5345_reset(void *softc)
{
    bcm5345_state_t *sc = (bcm5345_state_t *)softc;

    /* Turn off the Ethernet interface. */

    if (sc->state == eth_state_on)
	bcm5345_stop(sc);

    sc->state = eth_state_uninit;
}
