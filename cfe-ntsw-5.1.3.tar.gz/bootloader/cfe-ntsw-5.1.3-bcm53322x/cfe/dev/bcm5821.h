/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5821 cryptoaccelerator		       File: bcm5821.h
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#ifndef _BCM5821_H_
#define _BCM5821_H_

/* Register and field definitions for the Broadcom BCM5821 crypto
   accelerator.  The BCM5820 implements a compatible (modulo bugs)
   subset of the BCM5821. */

#define K_PCI_VENDOR_BROADCOM    0x14e4
#define K_PCI_ID_BCM5820         0x5820
#define K_PCI_ID_BCM5821         0x5821
#define K_PCI_ID_BCM5822         0x5822
#define K_PCI_ID_BCM5823         0x5823

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))


/* DMA Control and Status Register offsets */

#define R_MCR1                   0x00
#define R_DMA_CTRL               0x04
#define R_DMA_STAT               0x08
#define R_DMA_ERR                0x0C
#define R_MCR2                   0x10


/* 0x00  MCR1@: Master Command Record 1 Address */
/* 0x10  MCR2@: Master Command Record 2 Address */

/* See cfe_crypto.h for the formats of the command records. */


/* 0x04  DMA Control */

#define  M_DMA_CTRL_WR_BURST     _DD_MAKEMASK1(16)   /* Not 5820 */

#define  K_DMA_WR_BURST_128      0
#define  K_DMA_WR_BURST_240      M_DMA_CRTL_WR_BURST

#define M_DMA_CTRL_MOD_NORM      _DD_MAKEMASK1(22)
#define M_DMA_CTRL_RNG_MODE      _DD_MAKEMASK1(23)
#define M_DMA_CTRL_DMAERR_EN     _DD_MAKEMASK1(25)
#define M_DMA_CTRL_NORM_PCI      _DD_MAKEMASK1(26)   /* Not 5820 */
#define M_DMA_CTRL_LE_CRYPTO     _DD_MAKEMASK1(27)   /* Not 5820 */
#define M_DMA_CTRL_MCR1_INT_EN   _DD_MAKEMASK1(29)
#define M_DMA_CTRL_MCR2_INT_EN   _DD_MAKEMASK1(30)
#define M_DMA_CTRL_RESET         _DD_MAKEMASK1(31)


/* 0x08  DMA Status */

#define M_DMA_STAT_MCR2_EMPTY    _DD_MAKEMASK1(24)   /* Not 5820 */
#define M_DMA_STAT_MCR1_EMPTY    _DD_MAKEMASK1(25)   /* Not 5820 */
#define M_DMA_STAT_MCR2_INTR     _DD_MAKEMASK1(26)
#define M_DMA_STAT_MCR2_FULL     _DD_MAKEMASK1(27)
#define M_DMA_STAT_DMAERR_INTR   _DD_MAKEMASK1(28)
#define M_DMA_STAT_MCR1_INTR     _DD_MAKEMASK1(29)
#define M_DMA_STAT_MCR1_FULL     _DD_MAKEMASK1(30)
#define M_DMA_STAT_MSTR_ACCESS   _DD_MAKEMASK1(31)

/* 0x0C  DMA Error Address */

#define M_DMA_ERR_RD_FAULT       _DD_MAKEMASK1(1)
#define M_DMA_ERR_ADDR           0xFFFFFFFC


#endif /* _BCM_5821_H_ */
