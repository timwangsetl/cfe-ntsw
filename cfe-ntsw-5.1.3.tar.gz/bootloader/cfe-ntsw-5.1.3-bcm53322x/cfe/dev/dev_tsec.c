/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *********************************************************************
    *
    *  Copyright 2007
    *  Broadcom Corporation. All rights reserved.
    *     
    *  This software is furnished under license and may be used and
    *  copied only in accordance with the following terms and  
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified
    *  copies of this software in source and/or binary form.  No title
    *  or ownership is transferred hereby.
    *     
    *  1) Any source code used, modified or distributed must reproduce
    *     and retain this copyright notice and list of conditions
    *     as they appear in the source file.
    *
    *  2) No right is granted to use any trade name, trademark, or
    *     logo of Broadcom Corporation.  The "Broadcom Corporation"
    *     name may not be used to endorse or promote products derived
    *     from this software without the prior written permission of
    *     Broadcom Corporation.
    *
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#include "cfe.h"
#include "bcmnvram.h"

#include "lib_physio.h"
#include "cfe_irq.h"
#include "net_enet.h"
#include "pcivar.h"
#include "pcireg.h"
#include "mii.h"
#include "bcm_cmn.h"
#include "env_subr.h"
#include "dev_tsec.h"

#ifdef CPUCFG_MEMCPY
extern void *CPUCFG_MEMCPY(void *dest, const void *src, size_t cnt);
#define blockcopy(d, s, l) CPUCFG_MEMCPY((void*)a, (void*)b, l)
#else
#define blockcopy(d, s, l) memcpy((void*)d, (void*)s, l)
#endif

#if CFG_INTERRUPTS
#define CS_ENTER(sc) cfe_disable_irq(sc->irq)
#define CS_EXIT(sc)  cfe_enable_irq(sc->irq)
#else
#define CS_ENTER(sc) ((void)0)
#define CS_EXIT(sc)  ((void)0)
#endif

#ifndef XPOLL
#define XPOLL 1
#endif

#define DPRINT  if (0) printf

struct tsec_dev_s;

typedef struct phy_drv_s {
    uint32_t id;
    char *name;
    uint32_t shift;
    /* PHY Driver vectors */
    int (*init)(struct tsec_dev_s *sc);
    int (*reset)(struct tsec_dev_s *sc);
    int (*autoneg)(struct tsec_dev_s *sc);
    int (*getmode)(struct tsec_dev_s *sc, uint32_t *duplex, uint32_t *speed);
    int (*setmode)(struct tsec_dev_s *sc, uint32_t duplex, uint32_t speed);
} phy_drv_t;

static int phy_bcm5461s_init(struct tsec_dev_s *sc);
static int phy_bcm5461s_reset(struct tsec_dev_s *sc);
static int phy_bcm5461s_autoneg(struct tsec_dev_s *sc);
static int phy_bcm5461s_getmode(struct tsec_dev_s *sc, uint32_t *duplex, uint32_t *speed);
static int phy_bcm5461s_setmode(struct tsec_dev_s *sc, uint32_t duplex, uint32_t speed);
static int phy_bcm5482s_init(struct tsec_dev_s *sc);

phy_drv_t phy_drv_bcm5461s = {
	0x2060c,
	"Broadcom BCM5461S",
	4,
        phy_bcm5461s_init,
        phy_bcm5461s_reset,
        phy_bcm5461s_autoneg,
        phy_bcm5461s_getmode,
        phy_bcm5461s_setmode
};

phy_drv_t phy_drv_bcm5482 = {
	0x143bcb,
	"Broadcom BCM5482",
	4,
        phy_bcm5482s_init,
        phy_bcm5461s_reset,
        phy_bcm5461s_autoneg,
        phy_bcm5461s_getmode,
        phy_bcm5461s_setmode
};

phy_drv_t *phy_info[] = {
	&phy_drv_bcm5461s,
	&phy_drv_bcm5482,
	NULL
};

typedef enum {
    eth_state_uninit,
    eth_state_off,
    eth_state_on, 
} eth_state_t;

#define TX_BD_CNT	  8
#define RX_BD_CNT	  8

#define TSEC_BD_BUFSIZE         \
        ((TSEC_RX_BD_SIZE * RX_BD_CNT) + (TSEC_TX_BD_SIZE * TX_BD_CNT) + 128)

typedef struct tsec_dev_s {

    uint32_t    regbase;
    uint32_t    phybase;
    uint8_t     hwaddr[ENET_ADDR_LEN];

    uint32_t    phy_vendor;
    uint32_t    phy_device;
    
    uint32_t    phy_addr;
    uint32_t    phy_intf_type;
    phy_drv_t * phyinfo;
    uint32_t    link;
    uint32_t    duplexity;
    uint32_t    speed;

    uint8_t     bdbuf[TSEC_BD_BUFSIZE];

    /* TX BD ring */
    tsec_txbd_t     *txbd;
    /* index of the current TX buffer */
    uint32_t    txIdx;
    uint32_t    txIsrIdx;

    /* RX BD ring */
    tsec_rxbd_t     *rxbd;
    /* index of the current RX buffer */
    uint32_t    rxIdx;

    eth_state_t state;             /* current state */

    /* packet free lists */
    queue_t     freelist;
    uint8_t     *pktpool;
    queue_t     rxqueue;

    int         txbusy;
    int         restartrx;

    cfe_devctx_t *devctx;

    uint32_t    unit;           /* local mod_id */

    /* additional driver statistics */
    uint32_t    inpkts;
    uint32_t    outpkts;
    uint32_t    interrupts;
    uint32_t    rx_interrupts;
    uint32_t    tx_interrupts;
    uint32_t    tx_errors;
    uint32_t    rx_errors;
    uint32_t    rx_alloc_errors;
    uint32_t    rx_queued;
} tsec_dev_t;

#define TSEC_RX_BDRING(sc, idx)  ((sc)->rxbd + (idx))
#define TSEC_RX_BD_INDEX(sc)    (sc)->rxIdx

#define TSEC_TX_BDRING(sc, idx)  ((sc)->txbd + (idx))
#define TSEC_TX_BD_INDEX(sc)    (sc)->txIdx

static uint32_t tsec_get_next_index(uint32_t idx, uint32_t rlen)
{
    return (idx == (rlen - 1)) ? 0 : idx + 1;
}

#define MAX_UNIT_NUM    (4)

static tsec_dev_t *dev_cb[MAX_UNIT_NUM];

#define READCSR(sc,csr) (phys_read32((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->regbase + (csr), (val)))

#define READPHY(sc,csr)      (phys_read32((sc)->phybase + (csr)))
#define WRITEPHY(sc,csr,val) (phys_write32((sc)->phybase + (csr), (val)))


static void init_registers(tsec_dev_t *sc);
static void tsec_probe(cfe_driver_t *drv, unsigned long probe_a, 
                    unsigned long probe_b, void *probe_ptr);
static int tsec_open(cfe_devctx_t *ctx);
static int tsec_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int tsec_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat);
static int tsec_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int tsec_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int tsec_close(cfe_devctx_t *ctx);
static void tsec_poll(cfe_devctx_t *ctx, int64_t ticks);
static void tsec_stop(void *softc);
static int tsec_hwinit(tsec_dev_t *sc);
static void tsec_set_mac_mode(tsec_dev_t *sc, uint32_t duplex, uint32_t speed);
static int tsec_set_speed(tsec_dev_t *sc, int speed);

#if 1
uint16_t phy_mii_read(int mac, int reg);
void phy_mii_write(int mac, int reg, uint16_t val);
#endif

const static cfe_devdisp_t tsec_dispatch = {
    tsec_open,
    tsec_read,
    tsec_inpstat,
    tsec_write,
    tsec_ioctl,
    tsec_close,	
    tsec_poll,
    tsec_stop
};

cfe_driver_t tsecdrv = {
    "MPC854X TSEC DRIVER",
    "eth",
    CFE_DEV_NETWORK,
    &tsec_dispatch,
    tsec_probe
};

#define ETH_PKTPOOL_SIZE  64

#define MIN_ETHER_PACK  (ENET_MIN_PKT+ENET_CRC_SIZE)   /* size of min packet */
#define MAX_ETHER_PACK  (ENET_MAX_PKT+ENET_CRC_SIZE)   /* size of max packet */
#define VLAN_TAG_LEN    4                              /* VLAN type plus tag */
#define MAX_VLAN_PACK   (MAX_ETHER_PACK+VLAN_TAG_LEN)
#define ETH_PKTBUF_LEN      (((MAX_VLAN_PACK+31)/32)*32)

#define V_MIIM_CONTROL_RESET	(BMCR_RESET | BMCR_ANENABLE |\
                                 BMCR_DUPLEX | BMCR_SPEED1)
#define V_MIIM_CONTROL_INIT       (BMCR_ANENABLE | BMCR_DUPLEX | BMCR_SPEED1)
#define V_MIIM_CONTROL_RESTART    (BMCR_ANENABLE | BMCR_RESTARTAN |\
                                 BMCR_DUPLEX | BMCR_SPEED1)

#define V_MIIM_ANAR_INIT		(0x1E1)

#if __long64
typedef struct eth_pkt_s {
    queue_t next;			/* 16 */
    uint8_t *buffer;			/*  8 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;
#else
typedef struct eth_pkt_s {
    queue_t next;			/*  8 */
    uint8_t *buffer;			/*  4 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint32_t unused[3];			/* 12 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;
#endif

#define CACHE_ALIGN       32
#define ETH_PKTBUF_LINES  ((sizeof(eth_pkt_t) + (CACHE_ALIGN-1))/CACHE_ALIGN)
#define ETH_PKTBUF_SIZE   (ETH_PKTBUF_LINES*CACHE_ALIGN)
#define ETH_PKTBUF_OFFSET (offsetof(eth_pkt_t, data))

#define ETH_PKT_BASE(data) ((eth_pkt_t *)((data) - ETH_PKTBUF_OFFSET))

static eth_pkt_t *
eth_alloc_pkt(tsec_dev_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *) q_deqnext(&sc->freelist);
    CS_EXIT(sc);
    if (!pkt) {
        DPRINT("eth_alloc_pkt failed\n");
        return NULL;
    }

    pkt->buffer = pkt->data;
    pkt->length = ETH_PKTBUF_LEN;
    pkt->flags = 0;

    DPRINT("PKT-Alloc: 0x%08x\n", pkt);
    return pkt;
}

static void
eth_free_pkt(tsec_dev_t *sc, eth_pkt_t *pkt)
{
    DPRINT("PKT-free: 0x%08x\n", pkt);
    CS_ENTER(sc);
    q_enqueue(&sc->freelist, &pkt->next);
    CS_EXIT(sc);
}

static void
eth_initfreelist(tsec_dev_t *sc)
{
    int idx;
    uint8_t *ptr;
    eth_pkt_t *pkt;

    q_init(&sc->freelist);

    ptr = sc->pktpool;
    for (idx = 0; idx < ETH_PKTPOOL_SIZE; idx++) {
        pkt = (eth_pkt_t *) ptr;
        eth_free_pkt(sc, pkt);
        ptr += ETH_PKTBUF_SIZE;
    }
}

/* MII access */
static uint16_t
mii_read(tsec_dev_t *sc, int reg)
{
    uint32_t rval;
    uint32_t phyid = sc->phy_addr;

    /* Put the address of the phy, and the register
     * number into MIIMADD */
    WRITEPHY(sc, R_TSEC_MIIMADD_OFFSET, (phyid << 8) | reg);

    /* Clear the command register, and wait */
    WRITEPHY(sc, R_TSEC_MIIMCOM_OFFSET, 0);
    asm("sync");

    /* Initiate a read command, and wait */
    WRITEPHY(sc, R_TSEC_MIIMCOM_OFFSET, V_MIIM_READ_COMMAND);
    asm("sync");

    /* Wait for the the indication that the read is done */
    rval = READPHY(sc, R_TSEC_MIIMIND_OFFSET);
    while((rval & (V_MIIMIND_NOTVALID | V_MIIMIND_BUSY))) {
        cfe_usleep(1);
        rval = READPHY(sc, R_TSEC_MIIMIND_OFFSET);
    }

    /* Grab the value read from the PHY */
    rval = READPHY(sc, R_TSEC_MIIMSTAT_OFFSET);

    DPRINT("mii_read(%d): reg: %d val 0x%04x\n", phyid, reg, (uint16_t) rval);
    return (uint16_t) rval;
}

static void
mii_write(tsec_dev_t *sc, int reg, uint16_t value)
{
    uint32_t phyid = sc->phy_addr;
    int timeout=10000;
    uint32_t rval;

    DPRINT("mii_write(%d): reg: %d val 0x%04x\n",phyid, reg, value);
    WRITEPHY(sc, R_TSEC_MIIMADD_OFFSET, (phyid << 8) | reg);
    WRITEPHY(sc, R_TSEC_MIIMCON_OFFSET, value);
    asm("sync");

    rval = READPHY(sc, R_TSEC_MIIMIND_OFFSET);
    while((rval & V_MIIMIND_BUSY) && timeout--) {
        cfe_usleep(10);
        rval = READPHY(sc, R_TSEC_MIIMIND_OFFSET);
    }
    if (timeout == 0) {
        xprintf("mii_write failed \n");
    } 
}

static int
mii_probe(tsec_dev_t *sc)
{
    uint16_t    id1, id2, ii;
    uint32_t    phy_id, rval;

    WRITEPHY(sc, R_TSEC_MIIMCFG_OFFSET, V_MIIMCFG_RESET);
    asm("sync");
    WRITEPHY(sc, R_TSEC_MIIMCFG_OFFSET, V_MIIMCFG_INIT_VALUE);
    asm("sync");

    rval = READPHY(sc, R_TSEC_MIIMIND_OFFSET);
    while(rval & V_MIIMIND_BUSY) {
        cfe_usleep(10);
        rval = READPHY(sc, R_TSEC_MIIMIND_OFFSET);
    }

    id1 = mii_read(sc, MII_PHYIDR1);
    id2 = mii_read(sc, MII_PHYIDR2);
    if (id2 != 0x0000 && id2 != 0xFFFF) {
        sc->phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
        sc->phy_device = (id2 >> 4) & 0x3F;
        DPRINT("phy %d, vendor %06x part %02x\n",
                sc->phy_addr, sc->phy_vendor, sc->phy_device);
    
        /* get the phy driver for this phy */
        phy_id = (id1 << 16) | id2;
        for(ii=0; phy_info[ii]; ii++) {
            if(phy_info[ii]->id == (phy_id >> phy_info[ii]->shift)) {
                sc->phyinfo = phy_info[ii];
            }
        }

        if (sc->phyinfo == NULL) {
            xprintf("No phy driver support for PHYID %x\n", 
                    (phy_id >> phy_info[ii]->shift));
            return -1;
        }

        sc->phyinfo->reset(sc);
        sc->phyinfo->init(sc);
        sc->phyinfo->autoneg(sc);

        return 0;
    }

    return -1;
}

/***************** phy driver ************************/
static int phy_bcm5461s_reset(tsec_dev_t *sc)
{
    mii_write(sc, MII_BMCR, V_MIIM_CONTROL_RESET);
    cfe_usleep(1000);

    return 0;
}

static int phy_bcm5461s_init(tsec_dev_t *sc)
{
    mii_write(sc, MII_BMCR, V_MIIM_CONTROL_RESET);
    cfe_usleep(100);

    mii_write(sc, 0x1c, 0xfc08);
    
    mii_write(sc, MII_ANAR, V_MIIM_ANAR_INIT);
    mii_write(sc, MII_BMCR, V_MIIM_CONTROL_INIT);

    return 0;
}

static int phy_bcm5461s_autoneg(tsec_dev_t *sc)
{
    uint16_t rval;

    rval = mii_read(sc, MII_BMCR);
    mii_write(sc, MII_BMCR, (rval | BMCR_RESTARTAN));
  
    return 0;
}

#define DEBUG_PHY   1
static int phy_bcm5461s_getmode(tsec_dev_t *sc, uint32_t *dup, 
                                uint32_t *speed)
{
    uint16_t status = 0, remote, xremote;
    int linkspeed = ETHER_SPEED_UNKNOWN;

    status = mii_read(sc, MII_BMSR);
    status = mii_read(sc, MII_BMSR);
   
    if ((status & (BMSR_AUTONEG | BMSR_LINKSTAT))
	!= (BMSR_AUTONEG | BMSR_LINKSTAT)) {
        DPRINT("Autoneg failed\n");
            return ETHER_SPEED_UNKNOWN;
    }

    remote = mii_read(sc, MII_ANLPAR);

    if ((status & BMSR_ANCOMPLETE) != 0) {
        /* A link partner was negogiated... */

        if (status & BMSR_1000BT_XSR)
            xremote = mii_read(sc, MII_K1STSR);
        else
            xremote = 0;

        if ((xremote & K1STSR_LP1KFD) != 0) {
#if DEBUG_PHY
            xprintf("1000BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_1000FDX;
            *dup = 1;
            *speed = 1000;
        }
        else if ((xremote & K1STSR_LP1KHD) != 0) {
#if DEBUG_PHY
            xprintf("1000BaseT HDX\n");
#endif
            linkspeed = ETHER_SPEED_1000HDX;
            *dup = 0;
            *speed = 1000;
        }
        else if ((remote & ANLPAR_TXFD) != 0) {
#if DEBUG_PHY
            xprintf("100BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_100FDX;
            *dup = 1;
            *speed = 100;
        }
        else if ((remote & ANLPAR_TXHD) != 0) {
#if DEBUG_PHY
            xprintf("100BaseT HDX\n");
#endif
            linkspeed = ETHER_SPEED_100HDX;
            *dup = 0;
            *speed = 100;
        }
        else if ((remote & ANLPAR_10FD) != 0) {
#if DEBUG_PHY
            xprintf("10BaseT FDX\n");
#endif
            linkspeed = ETHER_SPEED_10FDX;
            *dup = 1;
            *speed = 10;
        }
        else if ((remote & ANLPAR_10HD) != 0) {
#if DEBUG_PHY
            xprintf("10BaseT HDX\n");
#endif            
            linkspeed = ETHER_SPEED_10HDX;
            *dup = 0;
            *speed = 10;
        }
    }
    else {
        /* no link partner convergence */
#if DEBUG_PHY
        xprintf("NC\n");
#endif        
        linkspeed = ETHER_SPEED_UNKNOWN;
        remote = xremote = 0;
    }
    return linkspeed;
}

static int phy_bcm5461s_setmode(tsec_dev_t *sc, uint32_t dup, 
                                uint32_t speed)
{
    /* FIXME */
    return 0;
}

static int phy_bcm5482s_init(tsec_dev_t *sc)
{
    mii_write(sc, MII_BMCR, V_MIIM_CONTROL_RESET);
    cfe_usleep(100);
    mii_write(sc, MII_ANAR, V_MIIM_ANAR_INIT);
    mii_write(sc, MII_BMCR, V_MIIM_CONTROL_INIT);
    
    return 0;
}


static void tsec_procrxring(tsec_dev_t *sc)
{
    eth_pkt_t *pkt, *new_pkt;
    tsec_rxbd_t *prxbd;
    
    prxbd = sc->rxbd + sc->rxIdx;

    while(!(prxbd->status & RXBD_EMPTY)) {

        pkt = ETH_PKT_BASE(prxbd->bufPtr);

        /* Send the packet up if there were no errors */
        if (!(prxbd->status & RXBD_ERROR_MASK)) {
            DPRINT("RX-IRQ: good packet on idx-%d\n", sc->rxIdx);
            new_pkt = eth_alloc_pkt(sc);

            if (new_pkt) {
                pkt->length = prxbd->length;
                CS_ENTER(sc);
                q_enqueue(&sc->rxqueue, &pkt->next);
                sc->rx_queued++;
                CS_EXIT(sc);
                sc->inpkts++;
                pkt = new_pkt;
            } else {
                sc->rx_alloc_errors++;
            }

            prxbd->bufPtr = (uint32_t) pkt->buffer;
        } else {
            DPRINT("RX-IRQ: bad packet on idx-%d\n", sc->rxIdx);
            DPRINT("Got error %x\n",
                   (prxbd->status & RXBD_ERROR_MASK));
            sc->rx_errors++;
        }

        prxbd->length = 0;

        /* Set the wrap bit if this is the last element in the list */
        prxbd->status = RXBD_EMPTY | RXBD_INTERRUPT |
                    (((sc->rxIdx + 1) == RX_BD_CNT) ? RXBD_WRAP : 0);

        sc->rxIdx = (sc->rxIdx + 1) % RX_BD_CNT;
        prxbd = sc->rxbd + sc->rxIdx;
    }
}

static void tsec_proctxchain(tsec_dev_t *sc)
{
    eth_pkt_t *pkt;
    tsec_txbd_t   *ptxbd;
    uint32_t    iidx, i;

    iidx = sc->txIsrIdx;

    for(iidx = sc->txIsrIdx; iidx != sc->txIdx; 
          iidx = tsec_get_next_index(iidx, TX_BD_CNT)) {

        ptxbd = sc->txbd + iidx;

        for(i=0; ptxbd->status & TXBD_READY; i++) {
            DPRINT("TX-IRQ: idx-%d still in use\n", iidx);
            sc->txIsrIdx = iidx;
            return;
        }

        DPRINT("TX-IRQ: idx-%d processed\n", iidx);
        /* Just free the packet */
        pkt = ETH_PKT_BASE(ptxbd->bufPtr);
        eth_free_pkt(sc, pkt);
        ptxbd->bufPtr = 0;

        if (ptxbd->status & TXBD_ERROR_MASK) {
            sc->tx_errors++;
        }

    }

    sc->txIsrIdx = iidx;
    return;
}

static void tsec_isr(void *arg)
{
    tsec_dev_t *sc = (tsec_dev_t *)arg;
    uint32_t irqstat = READCSR(sc, R_TSEC_IEVENT_OFFSET);

    sc->interrupts++;

    if (irqstat & (V_IEVENT_RXF0 | V_IEVENT_BSY)) {
        DPRINT("RX-IRQ: Status:0x%08x\n", irqstat);
        sc->rx_interrupts++;
        tsec_procrxring(sc);
    }

    if (irqstat & V_IEVENT_TXF) {
        DPRINT("TX-IRQ: Status:0x%08x\n", irqstat);
        sc->tx_interrupts++;
        tsec_proctxchain(sc);
    }

    WRITECSR(sc, R_TSEC_IEVENT_OFFSET, irqstat);

    if(irqstat & V_IEVENT_BSY) {
        DPRINT("BUSY-IRQ: Status:0x%08x\n", irqstat);
        DPRINT("RX-PKT queue : %d\n", sc->rx_queued);
        WRITECSR(sc, R_TSEC_RSTAT_OFFSET, V_RSTAT_CLEAR_RHALT);
    }
}

static void tsec_purge_bd_rings(tsec_dev_t *sc, int tx, int rx)
{
    eth_pkt_t *pkt;
    tsec_txbd_t   *ptxbd;
    tsec_rxbd_t   *prxbd;
    uint32_t    iidx;

    if (tx) {
        for(iidx = 0; iidx < TX_BD_CNT; iidx++) {
            ptxbd = sc->txbd + iidx;
            if (ptxbd->bufPtr) {
                pkt = ETH_PKT_BASE(ptxbd->bufPtr);
                eth_free_pkt(sc, pkt);
                ptxbd->bufPtr = 0;
            }
        }
    }

    if (rx) {
        for(iidx = 0; iidx < RX_BD_CNT; iidx++) {
            prxbd = sc->rxbd + iidx;
            if (prxbd->bufPtr) {
                pkt = ETH_PKT_BASE(prxbd->bufPtr);
                eth_free_pkt(sc, pkt);
                prxbd->bufPtr = 0;
            }
        }
    }

    return;
}

/* Initialize device structure. Returns success if PHY
 * initialization succeeded (i.e. if it recognizes the PHY)
 */
static void
tsec_probe(cfe_driver_t *drv, 
           unsigned long probe_a, unsigned long probe_b, 
           void *probe_ptr)
{
    uint8_t hwaddr[ENET_ADDR_LEN];
    tsec_dev_t *sc;
    uint32_t    index = probe_a;
    char        descr[80];

    if (index >= MAX_UNIT_NUM) {
        xprintf ("Invalid tsec controller (%d). Unit (0-3)\n", index);
        return;
    }

    if (dev_cb[index]) {
        xprintf ("tsec controller %d already initialized\n", index);
        return;
    }

    sc = KMALLOC(sizeof(tsec_dev_t), 0);
    if (sc == NULL) {
        xprintf("tsecdrv: No memory to complete probe\n");
        return;
    }

    memset(sc, 0, sizeof(*sc));

    sc->regbase = TSEC_BASE_ADDR + (index*TSEC_REG_SPACE_SICE);
    sc->phybase = TSEC_BASE_ADDR;
    sc->phy_addr = TSEC_PHY_ADDR(probe_b);
    sc->phy_intf_type = TSEC_IF_TYPE(probe_b);
    sc->unit = index;

    sc->txIdx = 0;
    sc->rxIdx = 0;

    sc->txbd = (tsec_txbd_t*)((((uint32_t)&sc->bdbuf[0]) + 64) & 0xffffffc0);
    sc->rxbd = (tsec_rxbd_t*)(sc->txbd + TX_BD_CNT); 

    if (probe_ptr)
        enet_parse_hwaddr((char *)probe_ptr, hwaddr);
    else {
        hwaddr[0] = 0x00;  hwaddr[1] = 0x00;  hwaddr[2] = 0x85;
        hwaddr[3] = 0x48;  hwaddr[5] = 0x00;
        hwaddr[4] = 0xe0 + index;
    }

    memcpy(sc->hwaddr, hwaddr, ENET_ADDR_LEN);

    dev_cb[index] = sc;

    tsec_hwinit(sc);

    xsprintf(descr, "MPC854X TSEC%d at 0x%08X PHYBASE 0x%08X", 
             sc->unit, sc->regbase, sc->phybase);
    cfe_attach(drv, sc, NULL, descr);

    sc->state = eth_state_off;
    return;
}

static int tsec_reset(tsec_dev_t *sc)
{
    WRITECSR(sc, R_TSEC_MACCFG1_OFFSET, V_MACCFG1_SOFT_RESET);
    cfe_usleep(10);
    WRITECSR(sc, R_TSEC_MACCFG1_OFFSET, 0);

    return 0;
}

static int tsec_hwinit(tsec_dev_t *sc)
{
    uint8_t     tmpbuf[6];
    uint32_t    i, ift;

    tsec_reset(sc);

    cfe_usleep(100);

    mii_probe(sc);

    /* Select Nibble/Byte mode */
    ift = (sc->phy_intf_type == TSEC_IF_MODE_MII) ? 
                                        V_MACCFG2_MII : V_MACCFG2_GMII;

    /* Init MACCFG2.  */
    WRITECSR(sc, R_TSEC_MACCFG2_OFFSET, (V_MACCFG2_INIT_SETTINGS | ift));

    /* Init ECNTRL */
    if (sc->phy_intf_type == TSEC_IF_MODE_GMII) {
        ift = V_ECNTRL_GMII_MODE;
    } else if (sc->phy_intf_type == TSEC_IF_MODE_RGMII) {
        ift = V_ECNTRL_GMII_MODE | V_ECNTRL_RPM;
    } else if (sc->phy_intf_type == TSEC_IF_MODE_MII) {
        ift = 0;
    } else {
        xprintf("Error : Invalid interface type (%d)\n", sc->phy_intf_type);
    }
    WRITECSR(sc, R_TSEC_ECNTRL_OFFSET, (V_ECNTRL_INIT_SETTINGS | ift));
    /* Copy the station address into the address registers. */
    for(i=0;i<MAC_ADDR_LEN;i++) {
        tmpbuf[MAC_ADDR_LEN - 1 - i] = sc->hwaddr[i];
    }
    WRITECSR(sc, R_TSEC_MACSTNADDR1_OFFSET, *((uint32_t *)(tmpbuf)));
    WRITECSR(sc, R_TSEC_MACSTNADDR2_OFFSET, *((uint32_t *)(tmpbuf + 4)));

    /* Clear out (for the most part) the other registers */
    init_registers(sc);

    return 0;
}

static int tsec_open(cfe_devctx_t *ctx)
{
    uint32_t i, duplex, speed, linkspeed;
    volatile tsec_rxbd_t *prxbd;
    volatile tsec_txbd_t *ptxbd;
    eth_pkt_t * pkt;
    tsec_dev_t *sc = ctx->dev_softc;
    uint32_t    rval;

    sc->devctx = ctx;
    
    tsec_hwinit(sc);

    /* Point to the buffer descriptors */
    WRITECSR(sc, R_TSEC_TBASE_OFFSET, (unsigned int)sc->txbd);
    WRITECSR(sc, R_TSEC_RBASE_OFFSET, (unsigned int)sc->rxbd);

    /* Allocate buffer pool */
    sc->pktpool = KMALLOC(ETH_PKTPOOL_SIZE*ETH_PKTBUF_SIZE, CACHE_ALIGN);
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);

    sc->rx_queued = 0;

    /* reset the indices to zero */
    sc->rxIdx = 0;
    sc->txIdx = 0;
    sc->txIsrIdx = 0;

    /* Initialize the Rx Buffer descriptors */
    prxbd = sc->rxbd;
    for (i = 0; i < RX_BD_CNT; i++) {
        pkt = eth_alloc_pkt(sc);
        if (pkt == NULL) {
            xprintf("Failed to alloc packet bufffer for RX BD ring.\n");
            return CFE_ERR_NOMEM;
        }
        prxbd->status = RXBD_EMPTY | RXBD_INTERRUPT;
        prxbd->length = 0;
        prxbd->bufPtr = (uint32_t) pkt->buffer;
        DPRINT("RXBD-%d at 0x%08x\n", i, prxbd);
        prxbd++;
    }
    prxbd = sc->rxbd + (RX_BD_CNT - 1);
    prxbd->status |= RXBD_WRAP;


    /* Initialize the TX Buffer Descriptors */
    ptxbd = sc->txbd;
    for(i=0; i<TX_BD_CNT; i++) {
        ptxbd->status = 0;
        ptxbd->length = 0;
        ptxbd->bufPtr = 0;
        DPRINT("TXBD-%d at 0x%08x\n", i, ptxbd);
        ptxbd++;
    }
    ptxbd = sc->txbd + (TX_BD_CNT - 1);
    ptxbd->status |= TXBD_WRAP;

    /* Get PHY mode (speed and duplexity ) */
    for (i = 0; i < 8; i++) {
        linkspeed = sc->phyinfo->getmode(sc, &duplex, &speed);
        if (linkspeed != ETHER_SPEED_UNKNOWN) {
            break;
        }
        cfe_sleep(CFE_HZ/2);
    }

    sc->duplexity = duplex;
    sc->speed = speed;
    if (linkspeed != ETHER_SPEED_UNKNOWN) {
        tsec_set_mac_mode(sc, duplex, speed);
    } else {
        xprintf("Auto-neg failed \n");
    }

    /* Enable Transmit and Receive */
    rval = READCSR(sc, R_TSEC_MACCFG1_OFFSET);
    WRITECSR(sc, R_TSEC_MACCFG1_OFFSET, 
                rval | V_MACCFG1_RX_EN | V_MACCFG1_TX_EN);

    /* Tell the DMA it is clear to go */
    rval = READCSR(sc, R_TSEC_DMACTRL_OFFSET);
    WRITECSR(sc, R_TSEC_DMACTRL_OFFSET, rval | V_DMACTRL_INIT_SETTINGS);

    WRITECSR(sc, R_TSEC_TSTAT_OFFSET, V_TSTAT_CLEAR_THALT);

    rval = READCSR(sc, R_TSEC_DMACTRL_OFFSET);
    rval &= ~(V_DMACTRL_GRS | V_DMACTRL_GTS);
    WRITECSR(sc, R_TSEC_DMACTRL_OFFSET, rval);

    /* Enable tsec interrupts */
    WRITECSR(sc, R_TSEC_IEVENT_OFFSET, (V_IEVENT_TXF | V_IEVENT_RXF0));

    sc->state = eth_state_on;
    return 0;
}

static void init_registers(tsec_dev_t * sc)
{
    /* Clear IEVENT */
    WRITECSR(sc, R_TSEC_IEVENT_OFFSET, V_IEVENT_INIT_CLEAR);
    WRITECSR(sc, R_TSEC_IMASK_OFFSET, V_IMASK_INIT_CLEAR);

    WRITECSR(sc, R_TSEC_HASH_IADDR0_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_IADDR1_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_IADDR2_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_IADDR3_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_IADDR4_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_IADDR5_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_IADDR6_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_IADDR7_OFFSET, 0);

    WRITECSR(sc, R_TSEC_HASH_GADDR0_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_GADDR1_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_GADDR2_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_GADDR3_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_GADDR4_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_GADDR5_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_GADDR6_OFFSET, 0);
    WRITECSR(sc, R_TSEC_HASH_GADDR7_OFFSET, 0);

    WRITECSR(sc, R_TSEC_RCTRL_OFFSET, 0x00000000);
    WRITECSR(sc, R_TSEC_MRBLR_OFFSET, V_MRBLR_INIT_SETTINGS);
    WRITECSR(sc, R_TSEC_MINFLR_OFFSET, V_MINFLR_INIT_SETTINGS);

    WRITECSR(sc, R_TSEC_ATTR_OFFSET, ATTR_INIT_SETTINGS);
    WRITECSR(sc, R_TSEC_ATTRELI_OFFSET, ATTRELI_INIT_SETTINGS);
}


/* Configure maccfg2 based on negotiated speed and duplex
 * reported by PHY handling code */
static void tsec_set_mac_mode(tsec_dev_t *sc, uint32_t duplex, uint32_t speed)
{
    uint32_t val, ectl;

    DPRINT("MAC-Init: speed : %d\n", speed);

    val = READCSR(sc, R_TSEC_MACCFG2_OFFSET);
    val &= ~(M_MACCFG2_FULL_DUPLEX);
    val |= M_MACCFG2_ADD_CRC;

    if(sc->duplexity) {
        val |= M_MACCFG2_FULL_DUPLEX;
    } 

    WRITECSR(sc, R_TSEC_MACCFG2_OFFSET, val);
    val &= ~(M_MACCFG2_IF);
    ectl = READCSR(sc, R_TSEC_ECNTRL_OFFSET);
    ectl &= 0xffffff80;
    switch(sc->speed) {
        case 1000:
            val |= V_MACCFG2_GMII;
            WRITECSR(sc, R_TSEC_MACCFG2_OFFSET, val);
            if (sc->phy_intf_type == TSEC_IF_MODE_RGMII) {
                ectl |= V_ECNTRL_GMII_MODE | V_ECNTRL_RPM;
            } else if (sc->phy_intf_type == TSEC_IF_MODE_GMII) {
                ectl |= V_ECNTRL_GMII_MODE;
            }
            WRITECSR(sc, R_TSEC_ECNTRL_OFFSET, ectl);
            break;

        case 100:
        case 10:
            val |= V_MACCFG2_MII;
            WRITECSR(sc, R_TSEC_MACCFG2_OFFSET, val);
            if (sc->phy_intf_type == TSEC_IF_MODE_RGMII) {
                ectl |= V_ECNTRL_GMII_MODE | V_ECNTRL_RPM | 
                        ((sc->speed == 100) ? V_ECNTRL_R100 : 0);
            } 
            WRITECSR(sc, R_TSEC_ECNTRL_OFFSET, ectl);
            break;
        default:
            printf("tsec: Speed was bad\n");
            break;
    }

    printf("Speed: %d, %s duplex\n", sc->speed,
           (sc->duplexity) ? "full" : "half");

}

static int tsec_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    int i;
    tsec_dev_t * sc = ctx->dev_softc;
    volatile tsec_txbd_t *ptxbd;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) tsec_isr(sc);

    if (tsec_get_next_index(sc->txIdx, TX_BD_CNT) == sc->txIsrIdx) {
        return CFE_ERR_NOMEM;
    }

    pkt = eth_alloc_pkt(sc);
    if (!pkt) return CFE_ERR_NOMEM;

    blen = buffer->buf_length;
    if (blen > pkt->length) blen = pkt->length;

    blockcopy(pkt->buffer, buffer->buf_ptr, blen);

    if (blen < ENET_MIN_PKT) {
        memset(pkt->buffer + blen, 0, ENET_MIN_PKT - blen);
        blen = ENET_MIN_PKT;
    }

    pkt->length = blen;

    ptxbd = sc->txbd + sc->txIdx;
    for(i=0; ptxbd->status & TXBD_READY; i++) {
        if (i >= 1000000) {
            xprintf("tsec: tx buffers full\n");
            eth_free_pkt(sc,pkt);
            return CFE_ERR_IOERR;
        }
    }
    ptxbd->bufPtr = (uint32_t) pkt->buffer;
    ptxbd->length = blen;
    ptxbd->status |= (TXBD_READY | TXBD_LAST | TXBD_CRC | TXBD_INTERRUPT);

    DPRINT("TX PKT (len:%d) L:0x%04x S:0x%04x P:0x%08x\n", 
       blen, ptxbd->length, ptxbd->status, ptxbd->bufPtr);

    /* Tell the DMA to go */
    WRITECSR(sc, R_TSEC_TSTAT_OFFSET, V_TSTAT_CLEAR_THALT);

    sc->txIdx = (sc->txIdx + 1) % TX_BD_CNT;

    sc->outpkts++;

    if (XPOLL) tsec_isr(sc);
    return 0;

}

static int tsec_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    tsec_dev_t * sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) tsec_isr(sc);

    if (sc->state != eth_state_on) {
        DPRINT("RX-READ failed. Not ready\n");
        return -1;
    }

    CS_ENTER(sc);
    pkt = (eth_pkt_t *)q_deqnext(&(sc->rxqueue));
    CS_EXIT(sc);

    if (pkt == NULL) {
        buffer->buf_retlen = 0;
        return 0;
    }

    blen = buffer->buf_length;
    if (blen > pkt->length) blen = pkt->length;

    blockcopy(buffer->buf_ptr, pkt->buffer, blen);
    buffer->buf_retlen = blen;

    eth_free_pkt(sc, pkt);
    sc->rx_queued--;

    DPRINT("TSEC-READ: consumed pkt(len:%d). Still %d remain \n", buffer->buf_retlen,
           sc->rx_queued);

    if (XPOLL) tsec_isr(sc);

    return 0;
}

static int
tsec_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    tsec_dev_t *sc = ctx->dev_softc;

    if (XPOLL) tsec_isr(sc);

    if (sc->state != eth_state_on) return -1;

    /* We avoid an interlock here because the result is a hint and an
       interrupt cannot turn a non-empty queue into an empty one. */
    inpstat->inp_status = (q_isempty(&(sc->rxqueue))) ? 0 : 1;

    return 0;
}

static int
tsec_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    tsec_dev_t *sc = ctx->dev_softc;
    int   speed;

    switch ((int)buffer->buf_ioctlcmd) {
        case IOCTL_ETHER_GETHWADDR:
            memcpy((void*)buffer->buf_ptr, sc->hwaddr, sizeof(sc->hwaddr));
            return 0;

	case IOCTL_ETHER_SETHWADDR:
	    return -1;    /* not supported */

	case IOCTL_ETHER_GETSPEED:
	    speed = sc->speed;
	    hs_memcpy_to_hs(buffer->buf_ptr, &speed, sizeof(speed));
	    return 0;

	case IOCTL_ETHER_SETSPEED:
	    hs_memcpy_from_hs(&speed,buffer->buf_ptr, sizeof(speed));
	    tsec_set_speed(sc, speed);
	    return -1;    /* not supported yet */

	case IOCTL_ETHER_GETLINK:
	    speed = sc->duplexity;
	    hs_memcpy_to_hs(buffer->buf_ptr, &speed, sizeof(speed));
	    return 0;

        default:
            return -1;
    }
}

static int tsec_set_speed(tsec_dev_t *sc, int speed)
{
    /* FIXME : Not implemented */
    return 0;
}

static void
tsec_poll(cfe_devctx_t *ctx, int64_t ticks)
{
    tsec_dev_t *sc = ctx->dev_softc;

    if (XPOLL) tsec_isr(sc);
}

static void
tsec_stop(void *softc)
{
    tsec_dev_t *sc = (tsec_dev_t *)softc;
    uint32_t    rval, count;

    /* Turn off the Ethernet interface. */

    if (sc->state == eth_state_on) {
        rval = READCSR(sc, R_TSEC_TSTAT_OFFSET);
        WRITECSR(sc, R_TSEC_TSTAT_OFFSET, rval);
        rval = READCSR(sc, R_TSEC_RSTAT_OFFSET);
        WRITECSR(sc, R_TSEC_RSTAT_OFFSET, rval);

        rval = READCSR(sc, R_TSEC_DMACTRL_OFFSET);
        WRITECSR(sc, R_TSEC_DMACTRL_OFFSET, rval | V_DMACTRL_GTS);

        rval = READCSR(sc, R_TSEC_IEVENT_OFFSET);
        count = 1000000;
        while (((rval & V_IEVENT_GTSC) == 0) && (--count)) {
            rval = READCSR(sc, R_TSEC_IEVENT_OFFSET);
        }

        WRITECSR(sc, R_TSEC_IEVENT_OFFSET, V_IEVENT_GTSC);

        cfe_usleep(20000);

        rval = READCSR(sc, R_TSEC_MACCFG1_OFFSET);
        rval &= ~( V_MACCFG1_RX_EN | V_MACCFG1_TX_EN);
        WRITECSR(sc, R_TSEC_MACCFG1_OFFSET, rval);

        rval = READCSR(sc, R_TSEC_DMACTRL_OFFSET);
        WRITECSR(sc, R_TSEC_DMACTRL_OFFSET, rval | V_DMACTRL_GRS);

        rval = READCSR(sc, R_TSEC_IEVENT_OFFSET);
        count = 1000000;
        while (((rval & V_IEVENT_GRSC) == 0) && (--count)) {
            rval = READCSR(sc, R_TSEC_IEVENT_OFFSET);
        }

        WRITECSR(sc, R_TSEC_IEVENT_OFFSET, V_IEVENT_GRSC);

        cfe_usleep(40000);

        /* 
         * Dont reset TSEC controller as VxWorks TSEC driver relies 
         * on some of the configuration specifically reduced pin mode
         * by reading the R_TSEC_MACCFG1_OFFSET register.
         * Just disable Tx/RX portion of the controller.
         */
        rval = READCSR(sc, R_TSEC_MACCFG1_OFFSET);
        rval |= (V_MACCFG1_RESET_RX_MC | V_MACCFG1_RESET_TX_MC | 
                 V_MACCFG1_RESET_RX_FUN | V_MACCFG1_RESET_TX_FUN);
        WRITECSR(sc, R_TSEC_MACCFG1_OFFSET, rval);

        /*
         * Free resources.
         */
        tsec_purge_bd_rings(sc, 1, 1);

        KFREE(sc->pktpool);
    }

    sc->state = eth_state_uninit;
}

static const char *
tsec_devname(tsec_dev_t *sc)
{
    return (sc->devctx != NULL ? cfe_device_name(sc->devctx) : "eth?");
}

static int
tsec_close(cfe_devctx_t *ctx)
{
    tsec_dev_t *sc = ctx->dev_softc;

    tsec_stop(sc);

    xprintf("%s: %d sent, %d received, %d interrupts rx_alloc_err %d\n",
        tsec_devname(sc), sc->outpkts, sc->inpkts, sc->interrupts, sc->rx_alloc_errors);
    xprintf("  %d tx interrupts, %d rx interrupts tx_err %d rx_err %d\n",
        sc->tx_interrupts, sc->rx_interrupts, sc->tx_errors, sc->rx_errors);

    sc->tx_interrupts = 0;
    sc->rx_interrupts = 0;
    sc->tx_errors = 0;
    sc->rx_errors = 0;
    sc->rx_alloc_errors = 0;
    sc->outpkts = 0;
    sc->inpkts = 0;
    sc->devctx = NULL;

    return 0;
}

#if 1
uint16_t phy_mii_read(int mac, int reg)
{
    tsec_dev_t *dev = dev_cb[mac];

    return mii_read(dev, reg);
}
void phy_mii_write(int mac, int reg, uint16_t val)
{
    tsec_dev_t *dev = dev_cb[mac];

    return mii_write(dev, reg, val);
}
#endif

