/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BC5821 crypto accelerator driver	File: dev_bcm5821.c
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

/*
   CFE Driver for the BCM5820, BCM5821 and BCM5823 crypto coprocessor
   chips.  It provides only a minimal interface to the hardware, primarily
   via ioctl calls.

   Reference:
     BCM5821 Super-eCommerce Processor
     Data Sheet 5821-DS105-D1 (draft, 7/26/02)
     Broadcom Corp., 16215 Alton Parkway, Irvine, CA.
*/

#include "cfe.h"
#include "lib_physio.h"
#include "pcivar.h"
#include "pcireg.h"

#include "cfe_crypto.h"
#include "bcm5821.h"

#ifndef CRYPTO_DEBUG
#define CRYPTO_DEBUG 0
#endif

static void bcm5821_probe(cfe_driver_t *drv,
			  unsigned long probe_a, unsigned long probe_b, 
			  void *probe_ptr);


/* Address mapping macros */

/* Note that PTR_TO_PHYS only works with 32-bit addresses, but then
   so does the bcm528x. */
#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((void *)KERNADDR(a))

#if ENDIAN_BIG
/* For the 5821 and successors, all mappings through the PCI host
   bridge use match bits mode.  This works because the NORM_PCI bit in
   DMA Control is clear.  The 5820 does not have such a bit, so
   pointers to data byte sequences use match bytes, but control blocks
   and pointers to them use match bits. */

#else /* !ENDIAN_BIG */
#undef PHYS_TO_PCI
#undef PCI_TO_PHYS
#define PHYS_TO_PCI(a) ((uint32_t) (a))
#define PCI_TO_PHYS(a) ((uint32_t) (a))
#endif

#define READCSR(sc,csr)      (phys_read32((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->regbase + (csr), (val)))


typedef struct bcm5821_state_s {
    uint32_t  regbase;
    uint8_t irq;
    pcitag_t tag;		/* tag for configuration registers */

    uint16_t device;            /* chip device code */
    uint8_t revision;           /* chip revision */

    cfe_devctx_t *devctx;

    crypto_info_t info;         /* chip capabilities */
} bcm5821_state_t;


static void
dumpcsrs(bcm5821_state_t *sc, const char *legend)
{
    xprintf("%s:\n", legend);
    xprintf("---DMA---\n");
    /* DMA control and status registers */
    xprintf("MCR1: %08X  CTRL: %08X  STAT: %08X  ERR:  %08X\n",
	    READCSR(sc, R_MCR1), READCSR(sc, R_DMA_CTRL), 
	    READCSR(sc, R_DMA_STAT), READCSR(sc, R_DMA_ERR));
    xprintf("MCR2: %08X\n", READCSR(sc, R_MCR2));
    xprintf("---------\n");
}


static void
bcm5821_hwinit(bcm5821_state_t *sc)
{
    uint32_t ctrl;
    uint32_t status;

    ctrl = (M_DMA_CTRL_MCR1_INT_EN | M_DMA_CTRL_MCR2_INT_EN |
	    M_DMA_CTRL_DMAERR_EN);
#if ENDIAN_BIG
    if (sc->info.chip == BCM5820)
      ctrl |= (M_DMA_CTRL_NORM_PCI | M_DMA_CTRL_LE_CRYPTO);
    /* Note for 5821: M_DMA_CTRL_NORM_PCI, M_DMA_CTRL_LE_CRYPTO not set. */
#else
    ctrl |= (M_DMA_CTRL_NORM_PCI | M_DMA_CTRL_LE_CRYPTO);
#endif
#if 0  /* Empirically, this reduces performance. */
    if (sc->info.chip != BCM5820)
      ctrl |= M_DMA_CTRL_WR_BURST;
#endif
    WRITECSR(sc, R_DMA_CTRL, ctrl);

    status = READCSR(sc, R_DMA_STAT);
    WRITECSR(sc, R_DMA_STAT, status);    /* reset write-to-clear bits */
    status = READCSR(sc, R_DMA_STAT);

    if (CRYPTO_DEBUG) dumpcsrs(sc, "init");
}


static void
bcm5821_start(bcm5821_state_t *sc)
{
    bcm5821_hwinit(sc);
}

static void
bcm5821_stop(bcm5821_state_t *sc)
{
    WRITECSR(sc, R_DMA_CTRL, 0);
}


/* Utilities */

static int
bcm5821_do_cmd(bcm5821_state_t *sc, int port, uint32_t *mcr)
{
    uint32_t status;
    int i;
    static const int R_MCR[2+1] = {
	0, R_MCR1,          R_MCR2};
    static const uint32_t M_DMA_STAT_MCR_FULL[2+1] = {
	0, M_DMA_STAT_MCR1_FULL, M_DMA_STAT_MCR2_FULL};

    if (port != 1 && port != 2)
	return -1;

    status = READCSR(sc, R_DMA_STAT);
    WRITECSR(sc, R_DMA_STAT, status);    /* clear pending bits */
    status = READCSR(sc, R_DMA_STAT);

    for (i = 0; i < 10000; i++) {
	status = READCSR(sc, R_DMA_STAT);
	if ((status & M_DMA_STAT_MCR_FULL[port]) == 0)
	    break;
	cfe_usleep(10);
	}
    if (i == 10000) {
	if (CRYPTO_DEBUG) dumpcsrs(sc, "bcm5821: full bit never clears");
	return -1;
	}

    WRITECSR(sc, R_MCR[port], PHYS_TO_PCI(PTR_TO_PHYS(mcr)));

    for (i = 0; i < 10000; i++) {
	if ((mcr[0] & M_MCR_DONE) != 0)
	    break;
	cfe_usleep(10);
	}
    if (i == 10000) {
	if (CRYPTO_DEBUG) dumpcsrs(sc, "bcm5821: done bit never sets");
	/*return -1;*/
	}

    status = READCSR(sc, R_DMA_STAT);
    WRITECSR(sc, R_DMA_STAT, status);    /* clear pending bits */
    cfe_usleep(100);

    return 0;
}


static int bcm5821_open(cfe_devctx_t *ctx);
static int bcm5821_read(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int bcm5821_inpstat(cfe_devctx_t *ctx,iocb_inpstat_t *inpstat);
static int bcm5821_write(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int bcm5821_ioctl(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int bcm5821_close(cfe_devctx_t *ctx);

const static cfe_devdisp_t bcm5821_dispatch = {
    bcm5821_open,
    bcm5821_read,
    bcm5821_inpstat,
    bcm5821_write,
    bcm5821_ioctl,
    bcm5821_close,	
    NULL,
    NULL
};

cfe_driver_t bcm5821drv = {
    "BCM582x crypto",
    "crypt",
    CFE_DEV_OTHER,
    &bcm5821_dispatch,
    bcm5821_probe
};


static int
bcm5821_attach(cfe_driver_t *drv, pcitag_t tag, int index)
{
    bcm5821_state_t *sc;
    char descr[80];
    phys_addr_t pa;
    uint32_t base;
    pcireg_t device, class;

    pci_map_mem(tag, PCI_MAPREG(0), PCI_MATCH_BITS, &pa);
    base = (uint32_t)pa;

    sc = (bcm5821_state_t *) KMALLOC(sizeof(bcm5821_state_t),0);
    if (sc == NULL) {
	xprintf("BCM5821: No memory to complete probe\n");
	return 0;
	}

    memset(sc, 0, sizeof(*sc));

    sc->regbase = base;

    sc->irq = pci_conf_read(tag, PCI_BPARAM_INTERRUPT_REG) & 0xFF;

    device = pci_conf_read(tag, PCI_ID_REG);
    class = pci_conf_read(tag, PCI_CLASS_REG);

    sc->tag = tag;
    sc->device = PCI_PRODUCT(device);
    sc->revision = PCI_REVISION(class);
    switch (sc->device) {
	case K_PCI_ID_BCM5820:  sc->info.chip = BCM5820;  break;
	default:
	case K_PCI_ID_BCM5821:  sc->info.chip = BCM5821;  break;
	case K_PCI_ID_BCM5822:  sc->info.chip = BCM5822;  break;
	case K_PCI_ID_BCM5823:  sc->info.chip = BCM5823;  break;
	}

    sc->devctx = NULL;

    xsprintf(descr, "BCM%04X Crypto at 0x%08X", sc->device, base);
    cfe_attach(drv, sc, NULL, descr);

    return 1;
}

static void
bcm5821_probe(cfe_driver_t *drv,
	      unsigned long probe_a, unsigned long probe_b, 
	      void *probe_ptr)
{
    int index;
    int n;

    n = 0;
    index = 0;
    for (;;) {
	pcitag_t tag;
	pcireg_t device;

	if (pci_find_class(PCI_CLASS_PROCESSOR, index, &tag) != 0)
	   break;

	index++;

	device = pci_conf_read(tag, PCI_ID_REG);
	if (PCI_VENDOR(device) == K_PCI_VENDOR_BROADCOM) {
	    if (PCI_PRODUCT(device) == K_PCI_ID_BCM5820 ||
		PCI_PRODUCT(device) == K_PCI_ID_BCM5821 ||
		PCI_PRODUCT(device) == K_PCI_ID_BCM5823) {
		bcm5821_attach(drv, tag, n);
		n++;
		}
	    }
	}
}


/* The functions below are called via the dispatch vector for the 5821 */

static int
bcm5821_open(cfe_devctx_t *ctx)
{
    bcm5821_state_t *sc = ctx->dev_softc;

    sc->devctx = ctx;
    bcm5821_start(sc);
    return 0;
}

static int
bcm5821_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    return -1;
}

static int
bcm5821_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    return 0;
}

static int
bcm5821_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    return -1;
}

static int
bcm5821_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    bcm5821_state_t *sc = ctx->dev_softc;

    /* Note: This driver assumes the caller will use 32-bit pointers */

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_CRYPTO_GETINFO:
	    *((crypto_info_t *)HSADDR2PTR(buffer->buf_ptr)) = sc->info;
	    break;
	case IOCTL_CRYPTO_CMD_1:
	    bcm5821_do_cmd(sc, 1, (uint32_t *)HSADDR2PTR(buffer->buf_ptr));
	    break;
	case IOCTL_CRYPTO_CMD_2:
	    bcm5821_do_cmd(sc, 2, (uint32_t *)HSADDR2PTR(buffer->buf_ptr));
	    break;
	default:
	    return -1;
	}

    return 0;
}

static int
bcm5821_close(cfe_devctx_t *ctx)
{
    bcm5821_state_t *sc = ctx->dev_softc;

    bcm5821_stop(sc);
    sc->devctx = NULL;
    return 0;
}
