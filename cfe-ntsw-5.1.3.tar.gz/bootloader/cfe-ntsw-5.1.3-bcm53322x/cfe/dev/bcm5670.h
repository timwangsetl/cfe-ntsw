/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5670 XGS HiGig Switch Fabric		File: bcm5670.h
    *  
    *  Author: Ed Satterthwaite
    *
    *********************************************************************  
    *
    *  Copyright 2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

#ifndef _BCM5670_H_
#define _BCM5670_H_

/* Register and field definitions for the Broadcom BCM567x family of
   XGS Multi-port HiGig Switch Fabric.

   Support is primarily for the CPU interface (CMIC) and its
   associated DMA.

   Reference:

       BCM5670/BCM5671 Programmer's Reference Guide
       Document 5670_5671-PG01-R (08/26/03)
       Broadcom Corp., 1625 Alton Parkway, Irvine CA.
*/

#define _DD_MAKEMASK1(n) (1 << (n))
#define _DD_MAKEMASK(v,n) ((((1)<<(v))-1) << (n))
#define _DD_MAKEVALUE(v,n) ((v) << (n))
#define _DD_GETVALUE(v,n,m) (((v) & (m)) >> (n))


/* Known devices. */

#define K_PCI_VENDOR_BROADCOM    0x14e4
#define K_PCI_ID_BCM5670         0x5670
#define K_PCI_ID_BCM5671         0x5671


/* Basic Switch Geometry */

#define CMIC_PORT                0
#define HIGIG_PORTS              8      /* 4 (1, 3, 6, 8) on 5671 */

/* Various bit maps have a standard bit position for each relevant port. */
#define HIGIG_BIT(port)          (1 << (port))
#define CMIC_BIT                 (1 << CMIC_PORT)
#define PORT_BIT(port)           (1 << (port))


/* Header formats. */

#define K_HDR_MODE_IEEE          0x0
#define K_HDR_MODE_HIGIG         0x1
#define K_HDR_MODE_ALLLYR        0x2

/* XGS (HiGig) packet header format. */

#define K_HIGIG_START            0xFB
#define K_HIGIG_HGI              0x80

#define K_HIGIG_OP_CPU           0x0
#define K_HIGIG_OP_UC            0x1
#define K_HIGIG_OP_BC            0x2             /* or DLF */
#define K_HIGIG_OP_MC            0x3
#define K_HIGIG_OP_IPMC          0x4

#define XGS_HDR_LEN              12



/* PCI-accessible CSRs and their fields. (Section 4) */

/* Extensions to PCI configuration registers */

#define PCI_TIMEOUT_REG          0x40

#define PCI_TRDY_SHIFT           0
#define PCI_TRDY_MASK            0xFF

#define PCI_RETRY_SHIFT          8
#define PCI_RETRY_MASK           0xFF



/* CMIC Registers in PCI Memory Space (Section 5) */

#define R_CMIC_SCHAN_MESSAGE     0x0000
#define R_CMIC_SCHAN_CTRL        0x0050
#define R_CMIC_SCHAN_ERR         0x005C
#define R_CMIC_DMA_CTRL          0x0100
#define R_CMIC_DMA_STAT          0x0104
#define R_CMIC_CONFIG            0x010C
#define R_CMIC_DMA_DESC(ch)      (0x0110+4*(ch))   /* 0 <= ch <= 3 */

#define R_CMIC_I2C_SLAVE_ADDR    0x0120
#define R_CMIC_I2C_DATA          0x0124
#define R_CMIC_I2C_CTRL          0x0128
#define R_CMIC_I2C_STAT          0x012C
#define R_CMIC_I2C_SLAVE_XADDR   0x0130
#define R_CMIC_I2C_RESET         0x013C

#define R_CMIC_LINK_STAT         0x0140
#define R_CMIC_IRQ_STAT          0x0144
#define R_CMIC_IRQ_MASK          0x0148
#define R_CMIC_MIIM_PARAM        0x0158
#define R_CMIC_MIIM_READ_DATA    0x015C
#define R_CMIC_SCAN_PORTS        0x0160
#define R_CMIC_STAT_DMA_ADDR     0x0164
#define R_CMIC_STAT_DMA_SETUP    0x0168
#define R_CMIC_STAT_DMA_PORTS    0x016C
#define R_CMIC_ENDIANESS_SEL     0x0174
#define R_CMIC_DEVICE_ID         0x0178
#define R_CMIC_CLK_ENABLE        0x017C
#define R_CMIC_MMUIRQ_STAT       0x01A0
#define R_CMIC_MMUIRQ_MASK       0x01A4
#define R_CMIC_PKT_HEADER        0x01A8

#define R_CMIC_SCHAN_MSG_DMA     0x0800   /* alias */

#define R_CMIC_LED_CONTROL       0x1000
#define R_CMIC_LED_STATUS        0x1004
#define R_LED_PROGRAM_RAM_BASE   0x1800
#define R_LED_DATA_RAM_BASE      0x1C00


/* SCTL: Status and Control Register (0x0050) */

/* Bit positions used for set/clear commands. */
#define S_SCTL_MSG_START         0
#define S_SCTL_MSG_DONE          1
#define S_SCTL_LINK_STAT_MSG     8
#define S_SCTL_PCI_FATAL_ERR     9
#define S_SCTL_PCI_PARITY_ERR    10
#define S_SCTL_MIIM_RD_START     16
#define S_SCTL_MIIM_WR_START     17
#define S_SCTL_MIIM_OP_DONE      18
#define S_SCTL_MIIM_LINK_SCAN_EN 19

#define M_SCTL_MSG_START         _DD_MAKEMASK1(S_SCTL_MSG_START)
#define M_SCTL_MSG_DONE          _DD_MAKEMASK1(S_SCTL_MSG_DONE)
#define M_SCTL_LINK_STAT_MSG     _DD_MAKEMASK1(S_SCTL_LINK_STAT_MSG)
#define M_SCTL_PCI_FATAL_ERR     _DD_MAKEMASK1(S_SCTL_PCI_FATAL_ERR)
#define M_SCTL_PCI_PARITY_ERR    _DD_MAKEMASK1(S_SCTL_PCI_PARITY_ERR)
#define M_SCTL_MIIM_RD_START     _DD_MAKEMASK1(S_SCTL_MIIM_RD_START)
#define M_SCTL_MIIM_WR_START     _DD_MAKEMASK1(S_SCTL_MIIM_WR_START)
#define M_SCTL_MIIM_OP_DONE      _DD_MAKEMASK1(S_SCTL_MIIM_OP_DONE)
#define M_SCTL_MIIM_LINK_SCAN_EN _DD_MAKEMASK1(S_SCTL_MIIM_LINK_SCAN_EN)

#define S_SCTL_BIT_POS           0
#define M_SCTL_BIT_POS           _DD_MAKEMASK(5,S_SCTL_BIT_POS)
#define V_SCTL_BIT_POS(x)        _DD_MAKEVALUE(x,S_SCTL_BIT_POS)
#define G_SCTL_BIT_POS(x)        _DD_GETVALUE(x,S_SCTL_BIT_POS,M_SCTL_BIT_POS)

#define M_SCTL_BITVAL            _DD_MAKEMASK1(7)
#define V_SCTL_BIT_0             0
#define V_SCTL_BIT_1             M_SCTL_BITVAL

         
/* SERR: S-Channel Error Status Register (0x005C) */

#define S_SERR_ERR_CODE          0
#define M_SERR_ERR_CODE          _DD_MAKEMASK(8,S_SERR_ERR_CODE)
#define V_SERR_ERR_CODE(x)       _DD_MAKEVALUE(x,S_SERR_ERR_CODE)
#define G_SERR_ERR_CODE(x)       _DD_GETVALUE(x,S_SERR_ERR_CODE,M_SERR_ERR_CODE)

#define S_SERR_OP_CODE           8
#define M_SERR_OP_CODE           _DD_MAKEMASK(7,S_SERR_OP_CODE)
#define V_SERR_OP_CODE(x)        _DD_MAKEVALUE(x,S_SERR_OP_CODE)
#define G_SERR_OP_CODE(x)        _DD_GETVALUE(x,S_SERR_OP_CODE,M_SERR_OP_CODE)

#define S_SERR_SRC_PORT          15
#define M_SERR_SRC_PORT          _DD_MAKEMASK(8,S_SERR_SRC_PORT)
#define V_SERR_SRC_PORT(x)       _DD_MAKEVALUE(x,S_SERR_SRC_PORT)
#define G_SERR_SRC_PORT(x)       _DD_GETVALUE(x,S_SERR_SRC_PORT,M_SERR_SRC_PORT)

#define S_SERR_DST_PORT          23
#define M_SERR_DST_PORT          _DD_MAKEMASK(8,S_SERR_DST_PORT)
#define V_SERR_DST_PORT(x)       _DD_MAKEVALUE(x,S_SERR_DST_PORT)
#define G_SERR_DST_PORT(x)       _DD_GETVALUE(x,S_SERR_DST_PORT,M_SERR_DST_PORT)

#define M_SERR_VALID             _DD_MAKEMASK1(31)


/* DMACTL: DMA Control Register (0x0100) */

#define M_CH_DIRECTION(ch)       _DD_MAKEMASK1(0+8*(ch))  /* 0 <= ch <= 3 */
#define M_CH_NO_MOD_PBMP(ch)     _DD_MAKEMASK1(1+8*(ch))
#define M_ABORT_DMA_CH(ch)       _DD_MAKEMASK1(2+8*(ch))
#define M_INTR_SEL_DES_PKT_CH(ch)  _DD_MAKEMASK1(3+8*(ch))
#define M_DROP_TX_PRT_BITS0_CH(ch) _DD_MAKEMASK1(4+8*(ch))

/* DMASTAT: DMA Status Register (0x0104) */

/* Bit positions used for set/clear commands. */

#define S_CH_DMA_EN(ch)          (0+(ch))                 /* 0 <= ch <= 3 */
#define S_CH_CHAIN_DONE(ch)      (4+(ch))
#define S_CH_DESC_DONE(ch)       (8+(ch))
#define S_DMA_RESET              12
#define S_STAT_DMA_OPN_CMPLT     13
#define S_STAT_DMA_ITR_DONE      14
#define S_STAT_DMA_ACTIVE        15
#define S_CH_DMA_ACTIVE(ch)      (18+(ch))

#define M_CH_DMA_EN(ch)          _DD_MAKEMASK1(S_CH_DMA_EN(ch))
#define M_CH_CHAIN_DONE(ch)      _DD_MAKEMASK1(S_CH_CHAIN_DONE(ch))
#define M_CH_DESC_DONE(ch)       _DD_MAKEMASK1(S_CH_DESC_DONE(ch))
#define M_DMA_RESET              _DD_MAKEMASK1(S_DMA_RESET)
#define M_STAT_DMA_OPN_CMPLT     _DD_MAKEMASK1(S_STAT_DMA_OPN_CMPLT)
#define M_STAT_DMA_ITR_DONE      _DD_MAKEMASK1(S_STAT_DMA_ITR_DONE)
#define M_STAT_DMA_ACTIVE        _DD_MAKEMASK1(S_STAT_DMA_ACTIVE)
#define M_CH_DMA_ACTIVE(ch)      _DD_MAKEMASK1(S_CH_DMA_ACTIVE(ch))

#define S_PCI_PARITY_ERR         24
#define M_PCI_PARITY_ERR         _DD_MAKEMASK(2,S_PCI_PARITY_ERR)
#define V_PCI_PARITY_ERR(x)      _DD_MAKEVALUE(x,S_PCI_PARITY_ERR)
#define G_PCI_PARITY_ERR(x)      _DD_GETVALUE(x,S_PCI_PARITY_ERR,M_PCI_PARITY_ERR)

#define S_PCI_FATAL_ERR          29
#define M_PCI_FATAL_ERR          _DD_MAKEMASK(2,S_PCI_FATAL_ERR)
#define V_PCI_FATAL_ERR(x)       _DD_MAKEVALUE(x,S_PCI_FATAL_ERR)
#define G_PCI_FATAL_ERR(x)       _DD_GETVALUE(x,S_PCI_FATAL_ERR,M_PCI_FATAL_ERR)

#define S_DMA_BIT_POS            0
#define M_DMA_BIT_POS            _DD_MAKEMASK(5,S_DMA_BIT_POS)
#define V_DMA_BIT_POS(x)         _DD_MAKEVALUE(x,S_DMA_BIT_POS)
#define G_DMA_BIT_POS(x)         _DD_GETVALUE(x,S_DMA_BIT_POS,M_DMA_BIT_POS)

#define M_DMA_BITVAL             _DD_MAKEMASK1(7)
#define V_DMA_BIT_0              0
#define V_DMA_BIT_1              M_DMA_BITVAL


/* CONFIG: Configuration Register (0x010C) */

#define M_RD_BRST_EN             _DD_MAKEMASK1(0)
#define M_WR_BRST_EN             _DD_MAKEMASK1(1)
#define M_BE_CHECK_EN            _DD_MAKEMASK1(2)
#define M_MSTR_Q_MAX_EN          _DD_MAKEMASK1(3)
#define M_LINK_STAT_EN           _DD_MAKEMASK1(4)
#define M_RESET_CPS              _DD_MAKEMASK1(5)
#define M_ACT_LOW_INT            _DD_MAKEMASK1(6)
#define M_SCHAN_ABORT            _DD_MAKEMASK1(7)
#define M_UNTAG_ALL_RCV_EN       _DD_MAKEMASK1(8)
#define M_UNTAG_EN               _DD_MAKEMASK1(9)
#define M_LE_DMA_EN              _DD_MAKEMASK1(10)
#define M_I2C_EN                 _DD_MAKEMASK1(11)
#define M_MIS_ALIGN_DMA_MRD_ADDR_EN  _DD_MAKEMASK1(13)
#define M_DMA_GARBAGE_COLLECT_EN _DD_MAKEMASK1(15)
#define M_EN_PCI_RST_ON_INIT     _DD_MAKEMASK1(16)
#define M_EN_SG_OPN              _DD_MAKEMASK1(18)
#define M_EN_RLD_OPN             _DD_MAKEMASK1(19)
#define M_DIS_RLD_STAT_UPDATE    _DD_MAKEMASK1(20)
#define M_STOP_AUTO_SCAN_ON_LCHG _DD_MAKEMASK1(21)
#define M_ABORT_STAT_DMA         _DD_MAKEMASK1(22)


/* IRQSTAT: Interrupt Status Register (0x0144) */
/* IRQMASK: Interrupt Mask Register (0x0148) */

#define M_IRQ_SCH_MSG_DONE       _DD_MAKEMASK1(0)
#define M_IRQ_LINK_STAT_MOD      _DD_MAKEMASK1(4)
#define M_IRQ_DESC_DONE(ch)      _DD_MAKEMASK1(7+2*(ch))  /* 0 <= ch <= 3 */
#define M_IRQ_CHAIN_DONE(ch)     _DD_MAKEMASK1(8+2*(ch))
#define M_IRQ_PCI_PARITY_ERR     _DD_MAKEMASK1(15)
#define M_IRQ_PCI_FATAL_ERR      _DD_MAKEMASK1(16)
#define M_IRQ_SCHAN_ERR          _DD_MAKEMASK1(17)
#define M_IRQ_I2C_INTR           _DD_MAKEMASK1(18)
#define M_IRQ_MIIM_OP_DONE       _DD_MAKEMASK1(19)
#define M_IRQ_STATS_DMA_DONE     _DD_MAKEMASK1(20)
#define M_IRQ_MMU_GROUP_INTR     _DD_MAKEMASK1(21)


/* MIIMP: MIIM Parameter Register (0x0158) */

#define S_MIIMP_PHY_DATA          0
#define M_MIIMP_PHY_DATA          _DD_MAKEMASK(16,S_MIIMP_PHY_DATA)
#define V_MIIMP_PHY_DATA(x)       _DD_MAKEVALUE(x,S_MIIMP_PHY_DATA)
#define G_MIIMP_PHY_DATA(x)       _DD_GETVALUE(x,S_MIIMP_PHY_DATA,M_MIIMP_PHY_DATA)

#define S_MIIMP_PHY_ID            16
#define M_MIIMP_PHY_ID            _DD_MAKEMASK(8,S_MIIMP_PHY_ID)
#define V_MIIMP_PHY_ID(x)         _DD_MAKEVALUE(x,S_MIIMP_PHY_ID)
#define G_MIIMP_PHY_ID(x)         _DD_GETVALUE(x,S_MIIMP_PHY_ID,M_MIIMP_PHY_ID)

#define S_MIIMP_PHY_REG           24
#define M_MIIMP_PHY_REG           _DD_MAKEMASK(8,S_MIIMP_PHY_REG)
#define V_MIIMP_PHY_REG(x)        _DD_MAKEVALUE(x,S_MIIMP_PHY_REG)
#define G_MIIMP_PHY_REG(x)        _DD_GETVALUE(x,S_MIIMP_PHY_REG,M_MIIMP_PHY_REG)

/* MIIMRD: MIIM Read Data Register (0x015C) */

#define S_MIIMRD_DATA             0
#define M_MIIMRD_DATA             _DD_MAKEMASK(16,S_MIIMRD_DATA)
#define V_MIIMRD_DATA(x)          _DD_MAKEVALUE(x,S_MIIMRD_DATA)
#define G_MIIMRD_DATA(x)          _DD_GETVALUE(x,S_MIIMP_PHY_DATA,M_MIIMP_PHY_DATA)


/* ID: Device/Revision Module ID Register (0x0178) */

#define S_ID_DEVICE_ID            0
#define M_ID_DEVICE_ID            _DD_MAKEMASK(16,S_ID_DEVICE_ID)
#define V_ID_DEVICE_ID(x)         _DD_MAKEVALUE(x,S_ID_DEVICE_ID)
#define G_ID_DEVICE_ID(x)         _DD_GETVALUE(x,S_ID_DEVICE_ID,M_ID_DEVICE_ID)

#define S_ID_REVISION_ID          16
#define M_ID_REVISION_ID          _DD_MAKEMASK(8,S_ID_REVISION_ID)
#define V_ID_REVISION_ID(x)       _DD_MAKEVALUE(x,S_ID_REVISION_ID)
#define G_ID_REVISION_ID(x)       _DD_GETVALUE(x,S_ID_REVISION_ID,M_ID_REVISION_ID)


/* PFMT: Packet Header Format Register (0x01A8) */

#define S_PFMT_FORMAT             0
#define M_PFMT_FORMAT             _DD_MAKEMASK(2,S_PFMT_FORMAT)
#define V_PFMT_FORMAT(x)          _DD_MAKEVALUE(x,S_PFMT_FORMAT)
#define G_PFMT_FORMAT(x)          _DD_GETVALUE(x,S_PFMT_FORMAT,M_PFMT_FORMAT)



/* DMA Control Block (DCB) Format (pages 69-71, but note that the
   manual has multiple serious errors). */

/* Each DCB is 8 32-bit words.  The fields are defined below by word
   offset.  */

#define S_DCB0_MEM_ADDR          0
#define M_DCB0_MEM_ADDR          _DD_MAKEMASK(32,S_DCB0_MEM_ADDR)
#define V_DCB0_MEM_ADDR(x)       _DD_MAKEVALUE(x,S_DCB0_MEM_ADDR)
#define G_DCB0_MEM_ADDR(x)       _DD_GETVALUE(x,S_DCB0_MEM_ADDR,M_DCB0_MEM_ADDR)

#define S_DCB1_BYTE_COUNT        0
#define M_DCB1_BYTE_COUNT        _DD_MAKEMASK(16,S_DCB1_BYTE_COUNT)
#define V_DCB1_BYTE_COUNT(x)     _DD_MAKEVALUE(x,S_DCB1_BYTE_COUNT)
#define G_DCB1_BYTE_COUNT(x)     _DD_GETVALUE(x,S_DCB1_BYTE_COUNT,M_DCB1_BYTE_COUNT)

#define M_DCB1_RLD               _DD_MAKEMASK1(17)
#define M_DCB1_SG                _DD_MAKEMASK1(18)

#define S_DCB1_CRC_REGEN         25
#define M_DCB1_CRC_REGEN         _DD_MAKEMASK(2,S_DCB1_CRC_REGEN)
#define V_DCB1_CRC_REGEN(x)      _DD_MAKEVALUE(x,S_DCB1_CRC_REGEN)
#define G_DCB1_CRC_REGEN(x)      _DD_GETVALUE(x,S_DCB1_CRC_REGEN,M_DCB1_CRC_REGEN)

#define M_DCB1_JUMBO             _DD_MAKEMASK1(27)

#define S_DCB1_COS               28
#define M_DCB1_COS               _DD_MAKEMASK(3,S_DCB1_COS)
#define V_DCB1_COS(x)            _DD_MAKEVALUE(x,S_DCB1_COS)
#define G_DCB1_COS(x)            _DD_GETVALUE(x,S_DCB1_COS,M_DCB1_COS)

#define M_DCB1_C                 _DD_MAKEMASK1(31)

#define S_DCB2_PORT_MAP          0
#define M_DCB2_PORT_MAP          _DD_MAKEMASK(31,S_DCB2_PORT_MAP)
#define V_DCB2_PORT_MAP(x)       _DD_MAKEVALUE(x,S_DCB2_PORT_MAP)
#define G_DCB2_PORT_MAP(x)       _DD_GETVALUE(x,S_DCB2_PORT_MAP,M_DCB2_PORT_MAP)

#define S_DCB3_UNTAGGED_MAP      0
#define M_DCB3_UNTAGGED_MAP      _DD_MAKEMASK(32,S_DCB3_UNTAGGED_MAP)
#define V_DCB3_UNTAGGED_MAP(x)   _DD_MAKEVALUE(x,S_DCB3_UNTAGGED_MAP)
#define G_DCB3_UNTAGGED_MAP(x)   _DD_GETVALUE(x,S_DCB3_UNTAGGED_MAP,M_DCB3_UNTAGGED_MAP)

#define S_DCB4_L3_MAP            0
#define M_DCB4_L3_MAP            _DD_MAKEMASK(32,S_DCB4_L3_MAP)
#define V_DCB4_L3_MAP(x)         _DD_MAKEVALUE(x,S_DCB4_L3_MAP)
#define G_DCB4_L3_MAP(x)         _DD_GETVALUE(x,S_DCB4_L3_MAP,M_DCB4_L3_MAP)

/* Words 5 through 7 have different formats for tansmit and receive.
   First the transmit variants. */

#define S_DCB5_RCV_COUNT         0
#define M_DCB5_RCV_COUNT         _DD_MAKEMASK(16,S_DCB5_RCV_COUNT)
#define V_DCB5_RCV_COUNT(x)      _DD_MAKEVALUE(x,S_DCB5_RCV_COUNT)
#define G_DCB5_RCV_COUNT(x)      _DD_GETVALUE(x,S_DCB5_RCV_COUNT,M_DCB5_RCV_COUNT)

#define M_DCB5_SW                _DD_MAKEMASK1(20)

#define S_DCB5_OW                21
#define M_DCB5_OW                _DD_MAKEMASK(2,S_DCB5_OW)
#define V_DCB5_OW(x)             _DD_MAKEVALUE(x,S_DCB5_OW)
#define G_DCB5_OW(x)             _DD_GETVALUE(x,S_DCB5_OW,M_DCB5_OW)

#define S_DCB5_CRCW              23
#define M_DCB5_CRCW              _DD_MAKEMASK(2,S_DCB5_CRCW)
#define V_DCB5_CRCW(x)           _DD_MAKEVALUE(x,S_DCB5_CRCW)
#define G_DCB5_CRCW(x)           _DD_GETVALUE(x,S_DCB5_CRCW,M_DCB5_CRCW)

#define S_DCB5_COSW              26
#define M_DCB5_COSW              _DD_MAKEMASK(3,S_DCB5_COSW)
#define V_DCB5_COSW(x)           _DD_MAKEVALUE(x,S_DCB5_COSW)
#define G_DCB5_COSW(x)           _DD_GETVALUE(x,S_DCB5_COSW,M_DCB5_COSW)

#define M_DCB5_UTW               _DD_MAKEMASK1(29)
#define M_DCB5_EW                _DD_MAKEMASK1(30)
#define M_DCB5_V                 _DD_MAKEMASK1(31)

#define S_DCB6_SRC_PORT          0
#define M_DCB6_SRC_PORT          _DD_MAKEMASK(6,S_DCB6_SRC_PORT)
#define V_DCB6_SRC_PORT(x)       _DD_MAKEVALUE(x,S_DCB6_SRC_PORT)
#define G_DCB6_SRC_PORT(x)       _DD_GETVALUE(x,S_DCB6_SRC_PORT,M_DCB6_SRC_PORT)

#define M_DCB6_DONE              _DD_MAKEMASK1(8)

#define S_DCB6_CPU_OPCODES       14
#define M_DCB6_CPU_OPCODES       _DD_MAKEMASK(18,S_DCB6_CPU_OPCODES)
#define V_DCB6_CPU_OPCODES(x)    _DD_MAKEVALUE(x,S_DCB6_CPU_OPCODES)
#define G_DCB6_CPU_OPCODES(x)    _DD_GETVALUE(x,S_DCB6_CPU_OPCODES,M_DCB6_CPU_OPCODES)

/* Next the receive variants. */

#define M_DCB5_CRC               _DD_MAKEMASK1(16)
#define M_DCB5_ING_TAGGED        _DD_MAKEMASK1(17)
#define M_DCB5_SRC_PORT_TGID     _DD_MAKEMASK1(18)
#define M_DCB5_L3_BITMAP         _DD_MAKEMASK1(19)

#define S_DCB5_SRC_PORT_ID       24
#define M_DCB5_SRC_PORT_ID       _DD_MAKEMASK(5,S_DCB5_SRC_PORT_ID)
#define V_DCB5_SRC_PORT_ID(x)    _DD_MAKEVALUE(x,S_DCB5_SRC_PORT_ID)
#define G_DCB5_SRC_PORT_ID(x)    _DD_GETVALUE(x,S_DCB5_SRC_PORT_ID,M_DCB5_SRC_PORT_ID)

#define S_DCB5_SRC_PORT_TGID     18
#define G_DCB5_SRC_PORT_TGID(x)  (G_DCB5_SRC_PORT_ID(x) + \
                                  (((x) & M_DCB5_SRC_PORT_TGID) >> (S_DCB5_SRC_PORT_TGID-5)))

/* DCB7 used for testing only */



/* S-Channel Message Formats and Codes (pages 24-29) */

#define SC_PORT_CMIC            0x0
#define SC_PORT_HIGIG(n)        (n)            /* 1 <= n <= 8 */

#define M_SMHDR_C                _DD_MAKEMASK1(0)

#define S_SMHDR_COS              1
#define M_SMHDR_COS              _DD_MAKEMASK(3,S_SMHDR_COS)
#define V_SMHDR_COS(x)           _DD_MAKEVALUE(x,S_SMHDR_COS)
#define G_SMHDR_COS(x)           _DD_GETVALUE(x,S_SMHDR_COS,M_SMHDR_COS)

#define S_SMHDR_ECODE            4
#define M_SMHDR_ECODE            _DD_MAKEMASK(2,S_SMHDR_ECODE)
#define V_SMHDR_ECODE(x)         _DD_MAKEVALUE(x,S_SMHDR_ECODE)
#define G_SMHDR_ECODE(x)         _DD_GETVALUE(x,S_SMHDR_ECODE,M_SMHDR_ECODE)

#define M_SMHDR_E                _DD_MAKEMASK1(6)

#define S_SMHDR_DATA_LEN         7
#define M_SMHDR_DATA_LEN         _DD_MAKEMASK(7,S_SMHDR_DATA_LEN)
#define V_SMHDR_DATA_LEN(x)      _DD_MAKEVALUE(x,S_SMHDR_DATA_LEN)
#define G_SMHDR_DATA_LEN(x)      _DD_GETVALUE(x,S_SMHDR_DATA_LEN,M_SMHDR_DATA_LEN)

#define S_SMHDR_SRC_PORT         14
#define M_SMHDR_SRC_PORT         _DD_MAKEMASK(6,S_SMHDR_SRC_PORT)
#define V_SMHDR_SRC_PORT(x)      _DD_MAKEVALUE(x,S_SMHDR_SRC_PORT)
#define G_SMHDR_SRC_PORT(x)      _DD_GETVALUE(x,S_SMHDR_SRC_PORT,M_SMHDR_SRC_PORT)

#define S_SMHDR_DST_PORT         20
#define M_SMHDR_DST_PORT         _DD_MAKEMASK(6,S_SMHDR_DST_PORT)
#define V_SMHDR_DST_PORT(x)      _DD_MAKEVALUE(x,S_SMHDR_DST_PORT)
#define G_SMHDR_DST_PORT(x)      _DD_GETVALUE(x,S_SMHDR_DST_PORT,M_SMHDR_DST_PORT)

#define S_SMHDR_OP_CODE          26
#define M_SMHDR_OP_CODE          _DD_MAKEMASK(6,S_SMHDR_OP_CODE)
#define V_SMHDR_OP_CODE(x)       _DD_MAKEVALUE(x,S_SMHDR_OP_CODE)
#define G_SMHDR_OP_CODE(x)       _DD_GETVALUE(x,S_SMHDR_OP_CODE,M_SMHDR_OP_CODE)

#define SC_OP_NONE               0x00
#define SC_OP_RD_MEM_CMD         0x07
#define SC_OP_RD_MEM_ACK         0x08
#define SC_OP_WR_MEM_CMD         0x09
#define SC_OP_WR_MEM_ACK         0x0A
#define SC_OP_RD_REG_CMD         0x0B
#define SC_OP_RD_REG_ACK         0x0C
#define SC_OP_WR_REG_CMD         0x0D
#define SC_OP_WR_REG_ACK         0x0E
#define SC_OP_LINK_STATUS        0x13
#define SC_OP_LINK_UPDATE        0x30



/* MMU Register S-Channel Addresses (Section 6) */

/* The following are subindexed by ingress port */
#define R_MMU_CELLCNTING(port)   (0x00000100 + ((port)<<20))
#define R_MMU_CELLLMTING(port)   (0x00000120 + ((port)<<20))
#define R_MMU_PKTCNTING(port)    (0x00000140 + ((port)<<20))
#define R_MMU_PKTLMTING(port)    (0x00000160 + ((port)<<20))


/* The following are subindexed by COS */
#define R_MMU_CELLCNTCOS(port)   (0x00000180 + ((port)<<20))
#define R_MMU_CELLLMTCOS(port)   (0x00000188 + ((port)<<20))
#define R_MMU_PKTCNTCOS(port)    (0x00000190 + ((port)<<20))
#define R_MMU_PKTLMTCOS(port)    (0x00000198 + ((port)<<20))

#define R_MMU_CELLCNTTOTAL(port) (0x000001A0 + ((port)<<20))
#define R_MMU_CELLLMTTOTAL(port) (0x000001A1 + ((port)<<20))
#define R_MMU_ERRSTAT(port)      (0x000001A2 + ((port)<<20))
#define R_MMU_EGS_PRIMOD(port)   (0x000001A3 + ((port)<<20))
#define R_MMU_EGRMAXTIME(port)   (0x000001A4 + ((port)<<20))
#define R_MMU_INTCNTL(port)      (0x00001000 + ((port)<<20))
#define R_MMU_INTSTAT(port)      (0x00001001 + ((port)<<20))
#define R_MMU_INTCLR(port)       (0x00001002 + ((port)<<20))
#define R_MMU_LLA_PARAD(port)    (0x00001010 + ((port)<<20))
#define R_MMU_XQ_PARAD(port)     (0x00001011 + ((port)<<20))
#define R_MMU_PP_SBE_CNT(port)   (0x00001012 + ((port)<<20))
#define R_MMU_PP_DBE_CNT(port)   (0x00001013 + ((port)<<20))
#define R_MMU_PP_DBE_LOG(port)   (0x00001014 + ((port)<<20))
#define R_MMU_PP_SBE_LOG(port)   (0x00001015 + ((port)<<20))
#define R_MMU_PP_ECC_CNTL(port)  (0x00001016 + ((port)<<20))
#define R_MMU_UPK_ERRLOG(port)   (0x00001017 + ((port)<<20))
#define R_MMU_ING_PARAD(port)    (0x00001018 + ((port)<<20))



/* Ingress Register S-Channel Addresses (Section 6) */

#define R_ING_CNTL(port)         (0x00002800 + ((port)<<20))
#define R_ING_CPUTOBMAP(port)    (0x00002802 + ((port)<<20))
#define R_ING_MIRTOBMAP(port)    (0x00002803 + ((port)<<20))
#define R_ING_EGRMSKBMAP(port)   (0x00002804 + ((port)<<20))
#define R_ING_EPC_LNKBMAP(port)  (0x00002805 + ((port)<<20))
#define R_ING_HGTRUNK(port,i)    (0x00002806 + (i) + ((port)<<20))
#define R_ING_PRTTODEVID(port)   (0x0000280A + ((port)<<20))
#define R_ING_COS_MAP(port)      (0x0000280B + ((port)<<20))
#define R_ING_SRCMODFILTER(port) (0x0000280C + ((port)<<20))



/* XGXS PHY Registers (16 bits) (Section 7) */

/* Registers accessible in all blocks */
#define R_XGXS_IEEE_CONTROL       0x00
#define R_XGXS_IEEE_STAT          0x01
#define R_XGXS_PHY_ID_LO          0x02
#define R_XGXS_PHY_ID_HI          0x03
#define R_XGXS_BLKNO              0x1F

/* Registers accessible in block 0 */

#define R_XGXS_CTRL               0x10
#define R_XGXS_STAT               0x11
#define R_XGXS_XGMII_IDLE         0x12
#define R_XGXS_XGMII_SYNC         0x13
#define R_XGXS_XGMII_SKIP         0x14
#define R_XGXS_XGMII_SOPEOP       0x15
#define R_XGXS_XGMII_ALIGN        0x16
#define R_XGXS_XGMII_SWAP         0x19
#define R_XGXS_LSS_LSS_ID         0x1A
#define R_XGXS_LSS_TXINFO         0x1B
#define R_XGXS_LSS_WINDOW         0x1D



/* HiGig (10G) MAC Register S-Channel Addresses (64 bits) (Section 8) */

#define R_MAC_CTRL(port)         (0x00000000 + ((port)<<20))
#define R_MAC_XGXS_CTRL(port)    (0x00000001 + ((port)<<20))
#define R_MAC_XGXS_STAT(port)    (0x00000002 + ((port)<<20))
#define R_MAC_TXMUXCTRL(port)    (0x00000003 + ((port)<<20))  /* test only */
#define R_MAC_RXMUXCTRL(port)    (0x00000004 + ((port)<<20))  /* test only */
#define R_MAC_TXCTRL(port)       (0x00000005 + ((port)<<20))
#define R_MAC_TXMACSA(port)      (0x00000006 + ((port)<<20))
#define R_MAC_TXMAXSZ(port)      (0x00000007 + ((port)<<20))
#define R_MAC_TXPSETHR(port)     (0x00000008 + ((port)<<20))
#define R_MAC_RXCTRL(port)       (0x00000013 + ((port)<<20))
#define R_MAC_RXMACSA(port)      (0x00000014 + ((port)<<20))
#define R_MAC_RXMAXSZ(port)      (0x00000015 + ((port)<<20))


/* MACCTRL: 10G MAC Control Register (0x00C00020) */

#define M_MACCTRL_TX_EN          _DD_MAKEMASK1(0)
#define M_MACCTRL_RX_EN          _DD_MAKEMASK1(1)
#define M_MACCTRL_LCL_LOOP       _DD_MAKEMASK1(2)
#define M_MACCTRL_RMT_LOOP       _DD_MAKEMASK1(3)


/* XGXSCTRL: XGXS_IP Control Register (0x00C00021) */

#define S_XGXSCTRL_MODE          0
#define M_XGXSCTRL_MODE          _DD_MAKEMASK(4,S_XGXSCTRL_MODE)
#define V_XGXSCTRL_MODE(x)       _DD_MAKEVALUE(x,S_XGXSCTRL_MODE)
#define G_XGXSCTRL_MODE(x)       _DD_GETVALUE(x,S_XGXSCTRL_MODE,M_XGXSCTRL_MODE)

#define M_XGXSCTRL_HW_RST_L      _DD_MAKEMASK1(4)
#define M_XGXSCTRL_PWR_DWN       _DD_MAKEMASK1(5)
#define M_XGXSCTRL_IDDQ          _DD_MAKEMASK1(6)
#define M_XGXSCTRL_TXFIFO_RST_L  _DD_MAKEMASK1(7)
#define M_XGXSCTRL_AFIFO_RST     _DD_MAKEMASK1(8)
#define M_XGXSCTRL_RMT_LOOP      _DD_MAKEMASK1(9)
#define M_XGXSCTRL_PLL_BYP       _DD_MAKEMASK1(10)


/* XGSXSTAT: XGXS_IP Status Register (0x00C00022) */

#define M_XGXSSTAT_LINK          _DD_MAKEMASK1(0)
#define M_XGXSSTAT_RX_ACT        _DD_MAKEMASK1(1)
#define M_XGXSSTAT_SEQ_DONE      _DD_MAKEMASK1(2)
#define M_XGXSSTAT_TXPLL_LOCK    _DD_MAKEMASK1(3)
#define M_XGXSSTAT_TX_ACT        _DD_MAKEMASK1(4)
#define M_XGXSSTAT_TXFIFO_ERR    _DD_MAKEMASK1(5)
#define M_XGXSSTAT_RMT_FLT       _DD_MAKEMASK1(6)
#define M_XGXSSTAT_BRK_LINKS     _DD_MAKEMASK1(7)


/* TXCTRL: Transmit Control Register (0x00C00025) */

#define S_TXCTRL_HDR_MODE        0
#define M_TXCTRL_HDR_MODE        _DD_MAKEMASK(2,S_TXCTRL_HDR_MODE)
#define V_TXCTRL_HDR_MODE(x)     _DD_MAKEVALUE(x,S_TXCTRL_HDR_MODE)
#define G_TXCTRL_HDR_MODE(x)     _DD_GETVALUE(x,S_TXCTRL_HDR_MODE,M_TXCTRL_HDR_MODE)

#define S_TXCTRL_CRC_MODE        2
#define M_TXCTRL_CRC_MODE        _DD_MAKEMASK(2,S_TXCTRL_CRC_MODE)
#define V_TXCTRL_CRC_MODE(x)     _DD_MAKEVALUE(x,S_TXCTRL_CRC_MODE)
#define G_TXCTRL_CRC_MODE(x)     _DD_GETVALUE(x,S_TXCTRL_CRC_MODE,M_TXCTRL_CRC_MODE)
#define K_CRC_MODE_APPEND        0
#define K_CRC_MODE_KEEP          1
#define K_CRC_MODE_REPLACE       2

#define S_TXCTRL_AVG_IPG         4
#define M_TXCTRL_AVG_IPG         _DD_MAKEMASK(5,S_TXCTRL_AVG_IPG)
#define V_TXCTRL_AVG_IPG(x)      _DD_MAKEVALUE(x,S_TXCTRL_AVG_IPG)
#define G_TXCTRL_AVG_IPG(x)      _DD_GETVALUE(x,S_TXCTRL_AVG_IPG,M_TXCTRL_AVG_IPG)

#define S_TXCTRL_THROT_NUM       9
#define M_TXCTRL_THROT_NUM       _DD_MAKEMASK(6,S_TXCTRL_THROT_NUM)
#define V_TXCTRL_THROT_NUM(x)    _DD_MAKEVALUE(x,S_TXCTRL_THROT_NUM)
#define G_TXCTRL_THROT_NUM(x)    _DD_GETVALUE(x,S_TXCTRL_THROT_NUM,M_TXCTRL_THROT_NUM)

#define S_TXCTRL_THROT_DENOM     15
#define M_TXCTRL_THROT_DENOM     _DD_MAKEMASK(8,S_TXCTRL_THROT_DENOM)
#define V_TXCTRL_THROT_DENOM(x)  _DD_MAKEVALUE(x,S_TXCTRL_THROT_DENOM)
#define G_TXCTRL_THROT_DENOM(x)  _DD_GETVALUE(x,S_TXCTRL_THROT_DENOM,M_TXCTRL_THROT_DENOM)

#define M_TXCTRL_PAUSE_EN        _DD_MAKEMASK1(23)
#define M_TXCTRL_DISCARD         _DD_MAKEMASK1(24)
#define M_TXCTRL_ANY_START       _DD_MAKEMASK1(25)


/* RXCTRL: Receive Control Register (0x00C00033) */

#define S_RXCTRL_HDR_MODE        0
#define M_RXCTRL_HDR_MODE        _DD_MAKEMASK(2,S_RXCTRL_HDR_MODE)
#define V_RXCTRL_HDR_MODE(x)     _DD_MAKEVALUE(x,S_RXCTRL_HDR_MODE)
#define G_RXCTRL_HDR_MODE(x)     _DD_GETVALUE(x,S_RXCTRL_HDR_MODE,M_RXCTRL_HDR_MODE)

#define M_RXCTRL_STRIP_CRC       _DD_MAKEMASK1(2)
#define M_RXCTRL_IGNORE_CRC      _DD_MAKEMASK1(3)
#define M_RXCTRL_STRICT_PRMBL    _DD_MAKEMASK1(4)
#define M_RXCTRL_RX_PAUSE_EN     _DD_MAKEMASK1(5)
#define M_RXCTRL_RX_PASS_CTRL    _DD_MAKEMASK1(6)
#define M_RXCTRL_ANY_START       _DD_MAKEMASK1(7)



/* Counter Register Indices (Section 9) (36 or 42 bits) */

#define I_MIB_ITPKT              0x0009
#define I_MIB_ITXPF              0x000A
#define I_MIB_ITFCS              0x000B
#define I_MIB_ITMCA              0x000C
#define I_MIB_ITBCA              0x000D
#define I_MIB_ITFRG              0x000E
#define I_MIB_ITOVR              0x000F
#define I_MIB_ITUFL              0x0010
#define I_MIB_ITERR              0x0011
#define I_MIB_ITBYT              0x0012

#define I_MIB_ITR64              0x0016
#define I_MIB_ITR127             0x0017
#define I_MIB_ITR255             0x0018
#define I_MIB_ITR511             0x0019
#define I_MIB_ITR1023            0x001A
#define I_MIB_ITR1522            0x001B
#define I_MIB_IRMAX              0x001C
#define I_MIB_IRPKT              0x001D
#define I_MIB_IRFCS              0x001E
#define I_MIB_IRMCA              0x001F
#define I_MIB_IRBCA              0x0020
#define I_MIB_IRXCF              0x0021
#define I_MIB_IRXPF              0x0022
#define I_MIB_IRXUO              0x0023
#define I_MIB_IRJBR              0x0024
#define I_MIB_IROVR              0x0025
#define I_MIB_IRFLR              0x0026
#define I_MIB_IRBYT              0x0027
#define I_MIB_IRUND              0x0028
#define I_MIB_IRFRG              0x0029
#define I_MIB_IRERBYT            0x002A
#define I_MIB_IRERPKT            0x002B
#define I_MIB_IRJUNK             0x002C

#define I_MIB_TX_FIRST           I_MIB_ITPKT
#define I_MIB_TX_LAST            I_MIB_ITBYT
#define I_MIB_RX_FIRST           I_MIB_ITR64
#define I_MIB_RX_LAST            I_MIB_IRJUNK



/* RAM Table S-Channel Base Addresses (Section 10) */

#define M_UC(port)               (0x00000000 + ((port)<<20))
#define M_MC(port)               (0x04000000 + ((port)<<20))

#define M_VID(port)              (0x08000000 + ((port)<<20))

#define M_LLA(port)              (0x40000000 + ((port)<<20))

#endif /* _BCM5670_H_ */
