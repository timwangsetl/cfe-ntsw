/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *
    *  CAT28LV64 EEPROM driver 	File: dev_eeprom_24lv64.c
    *
    *  This module contains a CFE driver for a CAT28LV64  EEPROM
    *
    *  Author:  Sanjay Gupta
    *
    *********************************************************************
    *
    *  Copyright 2006
    *  Broadcom Corporation. All rights reserved.
    *
    *  This software is furnished under license and may be used and
    *  copied only in accordance with the following terms and
    *  conditions.  Subject to these conditions, you may download,
    *  copy, install, use, modify and distribute modified or unmodified
    *  copies of this software in source and/or binary form.  No title
    *  or ownership is transferred hereby.
    *
    *  1) Any source code used, modified or distributed must reproduce
    *     and retain this copyright notice and list of conditions
    *     as they appear in the source file.
    *
    *  2) No right is granted to use any trade name, trademark, or
    *     logo of Broadcom Corporation.  The "Broadcom Corporation"
    *     name may not be used to endorse or promote products derived
    *     from this software without the prior written permission of
    *     Broadcom Corporation.
    *
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */

#include "cfe.h"


/*  *********************************************************************
    *  Forward Declarations
    ********************************************************************* */

static void dev_eeprom_28lv64_probe(cfe_driver_t *drv,
                             unsigned long probe_a, unsigned long probe_b,
                             void *probe_ptr);

static int dev_eeprom_28lv64_open(cfe_devctx_t *ctx);
static int dev_eeprom_28lv64_read(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int dev_eeprom_28lv64_inpstat(cfe_devctx_t *ctx,iocb_inpstat_t *inpstat);
static int dev_eeprom_28lv64_write(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int dev_eeprom_28lv64_ioctl(cfe_devctx_t *ctx,iocb_buffer_t *buffer);
static int dev_eeprom_28lv64_close(cfe_devctx_t *ctx);

/*  *********************************************************************
    *  Dispatch tables
    ********************************************************************* */

#define EEPROM_SIZE	8192

const static cfe_devdisp_t dev_eeprom_28lv64_dispatch = {
    dev_eeprom_28lv64_open,
    dev_eeprom_28lv64_read,
    dev_eeprom_28lv64_inpstat,
    dev_eeprom_28lv64_write,
    dev_eeprom_28lv64_ioctl,
    dev_eeprom_28lv64_close,
    NULL,
    NULL
};

const cfe_driver_t dev_eeprom_28lv64 = {
    "CAT28LV64 EEPROM",
    "nvram",
    CFE_DEV_NVRAM,
    &dev_eeprom_28lv64_dispatch,
    dev_eeprom_28lv64_probe
};

typedef struct dev_eeprom_28lv64_s {
    uint32_t baseaddr;
    uint32_t env_offset;
    uint32_t env_size;
} dev_eeprom_28lv64_t;


/*  *********************************************************************
    *  eeprom_readbyte(slaveaddr,devaddr)
    *
    *  Input parameters:
    *  	   slaveaddr -  eeprom base address
    *  	   devaddr - byte with in the device to read
    *
    *  Return value:
    *  	   0 if ok
    *  	   else -1
    ********************************************************************* */

static uint8_t eeprom_readbyte(uint32_t baddr, int ofst)
{
    uint8_t b;

    b = *(volatile uint8_t*) (baddr + ofst);

    return b;
}

/*  *********************************************************************
    *  eeprom_writebyte(slaveaddr,devaddr,b)
    *
    *  write data to eeprom.
    *
    *  Input parameters:
    *  	   slaveaddr -  EEPROM base address
    *  	   devaddr - byte with in the device to read
    *      b - byte to write
    *
    *  Return value:
    *  	   0 if ok
    *  	   else -1
    ********************************************************************* */


static int eeprom_writebyte(uint32_t baddr, int ofst, uint8_t b)
{
    volatile uint8_t *ptr;
    int err = 0, retry = 10;

    ptr = (volatile uint8_t*)(baddr + ofst);

    do {
        *ptr = b;
        asm("eieio; sync");

        cfe_usleep(1000);
    } while ((*ptr != b) && (--retry));
   
    if (retry == 0) {
        printf("Failed to write eeprom (0x%08x) val:%02x\n", ptr, b);
    }
    return err;
}


/*  *********************************************************************
    *  eeprom_test(baddr)
    *
    *  test EEPROM. This function writes a byte and reads it back to see
    *  that EEPROM exists and is functional.
    *
    *  Input parameters:
    *   baddr - Base address of eeprom
    *   
    *  Return value:
    *  	   nothing
    ********************************************************************* */
static int eeprom_test(uint32_t baddr)
{
    uint8_t cc, dd, ee;
    int err = 0;

    cc = eeprom_readbyte(baddr, (EEPROM_SIZE - 1));

    dd = ~cc;
    eeprom_writebyte(baddr, (EEPROM_SIZE - 1), (uint8_t) dd);
    
    ee = dd ^ 0x55;
    ee = eeprom_readbyte(baddr, (EEPROM_SIZE - 1));

    if (ee != dd) {
        xprintf("EEPROM Error. test failed.\n");
        err = CFE_ERR_IOERR;
    }

    eeprom_writebyte(baddr, (EEPROM_SIZE - 1), cc);

    return err;
}

/*  *********************************************************************
    *  dev_eeprom_28lv64_probe(drv,a,b,ptr)
    *
    *  Probe routine for this driver.  This routine creates the
    *  local device context and attaches it to the driver list
    *  within CFE.
    *
    *  Input parameters:
    *  	   drv - driver handle
    *  	   a,b - probe hints (longs)
    *  	   ptr - probe hint (pointer)
    *
    *  Return value:
    *  	   nothing
    ********************************************************************* */

static void dev_eeprom_28lv64_probe(cfe_driver_t *drv,
				     unsigned long probe_a, unsigned long probe_b,
				     void *probe_ptr)
{
    dev_eeprom_28lv64_t *softc;
    char descr[80];

    softc = (dev_eeprom_28lv64_t *) KMALLOC(sizeof(dev_eeprom_28lv64_t),0);

    softc->baseaddr = probe_a;
    softc->env_offset  = 0;
    softc->env_size = EEPROM_SIZE;

    xsprintf(descr,"EEPROM (28LV64) at 0x%08X", probe_a);

    cfe_attach(drv,softc,NULL,descr);
}



/*  *********************************************************************
    *  dev_eeprom_28lv64_open(ctx)
    *
    *  Input parameters:
    *  	   ctx - device context (can obtain our softc here)
    *
    *  Return value:
    *  	   0 if ok
    *  	   else error code
    ********************************************************************* */

static int dev_eeprom_28lv64_open(cfe_devctx_t *ctx)
{
    dev_eeprom_28lv64_t *softc = ctx->dev_softc;
    int b;

    b = eeprom_test(softc->baseaddr);

    return (b < 0) ? -1 : 0;
}

/*  *********************************************************************
    *  dev_eeprom_28lv64_read(ctx,buffer)
    *
    *  Read bytes from the device.
    *
    *  Input parameters:
    *  	   ctx - device context (can obtain our softc here)
    *  	   buffer - buffer descriptor (target buffer, length, offset)
    *
    *  Return value:
    *  	   number of bytes read
    *  	   -1 if an error occured
    ********************************************************************* */

static int dev_eeprom_28lv64_read(cfe_devctx_t *ctx,iocb_buffer_t *buffer)
{
    dev_eeprom_28lv64_t *softc = ctx->dev_softc;
    hsaddr_t bptr;
    int blen;
    int idx;
    int b = 0;

    bptr = buffer->buf_ptr;
    blen = buffer->buf_length;

    if ((buffer->buf_offset + blen) > EEPROM_SIZE) return -1;

    idx = (int) buffer->buf_offset;

    while (blen > 0) {
	b = eeprom_readbyte(softc->baseaddr, idx);
	if (b < 0) break;
	hs_write8(bptr,b);
	bptr++;
	blen--;
	idx++;
	}

    buffer->buf_retlen = bptr - buffer->buf_ptr;
    return (b < 0) ? -1 : 0;
}

/*  *********************************************************************
    *  dev_eeprom_28lv64_inpstat(ctx,inpstat)
    *
    *  Test input (read) status for the device
    *
    *  Input parameters:
    *  	   ctx - device context (can obtain our softc here)
    *  	   inpstat - input status descriptor to receive value
    *
    *  Return value:
    *  	   0 if ok
    *  	   -1 if an error occured
    ********************************************************************* */

static int dev_eeprom_28lv64_inpstat(cfe_devctx_t *ctx,iocb_inpstat_t *inpstat)
{
    inpstat->inp_status = 1;

    return 0;
}

/*  *********************************************************************
    *  dev_eeprom_28lv64_write(ctx,buffer)
    *
    *  Write bytes from the device.
    *
    *  Input parameters:
    *  	   ctx - device context (can obtain our softc here)
    *  	   buffer - buffer descriptor (target buffer, length, offset)
    *
    *  Return value:
    *  	   number of bytes read
    *  	   -1 if an error occured
    ********************************************************************* */

static int dev_eeprom_28lv64_write(cfe_devctx_t *ctx,iocb_buffer_t *buffer)
{
    dev_eeprom_28lv64_t *softc = ctx->dev_softc;
    hsaddr_t bptr;
    int blen;
    int idx;
    int b = 0;

    bptr = buffer->buf_ptr;
    blen = buffer->buf_length;

    if ((buffer->buf_offset + blen) > EEPROM_SIZE) return -1;

    idx = (int) buffer->buf_offset;

    while (blen > 0) {
	b = hs_read8(bptr);
	bptr++;
	b = eeprom_writebyte(softc->baseaddr, idx, b);
	if (b < 0) break;
	blen--;
	idx++;
	}

    buffer->buf_retlen = bptr - buffer->buf_ptr;
    return (b < 0) ? -1 : 0;
}

/*  *********************************************************************
    *  dev_eeprom_28lv64_ioctl(ctx,buffer)
    *
    *  Perform miscellaneous I/O control operations on the device.
    *
    *  Input parameters:
    *  	   ctx - device context (can obtain our softc here)
    *  	   buffer - buffer descriptor (target buffer, length, offset)
    *
    *  Return value:
    *  	   number of bytes read
    *  	   -1 if an error occured
    ********************************************************************* */

static int dev_eeprom_28lv64_ioctl(cfe_devctx_t *ctx,iocb_buffer_t *buffer)
{
    dev_eeprom_28lv64_t *softc = ctx->dev_softc;
    nvram_info_t info;

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_NVRAM_GETINFO:
	    if (buffer->buf_length != sizeof(nvram_info_t)) return -1;
	    info.nvram_offset = softc->env_offset;
	    info.nvram_size =   softc->env_size;
	    info.nvram_eraseflg = FALSE;
	    buffer->buf_retlen = sizeof(nvram_info_t);
	    hs_memcpy_to_hs(buffer->buf_ptr,&info,sizeof(info));
	    return 0;
	default:
	    return -1;
	}
}

/*  *********************************************************************
    *  dev_eeprom_28lv64_close(ctx,buffer)
    *
    *  Close the device.
    *
    *  Input parameters:
    *  	   ctx - device context (can obtain our softc here)
    *
    *  Return value:
    *  	   0 if ok
    *  	   -1 if an error occured
    ********************************************************************* */

static int dev_eeprom_28lv64_close(cfe_devctx_t *ctx)
{
    return 0;
}


