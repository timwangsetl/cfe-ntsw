/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BCM5690 StrataXGS Ethernet Switch	     File: dev_bcm5690.c
    *  
    *  Author: Ed Satterthwaite
    *
    *********************************************************************  
    *
    *  Copyright 2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  BROADCOM PROPRIETARY AND CONFIDENTIAL
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the license.
    ********************************************************************* */

/*
    CFE interface and MAC driver for the BCM5690, BCM5691, BCM5692 and
    BCM5693 StrataXGS Gigabit Ethernet Multilayer Switches.  This
    driver treats the switch as a MAC implemented by the 569x CMIC
    port.  It is not a general switch controller, but as a side-effect
    the device is configured as an unmanaged L2 switch, and that 
    logic remains enabled after the MAC is closed.

    Reference:
       StrataXGS BCM5690/BCM5691/BCM5692/BCM5693 Programmer's Reference
          Guide
       Document 569x-PG100-R (4/24/03)
       Broadcom Corp., 1625 Alton Parkway, Irvine CA.
*/

#include "cfe.h"
#include "lib_physio.h"

#include "cfe_irq.h"

#include "net_enet.h"

#include "pcivar.h"
#include "pcireg.h"

#include "bcm5690.h"
#include "mii.h"

#ifndef XGS_DEBUG
#define XGS_DEBUG 0
#endif

#if ((ENDIAN_BIG + ENDIAN_LITTLE) != 1)
#error "dev_bcm5690: system endian not set"
#endif

/* Temporary, until configs supply MATCH_BYTES */
#if defined(MPC824X)  /* any machine without preserve-bits for PIO */
#define MATCH_BYTES  1
#else
#define MATCH_BYTES  0
#endif

/* Set IPOLL to drive processing through the pseudo-interrupt
   dispatcher.  Set XPOLL to drive processing by an external polling
   agent.  One must be set; setting both is ok. */

#ifndef IPOLL
#define IPOLL 0
#endif
#ifndef XPOLL
#define XPOLL 1
#endif

#define MIN_ETHER_PACK  (ENET_MIN_PKT+ENET_CRC_SIZE)   /* size of min packet */
#define MAX_ETHER_PACK  (ENET_MAX_PKT+ENET_CRC_SIZE)   /* size of max packet */

#define VLAN_TAG_LEN    4                              /* VLAN type plus tag */
#define VLAN_TYPE       0x8100
#define VLAN_DEFAULT    1
#define MAX_VLAN_PACK   (MAX_ETHER_PACK+VLAN_TAG_LEN)

#define XGS_HDR_LEN     12
#define MAX_XGS_PACK    (MAX_ETHER_PACK+XGS_HDR_LEN)

/* Packet buffers.  For the XGS CMIC, packet buffer alignment is
   arbitrary and can be to any byte boundary.  We would like it
   aligned to a cache line boundary for performance, although there is
   a trade-off with IP/TCP header alignment, and to facilitate cache
   flushing on hosts requiring that.  */

#define ETH_PKTBUF_LEN      (((MAX_VLAN_PACK+31)/32)*32)

typedef struct eth_pkt_s {
    queue_t next;			/*  8 */
    uint8_t *buffer;			/*  4 */
    uint32_t flags;			/*  4 */
    int32_t length;			/*  4 */
    uint32_t unused[3];			/* 12 */
    uint8_t data[ETH_PKTBUF_LEN];
} eth_pkt_t;

#define CACHE_ALIGN       32
#define ETH_PKTBUF_LINES  ((sizeof(eth_pkt_t) + (CACHE_ALIGN-1))/CACHE_ALIGN)
#define ETH_PKTBUF_SIZE   (ETH_PKTBUF_LINES*CACHE_ALIGN)
#define ETH_PKTBUF_OFFSET (offsetof(eth_pkt_t, data))

#define ETH_PKT_BASE(data) ((eth_pkt_t *)((data) - ETH_PKTBUF_OFFSET))

static void
show_packet(char c, eth_pkt_t *pkt)
{
    int i;
    int n = (pkt->length < 128 ? pkt->length : 128);

    for (i = 0; i < n; i++) {
	if (i % 32 == 0) {
	    if (i == 0)
		xprintf("%c[%4d]:", c, pkt->length);
	    else
		xprintf("\n        ");
	    }
	if (i % 4 == 0)
	    xprintf(" ");
	xprintf("%02x", pkt->buffer[i]);
	}
    xprintf("\n");
}


static void bcm5690_probe(cfe_driver_t *drv,
			  unsigned long probe_a, unsigned long probe_b, 
			  void *probe_ptr);


/* BCM569x Hardware Common Data Structures */

typedef uint32_t portmap_t;        /* wide enough for a bit per port */

/* DMA Control Block as a struct.  See DCBn_ definitions for word n. */

typedef struct dcb_s {
    uint32_t mem_addr;             /* buffer or chain address */
    uint32_t w1;
    uint32_t w2;
    uint32_t w3;
    uint32_t w4;
    uint32_t w5;
    uint32_t w6;
    uint32_t w7;
} dcb_t;


/* The switch must be opened as a MAC interface but will be left
   operating in unmanaged switch mode after the MAC interface is
   closed. */
typedef enum {
    eth_state_uninit,
    eth_state_off,
    eth_state_on, 
    eth_state_switch,
} eth_state_t;

typedef struct phy_info_s {
    uint8_t  addr;                 /* external PHY */
    uint8_t  linkspeed;
} phy_info_t;

typedef struct bcm5690_state_s {

    /* PCI access information */
    uint32_t  regbase;
    uint8_t   irq;
    pcitag_t  tag;		   /* tag for configuration registers */

    uint8_t   hwaddr[ENET_ADDR_LEN];
    uint16_t  device;              /* chip device code */
    uint8_t   revision;            /* chip revision */
    uint16_t  asic_revision;       /* mask revision */
    int       higig;

    eth_state_t state;             /* current state */
    uint32_t intmask;              /* interrupt mask */

    /* packet free lists */
    queue_t freelist;
    uint8_t *pktpool;
    queue_t rxqueue;

    /* rings */
    dcb_t *dcbs[4];

    /* rx pointers and state */
    dcb_t *rx_start;               /* beginning of ring */
    dcb_t *rx_end;                 /* wrap point */
    volatile dcb_t *rx_add;
    volatile dcb_t *rx_remove;
    volatile dcb_t *rx_last;
    unsigned int rx_onring;

    /* tx pointers and state */
    int txbusy;

    cfe_devctx_t *devctx;

    /* ports */
    unsigned int module;           /* local mod_id */
    portmap_t    portmap;          /* map of connected ports */
    phy_info_t   phy_info[GPIC_PORTS];

    /* additional driver statistics */
    uint32_t inpkts;
    uint32_t outpkts;
    uint32_t interrupts;
    uint32_t rx_interrupts;
    uint32_t tx_interrupts;
} bcm5690_state_t;

/* Driver parameterization */

#define TX_CH                    0
#define RX_CH1                   1
#define RX_CH2                   2
#define RX_CH3                   3


/* RX_RING_SIZE determines the number of descriptors.  MIN_RX_BUFFERS
   is the target value for the number of available receive buffers.
   It must be less than RX_RING_SIZE, and a value of 1 doesn't exploit
   hardware chaining. */
#define RX_RING_SIZE             8
#define MIN_RX_BUFFERS           7

/* Address mapping macros */

#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((uint8_t *)KERNADDR(a))

#define PCI_TO_PTR(a)  (PHYS_TO_PTR(PCI_TO_PHYS(a)))
#define PTR_TO_PCI(x)  (PHYS_TO_PCI(PTR_TO_PHYS(x)))


/* Address mapping macros */

#if (ENDIAN_BIG && MATCH_BYTES)
#define CSR_MATCH_MODE       PCI_MATCH_BYTES
#define READCSR(sc,csr)      (phys_read32_swapped((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32_swapped((sc)->regbase + (csr), (val)))
#else
#define CSR_MATCH_MODE       PCI_MATCH_BITS
#define READCSR(sc,csr)      (phys_read32((sc)->regbase + (csr)))
#define WRITECSR(sc,csr,val) (phys_write32((sc)->regbase + (csr), (val)))
#endif


/* Entry to and exit from critical sections (currently relative to
   interrupts only, not SMP) */

#if CFG_INTERRUPTS
#define CS_ENTER(sc) cfe_disable_irq(sc->irq)
#define CS_EXIT(sc)  cfe_enable_irq(sc->irq)
#else
#define CS_ENTER(sc) ((void)0)
#define CS_EXIT(sc)  ((void)0)
#endif


/* Utilities */

static const char *
xgs_devname(bcm5690_state_t *sc)
{
    return (sc->devctx != NULL ? cfe_device_name(sc->devctx) : "eth?");
}


/* MII/PHY access (internal and external) */

static int
mii_poll(bcm5690_state_t *sc)
{
    int timeout;
    uint32_t status;

    cfe_usleep(100);
    for (timeout = 10000; timeout > 0; timeout -= 100) {
	status = READCSR(sc, R_CMIC_SCHAN_CTRL);
	if ((status & M_SCTL_MIIM_OP_DONE) != 0)
	    break;
	cfe_usleep(100);
	}

    return (timeout > 0 ? CFE_OK : CFE_ERR_TIMEOUT);
}

static uint16_t
mii_read_internal(bcm5690_state_t *sc, int phy_addr, int reg)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = M_MIIMP_INTERNAL_SEL | V_MIIMP_PHY_ID(phy_addr)
        | V_MIIMP_PHY_REG(reg);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_1);

    if (mii_poll(sc) != CFE_OK) {
	xprintf("* int rd %d:%x\n", phy_addr, reg);
	return 0xFFFF;
	}

    return G_MIIMRD_DATA(READCSR(sc, R_CMIC_MIIM_READ_DATA));
}

static void
mii_write_internal(bcm5690_state_t *sc, int phy_addr, int reg, uint16_t value)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = M_MIIMP_INTERNAL_SEL
        | V_MIIMP_PHY_ID(phy_addr) | V_MIIMP_PHY_REG(reg)
        | V_MIIMP_PHY_DATA(value);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_1);

    if (mii_poll(sc) != CFE_OK) {
	xprintf("* int wr %d:%x\n", phy_addr, reg);
	}
}


/* S-Bus Access Routines */

#define R_CMIC_SCHAN_D(word)    (R_CMIC_SCHAN_MESSAGE+4*(word))

static int
schan_transact(bcm5690_state_t *sc)
{
    int i;
    uint32_t ctrl;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
	cfe_usleep(100);
	ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
	if (ctrl & M_SCTL_MSG_DONE)
	    break;
	}
    return (i < 1000 ? CFE_OK : CFE_ERR_TIMEOUT);
}

static uint32_t
schan_read_reg(bcm5690_state_t *sc, unsigned int reg)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_REG_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
	       | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);

    if (schan_transact(sc) != CFE_OK) xprintf("* schan rd %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    return READCSR(sc, R_CMIC_SCHAN_D(1));
}

static void
schan_write_reg(bcm5690_state_t *sc, unsigned int reg, uint32_t value)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_REG_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
	       | V_SMHDR_DATA_LEN(4));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), value);

    if (schan_transact(sc) != CFE_OK) xprintf("* schan wr %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


static uint64_t
schan_read_reg64(bcm5690_state_t *sc, unsigned int reg)
{
    uint32_t msg_hdr;
    uint64_t value;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_REG_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
	       | V_SMHDR_DATA_LEN(8));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);

    if (schan_transact(sc) != CFE_OK) xprintf("* schan rd64 %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    value = ((uint64_t)READCSR(sc, R_CMIC_SCHAN_D(1)) |
	     ((uint64_t)READCSR(sc, R_CMIC_SCHAN_D(2)) << 32));
    return value;
}

static void
schan_write_reg64(bcm5690_state_t *sc, unsigned int reg, uint64_t value)
{
    uint32_t msg_hdr;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_REG_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
	       | V_SMHDR_DATA_LEN(8));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), reg);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), (uint32_t)(value & 0xFFFFFFFF));
    WRITECSR(sc, R_CMIC_SCHAN_D(3), (uint32_t)(value >> 32));

    if (schan_transact(sc) != CFE_OK) xprintf("* schan wr64 %x\n", reg);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


static void
schan_read_mem(bcm5690_state_t *sc, unsigned int addr,
	       uint32_t *dest, int count)
{
    uint32_t msg_hdr;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_RD_MEM_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);

    if (schan_transact(sc) != CFE_OK) xprintf("* mem rd %x\n", addr);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
    for (i = 0; i < count; i++)
	dest[i] = READCSR(sc, R_CMIC_SCHAN_D(1+i));
}

static void
schan_write_mem(bcm5690_state_t *sc, unsigned int addr,
		uint32_t *src, int count)
{
    uint32_t msg_hdr;
    int i;

    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_WR_MEM_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC)
	       | V_SMHDR_DATA_LEN(4*count));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), addr);
    for (i = 0; i < count; i++)
	WRITECSR(sc, R_CMIC_SCHAN_D(2+i), src[i]);

    if (schan_transact(sc) != CFE_OK) xprintf("* mem wr %x\n", addr);

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


/* 10/100/1000 PHY Management routines (GPIC ports). */

/* The current code cannot deal with dynamic link state changes.  We
   therefore scan the GPIC ports to determine which have external PHYs
   with established links and activate only those ports. */

#if NYI  /* currently unused */
static void
mii_reset_internal(bcm5690_state_t *sc, unsigned int port)
{
    uint16_t mii_ctrl;
    uint8_t phy_addr = port+1;

    mii_ctrl = mii_read_internal(sc, port, R_MII_CONTROL);
    mii_ctrl |= BMCR_RESET;
    mii_write_internal(sc, port, R_MII_CONTROL, mii_ctrl);

    cfe_usleep(10);

    mii_ctrl = mii_read(sc, phy_addr, R_MII_CONTROL);
    mii_ctrl |= BMCR_RESET;
    mii_write(sc, phy_addr, R_MII_CONTROL, mii_ctrl);
    /* RESET bit is self-clearing in the external PHY. */
}
#endif /* NYI */


/* Internal PHYs in SGMII mode.  Transfer status from external PHYs */

static uint16_t
mii_read(bcm5690_state_t *sc, int phy_addr, int reg)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);
    
    cmd = V_MIIMP_PHY_ID(phy_addr) | V_MIIMP_PHY_REG(reg);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_RD_START | V_SCTL_BIT_1);

    if (mii_poll(sc) != CFE_OK) {
	xprintf("* ext rd %d:%x\n", phy_addr, reg);
	return 0xFFFF;
	}

    return G_MIIMRD_DATA(READCSR(sc, R_CMIC_MIIM_READ_DATA));
}

#if NYI  /* not currently used */
static void
mii_write(bcm5690_state_t *sc, int phy_addr, int reg, uint16_t value)
{
    uint32_t cmd;

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_0);
    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_OP_DONE | V_SCTL_BIT_0);

    cmd = V_MIIMP_PHY_ID(phy_addr) | V_MIIMP_PHY_REG(reg)
        | V_MIIMP_PHY_DATA(value);
    WRITECSR(sc, R_CMIC_MIIM_PARAM, cmd);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL, S_SCTL_MIIM_WR_START | V_SCTL_BIT_1);

    if (mii_poll(sc) != CFE_OK) {
	xprintf("* ext wr %d:%x\n", phy_addr, reg);
	}
}
#endif

static int
mii_status(bcm5690_state_t *sc, int phy_addr)
{
    uint16_t  status, remote, xremote;
    int linkspeed;

    linkspeed = ETHER_SPEED_UNKNOWN;

    /* Read twice to clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);
    status = mii_read(sc, phy_addr, MII_BMSR);

    remote = mii_read(sc, phy_addr, MII_ANLPAR);
    
    if ((status & BMSR_ANCOMPLETE) != 0) {
	/* A link partner was negogiated... */

	if (status & BMSR_1000BT_XSR)
	    xremote = mii_read(sc, phy_addr, MII_K1STSR);
	else
	    xremote = 0;

	if ((xremote & K1STSR_LP1KFD) != 0) {
	    xprintf("1000BaseT FDX\n");
	    linkspeed = ETHER_SPEED_1000FDX;
	    }
	else if ((xremote & K1STSR_LP1KHD) != 0) {
	    xprintf("1000BaseT HDX\n");
	    linkspeed = ETHER_SPEED_1000HDX;
	    }
	else if ((remote & ANLPAR_TXFD) != 0) {
	    xprintf("100BaseT FDX\n");
	    linkspeed = ETHER_SPEED_100FDX;	 
	    }
	else if ((remote & ANLPAR_TXHD) != 0) {
	    xprintf("100BaseT HDX\n");
	    linkspeed = ETHER_SPEED_100HDX;	 
	    }
	else if ((remote & ANLPAR_10FD) != 0) {
	    xprintf("10BaseT FDX\n");
	    linkspeed = ETHER_SPEED_10FDX;	 
	    }
	else if ((remote & ANLPAR_10HD) != 0) {
	    xprintf("10BaseT HDX\n");
	    linkspeed = ETHER_SPEED_10HDX;	 
	    }
	}
    else {
	/* no link partner convergence */
	xprintf("NC\n");
	linkspeed = ETHER_SPEED_UNKNOWN;
	remote = xremote = 0;
	}

    /* clear latching bits */
    status = mii_read(sc, phy_addr, MII_BMSR);

    return linkspeed;
}


static void
mii_setup_internal(bcm5690_state_t *sc, unsigned int port, int linkspeed)
{
    uint16_t mii_ctrl, sgmii_ctrl, sgmii2_ctrl, misc_ctrl;
    
    mii_ctrl = mii_read_internal(sc, port, R_MII_CONTROL);
    mii_ctrl |= BMCR_RESET;
    mii_write_internal(sc, port, R_MII_CONTROL, mii_ctrl);

    /* Force standard SGMII */
    sgmii2_ctrl = mii_read_internal(sc, port, R_SGMII_CONTROL_2);
    sgmii2_ctrl &= ~(M_SGMII2_EN10B | M_SGMII2_FIBER_MODE);
    mii_write_internal(sc, port, R_SGMII_CONTROL_2, sgmii2_ctrl);

    /* Force pass-through mode, no autonegotiation */
    sgmii_ctrl = mii_read_internal(sc, port, R_SGMII_CONTROL);
    sgmii_ctrl &= ~M_SGMII_AN_SEL;
    sgmii_ctrl |= M_SGMII_SG_AN_ENABLE;   /* Note: 0 => enabled. */
    mii_write_internal(sc, port, R_SGMII_CONTROL, sgmii_ctrl);
    misc_ctrl = mii_read_internal(sc, port, R_MISC_CONTROL);
    misc_ctrl &= ~M_MISC_MAC_MODE;
    mii_write_internal(sc, port, R_MISC_CONTROL, misc_ctrl);

    if (linkspeed != ETHER_SPEED_UNKNOWN) {
	mii_ctrl &= ~(BMCR_SPEED0 | BMCR_SPEED1 | BMCR_DUPLEX);
	switch (linkspeed) {
	    case ETHER_SPEED_1000FDX:
	        mii_ctrl |= (BMCR_SPEED1000 | BMCR_DUPLEX);
	        break;
	    case ETHER_SPEED_1000HDX:
	        mii_ctrl |= BMCR_SPEED1000;
	        break;
	    case ETHER_SPEED_100FDX:
	        mii_ctrl |= (BMCR_SPEED100 | BMCR_DUPLEX);
	        break;
	    case ETHER_SPEED_100HDX:
	        mii_ctrl |= BMCR_SPEED100;
	        break;
	    case ETHER_SPEED_10FDX:
	        mii_ctrl |= (BMCR_SPEED10 | BMCR_DUPLEX);
	        break;
	    case ETHER_SPEED_10HDX:
	        mii_ctrl |= BMCR_SPEED10;
	        break;
	    }
	mii_ctrl &= ~BMCR_RESET;
	cfe_usleep(10);
	mii_write_internal(sc, port, R_MII_CONTROL, mii_ctrl);
	}
}

static portmap_t
phy_scan(bcm5690_state_t *sc)
{
    unsigned int port;
    portmap_t portmap;
    uint8_t phy_addr;
    uint16_t id1, id2;
    int linkspeed;

    portmap = 0;

    for (port = 0; port < GPIC_PORTS; port++) {

	/* The addresses of external PHYs depend on pin strapping.  The
	   following mapping is the conventional one (used on eval
	   boards); the PHYs are programmed 1-12, in port order. */
	sc->phy_info[port].addr = phy_addr = port+1;

        id1 = mii_read(sc, phy_addr, MII_PHYIDR1);
	id2 = mii_read(sc, phy_addr, MII_PHYIDR2);
	if ((id1 != 0x0000 && id1 != 0xFFFF) ||
	    (id2 != 0x0000 && id2 != 0xFFFF)) {
	    if (id1 != id2) {
		xprintf("port %2d", port);
		if (1 || XGS_DEBUG) {
		    uint32_t phy_vendor;
		    uint16_t phy_device;
		    phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
		    phy_device = (id2 >> 4) & 0x3F;
		    xprintf(" (phy vendor %06X part %02X)",
			    phy_vendor, phy_device);
		    }
		xprintf(": ");
		linkspeed = mii_status(sc, phy_addr);
		sc->phy_info[port].linkspeed = linkspeed;
		if (linkspeed != ETHER_SPEED_UNKNOWN)
		    portmap |= GPIC_BIT(port);
		}
	    }
	}
    return portmap;
}


/* HiGig (XGXS) MII/PHY Management (IPIC port) */

/* The IPIC port has only an internal PHY.  Since the Strata chips at
   each end of a HiGig link are initialized in unknown order, we
   require only a plausible PHY, not an established link.
   Empirically, the PHY registers for an unconnected IPIC port read as
   0s. */

#if XGS_DEBUG
static void
xgxs_phy_dump_internal(bcm5690_state_t *sc, const char *label)
{
    int i;
    uint16_t  r;
    uint16_t  id1, id2;
    uint32_t  phy_vendor;
    uint16_t  phy_device;

    xprintf("%s, MII(%d):\n", label, IPIC_PORT);

    mii_write_internal(sc, IPIC_PORT, R_XGXS_BLKNO, 0);

    id1 = mii_read_internal(sc, IPIC_PORT, MII_PHYIDR1);
    id2 = mii_read_internal(sc, IPIC_PORT, MII_PHYIDR2);
    phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
    phy_device = (id2 >> 4) & 0x3F;

    /* Required registers (all blocks) */
    for (i = 0x0; i <= 0x3; ++i) {
	r = mii_read_internal(sc, IPIC_PORT, i);
	xprintf(" REG%02X: %04X", i, r);
	}
    xprintf("\n");

    /* Block 0 */
    for (i = 0x10; i <= 0x16; ++i) {
	r = mii_read_internal(sc, IPIC_PORT, i);
	xprintf(" REG%02X: %04X", i, r);
	if (i == 0x13) xprintf("\n");
	}
    xprintf("\n");
    for (i = 0x19; i <= 0x1D; ++i) {
	r = mii_read_internal(sc, IPIC_PORT, i);
	xprintf(" REG%02X: %04X", i, r);
	if (i == 0x1B) xprintf("\n");
	}
    xprintf("\n");
    r = mii_read_internal(sc, IPIC_PORT, 0x1F);
    xprintf(" REG%02X: %04X\n", 0x1F, r);

    /* other blocks here? */
}
#else
#define xgxs_phy_dump_internal(sc,label)
#endif


static portmap_t
xgxs_phy_scan(bcm5690_state_t *sc)
{
    uint16_t id1, id2;
    uint16_t status;

    /* Restore default XGXS block. */
    mii_write_internal(sc, IPIC_PORT, R_XGXS_BLKNO, 0);

    xgxs_phy_dump_internal(sc, "scan");

    id1 = mii_read_internal(sc, IPIC_PORT, R_XGXS_PHY_ID_LO);
    id2 = mii_read_internal(sc, IPIC_PORT, R_XGXS_PHY_ID_HI);
    if ((id1 != 0x0000 && id1 != 0xFFFF) || (id2 != 0x0000 && id2 != 0xFFFF)) {
	if (id1 != id2) {
	    xprintf("port %2d", IPIC_PORT);
	    if (XGS_DEBUG) {
		uint32_t phy_vendor;
		uint16_t phy_device;
		phy_vendor = ((uint32_t)id1 << 6) | ((id2 >> 10) & 0x3F);
		phy_device = (id2 >> 4) & 0x3F;
		xprintf(" (phy vendor %06X part %02X)",
			phy_vendor, phy_device);
		}
	    xprintf(": ");
	    status = mii_read_internal(sc, IPIC_PORT, R_XGXS_IEEE_STAT);
	    if (status & (1 << 4))
		xprintf("10000 FDX\n");
	    else
		xprintf("not linked\n");
	    }
	}

    return IPIC_BIT;
}


/* Switch management */

static void
arl_init(bcm5690_state_t *sc)
{
    schan_write_reg(sc, R_ARL_CONTROL, M_ARLCTL_ARL_INIT);
    cfe_sleep(CFE_HZ/5);
    schan_write_reg(sc, R_ARL_CONTROL, 0x0);
    schan_write_reg(sc, R_ARL_CONTROL, V_ARLCTL_CLK_GRAN(0x7));
    schan_write_reg(sc, R_HASH_CONTROL,
		    V_HASHCTL_HASH_SELECT(K_HASH_CRC16_UPPER));
}


static void
mmu_init(bcm5690_state_t *sc, portmap_t portmap)
{
    schan_write_reg(sc, R_MMUPORTENABLE, portmap);
}


/* Initialize auxiliary forwarding tables.  */
static void
table_init(bcm5690_state_t *sc, portmap_t portmap)
{
    static uint32_t port[1] = {0};
    static uint32_t emask[1] = {0};
    static uint32_t block[1] = {0};

    static uint32_t v0[3] = {0x00000000, 0x00000000, 0x00000000};
    static uint32_t v1[3] = {0x00000001, 0x00002000, 0x00000000};
    uint32_t vb[3];
    uint32_t stg[1];
    int i;

    for (i = 0; i < GPIC_PORTS; i++)
	schan_write_mem(sc, M_PORT + i, port, 1);
    for (i = 0; i < 1024; i++)
	schan_write_mem(sc, M_EGRESS_MASK + i, emask, 1);

    for (i = 0; i < 4096; i++)
	schan_write_mem(sc, M_VLAN + i, v0, 3);
    memcpy(vb, v1, sizeof(vb));
    vb[1] |= portmap;
    vb[2] |= portmap;    /* Strip all VLAN tags on egress for now. */
    schan_write_mem(sc, M_VLAN + VLAN_DEFAULT, vb, 3);

    /* Force forwarding state for spanning tree. */
    stg[0] = 0x03FFFFFF;     /* XXX manual is wrong on default. */
    schan_write_mem(sc, M_VLAN_STG + 0, stg, 1);

    for (i = 0; i < 32; i++)
	schan_write_mem(sc, M_PORT_MAC_BLOCK + i, block, 1);

    cfe_sleep(CFE_HZ/5);
}


static void
l2_enter(bcm5690_state_t *sc, uint8_t mac_addr[], unsigned int port)
{
    uint32_t l2_entry[3];
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;
  
    l2_entry[0] = ((mac_addr[5] <<  0) |
		   (mac_addr[4] <<  8) |
		   (mac_addr[3] << 16) |
		   (mac_addr[2] << 24));
    l2_entry[1] = ((mac_addr[1] <<  0) |
		   (mac_addr[0] <<  8) |
		   (VLAN_DEFAULT << 16));
    l2_entry[2] = ((1 << 24) | (1 << 22) |
		   (sc->module << 10) |
		   (port << 4));
    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_L2_INS_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), l2_entry[0]);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), l2_entry[1]);
    WRITECSR(sc, R_CMIC_SCHAN_D(3), l2_entry[2]);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
	cfe_usleep(100);
	ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
	if (ctrl & M_SCTL_MSG_DONE)
	    break;
	}

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}

static void
l2_delete(bcm5690_state_t *sc, uint8_t mac_addr[])
{
    uint32_t l2_entry[2];
    uint32_t msg_hdr;
    uint32_t ctrl;
    int i;
  
    l2_entry[0] = ((mac_addr[5] <<  0) |
		   (mac_addr[4] <<  8) |
		   (mac_addr[3] << 16) |
		   (mac_addr[2] << 24));
    l2_entry[1] = ((mac_addr[1] <<  0) |
		   (mac_addr[0] <<  8) |
		   (VLAN_DEFAULT << 16));
    msg_hdr = (V_SMHDR_OP_CODE(SC_OP_L2_DEL_CMD)
	       | V_SMHDR_SRC_BLOCK(SC_BLOCK_CMIC));
    WRITECSR(sc, R_CMIC_SCHAN_D(0), msg_hdr);
    WRITECSR(sc, R_CMIC_SCHAN_D(1), l2_entry[0]);
    WRITECSR(sc, R_CMIC_SCHAN_D(2), l2_entry[1]);

    WRITECSR(sc, R_CMIC_SCHAN_CTRL,
	     V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_1);

    for (i = 0; i < 1000; i++) {
	cfe_usleep(100);
	ctrl = READCSR(sc, R_CMIC_SCHAN_CTRL);
	if (ctrl & M_SCTL_MSG_DONE)
	    break;
	}

    msg_hdr = READCSR(sc, R_CMIC_SCHAN_D(0));
}


static void
l2_dump(bcm5690_state_t *sc)
{
    uint32_t l2_entry[3];
    uint8_t status1, status2;
    uint8_t module, port;
    int i;
    
    for (i = 0; i < 16384; i++) {
	schan_read_mem(sc, M_L2_ENTRY + i, l2_entry, 3);
	status1 = (l2_entry[2] >> 22) & 0x7;
	if (status1 & 0x04) {    /* valid */
	    status2 = ((l2_entry[2] & 0xF) << 4) | ((l2_entry[1] >> 24) & 0xF);
	    module = (l2_entry[2] >> 10) & 0x1F;
	    port = (l2_entry[2] >> 4) & 0x3F;
	    xprintf("  %03x,%1d: %01x %02x %02x/%01x %04x%08x\n",
		    i/8, i % 8,
		    status1, status2, module, port,
		    l2_entry[1] & 0xFFFF, l2_entry[0]);
	    }
	}
}


/* Gigabit MAC management */

static void
dump_gpic(bcm5690_state_t *sc, unsigned int port)
{
    xprintf("--- gpic: %d ---\n", port);
    xprintf("MAXFR:       %08x   GTH_FE_MAXF: %08x\n",
	    schan_read_reg(sc, R_MAXFR(port)),
	    schan_read_reg(sc, R_GTH_FE_MAXF(port)));
    xprintf("CONFIG:      %08x   GEGR_ENABLE: %08x\n",
	    schan_read_reg(sc, R_CONFIG(port)),
	    schan_read_reg(sc, R_GEGR_ENABLE(port)));
    xprintf("CPU_CONTROL: %08x   EPC_LINK:    %08x\n",
	    schan_read_reg(sc, R_CPU_CONTROL(port)),
	    schan_read_reg(sc, R_EPC_LINK(port)));
    xprintf("-----------------\n");
}


static void
gpic_init(bcm5690_state_t *sc, unsigned int port, int linkspeed)
{
    uint32_t config;
    unsigned int offset;
    int gmac;

    /* Zero the port statistics */
    for (offset = 0x20; offset < 0x2A; offset++)
	schan_write_reg(sc, R_GPIC(port, offset), 0);
    for (offset = 0x2C; offset < 0x57; offset++)
	schan_write_reg(sc, R_GPIC(port, offset), 0);
    for (offset = 0x5B; offset < 0x73; offset++)
	schan_write_reg(sc, R_GPIC(port, offset), 0);
    for (offset = 0x74; offset < 0x76; offset++)
	schan_write_reg(sc, R_GPIC(port, offset), 0);

    schan_write_reg(sc, R_GEGR_ENABLE(port), 0x1);

    gmac =
      (linkspeed == ETHER_SPEED_1000FDX || linkspeed == ETHER_SPEED_1000HDX);
    if (gmac)
	config = (0x0 << 22);
    else
	config = (0x1 << 22);
    config |= (0 << 3) | (sc->module << 5);   /* PORT_TYPE, MY_MODID */
    schan_write_reg(sc, R_CONFIG(port), config);
    schan_write_reg(sc, R_EPC_LINK(port), sc->portmap | CMIC_BIT);
    schan_write_reg(sc, R_CPU_CONTROL(port), 0);
    schan_write_reg(sc, R_BCAST_BLOCK_MASK(port), 0);

    /* CPU has a static L2 entry, so don't send unknown unicast there. */
    schan_write_reg(sc, R_UNKNOWN_UCAST_BLOCK_MASK(port), CMIC_BIT);

    /* If there is an IPIC port, forward all other-module traffic there. */
    if (sc->higig) {
	uint32_t ports;
	unsigned int module, slot;

	ports = 0;
	for (module = 0; module < 32; module++) {
	    slot = module % 8;
	    if (module != sc->module) ports |= (IPIC_PORT << (4*slot));
	    if (slot == 7) {
		schan_write_reg(sc, R_MODPORT_7_0(port) + (module/8), ports);
		ports = 0;
		}
	    }
	}

    schan_write_reg(sc, R_VLAN_CONTROL(port), VLAN_DEFAULT);
    schan_write_reg(sc, R_PRTABLE_DEFAULT(port), VLAN_DEFAULT);

    if (gmac) {
	schan_write_reg(sc, R_GMACC2(port), 0x0C);
	schan_write_reg(sc, R_GMACC1(port), 0x000A1001);
	schan_write_reg(sc, R_GMACC0(port), 0x0);
	schan_write_reg(sc, R_MAXFR(port), MAX_VLAN_PACK);
	cfe_usleep(10);

	schan_write_reg(sc, R_GMACC0(port), 0x1);
	schan_write_reg(sc, R_GPCSC(port), 0x4);
	cfe_usleep(10);

	schan_write_reg(sc, R_GMACC1(port), 0x500A1001);
	}
    else {
	schan_write_reg(sc, R_GTH_FE_MAC1(port), 0x0);
	if (linkspeed == ETHER_SPEED_100HDX || linkspeed == ETHER_SPEED_10HDX)
	    schan_write_reg(sc, R_GTH_FE_MAC2(port), 0x0);
	else
	    schan_write_reg(sc, R_GTH_FE_MAC2(port), 0x1);
	schan_write_reg(sc, R_GTH_FE_IPGT(port), 0x15);
	schan_write_reg(sc, R_GTH_FE_IPGR(port), 0x0C12);
	schan_write_reg(sc, R_GTH_FE_MAXF(port), MAX_VLAN_PACK);
	cfe_usleep(10);
	schan_write_reg(sc, R_GTH_FE_MAC1(port), 0x1);
	}
    mii_setup_internal(sc, port, linkspeed);
}

static void
gpic_stat_dump(bcm5690_state_t *sc, unsigned int port)
{
    uint32_t g;
    uint32_t count;
    int i;

    g = (port << 20);
    xprintf("--- gpic: %d ---\n", port);
    xprintf("GTPKT:   %08x   GTBYT:   %08x\n",
	    schan_read_reg(sc, g | 0x00048),
	    schan_read_reg(sc, g | 0x0005B));
    xprintf("GRPKT:   %08x   GRBYT:   %08x\n",
	    schan_read_reg(sc, g | 0x0002C),
	    schan_read_reg(sc, g | 0x0002F));
    xprintf("GRRUC:   %08x   GRMCA:   %08x   GRBCA:   %08x\n",
	    schan_read_reg(sc, g | 0x00043),
	    schan_read_reg(sc, g | 0x00030),
	    schan_read_reg(sc, g | 0x00031));

    /* Print error counts if non-zero. */
    count = schan_read_reg(sc, g | 0x0002D);
    if (count != 0) xprintf("GRUND:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x0002E);
    if (count != 0) xprintf("GRFRG:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x00032);
    if (count != 0) xprintf("GRFCS:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x00036);
    if (count != 0) xprintf("GRALN:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x00038);
    if (count != 0) xprintf("GRCDE:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x00039);
    if (count != 0) xprintf("GRFCR:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x0003A);
    if (count != 0) xprintf("GROVR:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x0003B);
    if (count != 0) xprintf("GRJBR:   %08x\n", count);
    count = schan_read_reg(sc, g | 0x00042);
    if (count != 0) xprintf("GRDISC:  %08x\n", count);
    count = schan_read_reg(sc, g | 0x00044);
    if (count != 0) xprintf("GRDISC:  %08x\n", count);
    count = schan_read_reg(sc, g | 0x00045);
    if (count != 0) xprintf("GRFILDR: %08x\n", count);
    count = schan_read_reg(sc, g | 0x00046);
    if (count != 0) xprintf("GRPORTD: %08x\n", count);
    for (i = 0; i < 14; i++) {
	count = schan_read_reg(sc, g | (0x0064+i));
	if (count != 0)
	    xprintf("GRHOLD[%d]: %08x\n", i, count);
	}
    count = schan_read_reg(sc, g | 0x00072);
    if (count != 0) xprintf("GRDROP:  %08x\n", count);

    xprintf("-----------------\n");
}

static void
gpic_stop(bcm5690_state_t *sc, unsigned int port)
{
}

static void
gpic_set_managed(bcm5690_state_t *sc, unsigned int port, int managed)
{
    portmap_t mask;

    /* Currently, CPU does not handle exception frames. */
    schan_write_reg(sc, R_CPU_CONTROL(port), (managed ? 0 : 0));

    mask = schan_read_reg(sc, R_BCAST_BLOCK_MASK(port));
    if (managed)
	mask |= CMIC_BIT;
    else
	mask &= ~CMIC_BIT;
    schan_write_reg(sc, R_BCAST_BLOCK_MASK(port), mask);

    mask = schan_read_reg(sc, R_UNKNOWN_MCAST_BLOCK_MASK(port));
    if (managed)
	mask |= CMIC_BIT;
    else
	mask &= ~CMIC_BIT;
    schan_write_reg(sc, R_UNKNOWN_MCAST_BLOCK_MASK(port), mask);

    mask =schan_read_reg(sc, R_EPC_LINK(port));
    if (managed)
	mask |= CMIC_BIT;
    else
	mask &= ~CMIC_BIT;
    schan_write_reg(sc, R_EPC_LINK(port), mask);
}


static void
port_init(bcm5690_state_t *sc)
{
    unsigned int port;
    int linkspeed;

    for (port = 0; port < GPIC_PORTS; port++) {
	linkspeed = sc->phy_info[port].linkspeed;
	if (linkspeed != ETHER_SPEED_UNKNOWN) {
	    gpic_init(sc, port, linkspeed);
	    if (XGS_DEBUG) dump_gpic(sc, port);
	    }
	}
}

static void
port_stop(bcm5690_state_t *sc)
{
    unsigned int port;

    for (port = 0; port < GPIC_PORTS; port++) {
	if ((sc->portmap & GPIC_BIT(port)) != 0) {
	    if (0 && XGS_DEBUG) dump_gpic(sc, port);
	    gpic_stop(sc, port);
	    if (1 || XGS_DEBUG)	gpic_stat_dump(sc, port);
	    }
	}
}

static void
port_set_managed(bcm5690_state_t *sc, int managed)
{
    unsigned int port;

    for (port = 0; port < GPIC_PORTS; port++) {
	if ((sc->portmap & GPIC_BIT(port)) != 0) {
	    gpic_set_managed(sc, port, managed);
	    }
	}
}


/* 10 Gigabit MAC management */

static void
xmac_init(bcm5690_state_t *sc)
{
    uint64_t ctrl;
    uint64_t rx_ctrl, tx_ctrl;
    uint64_t xgxs_ctrl, xgsx_stat;
    int i;

    /* See the port initialization sequence suggested in the
       BCM5670/BCM5671 Programmer's Reference Guide, p 67. */
    ctrl = schan_read_reg64(sc, R_MAC_CTRL(IPIC_PORT));
    rx_ctrl = schan_read_reg64(sc, R_MAC_RXCTRL(IPIC_PORT));
    tx_ctrl = schan_read_reg64(sc, R_MAC_TXCTRL(IPIC_PORT));

    tx_ctrl &= ~(M_TXCTRL_HDR_MODE | M_TXCTRL_CRC_MODE);
    tx_ctrl |= (V_TXCTRL_HDR_MODE(K_HDR_MODE_HIGIG) |
		V_TXCTRL_CRC_MODE(K_CRC_MODE_KEEP));
    schan_write_reg64(sc, R_MAC_TXCTRL(IPIC_PORT), tx_ctrl);
    rx_ctrl &= ~M_RXCTRL_HDR_MODE;
    rx_ctrl |= (V_RXCTRL_HDR_MODE(K_HDR_MODE_HIGIG) | M_RXCTRL_STRIP_CRC);
    schan_write_reg64(sc, R_MAC_RXCTRL(IPIC_PORT), rx_ctrl);

    xgxs_ctrl = schan_read_reg64(sc, R_MAC_XGXS_CTRL(IPIC_PORT));
    xgxs_ctrl &= ~(M_XGXSCTRL_IDDQ | M_XGXSCTRL_PWR_DWN);
    schan_write_reg64(sc, R_MAC_XGXS_CTRL(IPIC_PORT), xgxs_ctrl);
    cfe_usleep(100);
    xgxs_ctrl |= M_XGXSCTRL_HW_RST_L;
    schan_write_reg64(sc, R_MAC_XGXS_CTRL(IPIC_PORT), xgxs_ctrl);

    for (i = 10; i > 0; i--) {
	xgsx_stat = schan_read_reg64(sc, R_MAC_XGXS_STAT(IPIC_PORT));
	if ((xgsx_stat & M_XGXSSTAT_TXPLL_LOCK) != 0)
	    break;
	cfe_usleep(1000);
	}
    if (i == 0)
	xprintf("%s: XGXS PLL failed to lock\n", xgs_devname(sc));

    /* XXX The addition of 8 bytes here is empirical but necessary. */
    schan_write_reg64(sc, R_MAC_TXMAXSZ(IPIC_PORT), MAX_XGS_PACK+8);
    schan_write_reg64(sc, R_MAC_RXMAXSZ(IPIC_PORT), MAX_XGS_PACK+8);
}


static void
ipic_init(bcm5690_state_t *sc, unsigned int port)
{
    uint32_t base = (0x00000020 + (IPIC_PORT << 20));
    unsigned int offset;
    uint64_t ctrl;
    
    /* Zero the port statistics (36- or 42-bit registers) */
    for (offset = I_MIB_TX_FIRST; offset <= I_MIB_TX_LAST; offset++)
	schan_write_reg64(sc, base + offset, 0);
    for (offset = I_MIB_RX_FIRST; offset <= I_MIB_RX_LAST; offset++)
	schan_write_reg64(sc, base + offset, 0);
    /* The 569x extensions */
    for (offset = I_MIB_ITAGE; offset < I_MIB_IHOLD+14; offset++)
	schan_write_reg64(sc, base + offset, 0);

    schan_write_reg(sc, R_IEGR_ENABLE, 0x1);
    schan_write_reg(sc, R_ICONFIG, (sc->module << 12));  /* MY_MODID */
    schan_write_reg(sc, R_ILINK, sc->portmap | CMIC_BIT);
    schan_write_reg(sc, R_ICPU_CONTROL, 0);

    schan_write_reg(sc, R_IVLAN_CONTROL, VLAN_DEFAULT);

    /* Start the XGXS MAC. */
    ctrl = schan_read_reg64(sc, R_MAC_CTRL(IPIC_PORT));
    ctrl |= (M_MACCTRL_RX_EN | M_MACCTRL_TX_EN);
    schan_write_reg64(sc, R_MAC_CTRL(IPIC_PORT), ctrl);
}

static void
ipic_stat_dump(bcm5690_state_t *sc, unsigned int port)
{
    uint32_t base = (0x00000020 + (IPIC_PORT << 20));
    uint32_t count;
    int i;

    xprintf("--- ipic: %d ---\n", IPIC_PORT);
    xprintf("ITPKT:   %08llx   ITBYT:   %08llx\n",
	    schan_read_reg64(sc, base + I_MIB_ITPKT),
	    schan_read_reg64(sc, base + I_MIB_ITBYT));
    xprintf("IRPKT:   %08llx   IRBYT:   %08llx\n",
	    schan_read_reg64(sc, base + I_MIB_IRPKT),
	    schan_read_reg64(sc, base + I_MIB_IRBYT));
    xprintf("IRRUC:   %08llx   IRMCA:   %08llx   IRBCA:   %08llx\n",
	    schan_read_reg64(sc, base + 0x00036),
	    schan_read_reg64(sc, base + I_MIB_IRMCA),
	    schan_read_reg64(sc, base + I_MIB_IRBCA));

    /* Print error counts if non-zero. */
    count = schan_read_reg64(sc, base + I_MIB_IRUND);
    if (count != 0) xprintf("IRUND:   %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_IRFRG);
    if (count != 0) xprintf("IRFRG:   %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_IRFCS);
    if (count != 0) xprintf("IRFCS:   %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_IROVR);
    if (count != 0) xprintf("IROVR:   %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_IRDISC);
    if (count != 0) xprintf("IRDISC:  %08llx\n", count);
    count = schan_read_reg64(sc, base + I_MIB_ISDISC);
    if (count != 0) xprintf("ISDISC:  %08llx\n", count);
    for (i = 0; i < 14; i++) {
	count = schan_read_reg64(sc, base + (I_MIB_IHOLD+i));
	if (count != 0)
	    xprintf("IHOLD[%d]: %08llx\n", i, count);
	}

    xprintf("-----------------\n");
}

static void
ipic_stop(bcm5690_state_t *sc, unsigned int port)
{
}

static void
ipic_set_managed(bcm5690_state_t *sc, unsigned int port, int managed)
{
    portmap_t mask;

    /* Currently, CPU does not handle exception frames. */
    schan_write_reg(sc, R_ICPU_CONTROL, (managed ? 0 : 0));

    mask = schan_read_reg(sc, R_IBCAST_BLOCK_MASK);
    if (managed)
	mask |= CMIC_BIT;
    else
	mask &= ~CMIC_BIT;
    schan_write_reg(sc, R_IBCAST_BLOCK_MASK, mask);

    mask = schan_read_reg(sc, R_IUNKNOWN_MCAST_BLOCK_MASK);
    if (managed)
	mask |= CMIC_BIT;
    else
	mask &= ~CMIC_BIT;
    schan_write_reg(sc, R_IUNKNOWN_MCAST_BLOCK_MASK, mask);

    mask = schan_read_reg(sc, R_ILINK);
    if (managed)
	mask |= CMIC_BIT;
    else
	mask &= ~CMIC_BIT;
    schan_write_reg(sc, R_ILINK, mask);
}


static void
xgxs_port_init(bcm5690_state_t *sc)
{
    if ((sc->portmap & IPIC_BIT) != 0)
	ipic_init(sc, IPIC_PORT);
}

static void
xgxs_port_stop(bcm5690_state_t *sc)
{
    if ((sc->portmap & IPIC_BIT) != 0) {
	ipic_stop(sc, IPIC_PORT);
	if (1 || XGS_DEBUG) ipic_stat_dump(sc, IPIC_PORT);
	}
}

static void
xgxs_port_set_managed(bcm5690_state_t *sc, int managed)
{
    if ((sc->portmap & IPIC_BIT) != 0)
	ipic_set_managed(sc, IPIC_PORT, managed);
}


/* Address management */

/* Do brute-force lookups and simple FIFO table management for now.  */

typedef struct host_s {
    uint8_t addr[ENET_ADDR_LEN];
    uint8_t module;
    uint16_t portmap;
} host_t;

#define HOST_TAB_SIZE   16

static host_t hosts[HOST_TAB_SIZE];
static unsigned int last_host, next_host;

static void
host_init(bcm5690_state_t *sc)
{
    memset(hosts, 0, sizeof(hosts));
    last_host = next_host = 0;
}

static int
host_lookup (bcm5690_state_t *sc, uint8_t addr[])
{
    unsigned int i;

    i = last_host;
    do {
	if (memcmp(&hosts[i].addr, addr, ENET_ADDR_LEN) == 0) {
	    last_host = i;
	    return i;
	    }
	i = (i + 1) % HOST_TAB_SIZE;
    } while (i != last_host);

    return -1;
}

static void
host_add (bcm5690_state_t *sc, uint8_t addr[], uint8_t module, uint16_t map)
{
    if (host_lookup(sc, addr) == -1) {
	memcpy(&hosts[next_host].addr, addr, ENET_ADDR_LEN);
	hosts[next_host].module = module;
	hosts[next_host].portmap = map;

	if (XGS_DEBUG) xprintf("learn host %d: %a at %02x %04x\n",
			       next_host, addr, module, map);

	next_host = (next_host + 1) % HOST_TAB_SIZE;
	}
}


/* Switch management control. */

static void xgs_unmanaged(bcm5690_state_t *sc)
{
    portmap_t mask;

    /* Stop L2 forwarding to the CPU as host. */
    l2_delete(sc, sc->hwaddr);

    /* XXX A more paranoid implementation could also remove the CMIC
       port from DEFAULT_VLAN membership, but the code here appears
       adequate (perhaps even overkill). */

    /* For all the GPIC ports, disable forwarding of management
       traffic as well as flooding of multicast/broadcast packets to
       the CPU. */
    port_set_managed(sc, 0);

    /* Do the same for the HiGig ports. */
    xgxs_port_set_managed(sc, 0);

    /* Now stop the MMU from accepting more packets. */
    mask = schan_read_reg(sc, R_MMUPORTENABLE);
    mask &= ~CMIC_BIT;
    schan_write_reg(sc, R_MMUPORTENABLE, mask);
}

static void xgs_managed(bcm5690_state_t *sc)
{
    portmap_t mask;

    /* Undo the disabling of CMIC traffic above. */

    mask = schan_read_reg(sc, R_MMUPORTENABLE);
    mask |= CMIC_BIT;
    schan_write_reg(sc, R_MMUPORTENABLE, mask);

    port_set_managed(sc, 1);
    xgxs_port_set_managed(sc, 1);

    /* XXX Also add to DEFAULT_VLAN?  See comments above. */
    l2_enter(sc, sc->hwaddr, CMIC_PORT);
}


/* Packet management */

#define ETH_PKTPOOL_SIZE  16

static eth_pkt_t *
eth_alloc_pkt(bcm5690_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *) q_deqnext(&sc->freelist);
    CS_EXIT(sc);
    if (!pkt) return NULL;

    pkt->buffer = pkt->data;
    pkt->length = ETH_PKTBUF_LEN;
    pkt->flags = 0;

    return pkt;
}

static void
eth_free_pkt(bcm5690_state_t *sc, eth_pkt_t *pkt)
{
    CS_ENTER(sc);
    q_enqueue(&sc->freelist, &pkt->next);
    CS_EXIT(sc);
}

static void
eth_initfreelist(bcm5690_state_t *sc)
{
    int idx;
    uint8_t *ptr;
    eth_pkt_t *pkt;

    q_init(&sc->freelist);

    ptr = sc->pktpool;
    for (idx = 0; idx < ETH_PKTPOOL_SIZE; idx++) {
	pkt = (eth_pkt_t *) ptr;
	eth_free_pkt(sc, pkt);
	ptr += ETH_PKTBUF_SIZE;
	}
}



/* Packet DMA Service */

#define V_BIT_POS_RX1_EN         (V_DMA_BIT_POS(S_CH_DMA_EN(RX_CH1)))
#define V_BIT_POS_RX1_DESC_DONE  (V_DMA_BIT_POS(S_CH_DESC_DONE(RX_CH1)))
#define V_BIT_POS_RX1_CHAIN_DONE (V_DMA_BIT_POS(S_CH_CHAIN_DONE(RX_CH1)))

static int
xgs_add_rcvbuf(bcm5690_state_t *sc, eth_pkt_t *pkt)
{
    volatile dcb_t *dcb;
    volatile dcb_t *next;
    volatile dcb_t *last;
    uint32_t w1;

    dcb = sc->rx_add;

    next = dcb+1;
    if (next == sc->rx_end)
	next = sc->rx_start;

    /* If the next is the same as our remove pointer, the ring is
       considered full.  */
    if (next == sc->rx_remove)
	return -1;

    /* Add a descriptor with its chain bit off */
    memset((void *)dcb, 0, sizeof(dcb_t));
    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = (V_DCB1_BYTE_COUNT(ETH_PKTBUF_LEN)
	       | V_DCB1_COS(0));
    
    CACHE_DMA_INVAL(pkt->buffer, pkt->length);
    CACHE_DMA_SYNC(dcb, sizeof(dcb_t));

    /* Turn on the chain bit for the previous descriptor */

    /* XXX Chaining from last to first via the terminal RLD DCB
       appears to lose pending interrupts.  For now, cause an
       end-of-chain interrupt and restart instead. */
    if (dcb != sc->rx_start) {
	last = sc->rx_last;
	w1 = last->w1 | M_DCB1_C;
	last->w1 = w1;
	CACHE_DMA_SYNC(last, sizeof(dcb_t));   /* XXX or just write uncached? */
	}
    
    sc->rx_last = dcb;
    sc->rx_add = next;
    return 0;
}

static void
xgs_fillrxring(bcm5690_state_t *sc)
{
    eth_pkt_t *pkt;

    CS_ENTER(sc);
    while (1) {
	if (sc->rx_onring >= MIN_RX_BUFFERS) {
	    CS_EXIT(sc);
	    break;
	    }
	CS_EXIT(sc);
	pkt = eth_alloc_pkt(sc);
	if (pkt == NULL) {
	    /* could not allocate a buffer */
	    break;
	    }
	if (xgs_add_rcvbuf(sc, pkt) != 0) {
	    /* could not add buffer to ring */
	    eth_free_pkt(sc, pkt);
	    break;
	    }
	CS_ENTER(sc);
	sc->rx_onring++;
	}
}

static void
xgs_rx_callback(bcm5690_state_t *sc, eth_pkt_t *pkt)
{
    if (XGS_DEBUG) show_packet('>', pkt);   /* debug */

    CS_ENTER(sc);
    q_enqueue(&sc->rxqueue, &pkt->next);
    CS_EXIT(sc);
    sc->inpkts++;
}

static void
xgs_procrxring(bcm5690_state_t *sc)
{
    volatile dcb_t *dcb;
    eth_pkt_t *pkt;
    eth_pkt_t *new_pkt;

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_DESC_DONE | V_DMA_BIT_0);

    while (1) {
	dcb = sc->rx_remove;
	CACHE_DMA_INVAL(dcb, sizeof(dcb_t));

	if (dcb == sc->rx_add || (dcb->w5 & M_DCB5_DONE) == 0)
	    return;
    
#if XGS_DEBUG
	xprintf("recv: dcb %08x %08x %08x %08x\n"
		"          %08x %08x %08x %08x\n",
		dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
		dcb->w4, dcb->w5, dcb->w6, dcb->w7);
#endif

	pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));
	pkt->length = G_DCB5_RCV_COUNT(dcb->w5) - ENET_CRC_SIZE;
	CACHE_DMA_INVAL(pkt->buffer, pkt->length);

	/* Learn src addresses only from unicast.  This assumes that
	   the appropriate egress port is the same as the ingress
	   port.  In an interrupt-driven system, it would be better to
	   defer this, but the descriptor information must be saved in
	   that case.  */
	if ((pkt->buffer[0] & 0x01) == 0)
	    host_add(sc, &pkt->buffer[ENET_ADDR_LEN],
		     G_DCB6_SRC_MOD_ID(dcb->w6),
		     1 << G_DCB6_SRC_PORT(dcb->w6));

	xgs_rx_callback(sc, (eth_pkt_t *)pkt);
    
	/* update the remove pointer */
	dcb++;
	if (dcb == sc->rx_end)
	    dcb = sc->rx_start;
	sc->rx_remove = dcb;

	new_pkt = eth_alloc_pkt(sc);
	if (new_pkt) {
	    /* The ring must have space now. */
	    xgs_add_rcvbuf(sc, new_pkt);
	    }
	else {
	    CS_ENTER(sc);
	    sc->rx_onring--;
	    CS_EXIT(sc);
	    }
	}
}

static void
xgs_procrxdone(bcm5690_state_t *sc)
{
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_CHAIN_DONE | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_DESC(RX_CH1), PTR_TO_PCI(sc->rx_remove));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_1);
}


#define V_BIT_POS_TX_EN          (V_DMA_BIT_POS(S_CH_DMA_EN(TX_CH)))
#define V_BIT_POS_TX_DESC_DONE   (V_DMA_BIT_POS(S_CH_DESC_DONE(TX_CH)))
#define V_BIT_POS_TX_CHAIN_DONE  (V_DMA_BIT_POS(S_CH_CHAIN_DONE(TX_CH)))

static int
xgs_transmit(bcm5690_state_t *sc, eth_pkt_t *pkt)
{
    unsigned int module;
    portmap_t portmap;
    /*volatile*/ dcb_t *dcb;

    if (sc->txbusy)
	return -1;

    sc->txbusy = 1;

    if (XGS_DEBUG) show_packet('<', pkt);

    /* The CMIC "recomputes" the CRC, does not append it. */
    pkt->length += ENET_CRC_SIZE;

    /* For unicast destinations, use the learned address if any,
       otherwise broadcast.  */
    if ((pkt->buffer[0] & 0x01) == 0) {
	int i = host_lookup(sc, &pkt->buffer[0]);

	if (i != -1) {
	    module = hosts[i].module;
	    portmap = hosts[i].portmap;
	    }
	else {
	    if (XGS_DEBUG) xprintf("bcast host %a\n", &pkt->buffer[0]);
	    module = sc->module;
	    portmap = sc->portmap;
	    }
	}
    else {
	module = sc->module;
	portmap = sc->portmap;
        }

    dcb = sc->dcbs[TX_CH];
    memset(dcb, 0, sizeof(dcb_t));
    dcb->mem_addr = PTR_TO_PCI(pkt->buffer);
    dcb->w1 = (V_DCB1_BYTE_COUNT(pkt->length)
	       | M_DCB1_CRC_REGEN
	       | V_DCB1_DST_MOD_ID(module)
	       | V_DCB1_COS(0));
    dcb->w2 = V_DCB2_PORT_MAP(portmap);
    dcb->w3 = V_DCB3_UNTAGGED_MAP(sc->portmap);
    
    CACHE_DMA_SYNC(pkt->buffer, pkt->length);
    CACHE_DMA_SYNC(dcb, sizeof(dcb_t));

    WRITECSR(sc, R_CMIC_DMA_DESC(TX_CH), PTR_TO_PCI(dcb));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_1);

    sc->outpkts++;
    return 0;
}

static void
xgs_proctxchain(bcm5690_state_t *sc)
{
    /*volatile*/ dcb_t *dcb;
    eth_pkt_t *pkt;

    if (!sc->txbusy)
	return;

    dcb = sc->dcbs[TX_CH];
    CACHE_DMA_INVAL(dcb, sizeof(dcb_t));

    if ((dcb->w5 & M_DCB5_DONE) == 0)
	return;

#if XGS_DEBUG
    xprintf("xmit: dcb %08x %08x %08x %08x\n          %08x %08x %08x %08x\n",
	    dcb->mem_addr, dcb->w1, dcb->w2, dcb->w3,
	    dcb->w4, dcb->w5, dcb->w6, dcb->w7);
#endif

    /* Just free the packet */
    pkt = ETH_PKT_BASE(PCI_TO_PTR(dcb->mem_addr));
    eth_free_pkt(sc, pkt);

    /* Evidently, the channel will not restart until CHAIN_DONE is
       clear, and empirically, CHAIN_DONE cannot reliably be cleared
       until DMA_EN is cleared. */

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_EN | V_DMA_BIT_0);

    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_DESC_DONE | V_DMA_BIT_0);
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_TX_CHAIN_DONE | V_DMA_BIT_0);

    sc->txbusy = 0;
}


static void
xgs_initrings(bcm5690_state_t *sc)
{
    dcb_t *rxd;

    /* Initialize the ring control bits */
    for (rxd = sc->rx_start; rxd != sc->rx_end; rxd++) {
	memset(rxd, 0, sizeof(dcb_t));
	rxd->w1 = 0;    /* Clear S/G, RLD, C */
	CACHE_DMA_SYNC(rxd, sizeof(dcb_t));
	}

    /* The final descriptor is used just to close the ring (RLD). It
       is never read or updated again by software and can safely share
       a cache line with the preceding descriptor.
       XXX This feature is (temporarily?) not used; see above.  */
    rxd = sc->rx_end;
    memset(rxd, 0, sizeof(dcb_t));
    rxd->mem_addr = PTR_TO_PCI(sc->rx_start);
    rxd->w1 = M_DCB1_RLD | M_DCB1_C;
    CACHE_DMA_SYNC(rxd, sizeof(dcb_t));

    sc->rx_add = sc->rx_remove = sc->rx_start;
    sc->rx_last = sc->rx_end;
    sc->rx_onring = 0;

    /* Precharge the receive ring. */
    xgs_fillrxring(sc);

    /* Start DMA.  XXX Make this a function? */
    WRITECSR(sc, R_CMIC_DMA_DESC(RX_CH1), PTR_TO_PCI(sc->rx_remove));
    WRITECSR(sc, R_CMIC_DMA_STAT, V_BIT_POS_RX1_EN | V_DMA_BIT_1);
}

static void
xgs_init(bcm5690_state_t *sc)
{
    /* Allocate buffer pool */
    sc->pktpool = KMALLOC(ETH_PKTPOOL_SIZE*ETH_PKTBUF_SIZE, CACHE_ALIGN);
    eth_initfreelist(sc);
    q_init(&sc->rxqueue);

    sc->dcbs[TX_CH] = KMALLOC(sizeof(dcb_t), CACHE_ALIGN);
    sc->txbusy = 0;

    /* The final rx DCB is used just for chaining. */
    sc->dcbs[RX_CH1] = KMALLOC((RX_RING_SIZE+1) * sizeof(dcb_t), CACHE_ALIGN);

    sc->rx_start = sc->dcbs[RX_CH1];
    sc->rx_end = sc->rx_start + RX_RING_SIZE;

    xgs_initrings(sc);
}

static void
xgs_reinit(bcm5690_state_t *sc)
{
    /* NYI */
}


static void
xgs_hwinit(bcm5690_state_t *sc)
{
    if (sc->state == eth_state_uninit) {
	uint32_t config;

#if ENDIAN_BIG
	/* Documentation is confusing/misleading here.  For 47xx and 1250: */
	WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x02020202);
#else
	WRITECSR(sc, R_CMIC_ENDIANESS_SEL, 0x00000000);
#endif

	/* Clear S-channel bits */
	WRITECSR(sc, R_CMIC_SCHAN_CTRL,
		 V_SCTL_BIT_POS(S_SCTL_MIIM_OP_DONE) | V_SCTL_BIT_0);
	WRITECSR(sc, R_CMIC_SCHAN_CTRL,
		 V_SCTL_BIT_POS(S_SCTL_MSG_START) | V_SCTL_BIT_0);

	config = READCSR(sc, R_CMIC_CONFIG);
	/* PCI interface options. */
	config |= M_RD_BRST_EN | M_WR_BRST_EN | M_MSTR_Q_MAX_EN;
	/* DMA options */
	config |= M_IGNORE_ADR_ALIGN_EN | M_SG_ENABLE | M_SG_RELOAD_ENABLE;
	/* Normal operation */
	config |= M_EXT_MDIO_MSTR_DIS;
	WRITECSR(sc, R_CMIC_CONFIG, config);

	/* Configure DMA channels. */
	WRITECSR(sc, R_CMIC_DMA_CTRL, M_CH_DIRECTION(TX_CH));

	sc->portmap = phy_scan(sc);
	if (sc->higig) {
	    /* Scanning the HiGig port requires enabling its MAC. */
	    xmac_init(sc);
	    sc->portmap |= xgxs_phy_scan(sc);
	    }
	xprintf("%s: active port map: %04X\n", xgs_devname(sc), sc->portmap);

	arl_init(sc);
	mmu_init(sc, sc->portmap | CMIC_BIT);
	table_init(sc, sc->portmap | CMIC_BIT);

	port_init(sc);
	if (sc->higig)
	    xgxs_port_init(sc);

	l2_enter(sc, sc->hwaddr, CMIC_PORT);

	sc->state = eth_state_off;
	}
}


static void
xgs_isr(void *arg)
{
    bcm5690_state_t *sc = (bcm5690_state_t *)arg;
    uint32_t irqstat = READCSR(sc, R_CMIC_IRQ_STAT);

    if (IPOLL) sc->interrupts++;

    /* XGS DMA does not guarantee the order in which the DESC_DONE and
       CHAIN_DONE interrupts are delivered.  The following code does
       assume that the DONE bits of all completed descriptors are set
       before either interrupt is asserted. */

    if (irqstat & M_IRQ_CHAIN_DONE(RX_CH1)) {
	if (IPOLL) sc->rx_interrupts++;
        xgs_procrxring(sc);
	xgs_procrxdone(sc);
	}
    else if (irqstat & M_IRQ_DESC_DONE(RX_CH1)) {
	if (IPOLL) sc->rx_interrupts++;
        xgs_procrxring(sc);
	}

    if (irqstat & M_IRQ_CHAIN_DONE(TX_CH)) {
	if (IPOLL) sc->tx_interrupts++;
        xgs_proctxchain(sc);
	}
}

static void
xgs_start(bcm5690_state_t *sc)
{
    uint32_t pending;

    if (sc->state == eth_state_switch) {
        xgs_managed(sc);
	}
    else {
	host_init(sc);

	xgs_hwinit(sc);

	sc->intmask = 0;
	WRITECSR(sc, R_CMIC_IRQ_MASK, 0);
	pending = READCSR(sc, R_CMIC_IRQ_STAT);
	WRITECSR(sc, R_CMIC_IRQ_STAT, pending);
	(void)READCSR(sc, R_CMIC_IRQ_STAT);   /* push */
	}

    sc->intmask = (M_IRQ_CHAIN_DONE(RX_CH1) | M_IRQ_DESC_DONE(RX_CH1)
		   | M_IRQ_CHAIN_DONE(TX_CH));

#if IPOLL
    cfe_request_irq(sc->irq, xgs_isr, sc, CFE_IRQ_FLAGS_SHARED, 0);
    WRITECSR(sc, R_CMIC_IRQ_MASK, sc->intmask);
#endif

    sc->state = eth_state_on;
}

static void
xgs_stop(bcm5690_state_t *sc)
{
    if (XGS_DEBUG) l2_dump(sc);

    if (sc->higig)
	xgxs_port_stop(sc);
    port_stop(sc);

    if (sc->state == eth_state_on) {
	sc->intmask = 0;
	WRITECSR(sc, R_CMIC_IRQ_MASK, 0);
	(void)READCSR(sc, R_CMIC_IRQ_MASK);   /* push */
#if IPOLL
	cfe_free_irq(sc->irq, 0);
#endif
	/* Shut down the CPU interface. */
	xgs_unmanaged(sc);
	xgs_reinit(sc);
	sc->state = eth_state_switch;
	}
}


static int bcm5690_open(cfe_devctx_t *ctx);
static int bcm5690_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5690_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat);
static int bcm5690_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5690_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer);
static int bcm5690_close(cfe_devctx_t *ctx);
static void bcm5690_poll(cfe_devctx_t *ctx, int64_t ticks);
static void bcm5690_reset(void *softc);

const static cfe_devdisp_t bcm5690_dispatch = {
    bcm5690_open,
    bcm5690_read,
    bcm5690_inpstat,
    bcm5690_write,
    bcm5690_ioctl,
    bcm5690_close,	
    bcm5690_poll,
    bcm5690_reset
};

cfe_driver_t bcm5690drv = {
    "BCM569x switch",
    "eth",
    CFE_DEV_NETWORK,
    &bcm5690_dispatch,
    bcm5690_probe
};


static int
bcm5690_attach(cfe_driver_t *drv, pcitag_t tag, uint8_t hwaddr[])
{
    bcm5690_state_t *sc;
    char descr[80];
    phys_addr_t pa;
    pcireg_t device, class;
    uint32_t cmic_id;

    pci_map_mem(tag, PCI_MAPREG(0), CSR_MATCH_MODE, &pa);

    sc = (bcm5690_state_t *) KMALLOC(sizeof(bcm5690_state_t), 0);
    if (sc == NULL) {
	xprintf("BCM569x: No memory to complete probe\n");
	return 0;
	}
    memset(sc, 0, sizeof(*sc));

    sc->regbase = (uint32_t)pa;
    sc->irq = pci_conf_read(tag, PCI_BPARAM_INTERRUPT_REG) & 0xFF;

    device = pci_conf_read(tag, PCI_ID_REG);
    class = pci_conf_read(tag, PCI_CLASS_REG);
    sc->tag = tag;
    sc->device = PCI_PRODUCT(device);
    sc->revision = PCI_REVISION(class);
    switch (sc->device) {
	case K_PCI_ID_BCM5690:
	case K_PCI_ID_BCM5692:
	    sc->higig = 1;
	    break;
	default:
	    sc->higig = 0;
	    break;
	}

    cmic_id = READCSR(sc, R_CMIC_DEV_REV_ID);
    sc->module = G_ID_MOD_ID(cmic_id);

    sc->devctx = NULL;

    /* Always use the MAC address that was passed in. */
    memcpy(sc->hwaddr, hwaddr, ENET_ADDR_LEN);

    xgs_init(sc);
    sc->state = eth_state_uninit;

    xsprintf(descr, "BCM%04X StrataXGS Switch (mod %02X) at 0x%08X",
	     sc->device, sc->module, sc->regbase);
    cfe_attach(drv, sc, NULL, descr);

    return 1;
}

static void
bcm5690_probe(cfe_driver_t *drv,
	      unsigned long probe_a, unsigned long probe_b, 
	      void *probe_ptr)
{
    int index;
    uint8_t hwaddr[ENET_ADDR_LEN];

    if (probe_ptr)
	enet_parse_hwaddr((char *)probe_ptr, hwaddr);
    else {
	/* Use default address 02-10-18-56-90-01 */
	hwaddr[0] = 0x02;  hwaddr[1] = 0x10;  hwaddr[2] = 0x18;
	hwaddr[3] = 0x56;  hwaddr[4] = 0x90;  hwaddr[5] = 0x01;
	}

    index = 0;
    for (;;) {
	pcitag_t tag;
	pcireg_t device;

	if (pci_find_class(PCI_CLASS_NETWORK, index, &tag) != 0)
	   break;

	index++;

	device = pci_conf_read(tag, PCI_ID_REG);
	if (PCI_VENDOR(device) == K_PCI_VENDOR_BROADCOM) {
	    switch (PCI_PRODUCT(device)) {
		case K_PCI_ID_BCM5690:
		case K_PCI_ID_BCM5691:
		case K_PCI_ID_BCM5692:
		case K_PCI_ID_BCM5693:
		    bcm5690_attach(drv, tag, hwaddr);
		    enet_incr_hwaddr(hwaddr, 1);
		    break;
		default:
		    break;
		}
	    }
	}
}


/* The functions below are called via the dispatch vector for the XGS switch */

static int
bcm5690_open(cfe_devctx_t *ctx)
{
    bcm5690_state_t *sc = ctx->dev_softc;

    if (sc->state == eth_state_on)
	xgs_stop(sc);

    sc->devctx = ctx;

    sc->inpkts = sc->outpkts = 0;
    sc->interrupts = 0;
    sc->rx_interrupts = sc->tx_interrupts = 0;

    xgs_start(sc);

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm5690_read(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm5690_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    CS_ENTER(sc);
    pkt = (eth_pkt_t *)q_deqnext(&(sc->rxqueue));
    CS_EXIT(sc);

    if (pkt == NULL) {
	buffer->buf_retlen = 0;
	return 0;
	}

    blen = buffer->buf_length;
    if (blen > pkt->length) blen = pkt->length;

    /* Remove the VLAN tag. */
    hs_memcpy_to_hs(buffer->buf_ptr, pkt->buffer, 12);
    hs_memcpy_to_hs(buffer->buf_ptr+12, pkt->buffer+16, blen-16);
    buffer->buf_retlen = blen - VLAN_TAG_LEN;

    eth_free_pkt(sc, pkt);

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm5690_inpstat(cfe_devctx_t *ctx, iocb_inpstat_t *inpstat)
{
    bcm5690_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    /* We avoid an interlock here because the result is a hint and an
       interrupt cannot turn a non-empty queue into an empty one. */
    inpstat->inp_status = (q_isempty(&(sc->rxqueue))) ? 0 : 1;

    return 0;
}

static int
bcm5690_write(cfe_devctx_t *ctx, iocb_buffer_t *buffer)
{
    bcm5690_state_t *sc = ctx->dev_softc;
    eth_pkt_t *pkt;
    int blen;

    if (XPOLL) xgs_isr(sc);

    if (sc->state != eth_state_on) return -1;

    pkt = eth_alloc_pkt(sc);
    if (!pkt) return CFE_ERR_NOMEM;

    blen = buffer->buf_length;
    if (blen > pkt->length - VLAN_TAG_LEN)
	blen = pkt->length - VLAN_TAG_LEN;

    /* Empirically, the logic will unconditionally delete 4 bytes from
       the nominal position of a VLAN tag, so insert something to
       strip. */
    hs_memcpy_from_hs(pkt->buffer, buffer->buf_ptr, 12);
    pkt->buffer[12] = VLAN_TYPE >> 8; pkt->buffer[13] = VLAN_TYPE & 0xFF;
    pkt->buffer[14] = VLAN_DEFAULT >> 8; pkt->buffer[15] = VLAN_DEFAULT & 0xFF;
    hs_memcpy_from_hs(pkt->buffer+16, buffer->buf_ptr+12, blen-12);

    /* The CMIC apparently does not correctly auto-pad short packets. */
    if (blen < ENET_MIN_PKT) {
	memset(pkt->buffer + blen + VLAN_TAG_LEN, 0, ENET_MIN_PKT - blen);
	blen = ENET_MIN_PKT;
	}

    pkt->length = blen + VLAN_TAG_LEN;

    if (xgs_transmit(sc, pkt) != 0) {
	eth_free_pkt(sc,pkt);
	return CFE_ERR_IOERR;
	}

    if (XPOLL) xgs_isr(sc);
    return 0;
}

static int
bcm5690_ioctl(cfe_devctx_t *ctx, iocb_buffer_t *buffer) 
{
    bcm5690_state_t *sc = ctx->dev_softc;

    switch ((int)buffer->buf_ioctlcmd) {
	case IOCTL_ETHER_GETHWADDR:
	    hs_memcpy_to_hs(buffer->buf_ptr, sc->hwaddr, sizeof(sc->hwaddr));
	    return 0;

	default:
	    return -1;
	}
}

static int
bcm5690_close(cfe_devctx_t *ctx)
{
    bcm5690_state_t *sc = ctx->dev_softc;

    xgs_stop(sc);

    xprintf("%s: %d sent, %d received",
	    xgs_devname(sc), sc->outpkts, sc->inpkts);
    if (IPOLL) {
	xprintf(", %d interrupts\n", sc->interrupts);
	xprintf("  %d tx interrupts, %d rx interrupts",
		sc->tx_interrupts, sc->rx_interrupts);
	}
    xprintf("\n");

    sc->devctx = NULL;
    return 0;
}

static void
bcm5690_poll(cfe_devctx_t *ctx, int64_t ticks)
{
    bcm5690_state_t *sc = ctx->dev_softc;

    if (XPOLL) xgs_isr(sc);
}

static void
bcm5690_reset(void *softc)
{
    bcm5690_state_t *sc = (bcm5690_state_t *)softc;

    /* Turn off the Ethernet interface. */

    if (sc->state == eth_state_on)
	xgs_stop(sc);

    /* XXX Reset the chip here. */
    sc->state = eth_state_uninit;
}
