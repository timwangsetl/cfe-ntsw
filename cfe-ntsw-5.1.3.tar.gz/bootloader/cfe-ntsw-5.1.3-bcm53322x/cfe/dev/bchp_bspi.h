/***************************************************************
**
**  Broadcom Corp. Confidential
**  Copyright 2007 Broadcom Corp.  All Rights Reserved.
**
**  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED 
**  SOFTWARE LICENSE AGREEMENT  BETWEEN THE USER AND BROADCOM.  
**  YOU HAVE NO RIGHT TO USE OR EXPLOIT THIS MATERIAL EXCEPT 
**  SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
**
**  File:         bspi_flash.h
**  Description:  Serial flash mgmt
**  Created:      Wed Mar 21 13:31:21 PDT 2007 - Jeffrey P. Fisher      
**
****************************************************************/
#ifndef __BCHP_BSPI_H__
#define __BCHP_BSPI_H__

/*
 * Register and bit definitions for the BSPI control
 * registers.
 */

/* Control and Interrupt Registers */
#define BCHP_BSPI_MAST_N_BOOT_CTRL    0x680
#define BCHP_BSPI_BUSY_STATUS         0x684
#define BCHP_BSPI_INTR_STATUS         0x688
#define BCHP_BSPI_B0_STATUS           0x68c
#define BCHP_BSPI_B0_CTRL             0x690
#define BCHP_BSPI_B1_STATUS           0x694
#define BCHP_BSPI_B1_CTRL             0x698

/*
 * Register and bit definitions for the MSPI control
 * registers.
 */

/* Control and Interrupt Registers */
#define BCHP_MSPI_SPCR0_LSB           0x500
#define BCHP_MSPI_SPCR0_MSB           0x504
#define BCHP_MSPI_SPCR1_LSB           0x508
#define BCHP_MSPI_SPCR1_MSB           0x50c
#define BCHP_MSPI_NEWQP               0x510
#define BCHP_MSPI_ENDQP               0x514
#define BCHP_MSPI_SPCR2               0x518
#define BCHP_MSPI_MSPI_STATUS         0x520
#define BCHP_MSPI_CPTQP               0x524
#define BCHP_MSPI_TXRAM00             0x540
#define BCHP_MSPI_RXRAM00             0x5c0
#define BCHP_MSPI_RXRAM01             0x5c4
#define BCHP_MSPI_CDRAM00             0x640

#define ReadReg32(x)    \
  (*(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BASE+(x)))
#define WriteReg32(x,v) \
  (*(volatile uint32_t *)PHYS_TO_K1(SB_CHIPC_BASE+(x)) = (v))

#define BCHP_MSPI_SPCR2_spe_MASK         (1 << (6))
#define BCHP_MSPI_MSPI_STATUS_SPIF_MASK  (1 << (0))
#define BCHP_MSPI_SPCR0_MSB_MSTR_MASK    (1 << (7))
#define BCHP_MSPI_SPCR0_MSB_CPOL_MASK    (1 << (1))
#define BCHP_MSPI_SPCR0_MSB_CPHA_MASK    (1 << (0))


#endif /* __BCHP_BSPI_H__ */

