
/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Virtual Flash Driver for dual image     File: dev_dimage.c
    *  
    *  This driver supports dual image functionalities.
    *  
    *  Author:  Jimmy Chao
    *  
    *********************************************************************  
    *
    *  Copyright 2000-2007
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"

/*  *********************************************************************
    *  Configurations
    ********************************************************************* */

#define DIMG_DRV_DEBUG      0 /* 0-2 for debugging level */
#define OS_PART1            "flash1.os"
#define OS_PART2            "flash1.os2"
#define VPART1_BOOTINFO     "os"
#define VPART2_BOOTINFO     "os2"

/*  *********************************************************************
    *  Structures
    ********************************************************************* */
    
typedef struct dimagedev_s {
    int primary;        /* Whether this virtual partition is primary */
    int score;          /* The max score we get; -2 if only one partition */
    const char *part;   /* Physical partition name */
    int handle;         /* Handle to underlying flash partition if opened */
    int dirty;          /* Indicates the partition has been written */
} dimagedev_t;
    

/*  *********************************************************************
    *  Macros
    ********************************************************************* */

/* Timestamp format */
#define TIMESTAMP_MAGIC_START   (0xAC)
#define TIMESTAMP_MAGIC_END     (0x47)

/* Debug macro */
#define DIMG_DBG(depth, fmt, args...) do { \
    if (DIMG_DRV_DEBUG >= depth) { \
        xprintf(fmt , ##args); \
    } \
} while(0) 

/* gzip flag byte */
#define ASCII_FLAG   0x01   /* bit 0 set: file probably ascii text */
#define HEAD_CRC     0x02   /* bit 1 set: header CRC present */
#define EXTRA_FIELD  0x04   /* bit 2 set: extra field present */
#define ORIG_NAME    0x08   /* bit 3 set: original file name present */
#define COMMENT      0x10   /* bit 4 set: file comment present */
#define RESERVED     0xE0   /* bits 5..7: reserved */

/*  *********************************************************************
    *  Forward declarations
    ********************************************************************* */

static void flashdrv_probe(cfe_driver_t * drv,
      unsigned long probe_a, unsigned long probe_b, void *probe_ptr);

static int flashdrv_open(cfe_devctx_t * ctx);
static int flashdrv_read(cfe_devctx_t * ctx, iocb_buffer_t * buffer);
static int flashdrv_inpstat(cfe_devctx_t * ctx, iocb_inpstat_t * inpstat);
static int flashdrv_write(cfe_devctx_t * ctx, iocb_buffer_t * buffer);
static int flashdrv_ioctl(cfe_devctx_t * ctx, iocb_buffer_t * buffer);
static int flashdrv_close(cfe_devctx_t * ctx);


/*  *********************************************************************
    *  Device dispatch
    ********************************************************************* */

const static cfe_devdisp_t flashdrv_dispatch = {
    flashdrv_open,
    flashdrv_read,
    flashdrv_inpstat,
    flashdrv_write,
    flashdrv_ioctl,
    flashdrv_close,
    NULL,
    NULL
};

const cfe_driver_t dimagedrv = {
    "Dual Image Virtual Flash",
    "vflash",
    CFE_DEV_FLASH,
    &flashdrv_dispatch,
    flashdrv_probe
};


/*  *********************************************************************
    *  Externs
    ********************************************************************* */


/*  *********************************************************************
    *  Globals
    ********************************************************************* */

/* gz format */    
static const uint8_t gz_magic[] = { 0x1f, 0x8b, 0x08};


/*  *********************************************************************
    *  check_header(handle)
    *  
    *  Check image header and get the image boundary
    *  
    *  Input parameters: 
    *      handle - handle returned by cfe_open with the partition
    *      
    *  Return value:
    *      The offset where timestamp should begin with
    ********************************************************************* */

static int
check_header(int handle, int *pbytecount)
{
    uint8_t buf[128];
    int r;
    int flags;
    int offset;
    int bytecount;
    
    /* Read the first 128 bytes into buffer */
    r = cfe_readblk(handle, 0, PTR2HSADDR(buf), sizeof(buf) - 1);
    if (r != sizeof(buf) - 1) {
        return -2;
    }
    buf[sizeof(buf) - 1] = 0; /* To terminate for string operations */
    
    /* Check gzip header */
    if (memcmp(buf, gz_magic, sizeof(gz_magic))) {
        return -1;
    }
    
    /* Check flags */
    flags = (int)buf[3];
    if (flags & RESERVED) {
        /* It should always be zero */
        return -1;
    }
    if (flags & EXTRA_FIELD) {
        /* We don't allow extra fields for now */
        return -1;
    }
    if ((flags & COMMENT) == 0 || (flags & ORIG_NAME) == 0) {
        /* WSS image must have comment and filename */
        return -1;
    }
    
    /* File name starts at offset 10 */
    offset = 10;
    
    /* Skip filename */
    offset += strlen((const char *)&buf[offset]) + 1;
    if (offset >= sizeof(buf)) {
        return -1;
    }
    
    /* Now the comment */
    if (strlen((const char *)&buf[offset]) != 8 + 4) {
        return -1;
    }
    
    /* Extract byte count from comment */
    buf[offset + 8] = 0;
    bytecount = xtoi((const char *)&buf[offset]);
    if (bytecount <= 0) {
        return -1;
    } else {
        flash_info_t flashinfo;
        if (cfe_ioctl(handle, IOCTL_FLASH_GETINFO, 
            (unsigned char *)&flashinfo, sizeof(flash_info_t), &r, 0) == 0) {
            if (bytecount > flashinfo.flash_size - offset - 8 - 4) {
                return -1;
            }
        }
    }
    
    if (pbytecount) {
        *pbytecount = bytecount;
    }
    return offset + 8 + 4 + 1 + bytecount;
}

/*  *********************************************************************
    *  check_image(handle)
    *  
    *  Check image header, verify checksum and get the image boundary
    *  
    *  Input parameters: 
    *      handle - handle returned by cfe_open with the partition
    *      
    *  Return value:
    *      The offset where timestamp should begin with.
    *      0 if header OK but checksum incorrect.
    *      <0 if header not OK.
    ********************************************************************* */
static int
check_image(int handle)
{
    unsigned char buf[256];
    int bytecount, checksum;
    int offset;
    int r;
    int res, start, i, j;
    
    /* Check header and get offset of the payload */
    offset = check_header(handle, &bytecount);
    if (offset < 0) {
        return offset;
    }
    
    /* Get checksum */
    r = cfe_readblk(handle, offset - bytecount - 5, PTR2HSADDR(buf), 5);
    if (buf[4] != 0) {
        return -1;
    }
    checksum = xtoi((const char*)buf);
    
    /* Check checksum */
    start = offset - bytecount;
    res = 0;
    for(i=0; i<bytecount;) {
        int bytes = bytecount - i > sizeof(buf)? sizeof(buf) : bytecount - i;
        r = cfe_readblk(handle, start + i, PTR2HSADDR(buf), bytes);
        if (r != bytes) {
            return -1;
        }
        for(j=0; j<r; j++) {
            res += (int)buf[j];
        }
        i += r;
    }
    res &= 0xFFFF;
    if (res != checksum) {
        return 0;
    }
    
    return offset;
}

/*  *********************************************************************
    *  calculate_score(handle)
    *  
    *  Calculate the score which measures how valid and latest the image is
    *  
    *  Input parameters: 
    *      handle - handle returned by cfe_open with the partition
    *      
    *  Return value:
    *      Score of the partition:
    *         -2:     something's wrong
    *         -1:     invalid image
    *          0:     header OK but no timestamp
    *         others: header OK with score set to the timestampe
    ********************************************************************* */

static int
calculate_score(int handle)
{
    /*
     * XXX: We check header and timestamp only without checksum verification
     *      in this stage. Problem may occur in the follwing rare case:
     *      - Part1 contains valid header, TS but invalid checksum
     *      - Part2 contains valid header, TS and checksum but TS is smaller
     *      Then the Part1 becomes primary and after writing new firmware,
     *      Part2 (only which contains valid firmware) is overwritten.
     *      This is very rare for end users because we could enter here 
     *      only when failing to boot both partitions.
     */
    
    int offset;
    int r;
    unsigned char buf[4];
    int16_t ts;
    
    /* Check header first */
    offset = check_header(handle, NULL);
    if (offset < 0) {
        return offset;
    }

    /* Header OK, now check if there is any valid timestamp */
    r = cfe_readblk(handle, offset, PTR2HSADDR(buf), 4);
    if (r != 4) {
        /* The bytecount may be incorrect */
        return -1;
    }
    if (buf[0] != TIMESTAMP_MAGIC_START || buf[3] != TIMESTAMP_MAGIC_END) {
        /* No timestamp found, but the image header is OK */
        return 0;
    }
    ts = (int16_t)(((uint16_t) buf[2] << 8) + (uint16_t)buf[1]);
    if (ts <= 0) {
        /* Timestamp magic OK, but the timestamp value is incorrect */
        return 0;
    }
    
    /* Timestamp OK, return it as a score */
    return (int)ts;
}

/*  *********************************************************************
    *  determine_partition(primary)
    *  
    *  Determine which physical partition should be used.
    *  
    *  Input parameters: 
    *      primary - whether it's a primary one
    *      
    *  Return value:
    *      Name of the physical partition
    ********************************************************************* */

static const char *
determine_partition(int primary, int *pscore)
{
    int handle;
    int score1 = -1, score2 = -1;
    
    /* If there is no partition 2, then we only use partition 1 for all */
    handle = cfe_open(OS_PART2);
    if (handle < 0) {
        handle = cfe_open(OS_PART1);
        if (handle < 0) {
            /* In case both partitions are not defined */
            DIMG_DBG(1, "DIMG - ERROR: cannot open both partitions!\n");
            return NULL;
        }
        cfe_close(handle);
        if (pscore) {
            *pscore = -2; /* For this special case */
        }
        DIMG_DBG(1, "DIMG - No %s found. Single partition only.\n", OS_PART2);
        return OS_PART1;
    }
    
    /* Get the score for partition 2*/
    score2 = calculate_score(handle);
    if (score2 < -1) {
        /* We treat read problem with os2 partition as one partition only */
        if (pscore) {
            *pscore = -2; /* For this special case */
        }
        DIMG_DBG(1, "DIMG - Can't read %s. Single partition only.\n", OS_PART2);
        cfe_close(handle);
        return OS_PART1;
    }
    cfe_close(handle);
    
    /* Get the score for partition 1 */
    handle = cfe_open(OS_PART1);
    if (handle < 0) {
        /* Return error if we cannot even open partition 1 */
        DIMG_DBG(1, "DIMG - ERROR: cannot open %s!\n", OS_PART1);
        return NULL;
    }
    score1 = calculate_score(handle);
    if (score1 < -1) {
        /* Return error if we cannot read data successfully */
        DIMG_DBG(1, "DIMG - ERROR: cannot read %s!\n", OS_PART1);
        cfe_close(handle);
        return NULL;
    }
    cfe_close(handle);
    
    DIMG_DBG(1, "DIMG determined scores - %s:%d %s:%d\n", 
        OS_PART1, score1, OS_PART2, score2);
    if (score1 == 0x7fff || score2 == 0x7fff) {
        /* Deal with overflow condition */
        if (score1 == 1) {
            score2 = 0;
        } else if (score2 == 1) {
            score1 = 0;
        }
    }
    if (primary) {
        if (pscore) {
            /* Score of the other partition */
            *pscore = score1 >= score2 ? score2 : score1;
        }
        return score1 >= score2 ? OS_PART1 : OS_PART2;
    } else {
        if (pscore) {
            /* Score of the other partition */
            *pscore = score1 >= score2 ? score1 : score2;
        }
        return score1 >= score2 ? OS_PART2 : OS_PART1;
    }
}

/*  *********************************************************************
    *  flashdrv_probe(drv,probe_a,probe_b,probe_ptr)
    *  
    *  Device probe routine.  Attach the flash device to
    *  CFE's device table.
    *  
    *  Input parameters: 
    *      drv - driver descriptor
    *      probe_a - physical address of flash
    *      probe_b - size of flash (bytes)
    *      probe_ptr - unused
    *      
    *  Return value:
    *      nothing
    ********************************************************************* */

static void
flashdrv_probe(cfe_driver_t * drv,
      unsigned long probe_a, unsigned long probe_b, void *probe_ptr)
{
    dimagedev_t *psoftc, *ssoftc;
    char descr[80];

    psoftc = (dimagedev_t *) KMALLOC(sizeof(dimagedev_t), 0);
    if (!psoftc) {
        return;
    }
    ssoftc = (dimagedev_t *) KMALLOC(sizeof(dimagedev_t), 0);
    if (!ssoftc) {
        KFREE(psoftc);
        return;
    }

    /* Set up device for primary image */
    psoftc->primary = 1;
    psoftc->handle = -1;
    xsprintf(descr, "Primary OS image");
    cfe_attach(drv, psoftc, VPART1_BOOTINFO, descr);

    /* Set up device for Secondary image */
    ssoftc->primary = 0;
    ssoftc->handle = -1;
    xsprintf(descr, "Secondary OS image");
    cfe_attach(drv, ssoftc, VPART2_BOOTINFO, descr);

    DIMG_DBG(1, "DIMG attach\n");
}


/*  *********************************************************************
    *  flashdrv_open(ctx)
    *  
    *  Called when the flash device is opened.
    *  
    *  Input parameters: 
    *      ctx - device context
    *      
    *  Return value:
    *      0 if ok else error code
    ********************************************************************* */

static int
flashdrv_open(cfe_devctx_t * ctx)
{
    dimagedev_t *softc = ctx->dev_softc;
    const char *device;
    int score;
    
    if (softc->handle >= 0) {
        return CFE_ERR_DEVOPEN;
    }
    
    /* Open the real device */
    device = determine_partition(softc->primary, &score);
    if (device == NULL) {
        return CFE_ERR_IOERR;
    }
    softc->score = score;
    softc->part = device;
    softc->dirty = 0;
    softc->handle = cfe_open((char *)device);
    DIMG_DBG(1, "DIMG open(%s): partition=%s handle=%d max_score=%d\n",
        softc->primary? "primary" : "secondary", device, softc->handle,
        score);
    if (softc->handle < 0) {
        return softc->handle;
    }
    
    return 0;
}


/*  *********************************************************************
    *  flashdrv_read(ctx,buffer)
    *  
    *  Read data from the flash device.    The flash device is 
    *  considered to be like a disk (you need to specify the offset).
    *  
    *  Input parameters: 
    *      ctx - device context
    *      buffer - buffer descriptor
    *      
    *  Return value:
    *      0 if ok, else error code
    ********************************************************************* */

static int
flashdrv_read(cfe_devctx_t * ctx, iocb_buffer_t * buffer)
{
    dimagedev_t *softc = ctx->dev_softc;
    int r;

    if (buffer == NULL || softc->handle < 0) {
        return CFE_ERR_INV_PARAM;
    }
    
    /* Read data from actual flash device */
    r = cfe_readblk(softc->handle, buffer->buf_offset, 
            buffer->buf_ptr, buffer->buf_length);
    DIMG_DBG(2, "DIMG read(%d): offset=%u length=%u result=%d\n", 
        softc->handle, (int)buffer->buf_offset, (int)buffer->buf_length, r);
    if (r < 0) {
        return r;
    }
    buffer->buf_retlen = r;
    
    return 0;
}

/*  *********************************************************************
    *  flashdrv_inpstat(ctx,inpstat)
    *  
    *  Return "input status".  For flash devices, we always return true.
    *  
    *  Input parameters: 
    *      ctx - device context
    *      inpstat - input status structure
    *      
    *  Return value:
    *      0 if ok, else error code
    ********************************************************************* */

static int
flashdrv_inpstat(cfe_devctx_t * ctx, iocb_inpstat_t * inpstat)
{
    inpstat->inp_status = 1;
    return 0;
}


/*  *********************************************************************
    *  flashdrv_write(ctx,buffer)
    *  
    *  Write data to the flash device.    The flash device is 
    *  considered to be like a disk (you need to specify the offset).
    *  
    *  Input parameters: 
    *      ctx - device context
    *      buffer - buffer descriptor
    *      
    *  Return value:
    *      0 if ok, else error code
    ********************************************************************* */

static int
flashdrv_write(cfe_devctx_t * ctx, iocb_buffer_t * buffer)
{
    dimagedev_t *softc = ctx->dev_softc;
    int r;

    if (buffer == NULL || softc->handle < 0) {
        return CFE_ERR_INV_PARAM;
    }
    
    /* Write data to actual flash device */
    r = cfe_writeblk(softc->handle, buffer->buf_offset, 
            buffer->buf_ptr, buffer->buf_length);
    DIMG_DBG(1, "DIMG write(%d): offset=%u length=%u result=%d\n", 
        softc->handle, (int)buffer->buf_offset, (int)buffer->buf_length, r);
    if (r < 0) {
        return r;
    }
    buffer->buf_retlen = r;
    
    /* Mark it dirty if we have written something */
    if (r > 0) {
        softc->dirty = 1;
    }

    return 0;    
}


/*  *********************************************************************
    *  flashdrv_ioctl(ctx,buffer)
    *  
    *  Handle special IOCTL functions for the flash.  Flash devices
    *  support NVRAM information, sector and chip erase, and a
    *  special IOCTL for updating the running copy of CFE.
    *  
    *  Input parameters: 
    *      ctx - device context
    *      buffer - descriptor for IOCTL parameters
    *      
    *  Return value:
    *      0 if ok else error
    ********************************************************************* */
static int
flashdrv_ioctl(cfe_devctx_t * ctx, iocb_buffer_t * buffer)
{
    dimagedev_t *softc = ctx->dev_softc;
    int r;
    int retlen;

    if (buffer == NULL || softc->handle < 0) {
        return CFE_ERR_INV_PARAM;
    }
    
    /* Do IOCTL to actual flash device */
    retlen = buffer->buf_length;
    r = cfe_ioctl(softc->handle, buffer->buf_ioctlcmd, HSADDR2PTR(buffer->buf_ptr), 
            retlen, &retlen, buffer->buf_offset);
    DIMG_DBG(1, "DIMG ioctl(%d): ctrl=%d offset=%u len=%u result=%d rlen=%d\n", 
        softc->handle, (int)buffer->buf_ioctlcmd, (int)buffer->buf_offset, 
        (int)buffer->buf_length, r, retlen);
    if (r < 0) {
        return r;
    }
    buffer->buf_retlen = retlen;

    return 0;    
}


/*  *********************************************************************
    *  flashdrv_close(ctx)
    *  
    *  Close the flash device.
    *  
    *  Input parameters: 
    *      ctx - device context
    *      
    *  Return value:
    *      0
    ********************************************************************* */
static int
flashdrv_close(cfe_devctx_t * ctx)
{
    dimagedev_t *softc = ctx->dev_softc;
    
    DIMG_DBG(1, "DIMG close(%d)\n", softc->handle);
    if (softc->handle >= 0) {
        
        /* Should we update timestamp? (written and have two partitions) */
        if (softc->dirty && softc->score > -2) {

            /* We write timestamp only if checksum is OK */
            int offset = check_image(softc->handle);
            if (offset > 0) {
                int16_t score = 1;
                unsigned char buf[4];
                int r;

                if (softc->score > 0) {
                    score = (int16_t)softc->score + 1;
                    if (score < 0) {
                        score = 1;
                    }
                }
                buf[0] = TIMESTAMP_MAGIC_START;
                buf[3] = TIMESTAMP_MAGIC_END;
                buf[1] = score & 0xFF;
                buf[2] = (score >> 8) & 0xFF;
                r = cfe_writeblk(softc->handle, offset, PTR2HSADDR(buf), 4);
                DIMG_DBG(1, 
                    "DIMG timestamp(%d): offset=%u timestamp=%d result=%d\n", 
                    softc->handle, offset, score, r);
            } else {
                int offset, bytecount, r;
                unsigned char buf[4];
                DIMG_DBG(1, "DIMG timestamp(%d): checksum failed\n", 
                    softc->handle);
                offset = check_header(softc->handle, &bytecount);
                r = cfe_readblk(softc->handle, offset, PTR2HSADDR(buf), 4);
                if (r == 4) {
                    if (buf[0] == TIMESTAMP_MAGIC_START && 
                        buf[3] == TIMESTAMP_MAGIC_END) {
                            
                        /* 
                         * Checksum incorrect but it has a valid timestamp:
                         * Destroy the timestamp.
                         */
                        buf[0] = 0xFF;
                        r = cfe_writeblk(softc->handle, offset, PTR2HSADDR(buf), 1);
                        DIMG_DBG(1, 
                            "DIMG destory timestamp(%d): offset=%u result=%d\n", 
                            softc->handle, offset, r);
                    }
                }
            }
        }
        
        cfe_close(softc->handle);
        softc->dirty = 0;
        softc->handle = -1;
    }
    
    return 0;
}
