/***************************************************************
**
**  Broadcom Corp. Confidential
**  Copyright 2007 Broadcom Corp.  All Rights Reserved.
**
**  THIS SOFTWARE MAY ONLY BE USED SUBJECT TO AN EXECUTED 
**  SOFTWARE LICENSE AGREEMENT  BETWEEN THE USER AND BROADCOM.  
**  YOU HAVE NO RIGHT TO USE OR EXPLOIT THIS MATERIAL EXCEPT 
**  SUBJECT TO THE TERMS OF SUCH AN AGREEMENT.
**
**  File:         bspi_flash.h
**  Description:  Serial flash mgmt
**  Created:      Wed Mar 21 13:31:21 PDT 2007 - Jeffrey P. Fisher      
**
****************************************************************/
#ifndef __BSPI_FLASH_H__
#define __BSPI_FLASH_H__

#include "lib_types.h"

int bspi_read(char bus, unsigned int offset, unsigned char *data);
int bspi_sector_erase(char bus, unsigned int offset);
int bspi_page_program(char bus, unsigned int offset, unsigned char *buf, int len);
int bspi_probe(char bus, unsigned int *vender, unsigned int *dev);
void bspi_flush_prefetch_buffers(void);
#endif /* __BSPI_FLASH_H__ */

