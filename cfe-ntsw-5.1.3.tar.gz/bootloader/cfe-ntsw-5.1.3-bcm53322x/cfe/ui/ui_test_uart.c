/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  UART Test commands			File: ui_test_uart.c
    *  
    *  Some commands to test the uart device interface.
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "ui_command.h"
#include "cfe_fileops.h"
#include "cfe_boot.h"
#include "cfe_bootblock.h"
#include "cfe_loader.h"
#include "cfe_mem.h"

int ui_init_uarttestcmds(void);
int ui_init_uart_cmds(void);

static int ui_cmd_uarttest(ui_cmdline_t *cmd,int argc,char *argv[]);

static int ui_cmd_uart(ui_cmdline_t *cmd,int argc,char *argv[]);

int ui_init_uarttestcmds(void)
{
    cmd_addcmd("test uart",
	       ui_cmd_uarttest,
	       NULL,
	       "Echo characters to a UART",
	       "test uart [devname]",
	       "");
    return 0;
}

int ui_init_uart_cmds(void)
{
    cmd_addcmd("uart",
	       ui_cmd_uart,
	       NULL,
	       "test UART register",
	       "uart read/write/echo register/charactor",
	       "");
    return 0;
}

typedef         unsigned char uint8;
typedef         unsigned int  uint32;

#define         BASE                    0xB8000300
#define         UART16550_READ(y)    (*((volatile uint8*)(BASE + y)))
#define         UART16550_WRITE(y, z)  ((*((volatile uint8*)(BASE + y))) = z)
#define 		BRTC(baud)          (((1843200)/16)/(baud))

#define         REG_OFFSET              1

#define         OFS_RCV_BUFFER          (0*REG_OFFSET)
#define         OFS_TRANS_HOLD          (0*REG_OFFSET)
#define         OFS_SEND_BUFFER         (0*REG_OFFSET)
#define         OFS_LINE_CONTROL        (3*REG_OFFSET)
#define         OFS_INTR_ENABLE         (1*REG_OFFSET)
#define         OFS_LINE_STATUS         (5*REG_OFFSET)
#define         OFS_DATA_FORMAT         (3*REG_OFFSET)
#define         OFS_DIVISOR_LSB         (0*REG_OFFSET)
#define         OFS_DIVISOR_MSB         (1*REG_OFFSET)

#define         UART16550_BAUD_115200           115200
#define         UART16550_PARITY_NONE           0
#define         UART16550_DATA_8BIT             0x3
#define         UART16550_STOP_1BIT             0x0

uint8 Uart16550GetPoll(void);
void Uart16550Put(char byte);
void Uart16550Init(uint32 baud, uint8 data, uint8 parity, uint8 stop);

void Uart16550Init(uint32 baud, uint8 data, uint8 parity, uint8 stop)
{
	/* disable interrupts */
    UART16550_WRITE(OFS_LINE_CONTROL, 0x0);
	UART16550_WRITE(OFS_INTR_ENABLE, 0);

	/* set up buad rate */
	{ 
		uint32 divisor;
       
		/* set DIAB bit */
	        UART16550_WRITE(OFS_LINE_CONTROL, 0x80);
        
	        /* set divisor */
	        divisor = BRTC(baud);
        	UART16550_WRITE(OFS_DIVISOR_LSB, divisor & 0xff);
	        UART16550_WRITE(OFS_DIVISOR_MSB, (divisor & 0xff00)>>8);

        	/* clear DIAB bit */
	        UART16550_WRITE(OFS_LINE_CONTROL, 0x0);
	}

	/* set data format */
	UART16550_WRITE(OFS_DATA_FORMAT, data | parity | stop);
}

static int serialPortInitialized = 0;

uint8 Uart16550GetPoll(void)
{
	if (!serialPortInitialized) {
		serialPortInitialized = 1;
		Uart16550Init(UART16550_BAUD_115200,
					  UART16550_DATA_8BIT,
					  UART16550_PARITY_NONE, UART16550_STOP_1BIT);
	}

	while((UART16550_READ(OFS_LINE_STATUS) & 0x1) == 0);
		return UART16550_READ(OFS_RCV_BUFFER);
}


void Uart16550Put(char byte)
{
	if (!serialPortInitialized) {
		serialPortInitialized = 1;
		Uart16550Init(UART16550_BAUD_115200,
					  UART16550_DATA_8BIT,
					  UART16550_PARITY_NONE, UART16550_STOP_1BIT);
	}

	while ((UART16550_READ(OFS_LINE_STATUS) &0x20) == 0);
	    UART16550_WRITE(OFS_SEND_BUFFER, byte);
}

static int ui_cmd_uart(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int res, size, sfd, amtcopy;
    fileio_ctx_t *fsctx;
    void *ref;
    char line[256];
//    int i = 0, cnt[1024];
    hsaddr_t hsaddr;
    unsigned int saddr;

    res = fs_init("xmodem",&fsctx, "uart0");
    if (res != 0) {
	return res;
	}

    res = fs_open(fsctx, &ref, "", FILE_MODE_READ);

    if (res != 0) {
	fs_uninit(fsctx);
	return res;
	}

//    initlinebuf(&lb,ref,fsctx);
    hsaddr = (hsaddr_t)(intptr_t)(0x80001000);
    size = 0;

    for (;;)
    {
        res = fs_read(fsctx, ref,PTR2HSADDR(line),sizeof(line));
        if (res <= 0) break;		/* reached EOF */

	    hs_memcpy_to_hs(hsaddr, line, res);
        hsaddr += res;
        size += res;
	}

    /*
     * We're done with the file.
     */

    fs_close(fsctx,ref);
    fs_uninit(fsctx);
    
    printf("[%s:%d:1]loader size %d, calc size %d, write to %s\n", __FUNCTION__, __LINE__,hsaddr - 0x80001000, size, argv[0]);

    sfd = cfe_open(argv[0]);
    if (sfd < 0) {
        return ui_showerror(sfd,"Could not open source device");
    }

    saddr = 0x80001000;
    xprintf("Programming...");

    amtcopy = cfe_writeblk(sfd, 0, PTR2HSADDR(saddr), size);

    if (size == amtcopy) {
	    xprintf("done. %d bytes written\n",amtcopy);
	    res = 0;
	}else
        ui_showerror(amtcopy,"Failed.");
    cfe_close(sfd);

	res = 0;

    return res;
}

static int ui_cmd_uarttest(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int fd;
    char *x;
    char ch;
    const char *ptr;
    int len;
    int res;
    char buffer[64];
    static const char *testmsg =
      "A123456789B123456789C123456789D123456789E123456789F123456789"
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ++++abcdefghijklmnopqrstuvwxyz----"
      "A123456789B123456789C123456789D123456789E123456789F123456789"
      "~!@#$%^&*()_+{}[];:|\\,<.>/?~!@#$%^&*()_+{}[];:|\\,<.>/?      "
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ++++abcdefghijklmnopqrstuvwxyz----";

    x = cmd_getarg(cmd,0);
    if (!x) return ui_showusage(cmd);

    fd = cfe_open(x);
    if (fd < 0) {
	ui_showerror(fd,"could not open %s",x);
	return fd;
	}

    printf("Device open.  Stuff you type here goes there.  Type ~ to exit.\n");
    for (;;) {
	if (console_status()) {
	    console_read((unsigned char *)&ch,1);
	    if (ch == ('X' - '@')) {  /* ^X */
		ptr = testmsg;
		len = strlen(testmsg);
		}
	    else {
		ptr = &ch;
		len = 1;
		}
	    res = 0;
	    while (len > 0) {
		res = cfe_write(fd,PTR2HSADDR(ptr),len);
		if (res <= 0) break;
		len -= res;
		ptr += res;
		}
	    if (res < 0) break;
	    if (ch == '~') break;
	    }
	if (cfe_inpstat(fd)) {
	    res = cfe_read(fd,PTR2HSADDR(buffer),sizeof(buffer));
	    if (res > 0) console_write((unsigned char *)buffer,res);
	    if (res < 0) break;
	    }
	POLL();
	}

    cfe_close(fd);
    return 0;
}

