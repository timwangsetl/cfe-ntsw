/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  Environment commands			File: ui_envcmds.c
    *  
    *  User interface for environment variables
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "ui_command.h"


int ui_init_envcmds(void);
static int ui_cmd_setenv(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_printenv(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_unsetenv(ui_cmdline_t *cmd,int argc,char *argv[]);
#if !CFG_MINIMAL_SIZE
static int ui_cmd_clearenv(ui_cmdline_t *cmd,int argc,char *argv[]);
#endif /* !CFG_MINIMAL_SIZE */



static int ui_cmd_printenv(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char varname[80];
    char value[ENV_MAX_ENTRY_SIZE];
    int varlen,vallen;
    int idx;

    xprintf("Variable Name        Value\n");
    xprintf("-------------------- --------------------------------------------------\n");

    idx = 0;
    for (;;) {
	varlen = sizeof(varname);
	vallen = sizeof(value);
	if (env_enum(idx,varname,&varlen,value,&vallen) < 0) break;
	xprintf("%20s %s\n",varname,value);
	idx++;
	}

    return 0;
    
}

static int ui_cmd_setenv(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *varname;
    char *value;
    int roflag = ENV_FLG_NORMAL;
    int res;
    int defer_save = 0;

    varname = cmd_getarg(cmd,0);
    if (!varname) {
        if (cmd_sw_isset(cmd,"-p")) {
            res = env_save();
            return (res ? ui_showerror(res,"Could not save environment variables") : 0);
        } else {
            return ui_showusage(cmd);
        }
    }

    value = cmd_getarg(cmd,1);
    if (!value) {
	return ui_showusage(cmd);
	}

    if (strlen(varname) + strlen(value) + 1 + 1 > (ENV_MAX_ENTRY_SIZE - 1)) {
	return ui_showerror(CFE_ERR_INV_PARAM,
                            "Combined size of environment variable name "
                            "and value exceeds %d characters", ENV_MAX_ENTRY_SIZE);
    }
    if (!cmd_sw_isset(cmd,"-p")) {
	roflag = ENV_FLG_BUILTIN;	/* just in memory, not NVRAM */
	}

    if (cmd_sw_isset(cmd,"-P")) {
        roflag = ENV_FLG_NORMAL;
        defer_save = 1; /* Defer saving to persistent storage till -p is issued */
       }

    if (cmd_sw_isset(cmd,"-ro")) {
	roflag = ENV_FLG_READONLY;
	}

    if ((res = env_setenv(varname,value,roflag)) == 0) {
        if (defer_save == 0) {
            if (roflag != ENV_FLG_BUILTIN && (res = env_save()) != 0) {
                return ui_showerror(res,"Could not save environment");
            }
        }
    }
    else {
	return ui_showerror(res,"Could not set environment variable '%s'",
			    varname);
	}

    return 0;
}


static int ui_cmd_unsetenv(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *varname;
    int res;
    int type;

    varname = cmd_getarg(cmd,0);

    if (!varname) {
	return ui_showusage(cmd);
	}

    type = env_envtype(varname);

    if ((res = env_delenv(varname)) == 0) {
	if (type >= 0 && type != ENV_FLG_BUILTIN && (res = env_save()) != 0) {
            return ui_showerror(res,"Could not save environment");
            }
	}
    else {
	return ui_showerror(res,"Could not delete environment variable '%s'",
			    varname);
	}

    return 0;
}

#if !CFG_MINIMAL_SIZE
static int ui_cmd_clearenv(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char varname[80];
    char value[ENV_MAX_ENTRY_SIZE];
    int varlen,vallen;
    int idx;
    int res;
    int type;

    idx = 0;
    for (;;) {
        varlen = sizeof(varname);
        vallen = sizeof(value);
        if (env_enum(idx,varname,&varlen,value,&vallen) < 0) break;
        if (((type = env_envtype(varname)) & ENV_FLG_BUILTIN) == 0) {
            if ((res = env_delenv(varname))) {
                return ui_showerror(res,"Could not delete environment variable '%s'",
                                    varname);
            }
        } else {
            idx++;
        }
    }

    if ((res = env_save()) != 0) {
        return ui_showerror(res,"Could not save environment");
    }
    return 0;
}

static int ui_cmd_sizeenv(ui_cmdline_t *cmd,int arc,char *argv[])
{
    int used, total;
    
    env_sizeinfo_get(&used, &total);
    xprintf("Environment NVRAM size (in bytes):");
    xprintf(" used = %d, free = %d, total = %d\n", used, total - used, total);
    return 0;
}

#endif /* !CFG_MINIMAL_SIZE */

int ui_init_envcmds(void)
{

    cmd_addcmd("setenv",
	       ui_cmd_setenv,
	       NULL,
	       "Set an environment variable.",
	       "setenv [-ro] [-p] [-P] varname value\n\n"
	       "This command sets an environment variable.  By default, an environment variable\n"
	       "is stored only in memory and will not be retained across system restart.",
               "-P;Mark to store environment variable permanently in the NVRAM device, if present|"
	       "-p;Store environment variable permanently in the NVRAM device, if present|"
	       "-ro;Causes variable to be read-only\n" 
	       "(cannot be changed in the future, implies -p)");

    cmd_addcmd("printenv",
	       ui_cmd_printenv,
	       NULL,
	       "Display the environment variables",
	       "printenv\n\n"
	       "This command prints a table of the environment variables and their\n"
	       "current values.",
	       "");

    cmd_addcmd("unsetenv",
	       ui_cmd_unsetenv,
	       NULL,
	       "Delete an environment variable.",
	       "unsetenv varname\n\n"
	       "This command deletes an environment variable from memory and also \n"
	       "removes it from the NVRAM device (if present).",
	       "");

#if !CFG_MINIMAL_SIZE
    cmd_addcmd("clearenv",
	       ui_cmd_clearenv,
	       NULL,
	       "Clear environment variables.",
	       "clearenv\n\n"
	       "This command deletes all user defined variables from memory and also \n"
	       "removes them from the NVRAM device (if present).",
	       "");

    cmd_addcmd("sizeenv",
               ui_cmd_sizeenv,
               NULL,
               "Get environment space size information.",
               "sizeenv\n\n"
               "This command displays the size in bytes of used, free, and total \n"
               "environment space in the NVRAM device (if present).",
               "");
#endif /* !CFG_MINIMAL_SIZE */

    return 0;
}
