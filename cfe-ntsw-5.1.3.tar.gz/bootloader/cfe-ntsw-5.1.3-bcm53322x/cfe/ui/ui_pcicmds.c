/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  PCI Commands				File: ui_pcicmds.c
    *  
    *  PCI user interface routines
    *  
    *  Author:  Mitch Lichtenberg
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "env_subr.h"
#include "ui_command.h"

#if CFG_PCI
#include "pcivar.h"
extern int pci_probe_tag(pcitag_t tag);   /* currently internal */
#include "pcireg.h"
#endif

int ui_init_pcicmds(void);

#if CFG_PCI
static int pci_print_summary(pcitag_t tag)
{
    pcireg_t id, class;
    char devinfo[256];

    class = pci_conf_read(tag, PCI_CLASS_REG);
    id = pci_conf_read(tag, PCI_ID_REG);

    pci_devinfo(id, class, 1, devinfo);
    pci_tagprintf (tag, "%s\n", devinfo);

    return 0;	   
}

static int pci_print_concise(pcitag_t tag)
{
    pci_tagprintf (tag, "\n");
    pci_conf_print(tag);	

    return 0;
}

static int ui_cmd_pci(ui_cmdline_t *cmd,int argc,char *argv[])
{
    char *argp;

    if (cmd_sw_isset(cmd,"-init")) {
	pci_flags_t flags;
	char *str;
	extern cons_t pci_optnames[];

	flags = PCI_FLG_NORMAL;
#if (CFG_LDT && CFG_LDT_REV_017)
	flags |= PCI_FLG_LDT_REV_017;
#endif
	str = env_getenv("PCI_OPTIONS");
	setoptions(pci_optnames,str,&flags);
	
	xprintf("Initializing PCI. [%s]\n",str ? str : "normal");
	pci_configure(flags);

	return 0;
	}

    argp = cmd_getarg(cmd,0);

    if (argp == NULL) {
	if (cmd_sw_isset(cmd,"-v")) {
	    pci_foreachdev(pci_print_concise);
	    }
	else {
	    pci_foreachdev(pci_print_summary);
	    }
	}
    else {
	/* parse the tuple */
	int n, port, bus, dev, func;
	pcitag_t tag;
	char *p;

	port = bus = dev = func = 0;
	p = argp;  n = 0;

	while (*p >= '0' && *p <= '9') {
	    n = n*10 + (*p - '0');
	    p++;
	    }
	if (*p == '/')
	    bus = n;
	else  if (*p == ':') {
	    port = n;
	    p++;
	    while (*p >= '0' && *p <= '9') {
		bus = bus*10 + (*p - '0');
		p++;
		}
	    }
	else
	    goto fail;
	p++;
	while (*p >= '0' && *p <= '9') {
	    dev = dev*10 + (*p - '0');
	    p++;
	    }
	if (*p != '/')
	    goto fail;
	p++;
	while (*p >= '0' && *p <= '9') {
	    func = func*10 + (*p - '0');
	    p++;
	    }
	if (*p != '\000')
	    goto fail;

	tag = pci_make_tag(port,bus,dev,func);	

	pci_print_concise(tag);
	}

    return 0;

fail:
    printf("invalid PCI tuple %s\n", argp);
    return -1;
}


static int ui_cmd_pcidump(ui_cmdline_t *cmd,int argc,char *argv[])
{
    int port, bus, dev, func;
    int alldev;
    int d1, d2, d;
    int idx;
    pcitag_t tag;
    pcireg_t v0, v1, v2, v3;
    int printed, zeros;
    char *arg;
    char *x;

    port = bus = dev = func = 0;       /* defaults */
    alldev = 0;

    arg = cmd_getarg(cmd, 0);
    if (arg) {
	if ((x = strchr(arg, ':'))) {
	    *x++ = '\0';
	    port = atoi(arg);
	    arg = x;
	    }
	if ((x = strchr(arg, '/'))) {
	    *x++ = '\0';
	    bus = atoi(arg);
	    arg = x;
	    if ((x = strchr(arg, '/'))) {
		*x++ = '\0';
		if (arg[0] == '*') alldev = 1;
		dev = atoi(arg);
		arg = x;
		func = atoi(arg);
		}
	    }
	}

    if (alldev) {
	d1 = 0; d2 = 32;
	}
    else {
	d1 = dev; d2 = dev+1;
	}

    for (d = d1; d < d2; d++) {

	tag = pci_make_tag(port, bus, d, func);
	if (pci_probe_tag(tag)) {
	    if (cmd_sw_isset(cmd, "-scan")) {
		v0 = pci_conf_read(tag, 0);
    		pci_tagprintf (tag, "VID %04X DID %04X\n",
			v0 & 0xFFFF, v0 >> 16);
		}
	    else {
    		pci_tagprintf (tag, "\n");
		printed = zeros = 0;
		for (idx = 0; idx < 0x100; idx += 0x10) {
		    v0 = pci_conf_read(tag, idx+0x0);
		    v1 = pci_conf_read(tag, idx+0x4);
		    v2 = pci_conf_read(tag, idx+0x8);
		    v3 = pci_conf_read(tag, idx+0xC);
		    if (!printed || (v0 | v1 | v2 | v3) != 0) {
			xprintf(" %04X: %08X %08X %08X %08X\n",
				idx, v0, v1, v2, v3);
			printed = 1;
			zeros = 0;
			}
		    else if (!zeros) {
			xprintf(" ...\n");
			zeros = 1;
			}
		    }
		}
	    }
	else {
    	    pci_tagprintf (tag, "no device\n");
	    }
	}

    return 0;

}
#endif


int ui_init_pcicmds(void)
{

#if CFG_PCI
    cmd_addcmd("show pci",
	       ui_cmd_pci,
	       NULL,
	       "Display information about PCI buses and devices",
	       "show pci [-v] [[port:]bus/dev/func]\n\n"
	       "Displays information about PCI and LDT buses and devices in the\n"
	       "system.  If you specify a bus/dev/func triplet, only that device\n"
	       " will be displayed.",
	       "-v;Display verbose information|"
	       "-init;Reinitialize and rescan the PCI bus");

    cmd_addcmd("pci dump",
	       ui_cmd_pcidump,
	       NULL,
	       "Dump PCI configuration space.",
	       "pci dump [[port:]bus/dev/func]",
	       "-scan;Just see if there is a device there.");
#endif

    return 0;
}
