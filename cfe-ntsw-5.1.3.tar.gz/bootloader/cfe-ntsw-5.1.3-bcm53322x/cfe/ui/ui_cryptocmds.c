/*  *********************************************************************
    *  Broadcom Common Firmware Environment (CFE)
    *  
    *  BlueSteel (bcm582x) test commands	File: ui_cryptocmds.c
    *  
    *  A sandbox for testing bcm582{0,1,2,3} operations and performance.
    *  
    *********************************************************************  
    *
    *  Copyright 2000,2001,2002,2003,2004
    *  Broadcom Corporation. All rights reserved.
    *  
    *  This software is furnished under license and may be used and 
    *  copied only in accordance with the following terms and 
    *  conditions.  Subject to these conditions, you may download, 
    *  copy, install, use, modify and distribute modified or unmodified 
    *  copies of this software in source and/or binary form.  No title 
    *  or ownership is transferred hereby.
    *  
    *  1) Any source code used, modified or distributed must reproduce 
    *     and retain this copyright notice and list of conditions 
    *     as they appear in the source file.
    *  
    *  2) No right is granted to use any trade name, trademark, or 
    *     logo of Broadcom Corporation.  The "Broadcom Corporation" 
    *     name may not be used to endorse or promote products derived 
    *     from this software without the prior written permission of 
    *     Broadcom Corporation.
    *  
    *  3) THIS SOFTWARE IS PROVIDED "AS-IS" AND ANY EXPRESS OR
    *     IMPLIED WARRANTIES, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED
    *     WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
    *     PURPOSE, OR NON-INFRINGEMENT ARE DISCLAIMED. IN NO EVENT 
    *     SHALL BROADCOM BE LIABLE FOR ANY DAMAGES WHATSOEVER, AND IN 
    *     PARTICULAR, BROADCOM SHALL NOT BE LIABLE FOR DIRECT, INDIRECT,
    *     INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
    *     (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
    *     GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
    *     BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
    *     OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
    *     TORT (INCLUDING NEGLIGENCE OR OTHERWISE), EVEN IF ADVISED OF 
    *     THE POSSIBILITY OF SUCH DAMAGE.
    ********************************************************************* */


#include "cfe.h"
#include "ui_command.h"

int ui_init_cryptocmds(void);

static int ui_cmd_crypt0(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_crypt1(ui_cmdline_t *cmd,int argc,char *argv[]);
static int ui_cmd_crypt2(ui_cmdline_t *cmd,int argc,char *argv[]);

extern int cfe_docommands(char *buf);

/* The following are forward references (move to another file?) */

int bs_check (int device);
int bs_test (int device, int count);
int bs_test2 (int device0, int device1, int count);

static int enabled = 0;

static int
ui_enable_cryptocmds(void)
{
    cmd_addcmd("crypt",
	       ui_cmd_crypt0,
	       NULL,
	       "Crypto sanity check",
	       "crypt device",
	       "");
    cmd_addcmd("crypt1",
	       ui_cmd_crypt1,
	       NULL,
	       "Crypto du jour",
	       "crypt device [count]",
	       "");
    cmd_addcmd("crypt2",
	       ui_cmd_crypt2,
	       NULL,
	       "Crypto du jour (two devices)",
	       "crypt2 device1 device2 [count]",
	       "");

    return 0;
}


static int
ui_cmd_crypt0(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *devname;
    int devhandle;

    devname = cmd_getarg(cmd, 0);
    if (!devname) {
	xprintf("usage: crypt0 device\n");
	return -1;
	}

    devhandle = cfe_open(devname);
    if (devhandle < 0) {
        xprintf("crypt0: %s not found.\n", devname);
	return -1;
	}

    bs_check(devhandle);
    cfe_close(devhandle);

    return 0;
}

static int
ui_cmd_crypt1(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *devname;
    int devhandle;
    char *x;
    int count;
  
    devname = cmd_getarg(cmd, 0);
    if (!devname) {
	xprintf("usage: crypt device [count]\n");
	return -1;
	}

    devhandle = cfe_open(devname);
    if (devhandle < 0) {
        xprintf("crypt: %s not found.\n", devname);
	return -1;
	}

    x = cmd_getarg(cmd, 1);
    if (!x)
	count = 32;
    else
	count = atoi(x);

    bs_test(devhandle, count);
    cfe_close(devhandle);

    return 0;
}

static int
ui_cmd_crypt2(ui_cmdline_t *cmd, int argc, char *argv[])
{
    char *devname;
    int devhandle0, devhandle1;
    char *x;
    int count;

    devname = cmd_getarg(cmd, 0);
    if (!devname) {
	xprintf("usage: crypt2 device1 device2 [count]\n");
	return -1;
	}

    devhandle0 = cfe_open(devname);
    if (devhandle0 < 0) {
        xprintf("crypt2: %s not found.\n", devname);
	return -1;
	}

    devname = cmd_getarg(cmd, 1);
    if (!devname) {
	xprintf("usage: crypt2 device1 device2 [count]\n");
	return -1;
	}

    devhandle1 = cfe_open(devname);
    if (devhandle1 < 0) {
        xprintf("crypt2: %s not found.\n", devname);
	cfe_close(devhandle0);
	return -1;
	}

    x = cmd_getarg(cmd, 2);
    if (!x)
	count = 32;
    else
	count = atoi(x);

    bs_test2(devhandle0, devhandle1, count);

    cfe_close(devhandle0);
    cfe_close(devhandle1);

    return 0;
}


static int
ui_cmd_cryptotest(ui_cmdline_t *cmd, int argc, char *argv[])
{
    if (!enabled)
	ui_enable_cryptocmds();
    enabled = 1;
    return 0;
}

int
ui_init_cryptocmds(void)
{
    cmd_addcmd("test crypto",
	       ui_cmd_cryptotest,
	       NULL,
	       "Enable bcm582x test commands.",
	       "test crypto\n\n"
	       "This command enables assorted tests of the Blue Steel\n"
	       "bcm582x crypto accelerators",
               "");

    return 0;
}


/* ------------------------------------------------------------------ */

/* GLOBAL.H - RSAREF types and constants
 */

/* POINTER defines a generic pointer type */
typedef unsigned char *POINTER;

/* UINT2 defines a two byte word */
typedef unsigned short int UINT2;

/* UINT4 defines a four byte word */
typedef unsigned long int UINT4;


/* MD5.H - header file for MD5C.C
 */

/* Copyright (C) 1991-2, RSA Data Security, Inc. Created 1991. All
rights reserved.

License to copy and use this software is granted provided that it
is identified as the "RSA Data Security, Inc. MD5 Message-Digest
Algorithm" in all material mentioning or referencing this software
or this function.

License is also granted to make and use derivative works provided
that such works are identified as "derived from the RSA Data
Security, Inc. MD5 Message-Digest Algorithm" in all material
mentioning or referencing the derived work.

RSA Data Security, Inc. makes no representations concerning either
the merchantability of this software or the suitability of this
software for any particular purpose. It is provided "as is"
without express or implied warranty of any kind.

These notices must be retained in any copies of any part of this
documentation and/or software.
 */

/* MD5 context. */
typedef struct {
    UINT4 state[4];                                   /* state (ABCD) */
    UINT4 count[2];        /* number of bits, modulo 2^64 (lsb first) */
    unsigned char buffer[64];                         /* input buffer */
} MD5_CTX;

void MD5Init (MD5_CTX *);
void MD5Update (MD5_CTX *, unsigned char *, unsigned int);
void MD5Final (unsigned char [16], MD5_CTX *);


/* MD5C.C - RSA Data Security, Inc., MD5 message-digest algorithm
 */

/* Copyright (C) 1991-2, RSA Data Security, Inc. Created 1991. All
rights reserved.

License to copy and use this software is granted provided that it
is identified as the "RSA Data Security, Inc. MD5 Message-Digest
Algorithm" in all material mentioning or referencing this software
or this function.

License is also granted to make and use derivative works provided
that such works are identified as "derived from the RSA Data
Security, Inc. MD5 Message-Digest Algorithm" in all material
mentioning or referencing the derived work.

RSA Data Security, Inc. makes no representations concerning either
the merchantability of this software or the suitability of this
software for any particular purpose. It is provided "as is"
without express or implied warranty of any kind.

These notices must be retained in any copies of any part of this
documentation and/or software.
 */

/*
#include "global.h"
#include "md5.h"
*/

/* Constants for MD5Transform routine.
 */

#define S11 7
#define S12 12
#define S13 17
#define S14 22
#define S21 5
#define S22 9
#define S23 14
#define S24 20
#define S31 4
#define S32 11
#define S33 16
#define S34 23
#define S41 6
#define S42 10
#define S43 15
#define S44 21

static void MD5Transform (UINT4 [4], unsigned char [64]);
static void Encode (unsigned char *, UINT4 *, unsigned int);
static void Decode (UINT4 *, unsigned char *, unsigned int);
static void MD5_memcpy (POINTER, POINTER, unsigned int);
static void MD5_memset (POINTER, int, unsigned int);

static unsigned char PADDING[64] = {
    0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/* F, G, H and I are basic MD5 functions.
 */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))

/* ROTATE_LEFT rotates x left n bits.
 */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/* FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4.
   Rotation is separate from addition to prevent recomputation.
 */
#define FF(a, b, c, d, x, s, ac) { \
   (a) += F ((b), (c), (d)) + (x) + (UINT4)(ac); \
   (a) = ROTATE_LEFT ((a), (s)); \
   (a) += (b); \
   }
#define GG(a, b, c, d, x, s, ac) { \
   (a) += G ((b), (c), (d)) + (x) + (UINT4)(ac); \
   (a) = ROTATE_LEFT ((a), (s)); \
   (a) += (b); \
   }
#define HH(a, b, c, d, x, s, ac) { \
   (a) += H ((b), (c), (d)) + (x) + (UINT4)(ac); \
   (a) = ROTATE_LEFT ((a), (s)); \
   (a) += (b); \
   }
#define II(a, b, c, d, x, s, ac) { \
   (a) += I ((b), (c), (d)) + (x) + (UINT4)(ac); \
   (a) = ROTATE_LEFT ((a), (s)); \
   (a) += (b); \
   }

/* MD5 initialization. Begins an MD5 operation, writing a new context.
 */
void MD5Init (context)
MD5_CTX *context;                                        /* context */
{
    context->count[0] = context->count[1] = 0;
    /* Load magic initialization constants.
     */
    context->state[0] = 0x67452301;
    context->state[1] = 0xefcdab89;
    context->state[2] = 0x98badcfe;
    context->state[3] = 0x10325476;
}

/* MD5 block update operation. Continues an MD5 message-digest
  operation, processing another message block, and updating the
  context.
 */
void MD5Update (context, input, inputLen)
MD5_CTX *context;                                        /* context */
unsigned char *input;                                /* input block */
unsigned int inputLen;                     /* length of input block */
{
    unsigned int i, index, partLen;

    /* Compute number of bytes mod 64 */
    index = (unsigned int)((context->count[0] >> 3) & 0x3F);

    /* Update number of bits */
    if ((context->count[0] += ((UINT4)inputLen << 3))
	< ((UINT4)inputLen << 3))
	context->count[1]++;
    context->count[1] += ((UINT4)inputLen >> 29);

    partLen = 64 - index;

    /* Transform as many times as possible.
     */
    if (inputLen >= partLen) {
      	MD5_memcpy
	  ((POINTER)&context->buffer[index], (POINTER)input, partLen);
	MD5Transform (context->state, context->buffer);

	for (i = partLen; i + 63 < inputLen; i += 64)
	    MD5Transform (context->state, &input[i]);

	index = 0;
	}
    else
	i = 0;

    /* Buffer remaining input */
    MD5_memcpy
      ((POINTER)&context->buffer[index], (POINTER)&input[i],
       inputLen-i);
}

/* Encodes input (UINT4) into output (unsigned char). Assumes len is
  a multiple of 4.
 */
static UINT4 *MD5State (MD5_CTX *context)
{
    return context->state;
}

/* MD5 finalization. Ends an MD5 message-digest operation, writing the
  the message digest and zeroizing the context.
 */
void MD5Final (digest, context)
unsigned char digest[16];                         /* message digest */
MD5_CTX *context;                                       /* context */
{
    unsigned char bits[8];
    unsigned int index, padLen;

    /* Save number of bits */
    Encode (bits, context->count, 8);

    /* Pad out to 56 mod 64.
     */
    index = (unsigned int)((context->count[0] >> 3) & 0x3f);
    padLen = (index < 56) ? (56 - index) : (120 - index);
    MD5Update (context, PADDING, padLen);

    /* Append length (before padding) */
    MD5Update (context, bits, 8);
    /* Store state in digest */
    Encode (digest, context->state, 16);

    /* Zeroize sensitive information.
     */
    MD5_memset ((POINTER)context, 0, sizeof (*context));
}

/* MD5 basic transformation. Transforms state based on block.
 */
static void MD5Transform (state, block)
UINT4 state[4];
unsigned char block[64];
{
    UINT4 a = state[0], b = state[1], c = state[2], d = state[3], x[16];

    Decode (x, block, 64);

    /* Round 1 */
    FF (a, b, c, d, x[ 0], S11, 0xd76aa478); /* 1 */
    FF (d, a, b, c, x[ 1], S12, 0xe8c7b756); /* 2 */
    FF (c, d, a, b, x[ 2], S13, 0x242070db); /* 3 */
    FF (b, c, d, a, x[ 3], S14, 0xc1bdceee); /* 4 */
    FF (a, b, c, d, x[ 4], S11, 0xf57c0faf); /* 5 */
    FF (d, a, b, c, x[ 5], S12, 0x4787c62a); /* 6 */
    FF (c, d, a, b, x[ 6], S13, 0xa8304613); /* 7 */
    FF (b, c, d, a, x[ 7], S14, 0xfd469501); /* 8 */
    FF (a, b, c, d, x[ 8], S11, 0x698098d8); /* 9 */
    FF (d, a, b, c, x[ 9], S12, 0x8b44f7af); /* 10 */
    FF (c, d, a, b, x[10], S13, 0xffff5bb1); /* 11 */
    FF (b, c, d, a, x[11], S14, 0x895cd7be); /* 12 */
    FF (a, b, c, d, x[12], S11, 0x6b901122); /* 13 */
    FF (d, a, b, c, x[13], S12, 0xfd987193); /* 14 */
    FF (c, d, a, b, x[14], S13, 0xa679438e); /* 15 */
    FF (b, c, d, a, x[15], S14, 0x49b40821); /* 16 */

    /* Round 2 */
    GG (a, b, c, d, x[ 1], S21, 0xf61e2562); /* 17 */
    GG (d, a, b, c, x[ 6], S22, 0xc040b340); /* 18 */
    GG (c, d, a, b, x[11], S23, 0x265e5a51); /* 19 */
    GG (b, c, d, a, x[ 0], S24, 0xe9b6c7aa); /* 20 */
    GG (a, b, c, d, x[ 5], S21, 0xd62f105d); /* 21 */
    GG (d, a, b, c, x[10], S22,  0x2441453); /* 22 */
    GG (c, d, a, b, x[15], S23, 0xd8a1e681); /* 23 */
    GG (b, c, d, a, x[ 4], S24, 0xe7d3fbc8); /* 24 */
    GG (a, b, c, d, x[ 9], S21, 0x21e1cde6); /* 25 */
    GG (d, a, b, c, x[14], S22, 0xc33707d6); /* 26 */
    GG (c, d, a, b, x[ 3], S23, 0xf4d50d87); /* 27 */
    GG (b, c, d, a, x[ 8], S24, 0x455a14ed); /* 28 */
    GG (a, b, c, d, x[13], S21, 0xa9e3e905); /* 29 */
    GG (d, a, b, c, x[ 2], S22, 0xfcefa3f8); /* 30 */
    GG (c, d, a, b, x[ 7], S23, 0x676f02d9); /* 31 */
    GG (b, c, d, a, x[12], S24, 0x8d2a4c8a); /* 32 */

    /* Round 3 */
    HH (a, b, c, d, x[ 5], S31, 0xfffa3942); /* 33 */
    HH (d, a, b, c, x[ 8], S32, 0x8771f681); /* 34 */
    HH (c, d, a, b, x[11], S33, 0x6d9d6122); /* 35 */
    HH (b, c, d, a, x[14], S34, 0xfde5380c); /* 36 */
    HH (a, b, c, d, x[ 1], S31, 0xa4beea44); /* 37 */
    HH (d, a, b, c, x[ 4], S32, 0x4bdecfa9); /* 38 */
    HH (c, d, a, b, x[ 7], S33, 0xf6bb4b60); /* 39 */
    HH (b, c, d, a, x[10], S34, 0xbebfbc70); /* 40 */
    HH (a, b, c, d, x[13], S31, 0x289b7ec6); /* 41 */
    HH (d, a, b, c, x[ 0], S32, 0xeaa127fa); /* 42 */
    HH (c, d, a, b, x[ 3], S33, 0xd4ef3085); /* 43 */
    HH (b, c, d, a, x[ 6], S34,  0x4881d05); /* 44 */
    HH (a, b, c, d, x[ 9], S31, 0xd9d4d039); /* 45 */
    HH (d, a, b, c, x[12], S32, 0xe6db99e5); /* 46 */
    HH (c, d, a, b, x[15], S33, 0x1fa27cf8); /* 47 */
    HH (b, c, d, a, x[ 2], S34, 0xc4ac5665); /* 48 */

    /* Round 4 */
    II (a, b, c, d, x[ 0], S41, 0xf4292244); /* 49 */
    II (d, a, b, c, x[ 7], S42, 0x432aff97); /* 50 */
    II (c, d, a, b, x[14], S43, 0xab9423a7); /* 51 */
    II (b, c, d, a, x[ 5], S44, 0xfc93a039); /* 52 */
    II (a, b, c, d, x[12], S41, 0x655b59c3); /* 53 */
    II (d, a, b, c, x[ 3], S42, 0x8f0ccc92); /* 54 */
    II (c, d, a, b, x[10], S43, 0xffeff47d); /* 55 */
    II (b, c, d, a, x[ 1], S44, 0x85845dd1); /* 56 */
    II (a, b, c, d, x[ 8], S41, 0x6fa87e4f); /* 57 */
    II (d, a, b, c, x[15], S42, 0xfe2ce6e0); /* 58 */
    II (c, d, a, b, x[ 6], S43, 0xa3014314); /* 59 */
    II (b, c, d, a, x[13], S44, 0x4e0811a1); /* 60 */
    II (a, b, c, d, x[ 4], S41, 0xf7537e82); /* 61 */
    II (d, a, b, c, x[11], S42, 0xbd3af235); /* 62 */
    II (c, d, a, b, x[ 2], S43, 0x2ad7d2bb); /* 63 */
    II (b, c, d, a, x[ 9], S44, 0xeb86d391); /* 64 */

    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;

    /* Zeroize sensitive information.
     */
    MD5_memset ((POINTER)x, 0, sizeof (x));
}

/* Encodes input (UINT4) into output (unsigned char). Assumes len is
  a multiple of 4.
 */
static void Encode (output, input, len)
unsigned char *output;
UINT4 *input;
unsigned int len;
{
    unsigned int i, j;

    for (i = 0, j = 0; j < len; i++, j += 4) {
	output[j] = (unsigned char)(input[i] & 0xff);
	output[j+1] = (unsigned char)((input[i] >> 8) & 0xff);
	output[j+2] = (unsigned char)((input[i] >> 16) & 0xff);
	output[j+3] = (unsigned char)((input[i] >> 24) & 0xff);
	}
}

/* Decodes input (unsigned char) into output (UINT4). Assumes len is
  a multiple of 4.
 */
static void Decode (output, input, len)
UINT4 *output;
unsigned char *input;
unsigned int len;
{
    unsigned int i, j;

    for (i = 0, j = 0; j < len; i++, j += 4)
	output[i] = ((UINT4)input[j]) | (((UINT4)input[j+1]) << 8) |
	  (((UINT4)input[j+2]) << 16) | (((UINT4)input[j+3]) << 24);
}

/* Note: Replace "for loop" with standard memcpy if possible.
 */

static void MD5_memcpy (output, input, len)
POINTER output;
POINTER input;
unsigned int len;
{
    unsigned int i;

    for (i = 0; i < len; i++)
	output[i] = input[i];
}

/* Note: Replace "for loop" with standard memset if possible.
 */
static void MD5_memset (output, value, len)
POINTER output;
int value;
unsigned int len;
{
    unsigned int i;

    for (i = 0; i < len; i++)
	 ((char *)output)[i] = (char)value;
}


/* ------------------------------------------------------------------ */

typedef uint32_t u_int32_t;
typedef uint64_t u_int64_t;

/*	$OpenBSD: sha1.h,v 1.1.2.4 2004/06/05 23:12:36 niklas Exp $	*/

/*
 * SHA-1 in C
 * By Steve Reid <steve@edmweb.com>
 * 100% Public Domain
 */

#define	SHA1_BLOCK_LENGTH		64
#define	SHA1_DIGEST_LENGTH		20

typedef struct {
	u_int32_t	state[5];
	u_int64_t	count;
	unsigned char	buffer[SHA1_BLOCK_LENGTH];
} SHA1_CTX;
  
void SHA1Init(SHA1_CTX * context);
void SHA1Transform(u_int32_t state[5], unsigned char buffer[SHA1_BLOCK_LENGTH]);
void SHA1Update(SHA1_CTX *context, unsigned char *data, unsigned int len);
u_int32_t *SHA1State(SHA1_CTX *context);
void SHA1Final(unsigned char digest[SHA1_DIGEST_LENGTH], SHA1_CTX *context);


/*	$OpenBSD: sha1.c,v 1.5 2004/04/28 20:39:35 hshoexer Exp $	*/

/*
 * SHA-1 in C
 * By Steve Reid <steve@edmweb.com>
 * 100% Public Domain
 * 
 * Test Vectors (from FIPS PUB 180-1)
 * "abc"
 *   A9993E36 4706816A BA3E2571 7850C26C 9CD0D89D
 * "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
 *   84983E44 1C3BD26E BAAE4AA1 F95129E5 E54670F1
 * A million repetitions of "a"
 *   34AA973C D4C4DAA4 F61EEB2B DBAD2731 6534016F
*/

/* #define LITTLE_ENDIAN * This should be #define'd already, if true. */
/* #define SHA1HANDSOFF * Copies data before messing with it. */

#define SHA1HANDSOFF

#define rol(value, bits) (((value) << (bits)) | ((value) >> (32 - (bits))))

/* blk0() and blk() perform the initial expand. */
/* I got the idea of expanding during the round function from SSLeay */
#if ENDIAN_LITTLE
#define blk0(i) (block->l[i] = (rol(block->l[i],24)&0xFF00FF00) \
    |(rol(block->l[i],8)&0x00FF00FF))
#else
#define blk0(i) block->l[i]
#endif
#define blk(i) (block->l[i&15] = rol(block->l[(i+13)&15]^block->l[(i+8)&15] \
    ^block->l[(i+2)&15]^block->l[i&15],1))

/* (R0+R1), R2, R3, R4 are the different operations used in SHA1 */
#define R0(v,w,x,y,z,i) z+=((w&(x^y))^y)+blk0(i)+0x5A827999+rol(v,5);w=rol(w,30);
#define R1(v,w,x,y,z,i) z+=((w&(x^y))^y)+blk(i)+0x5A827999+rol(v,5);w=rol(w,30);
#define R2(v,w,x,y,z,i) z+=(w^x^y)+blk(i)+0x6ED9EBA1+rol(v,5);w=rol(w,30);
#define R3(v,w,x,y,z,i) z+=(((w|x)&y)|(w&x))+blk(i)+0x8F1BBCDC+rol(v,5);w=rol(w,30);
#define R4(v,w,x,y,z,i) z+=(w^x^y)+blk(i)+0xCA62C1D6+rol(v,5);w=rol(w,30);

/* Hash a single 512-bit block. This is the core of the algorithm. */

void
SHA1Transform(u_int32_t state[5], unsigned char buffer[SHA1_BLOCK_LENGTH])
{
    u_int32_t a, b, c, d, e;
    typedef union {
        unsigned char c[64];
        unsigned int l[16];
    } CHAR64LONG16;
    CHAR64LONG16* block;
#ifdef SHA1HANDSOFF
    static unsigned char workspace[SHA1_BLOCK_LENGTH];

    block = (CHAR64LONG16 *)workspace;
    bcopy(buffer, block, SHA1_BLOCK_LENGTH);
#else
    block = (CHAR64LONG16 *)buffer;
#endif
    /* Copy context->state[] to working vars */
    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
    e = state[4];

    /* 4 rounds of 20 operations each. Loop unrolled. */
    R0(a,b,c,d,e, 0); R0(e,a,b,c,d, 1); R0(d,e,a,b,c, 2); R0(c,d,e,a,b, 3);
    R0(b,c,d,e,a, 4); R0(a,b,c,d,e, 5); R0(e,a,b,c,d, 6); R0(d,e,a,b,c, 7);
    R0(c,d,e,a,b, 8); R0(b,c,d,e,a, 9); R0(a,b,c,d,e,10); R0(e,a,b,c,d,11);
    R0(d,e,a,b,c,12); R0(c,d,e,a,b,13); R0(b,c,d,e,a,14); R0(a,b,c,d,e,15);
    R1(e,a,b,c,d,16); R1(d,e,a,b,c,17); R1(c,d,e,a,b,18); R1(b,c,d,e,a,19);
    R2(a,b,c,d,e,20); R2(e,a,b,c,d,21); R2(d,e,a,b,c,22); R2(c,d,e,a,b,23);
    R2(b,c,d,e,a,24); R2(a,b,c,d,e,25); R2(e,a,b,c,d,26); R2(d,e,a,b,c,27);
    R2(c,d,e,a,b,28); R2(b,c,d,e,a,29); R2(a,b,c,d,e,30); R2(e,a,b,c,d,31);
    R2(d,e,a,b,c,32); R2(c,d,e,a,b,33); R2(b,c,d,e,a,34); R2(a,b,c,d,e,35);
    R2(e,a,b,c,d,36); R2(d,e,a,b,c,37); R2(c,d,e,a,b,38); R2(b,c,d,e,a,39);
    R3(a,b,c,d,e,40); R3(e,a,b,c,d,41); R3(d,e,a,b,c,42); R3(c,d,e,a,b,43);
    R3(b,c,d,e,a,44); R3(a,b,c,d,e,45); R3(e,a,b,c,d,46); R3(d,e,a,b,c,47);
    R3(c,d,e,a,b,48); R3(b,c,d,e,a,49); R3(a,b,c,d,e,50); R3(e,a,b,c,d,51);
    R3(d,e,a,b,c,52); R3(c,d,e,a,b,53); R3(b,c,d,e,a,54); R3(a,b,c,d,e,55);
    R3(e,a,b,c,d,56); R3(d,e,a,b,c,57); R3(c,d,e,a,b,58); R3(b,c,d,e,a,59);
    R4(a,b,c,d,e,60); R4(e,a,b,c,d,61); R4(d,e,a,b,c,62); R4(c,d,e,a,b,63);
    R4(b,c,d,e,a,64); R4(a,b,c,d,e,65); R4(e,a,b,c,d,66); R4(d,e,a,b,c,67);
    R4(c,d,e,a,b,68); R4(b,c,d,e,a,69); R4(a,b,c,d,e,70); R4(e,a,b,c,d,71);
    R4(d,e,a,b,c,72); R4(c,d,e,a,b,73); R4(b,c,d,e,a,74); R4(a,b,c,d,e,75);
    R4(e,a,b,c,d,76); R4(d,e,a,b,c,77); R4(c,d,e,a,b,78); R4(b,c,d,e,a,79);

    /* Add the working vars back into context.state[] */
    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    /* Wipe variables */
    a = b = c = d = e = 0;
}


/* SHA1Init - Initialize new context */

void
SHA1Init(SHA1_CTX *context)
{
    /* SHA1 initialization constants */
    context->count = 0;
    context->state[0] = 0x67452301;
    context->state[1] = 0xEFCDAB89;
    context->state[2] = 0x98BADCFE;
    context->state[3] = 0x10325476;
    context->state[4] = 0xC3D2E1F0;
}


/* Run your data through this. */

void
SHA1Update(SHA1_CTX *context, unsigned char *data, unsigned int len)
{
    unsigned int i;
    unsigned int j;

    j = (u_int32_t)((context->count >> 3) & 63);
    context->count += (len << 3);
    if ((j + len) > 63) {
        bcopy(data, &context->buffer[j], (i = 64 - j));
        SHA1Transform(context->state, context->buffer);
        for ( ; i + 63 < len; i += 64) {
            SHA1Transform(context->state, &data[i]);
        }
        j = 0;
    }
    else i = 0;
    bcopy(&data[i], &context->buffer[j], len - i);
}


/* Read out the state. */

u_int32_t *
SHA1State(SHA1_CTX *context)
{
    return context->state;
}


/* Add padding and return the message digest. */

void
SHA1Final(unsigned char digest[SHA1_DIGEST_LENGTH], SHA1_CTX *context)
{
    unsigned int i;
    unsigned char finalcount[8];

    for (i = 0; i < 8; i++) {
        finalcount[i] = (unsigned char)((context->count >>
            ((7 - (i & 7)) * 8)) & 255);  /* Endian independent */
    }
    SHA1Update(context, (unsigned char *)"\200", 1);
    while ((context->count & 504) != 448) {
        SHA1Update(context, (unsigned char *)"\0", 1);
    }
    SHA1Update(context, finalcount, 8);  /* Should cause a SHA1Transform() */

    if (digest)
        for (i = 0; i < SHA1_DIGEST_LENGTH; i++) {
            digest[i] = (unsigned char)((context->state[i >> 2] >>
                ((3 - (i & 3)) * 8)) & 255);
      }
#if 0	/* We want to use this for "keyfill" */
    /* Wipe variables */
    i = 0;
    bzero(context->buffer, 64);
    bzero(context->state, 20);
    bzero(context->count, 8);
    bzero(&finalcount, 8);
#ifdef SHA1HANDSOFF  /* make SHA1Transform overwrite it's own static vars */
    SHA1Transform(context->state, context->buffer);
#endif
#endif
}

/* ------------------------------------------------------------------ */
#include "pcivar.h"
#include "cfe_crypto.h"

/*
   The following Packet Descriptor entries are temporarily here and
   not in cfe_crypto.h to simplify management of SIBYTE_PRIVATE_FILES.

   Each Master Command Record consists of a header word followed by an
   array of N Packet Descriptor (PD) entries.

     commandContext[0]     // DBC
     dataBuffer[0]
     pktLen[0]
     outputBuffer[0]      // DBC
     ...
     commandContext[N-1]
     dataBuffer[N-1]
     pktLen[N-1]
     outputBuffer[N-1]

   The format of the command context and buffer usage depend upon the
   particular command.  The offsets below are relative to the
   containing PD.
*/

/* Data Buffer Chain Entry Offsets */

#define DBC_ADDR                 0
#define DBC_NEXT                 4
#define DBC_LEN                  8

#define CHAIN_WORDS              3

#define S_DBC_DATA_LEN           0
#define M_DBC_DATA_LEN           _DD_MAKEMASK(16,S_DBC_DATA_LEN)
#define V_DBC_DATA_LEN(x)        _DD_MAKEVALUE(x,S_DBC_DATA_LEN)
#define G_DBC_DATA_LEN(x)        _DD_GETVALUE(x,S_DBC_DATA_LEN,M_DBC_DATA_LEN)

/* Packet Descriptor Offsets (as bytes) */

#define PD_CC_ADDR               0
#define PD_INPUT_FRAG            4
#define PD_INPUT_FRAG_ADDR       (PD_INPUT_FRAG+DBC_ADDR)
#define PD_INPUT_FRAG_NEXT       (PD_INPUT_FRAG+DBC_NEXT)
#define PD_INPUT_FRAG_LEN        (PD_INPUT_FRAG+DBC_LEN)
#define PD_PKT_LEN               16
#define PD_OUTPUT_FRAG           20
#define PD_OUTPUT_FRAG_ADDR      (PD_OUTPUT_FRAG+DBC_ADDR)
#define PD_OUTPUT_FRAG_NEXT      (PD_OUTPUT_FRAG+DBC_NEXT)
#define PD_OUTPUT_FRAG_LEN       (PD_OUTPUT_FRAG+DBC_LEN)

#define PD_SIZE                  32

#define S_PD_PKT_LEN             16
#define M_PD_PKT_LEN             _DD_MAKEMASK(16,S_PD_PKT_LEN)
#define V_PD_PKT_LEN(x)          _DD_MAKEVALUE(x,S_PD_PKT_LEN)
#define G_PD_PKT_LEN(x)          _DD_GETVALUE(x,S_PD_PKT_LEN,M_PD_PKT_LEN)

/* Packet Descriptor Indices (as words) */

#define PD_IN_ADDR               (PD_INPUT_FRAG_ADDR/4)
#define PD_IN_LEN                (PD_INPUT_FRAG_LEN/4)
#define PD_IN_NEXT               (PD_INPUT_FRAG_NEXT/4)
#define PD_OUT_ADDR              (PD_OUTPUT_FRAG_ADDR/4)
#define PD_OUT_LEN               (PD_OUTPUT_FRAG_LEN/4)
#define PD_OUT_NEXT              (PD_OUTPUT_FRAG_NEXT/4)


/* Crypotographic Operations */

/* MCR1 only (symmetric) */
#define K_IPSEC_3DES             0x0000
#define K_SSL_MAC                0x0001
#define K_TLS_HMAC               0x0002
#define K_SSL_3DES               0x0003
#define K_ARC4                   0x0004                /* Not 5820 */
#define K_HASH                   0x0005
#define K_IPSEC_AES              0x0040                /* 5823 only */

/* MCR2 only (asymmetric) */
#define K_DH_PK_GEN              0x0001
#define K_DH_SK_GEN              0x0002
#define K_RSA_PK_OP              0x0003
#define K_RSA_SK_OP              0x0004
#define K_DSA_SIGN               0x0005
#define K_DSA_VERIF              0x0006
#define K_RNG_DIRECT             0x0041
#define K_RNG_SHA1               0x0042
#define K_MOD_ADD                0x0043
#define K_MOD_SUB                0x0044
#define K_MOD_MUL                0x0045
#define K_MOD_REDUCE             0x0046
#define K_MOD_EXP                0x0047
#define K_MOD_INV                0x0048               /* Not 5821 */
#define K_MOD_2EXP               0x0049               /* Not 5820 */


/* Command Context Header */

/* Word 0 */

#define S_CC_OPCODE              16
#define M_CC_OPCODE              _DD_MAKEMASK(16,S_CC_OPCODE)
#define V_CC_OPCODE(x)           _DD_MAKEVALUE(x,S_CC_OPCODE)
#define G_CC_OPCODE(x)           _DD_GETVALUE(x,S_CC_OPCODE,M_CC_OPCODE)

#define S_CC_LEN                 0
#define M_CC_LEN                 _DD_MAKEMASK(16,S_CC_LEN)
#define V_CC_LEN(x)              _DD_MAKEVALUE(x,S_CC_LEN)
#define G_CC_LEN(x)              _DD_GETVALUE(x,S_CC_LEN,M_CC_LEN)

/* Word 1 */

#define S_CC_FLAGS               12
#define M_CC_FLAGS               _DD_MAKEMASK(4,S_CC_FLAGS)
#define V_CC_FLAGS(x)            _DD_MAKEVALUE(x,S_CC_FLAGS)
#define G_CC_FLAGS(x)            _DD_GETVALUE(x,S_CC_OPCODE,M_CC_OPCODE)

/* For IPSEC_3DES, IPSEC_AES, ... */
#define S_CC_OFFSET              16
#define M_CC_OFFSET              _DD_MAKEMASK(16,S_CC_OFFSET)
#define V_CC_OFFSET(x)           _DD_MAKEVALUE(x,S_CC_OFFSET)
#define G_CC_OFFSET(x)           _DD_GETVALUE(x,S_CC_OPCODE,M_CC_OPCODE)

/* The remaining command context fields depend on the opcode. */

/* IPSEC 3DES (K_IPSEC_3DES) */
/* SSL MAC (K_SSL_MAC) */
/* TLS HMAC (K_TLS_HMAC) */
/* Pure MD5/SHA-1 Hash (K_HASH) */

#define K_HASH_FLAGS_MD5         1
#define K_HASH_FLAGS_SHA1        2
#define K_IPSEC_FLAGS_IN         4
#define K_IPSEC_FLAGS_ENCRYPT    8

/* SSL MAC (K_SSL_MAC) */

#define SSL_MAC_CMD_WORDS        22

/* TLS HMAC (K_TLS_HMAC) */

#define TLS_HMAC_CMD_WORDS       16

/* Pure MD5/SHA-1 Hash (K_HASH) */

/* SSL/TLS DES/3DES (K_SSL_3DES) */

/* ARCFOUR (K_ARC4) */

#define ARC4_STATE_WORDS         (1 + 256/4)
#define ARC4_CMD_WORDS           (2 + ARC4_STATE_WORDS)

#define M_ARC4_FLAGS_KEY         _DD_MAKEMASK1(10)
#define M_ARC4_FLAGS_WRITEBACK   _DD_MAKEMASK1(11)
#define M_ARC4_FLAGS_NULLDATA    _DD_MAKEMASK1(12)


/* Random number generation (K_RNG_DIRECT, K_RNG_SHA1) */

/* Modular arithmetic (K_MOD_ADD, K_MOD_SUB, K_MOD_MUL) */

/* Modular Remainder (K_MOD_REDUCE) */

/* Modular Exponentiation (K_MOD_EXP) */

/* Double Modular Exponentiation (K_MOD_2EXP) */


#ifndef DEBUG
#define DEBUG 0
#endif  /* DEBUG */


#define CACHE_LINE_SIZE  32


/* Address mapping macros */

/* Note that PTR_TO_PHYS only works with 32-bit addresses, but then
   so does the bcm582x. */
#define PTR_TO_PHYS(x) (PHYSADDR((uintptr_t)(x)))
#define PHYS_TO_PTR(a) ((void *)KERNADDR(a))

#if ENDIAN_BIG

#if CPUCFG_REGS32   /* XXX This is a placeholder for 47XX */
/* The NORM_PCI bit in the OCP crypto core appears to be a noop.
   Mappings of data through the Silicon Backplane (_D) use match
   bytes, but control blocks and pointers to them use match bits. */

#define PHYS_TO_PCI_D(a) ((uint32_t) (a) + 0x10000000)
#define PCI_TO_PHYS_D(a) ((uint32_t) (a) - 0x10000000)

#else
/* For the 5821 and successors, all mappings through the PCI host
   bridge use match bits mode.  This works because the NORM_PCI bit in
   DMA Control is clear.  The 5820 does not have such a bit, so
   pointers to data byte sequences (_D) use match bytes, but control
   blocks and pointers to them use match bits. */

#define PHYS_TO_PCI_D(a) (a)
#define PCI_TO_PHYS_D(a) (a)
#endif

#else
#undef PHYS_TO_PCI
#undef PCI_TO_PHYS
#define PHYS_TO_PCI(a) ((uint32_t) (a))
#define PHYS_TO_PCI_D(a) (a)
#define PCI_TO_PHYS(a) ((uint32_t) (a))
#define PCI_TO_PHYS_D(a) (a)
#endif

/* For non-coherent memory systems, convert all pointers to
   descriptors and to the data part of packet buffers to do
   uncached access.
   XXX For data, cache flushes would probably be better. */
#if CPUCFG_COHERENT_DMA
#define SHARED(x) ((uint8_t *)(x))
#define CACHED(x) ((uint8_t *)(x))
#else
#define SHARED(x) ((uint8_t *)UNCADDR(PHYSADDR((uintptr_t)(x))))
#define CACHED(x) ((uint8_t *)KERNADDR(PHYSADDR((uintptr_t)(x))))
#endif


/* Utilities */

#if ENDIAN_LITTLE
static uint32_t
swap4(uint32_t x)
{
    uint32_t t;

    t = ((x & 0xFF00FF00) >> 8) | ((x & 0x00FF00FF) << 8);
    return (t >> 16) | ((t & 0xFFFF) << 16);
}
#endif


static unsigned int
hex_digit(char c)
{
    return ((c >= '0' && c <= '9') ? (c - '0') :
	    (c >= 'a' && c <= 'f') ? (c - 'a') + 10 :
	    (c >= 'A' && c <= 'F') ? (c - 'A') + 10 :
	    0);
}

static void
hex_encode(uint8_t hex[], const char *ascii, size_t n)
{
    int i;
    int len = strlen(ascii)/2;

    for (i = 0; i < len; i++)
	hex[i] = 16*hex_digit(ascii[2*i]) + hex_digit(ascii[2*i+1]);
    for (i = len; i < n; i++)
	hex[i] = 0;
}

static void *
bs_alloc (size_t len)
{
  uint32_t size = (len + (CACHE_LINE_SIZE-1)) & ~(CACHE_LINE_SIZE-1);

  return KMALLOC(size, CACHE_LINE_SIZE);
}

static void
bs_free_data (uint32_t addr, int swap)
{
    if (addr != 0) {
	if (swap)
	    KFREE(CACHED(PHYS_TO_PTR(PCI_TO_PHYS_D(addr))));
	else
	    KFREE(CACHED(PHYS_TO_PTR(PCI_TO_PHYS(addr))));
	}
}


/* Debugging functions */


/* Crypto test functions. */

#define HASH_MD5  0
#define HASH_SHA1 1

static uint32_t *
bs_alloc_hash (int func, const uint8_t *msg, size_t msg_len, int swap)
{
    uint32_t *mcr;
    uint32_t *cmd;    /* always reads at least 64 bytes */
    uint8_t  *message;
    uint8_t  *digest;
    int i;
    int hlen = (func == HASH_SHA1 ? 20 : 16);

    message = bs_alloc(msg_len);
    for (i = 0; i < msg_len; i++)
	message[i] = msg[i];
    CACHE_DMA_SYNC(message, msg_len);
   
    digest = bs_alloc(hlen);
    for (i = 0; i < hlen; i++)
	digest[i] = 0;
    CACHE_DMA_SYNC(digest, hlen);
   
    mcr = (uint32_t *)bs_alloc(MCR_WORDS(1)*4);
    mcr[0] = V_MCR_NUM_PACKETS(1);

   /* Always allocate >= 64 bytes */
    cmd = (uint32_t *)bs_alloc(64);
    cmd[0] = V_CC_OPCODE(K_HASH) | V_CC_LEN(8);
    if (func == HASH_SHA1)
	cmd[1] = V_CC_FLAGS(K_HASH_FLAGS_SHA1);
    else
	cmd[1] = V_CC_FLAGS(K_HASH_FLAGS_MD5);
    CACHE_DMA_SYNC(cmd, 64);

    mcr[1] = PHYS_TO_PCI(PTR_TO_PHYS(cmd));

    /* input fragment */
    mcr[2] = swap ? PHYS_TO_PCI_D(PTR_TO_PHYS(message))
                  : PHYS_TO_PCI(PTR_TO_PHYS(message));
    mcr[3] = 0;
    mcr[4] = V_DBC_DATA_LEN(msg_len);

    mcr[5] = V_PD_PKT_LEN(msg_len);

    mcr[6] = 0;
    mcr[7] = swap ? PHYS_TO_PCI_D(PTR_TO_PHYS(digest))
                  : PHYS_TO_PCI(PTR_TO_PHYS(digest));
    mcr[8] = 0;

    return mcr;
}

static void
bs_check_hash (uint8_t *hash, const uint8_t *digest, size_t hlen)
{
    int i;

    CACHE_DMA_INVAL(hash, hlen);

    xprintf(" ");
    for (i = 0; i < hlen; i++)
        xprintf("%02x", hash[i]);
    if (memcmp(hash, digest, hlen) == 0)
	xprintf(" - pass\n");
    else {
	xprintf(" - fail\n   (");
	for (i = 0; i < hlen; i++)
	    xprintf("%02x", digest[i]);
	xprintf(")\n");
	}
}

static void
bs_free_hash (uint32_t mcr[], int swap)
{
    KFREE(CACHED(PHYS_TO_PTR(PCI_TO_PHYS(mcr[1]))));
    bs_free_data(mcr[2], swap);
    bs_free_data(mcr[7], swap);

    KFREE(CACHED(mcr));
}


static uint8_t *
bs_hash_md5 (int device, const char *msg, size_t len)
{
    crypto_info_t info;
    int swap;
    int arglen;
    uint32_t *mcr;
    int rc;
    uint8_t *hash;

    arglen = sizeof(crypto_info_t);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_GETINFO, (unsigned char *)&info,
		   arglen, &arglen, 0);
    swap = (info.chip == BCM5820 || info.chip == OCP80B);
		   
    mcr = bs_alloc_hash(HASH_MD5, (const uint8_t *)msg, len, swap);

    arglen = sizeof(uint32_t *);
    CACHE_DMA_SYNC(mcr, MCR_WORDS(1)*4);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_CMD_1, (unsigned char *)SHARED(mcr),
		   arglen, &arglen, 0);
    CACHE_DMA_INVAL(mcr, MCR_WORDS(1)*4);

    hash = swap ? PHYS_TO_PTR(PCI_TO_PHYS_D(mcr[7]))
                : PHYS_TO_PTR(PCI_TO_PHYS(mcr[7]));
    mcr[7] = 0;
    bs_free_hash(mcr, swap);

    return hash;
}

static uint8_t *
bs_hash_sha1 (int device, const char *msg, size_t len)
{
    crypto_info_t info;
    int swap;
    int arglen;
    uint32_t *mcr;
    int rc;
    uint8_t *hash;

    arglen = sizeof(crypto_info_t);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_GETINFO, (unsigned char *)&info,
		   arglen, &arglen, 0);
    swap = (info.chip == BCM5820 || info.chip == OCP80B);
		   
    mcr = bs_alloc_hash(HASH_SHA1, (const uint8_t *) msg, len, swap);

    arglen = sizeof(uint32_t *);
    CACHE_DMA_SYNC(mcr, MCR_WORDS(1)*4);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_CMD_1, (unsigned char *)SHARED(mcr),
		   arglen, &arglen, 0);
    CACHE_DMA_INVAL(mcr, MCR_WORDS(1)*4);

    hash = swap ? PHYS_TO_PTR(PCI_TO_PHYS_D(mcr[7]))
                : PHYS_TO_PTR(PCI_TO_PHYS(mcr[7]));
    mcr[7] = 0;
    bs_free_hash(mcr, swap);

    return hash;
}


static void
bs_hmac_state (int func, uint32_t *dest,
	       const uint8_t *key, size_t keylen, uint8_t xor)
{
    uint8_t pad[64];
    unsigned int hashlen = (func == HASH_SHA1 ? 20 : 16);
    uint32_t *state;
    int i;

    memset(pad, 0, sizeof(pad));
    memcpy(pad, key, keylen);
    for (i = 0; i < sizeof(pad); i++)
	pad[i] ^= xor;
    if (func == HASH_SHA1) {
	SHA1_CTX sha1ctx;
    
	SHA1Init(&sha1ctx);
	SHA1Update(&sha1ctx, pad, sizeof(pad));
	state = SHA1State(&sha1ctx);
	}
    else {
	MD5_CTX md5ctx;
    
	MD5Init(&md5ctx);
	MD5Update(&md5ctx, pad, sizeof(pad));
	state = MD5State(&md5ctx);
	}
    /* State is defined by 32-bit words.  For match bits, no byte
       swizzle is required. */
    for (i = 0; i < hashlen/4; i++)
	dest[i] = state[i];
}

static uint32_t *
bs_alloc_hmac (int device, int func,
	       const uint8_t *key, size_t key_len,
	       const uint8_t *msg, size_t msg_len,
	       int swap)
{
    uint32_t *mcr;
    uint32_t *cmd;
    uint8_t  *message;
    uint8_t  *digest;
    int i;
    int hlen = (func == HASH_SHA1 ? 20 : 16);

    message = bs_alloc(msg_len);
    for (i = 0; i < msg_len; i++)
	message[i] = msg[i];
    CACHE_DMA_SYNC(message, msg_len);
   
    digest = bs_alloc(hlen);
    for (i = 0; i < hlen; i++)
	digest[i] = 0;
    CACHE_DMA_SYNC(digest, hlen);
   
    mcr = (uint32_t *)bs_alloc(MCR_WORDS(1)*4);
    mcr[0] = V_MCR_NUM_PACKETS(1);

    cmd = (uint32_t *)bs_alloc(80);
    memset(cmd, 0, 80);

    cmd[0] = V_CC_OPCODE(K_IPSEC_3DES) | V_CC_LEN(80);
    if (func == HASH_SHA1)
	cmd[1] = V_CC_FLAGS(K_HASH_FLAGS_SHA1) | V_CC_OFFSET(0);
    else
	cmd[1] = V_CC_FLAGS(K_HASH_FLAGS_MD5) | V_CC_OFFSET(0);

    bs_hmac_state(func, &cmd[10], key, key_len, 0x36);
    bs_hmac_state(func, &cmd[15], key, key_len, 0x5c);

    CACHE_DMA_SYNC(cmd, 80);
    mcr[1] = PHYS_TO_PCI(PTR_TO_PHYS(cmd));

    /* input fragment */
    mcr[2] = swap ? PHYS_TO_PCI_D(PTR_TO_PHYS(message))
                  : PHYS_TO_PCI(PTR_TO_PHYS(message));
    mcr[3] = 0;
    mcr[4] = V_DBC_DATA_LEN(msg_len);

    mcr[5] = V_PD_PKT_LEN(msg_len);

    mcr[6] = 0;
    mcr[7] = swap ? PHYS_TO_PCI_D(PTR_TO_PHYS(digest))
                  : PHYS_TO_PCI(PTR_TO_PHYS(digest));
    mcr[8] = 0;

    return mcr;
}

static void
bs_check_hmac (uint8_t *hash, const uint8_t *digest, size_t hlen)
{
    int i;

    CACHE_DMA_INVAL(hash, hlen);

    xprintf(" ");
    for (i = 0; i < hlen; i++)
        xprintf("%02x", hash[i]);
    if (memcmp(hash, digest, hlen) == 0)
	xprintf(" - pass\n");
    else {
	xprintf(" - fail\n   (");
	for (i = 0; i < hlen; i++)
	    xprintf("%02x", digest[i]);
	xprintf(")\n");
	}
}

static void
bs_free_hmac (uint32_t mcr[], int swap)
{
    KFREE(CACHED(PHYS_TO_PTR(PCI_TO_PHYS(mcr[1]))));
    bs_free_data(mcr[2], swap);
    bs_free_data(mcr[7], swap);

    KFREE(CACHED(mcr));
}


static uint8_t *
bs_hmac_md5 (int device,
	     const uint8_t *key, size_t keylen,
	     const uint8_t *msg, size_t len)
{
    crypto_info_t info;
    int swap;
    int arglen;
    uint32_t *mcr;
    int rc;
    uint8_t *hash;
    uint8_t *hashed_key;

    hashed_key = NULL;
    if (keylen > 64) {
	hashed_key = bs_hash_md5(device, (const char*) key, keylen);
	CACHE_DMA_INVAL(hashed_key, 16);
	key = hashed_key;
	keylen = 16;
	}

    arglen = sizeof(crypto_info_t);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_GETINFO, (unsigned char *)&info,
		   arglen, &arglen, 0);
    swap = (info.chip == BCM5820 || info.chip == OCP80B);
		   
    mcr = bs_alloc_hmac(device, HASH_MD5, key, keylen, msg, len, swap);

    arglen = sizeof(uint32_t *);
    CACHE_DMA_SYNC(mcr, MCR_WORDS(1)*4);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_CMD_1, (unsigned char *)SHARED(mcr),
		   arglen, &arglen, 0);
    CACHE_DMA_INVAL(mcr, MCR_WORDS(1)*4);

    hash = swap ? PHYS_TO_PTR(PCI_TO_PHYS_D(mcr[7]))
                : PHYS_TO_PTR(PCI_TO_PHYS(mcr[7]));
    mcr[7] = 0;
    bs_free_hmac(mcr, swap);

    if (hashed_key != NULL) KFREE(CACHED(hashed_key));

    return hash;
}

static uint8_t *
bs_hmac_sha1 (int device,
	      const uint8_t *key, size_t keylen,
	      const uint8_t *msg, size_t len)
{
    crypto_info_t info;
    int swap;
    int arglen;
    uint32_t *mcr;
    int rc;
    uint8_t *hash;
    uint8_t *hashed_key;

    hashed_key = NULL;
    if (keylen > 64) {
	hashed_key = bs_hash_sha1(device, (const char*) key, keylen);
	CACHE_DMA_INVAL(hashed_key, 20);
	key = hashed_key;
	keylen = 20;
	}

    arglen = sizeof(crypto_info_t);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_GETINFO, (unsigned char *)&info,
		   arglen, &arglen, 0);
    swap = (info.chip == BCM5820 || info.chip == OCP80B);
		   
    mcr = bs_alloc_hmac(device, HASH_SHA1, key, keylen, msg, len, swap);

    arglen = sizeof(uint32_t *);
    CACHE_DMA_SYNC(mcr, MCR_WORDS(1)*4);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_CMD_1, (unsigned char *)SHARED(mcr),
		   arglen, &arglen, 0);
    CACHE_DMA_INVAL(mcr, MCR_WORDS(1)*4);

    hash = swap ? PHYS_TO_PTR(PCI_TO_PHYS_D(mcr[7]))
                : PHYS_TO_PTR(PCI_TO_PHYS(mcr[7]));
    mcr[7] = 0;
    bs_free_hmac(mcr, swap);

    if (hashed_key != NULL) KFREE(CACHED(hashed_key));

    return hash;
}


static uint32_t *
bs_alloc_ipsec (int func,
		const uint8_t *key1, const uint8_t *key2, const uint8_t *iv,
		const uint8_t *msg, size_t msg_len,
		int swap)
{
    uint32_t *mcr;
    uint32_t *cmd;
    uint8_t  *message;
    uint8_t  *cipher;
    int i;

    message = bs_alloc(msg_len);
    for (i = 0; i < msg_len; i++)
	message[i] = msg[i];
    CACHE_DMA_SYNC(message, msg_len);
   
    cipher = bs_alloc(msg_len);
    for (i = 0; i < msg_len; i++)
	cipher[i] = 0;
    CACHE_DMA_SYNC(cipher, msg_len);
   
    mcr = (uint32_t *)bs_alloc(MCR_WORDS(1)*4);
    mcr[0] = V_MCR_NUM_PACKETS(1);

    cmd = (uint32_t *)bs_alloc(80);
    memset(cmd, 0, 80);

    cmd[0] = V_CC_OPCODE(func) | V_CC_LEN(80);
    cmd[1] = V_CC_FLAGS(K_IPSEC_FLAGS_ENCRYPT) | V_CC_OFFSET(0);

    if (func == K_IPSEC_3DES) {
	memcpy(&cmd[2], key1, 8);
	memcpy(&cmd[4], key2, 8);
	memcpy(&cmd[6], key1, 8);
	memcpy(&cmd[8], iv, 8);
	}
    else {
	/* NB: This command setup assumes 128-bit keys. */
	memcpy(&cmd[2], key1, 16);
	memcpy(&cmd[6], iv, 16);
	}
    
#if ENDIAN_LITTLE
    /* IV and key(s) must be byte-swapped. */
    for (i = 2; i < 10; i++)
	cmd[i] = swap4(cmd[i]);
#endif

    CACHE_DMA_SYNC(cmd, 80);
    mcr[1] = PHYS_TO_PCI(PTR_TO_PHYS(cmd));

    /* input fragment */
    mcr[2] = swap ? PHYS_TO_PCI_D(PTR_TO_PHYS(message))
                  : PHYS_TO_PCI(PTR_TO_PHYS(message));
    mcr[3] = 0;
    mcr[4] = V_DBC_DATA_LEN(msg_len);

    mcr[5] = V_PD_PKT_LEN(msg_len);

    /* output fragment */
    mcr[6] = swap ? PHYS_TO_PCI_D(PTR_TO_PHYS(cipher))
                  : PHYS_TO_PCI(PTR_TO_PHYS(cipher));
    mcr[7] = 0;    /* HMAC output would go here */
    mcr[8] = V_DBC_DATA_LEN(msg_len);

    return mcr;
}

static void
bs_check_ipsec (uint8_t *crypt, const uint8_t *cipher, size_t len)
{
    int i;

    CACHE_DMA_INVAL(crypt, len);

    xprintf(" ");
    for (i = 0; i < len; i++)
	xprintf("%02x", crypt[i]);
    if (memcmp(crypt, cipher, len) == 0)
	xprintf(" - pass\n");
    else {
	xprintf(" -fail\n   (");
	for (i = 0; i < len; i++)
	    xprintf("%02x", cipher[i]);
	xprintf(")\n");
    }
}

static void
bs_free_ipsec (uint32_t mcr[], int swap)
{
    KFREE(CACHED(PHYS_TO_PTR(PCI_TO_PHYS(mcr[1]))));
    bs_free_data(mcr[2], swap);
    bs_free_data(mcr[6], swap);

    KFREE(CACHED(mcr));
}

static uint8_t *
bs_ipsec (int device, int function,
	  const uint8_t *key1, const uint8_t *key2, const uint8_t *iv,
	  const uint8_t *msg, size_t len)
{
    crypto_info_t info;
    int swap;
    int arglen;
    uint32_t *mcr;
    int rc;
    uint8_t *cipher;

    arglen = sizeof(crypto_info_t);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_GETINFO, (unsigned char *)&info,
		   arglen, &arglen, 0);
    swap = (info.chip == BCM5820 || info.chip == OCP80B);
		   
    mcr = bs_alloc_ipsec(function, key1, key2, iv, msg, len, swap);

    arglen = sizeof(uint32_t *);
    CACHE_DMA_SYNC(mcr, MCR_WORDS(1)*4);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_CMD_1, (unsigned char *)SHARED(mcr),
		   arglen, &arglen, 0);
    CACHE_DMA_INVAL(mcr, MCR_WORDS(1)*4);

    cipher = swap ? PHYS_TO_PTR(PCI_TO_PHYS_D(mcr[6]))
                  : PHYS_TO_PTR(PCI_TO_PHYS(mcr[6]));
    mcr[6] = 0;
    bs_free_ipsec(mcr, swap);

    return cipher;
}

/* Unit checks on the implementation using RFC test suites, etc. */

static int
bs_check_md5 (int device)
{
    static const struct {
	const char *message;
	const char *digest;
    } md5_vectors[] = {
#if 0  /* 5821 cannot handle 0-length fragments (see Appendix B) */
	{"", "d41d8cd98f00b204e9800998ecf8427e"},
#endif
	{"a", "0cc175b9c0f1b6a831c399e269772661"},
	{"abc", "900150983cd24fb0d6963f7d28e17f72"},
	{"message digest", "f96b697d7cb7938d525a2f31aaf161d0"},
	{"abcdefghijklmnopqrstuvwxyz", "c3fcd3d76192e4007dfb496cca67e13b"},
	{"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
	 "d174ab98d277d9f5a5611c2c9f419d9f"},
	{"1234567890123456789012345678901234567890"
	   "1234567890123456789012345678901234567890",
	 "57edf4a22be3c955ac49da2e2107b67a"}
    };
    int i;

    xprintf("--------------- Pure MD5 Hash ----------------\n");
    for (i = 0; i < sizeof(md5_vectors)/sizeof(md5_vectors[0]); i++) {
	const char *message;
	uint8_t *hash;
	uint8_t  digest[16];

	message = md5_vectors[i].message;
	hash = bs_hash_md5(device, message, strlen(message));
	hex_encode(digest, md5_vectors[i].digest, sizeof(digest));
	bs_check_hash(hash, digest, sizeof(digest));
	KFREE(CACHED(hash));
	}

    return 0;
}

static int
bs_check_sha1 (int device)
{
    static const struct {
	const char *message;
	const char *digest;
    } sha1_vectors[] = {
	{"abc", "a9993e364706816aba3e25717850c26c9cd0d89d"},
	{"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
	 "84983e441c3bd26ebaae4aa1f95129e5e54670f1"}
    };
    int i;

    xprintf("-------------- Pure SHA-1 Hash ---------------\n");
    for (i = 0; i < sizeof(sha1_vectors)/sizeof(sha1_vectors[0]); i++) {
	const char *message;
	uint8_t *hash;
	uint8_t  digest[20];

	message = sha1_vectors[i].message;
	hash = bs_hash_sha1(device, message, strlen(message));
	hex_encode(digest, sha1_vectors[i].digest, sizeof(digest));
	bs_check_hash(hash, digest, sizeof(digest));
	KFREE(CACHED(hash));
	}

    return 0;
}


static int
bs_check_hmac_md5 (int device)
{
    /* Test cases from rfc2202 */
    static const struct {
        const char *key;      /* ASCII encoded hex */
	const char *message;
	const char *digest;   /* ASCII encoded hex */
    } md5_vectors[] = {
	{"0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b",
	 "Hi There",
         "9294727a3638bb1c13f48ef8158bfc9d"},
	{"4a656665",   /* "Jefe" */
	 "what do ya want for nothing?",
	 "750c783e6ab0b503eaa86e310a5db738"},
	{"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	 /* 0xdd repeated 50 times */
	  "\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd"
	  "\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd"
	  "\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd"
	  "\xdd\xdd",
	 "56be34521d144c88dbb8c733f0e8b3f6"},
	{"0102030405060708090a0b0c0d0e0f10111213141516171819",
	 /* 0xcd repeated 50 times */
	  "\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"
	  "\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"
	  "\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"
	  "\xcd\xcd",
	 "697eaf0aca3a3aea3a75164746ffaa79"},
	{"0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c",
	 "Test With Truncation",
	 "56461ef2342edc00f9bab995690efd4c"},
	{/* 0xaa repeated 80 times */
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	 "Test Using Larger Than Block-Size Key - Hash Key First",
	 "6b1ab7fe4bd7bf8f0b62e6ce61b9d0cd"},
	{/* 0xaa repeated 80 times */
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	 "Test Using Larger Than Block-Size Key and Larger "
	  "Than One Block-Size Data",
	 "6f630fad67cda0ee1fb1f562db3aa53e"},
    };
    int i;

    xprintf("--------------- IPsec MD5 HMAC ----------------\n");

    for (i = 0; i < sizeof(md5_vectors)/sizeof(md5_vectors[0]); i++) {
	uint8_t *key;
	size_t keylen;
	const char *message;
	uint8_t *hash;
	uint8_t  digest[16];

	keylen = strlen(md5_vectors[i].key)/2;
	key = KMALLOC(keylen, 0);
	hex_encode(key, md5_vectors[i].key, keylen);
	message = md5_vectors[i].message;
	hash = bs_hmac_md5(device, key, keylen, (const uint8_t*) message, 
                           strlen(message));
	KFREE(key);
	hex_encode(digest, md5_vectors[i].digest, sizeof(digest));
	bs_check_hmac(hash, digest, sizeof(digest));
	KFREE(CACHED(hash));
	}

    return 0;
}

static int
bs_check_hmac_sha1 (int device)
{
    /* Test cases from rfc2202 */
    static const struct {
        const char *key;      /* ASCII encoded hex */
	const char *message;
	const char *digest;   /* ASCII encoded hex */
    } sha1_vectors[] = {
	{"0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b",
	 "Hi There",
         "b617318655057264e28bc0b6fb378c8ef146be00"},
	{"4a656665",   /* "Jefe" */
	 "what do ya want for nothing?",
	 "effcdf6ae5eb2fa2d27416d5f184df9c259a7c79"},
	{"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	 /* 0xdd repeated 50 times */
	  "\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd"
	  "\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd"
	  "\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd\xdd"
	  "\xdd\xdd",
	 "125d7342b9ac11cd91a39af48aa17b4f63f175d3"},
	{"0102030405060708090a0b0c0d0e0f10111213141516171819",
	 /* 0xcd repeated 50 times */
	  "\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"
	  "\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"
	  "\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"
	  "\xcd\xcd",
	 "4c9007f4026250c6bc8414f9bf50c86c2d7235da"},
	{"0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c",
	 "Test With Truncation",
	 "4c1a03424b55e07fe7f27be1d58bb9324a9a5a04"},
	{/* 0xaa repeated 80 times */
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	 "Test Using Larger Than Block-Size Key - Hash Key First",
	 "aa4ae5e15272d00e95705637ce8a3b55ed402112"},
	{/* 0xaa repeated 80 times */
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	  "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
	 "Test Using Larger Than Block-Size Key and Larger "
	  "Than One Block-Size Data",
	 "e8e99d0f45237d786d6bbaa7965c7808bbff1a91"},
    };
    int i;

    xprintf("-------------- IPsec SHA-1 HMAC ---------------\n");
    for (i = 0; i < sizeof(sha1_vectors)/sizeof(sha1_vectors[0]); i++) {
	uint8_t *key;
	size_t keylen;
	const char *message;
	uint8_t *hash;
	uint8_t  digest[20];

	keylen = strlen(sha1_vectors[i].key)/2;
	key = KMALLOC(keylen, 0);
	hex_encode(key, sha1_vectors[i].key, keylen);
	message = sha1_vectors[i].message;
	hash = bs_hmac_sha1(device, key, keylen, (const uint8_t*) message, 
                            strlen(message));
	KFREE(key);
	hex_encode(digest, sha1_vectors[i].digest, sizeof(digest));
	bs_check_hmac(hash, digest, sizeof(digest));
	KFREE(CACHED(hash));
	}

    return 0;
}


static int
bs_check_ipsec_3des (int device)
{
    static const struct {
        const char *key1;
	const char *key2;
	const char *iv;
	const char *message;
	const char *cipher;
    } des_vectors[] = {
	/* From NIST FIP81 (single DES) */
	{"0123456789abcdef", "0123456789abcdef", "1234567890abcdef",
	 /* C1: "Now is the time for all " */
	 "4e6f77206973207468652074696d6520666f7220616c6c20",
	 "e5c7cdde872bf27c43e934008c389c0f683788499a7c05f6"},
	{"0123456789abcdef", "0123456789abcdef", "1234567890abcdef",
	 /* F1: "7654321 Now is the time for " */
	 "37363534333231204e6f77206973207468652074696d6520666f722000000000",
	 "b9916b8ee4c3da64b4f44e3cbefb99484521388fa59ae67d58d2e77e86062733"}
    };
    int i;

    xprintf("------------ IPsec 3DES Encrypt ---------------\n");
    for (i = 0; i < sizeof(des_vectors)/sizeof(des_vectors[0]); i++) {
	char    *message;
	size_t   len;
	uint8_t *crypt, *cipher;
	uint8_t  key1[8], key2[8], iv[8];

	hex_encode(key1, des_vectors[i].key1, 8);
	hex_encode(key2, des_vectors[i].key2, 8);
	hex_encode(iv, des_vectors[i].iv, 8);
	len = strlen(des_vectors[i].message)/2;
	message = KMALLOC(len, 0);
	hex_encode((uint8_t*)message, des_vectors[i].message, len);
	crypt = bs_ipsec(device, K_IPSEC_3DES, key1, key2, iv, 
                         (const uint8_t*) message, len);
	KFREE(message);
	cipher = KMALLOC(len, 0);
	hex_encode(cipher, des_vectors[i].cipher, len);
	bs_check_ipsec(crypt, cipher, len);
	KFREE(CACHED(crypt));
	KFREE(cipher);
	}

    return 0;
}

static int
bs_check_ipsec_aes (int device)
{
    static const struct {
        const char *key;
	const char *iv;
	const char *message;
	const char *cipher;
    } aes_vectors[] = {
	{"00000000000000000000000000000000",
	 "00000000000000000000000000000000",
	 "00000000000000000000000000000000",
	 "66e94bd4ef8a2c3b884cfa59ca342b2e"},
	{"2b7e151628aed2a6abf7158809cf4f3c",
	 "000102030405060708090a0b0c0d0e0f", 
	 "6bc1bee22e409f96e93d7e117393172a"
	 "ae2d8a571e03ac9c9eb76fac45af8e51"
	 "30c81c46a35ce411e5fbc1191a0a52ef"
	 "f69f2445df4f9b17ad2b417be66c3710",
	 "7649abac8119b246cee98e9b12e9197d"
	 "5086cb9b507219ee95db113a917678b2"
	 "73bed6b8e3c1743b7116e69e22229516"
	 "3ff1caa1681fac09120eca307586e1a7"},
    };
    crypto_info_t info;
    int arglen, rc;
    int i;

    xprintf("------------- IPsec AES Encrypt ---------------\n");

    arglen = sizeof(crypto_info_t);
    rc = cfe_ioctl(device, IOCTL_CRYPTO_GETINFO, (unsigned char *)&info,
		   arglen, &arglen, 0);
    if (info.chip != BCM5823 && info.chip != OCP80B) {
	xprintf("  *** AES not supported by this chip. ***\n");
	return -1;
	}

    for (i = 0; i < sizeof(aes_vectors)/sizeof(aes_vectors[0]); i++) {
	uint8_t *message;
	size_t   len;
	uint8_t *crypt, *cipher;
	uint8_t  key[16], iv[16];

	hex_encode(key, aes_vectors[i].key, sizeof(key));
	hex_encode(iv, aes_vectors[i].iv, sizeof(iv));
	len = strlen(aes_vectors[i].message)/2;
	message = KMALLOC(len, 0);
	hex_encode(message, aes_vectors[i].message, len);
	crypt = bs_ipsec(device, K_IPSEC_AES, key, NULL, iv, message, len);
	KFREE(message);
	cipher = KMALLOC(len, 0);
	hex_encode(cipher, aes_vectors[i].cipher, len);
	bs_check_ipsec(crypt, cipher, len);
	KFREE(CACHED(crypt));
	KFREE(cipher);
	}

    return 0;
}


/* Auxiliary functions */

int bs_check (int device);
int
bs_check (int device)
{
    bs_check_md5(device);
    bs_check_sha1(device);

    bs_check_hmac_md5(device);
    bs_check_hmac_sha1(device);

    bs_check_ipsec_3des(device);
    bs_check_ipsec_aes(device);

    return 0;
}


int bs_test (int device, int trials);
int
bs_test (int device, int trials)
{
#if 0
    bs_composite(device, 1472, trials);
#else
    xprintf("crypto: command \"crypt\" temporarily withdrawn\n");
#endif

    return 0;
}

int bs_test2 (int device0, int device1, int trials);
int
bs_test2 (int device0, int device1, int trials)
{
#if 0
    bs_composite2(device0, device1, 1472, trials);
#else
    xprintf("crypto: command \"crypt2\" temporarily withdrawn\n");
#endif

    return 0;
}
