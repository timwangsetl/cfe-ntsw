/*
 * THIS FILE AUTOMATICALLY GENERATED.  DO NOT EDIT.
 *
 * generated from:
 *	pcidevs 2002/09/03 broadcom 
 */

/*
 * Copyright (c) 1995, 1996 Christopher G. Demetriou
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Christopher G. Demetriou
 *	for the NetBSD Project.
 * 4. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

static const struct pci_knowndev pci_knowndevs[] = {
	{
	    PCI_VENDOR_ADP, PCI_PRODUCT_ADP_AIC6915,
	    0,
	    "Adaptec",
	    "AIC-6915 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_ALSC, PCI_PRODUCT_ALSC_SP1011,
	    0,
	    "Alliance Semiconductor",
	    "SP1011 HyperTransport-PCI Bridge",
	},
	{
	    PCI_VENDOR_ALSC, PCI_PRODUCT_ALSC_AS90L10208,
	    0,
	    "Alliance Semiconductor",
	    "AS90L10208 HyperTransport-PCI-X Bridge",
	},
	{
	    PCI_VENDOR_AMD, PCI_PRODUCT_AMD_HT7520,
	    0,
	    "Advanced Micro Devices",
	    "(PLX) HT7520 PCI-X Tunnel",
	},
	{
	    PCI_VENDOR_AMD, PCI_PRODUCT_AMD_HT7520_PIC,
	    0,
	    "Advanced Micro Devices",
	    "(PLX) HT7520 PCI-X IOAPIC",
	},
	{
	    PCI_VENDOR_AMD, PCI_PRODUCT_AMD_AMD8151_AGP,
	    0,
	    "Advanced Micro Devices",
	    "AMD8151 AGP Device",
	},
	{
	    PCI_VENDOR_AMD, PCI_PRODUCT_AMD_AMD8151,
	    0,
	    "Advanced Micro Devices",
	    "AMD8151 HyperTransport-AGP Bridge",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5700,
	    0,
	    "Broadcom",
	    "BCM5700 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5701,
	    0,
	    "Broadcom",
	    "BCM5701 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5703_0,
	    0,
	    "Broadcom",
	    "BCM5703 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5704C,
	    0,
	    "Broadcom",
	    "BCM5704 Dual 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5706,
	    0,
	    "Broadcom",
	    "BCM5706 10/100/1000 Ethernet TOE",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5705,
	    0,
	    "Broadcom",
	    "BCM5705 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5750,
	    0,
	    "Broadcom",
	    "BCM5750 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5705,
	    0,
	    "Broadcom",
	    "BCM5705 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5703,
	    0,
	    "Broadcom",
	    "BCM5703 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5704S,
	    0,
	    "Broadcom",
	    "BCM5704 Dual 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5703_2,
	    0,
	    "Broadcom",
	    "BCM5703 10/100/1000 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM4401_B,
	    0,
	    "Broadcom",
	    "BCM4401 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM4401,
	    0,
	    "Broadcom",
	    "BCM4401 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM4704,
	    0,
	    "Broadcom",
	    "BCM4704 PCI Host Bridge",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM4710,
	    0,
	    "Broadcom",
	    "BCM4710/4702 PCI Host Bridge",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5365,
	    0,
	    "Broadcom",
	    "BCM5365 PCI Host Bridge",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5345,
	    0,
	    "Broadcom",
	    "BCM5345 Switching Processor",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5670,
	    0,
	    "Broadcom",
	    "BCM5670 HiGig Switch Fabric",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5671,
	    0,
	    "Broadcom",
	    "BCM5671 HiGig Switch Fabric",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5673,
	    0,
	    "Broadcom",
	    "BCM5673 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5674,
	    0,
	    "Broadcom",
	    "BCM5674 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5675,
	    0,
	    "Broadcom",
	    "BCM5675 HiGig Switch Fabric",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5680,
	    0,
	    "Broadcom",
	    "BCM5680 StrataSwitch Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5690,
	    0,
	    "Broadcom",
	    "BCM5690 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5691,
	    0,
	    "Broadcom",
	    "BCM5691 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5692,
	    0,
	    "Broadcom",
	    "BCM5692 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5693,
	    0,
	    "Broadcom",
	    "BCM5693 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5695,
	    0,
	    "Broadcom",
	    "BCM5695 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5820,
	    0,
	    "Broadcom",
	    "BCM5820 Security Processor",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5821,
	    0,
	    "Broadcom",
	    "BCM5821 Security Processor",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5822,
	    0,
	    "Broadcom",
	    "BCM5822 Security Processor",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5823,
	    0,
	    "Broadcom",
	    "BCM5823 Security Processor",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM5850,
	    0,
	    "Broadcom",
	    "BCM5850 SSL/TLS Protocol Processor",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM56304,
	    0,
	    "Broadcom",
	    "BCM56304 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM56504,
	    0,
	    "Broadcom",
	    "BCM56504 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM56601,
	    0,
	    "Broadcom",
	    "BCM56601 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_BROADCOM, PCI_PRODUCT_BROADCOM_BCM56602,
	    0,
	    "Broadcom",
	    "BCM56602 StrataXGS Ethernet Switch",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21050,
	    0,
	    "Digital Equipment",
	    "DECchip 21050 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21040,
	    0,
	    "Digital Equipment",
	    "DECchip 21040 Ethernet",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21140,
	    0,
	    "Digital Equipment",
	    "DECchip 21140 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21041,
	    0,
	    "Digital Equipment",
	    "DECchip 21041 Ethernet",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21142,
	    0,
	    "Digital Equipment",
	    "DECchip 21142/21143 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21052,
	    0,
	    "Digital Equipment",
	    "DECchip 21052 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21150,
	    0,
	    "Digital Equipment",
	    "DECchip 21150 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21150_2,
	    0,
	    "Digital Equipment",
	    "DECchip 21150 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21152,
	    0,
	    "Digital Equipment",
	    "DECchip 21152 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21153,
	    0,
	    "Digital Equipment",
	    "DECchip 21153 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_DEC, PCI_PRODUCT_DEC_21154,
	    0,
	    "Digital Equipment",
	    "DECchip 21154 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_HINT, PCI_PRODUCT_HINT_HB4,
	    0,
	    "Hint Corp.",
	    "HB4 PCI-PCI Bridge (PLX PCI6150)",
	},
	{
	    PCI_VENDOR_INTEL, PCI_PRODUCT_INTEL_IN_BUSINESS,
	    0,
	    "Intel",
	    "InBusiness Fast Ethernet LAN Controller",
	},
	{
	    PCI_VENDOR_INTEL, PCI_PRODUCT_INTEL_82559ER,
	    0,
	    "Intel",
	    "82559ER Fast Ethernet LAN Controller",
	},
	{
	    PCI_VENDOR_INTEL, PCI_PRODUCT_INTEL_EEPRO100,
	    0,
	    "Intel",
	    "EE Pro 100 10/100 Fast Ethernet",
	},
	{
	    PCI_VENDOR_INTEL, PCI_PRODUCT_INTEL_EEPRO100S,
	    0,
	    "Intel",
	    "EE Pro 100 Smart 10/100 Fast Ethernet",
	},
	{
	    PCI_VENDOR_INTEL, PCI_PRODUCT_INTEL_82557,
	    0,
	    "Intel",
	    "82557 Fast Ethernet LAN Controller",
	},
	{
	    PCI_VENDOR_INTEL, PCI_PRODUCT_INTEL_21154,
	    0,
	    "Intel",
	    "21154 PCI-PCI Bridge",
	},
	{
	    PCI_VENDOR_OPTI, PCI_PRODUCT_OPTI_82C862,
	    0,
	    "Opti",
	    "82C862 FireLink USB Controller",
	},
	{
	    PCI_VENDOR_PERICOM, PCI_PRODUCT_PERICOM_PI7C7300,
	    0,
	    "Pericom Semiconductor",
	    "PI7C7300",
	},
	{
	    PCI_VENDOR_PERICOM, PCI_PRODUCT_PERICOM_PI7C8150,
	    0,
	    "Pericom Semiconductor",
	    "PI7C8150",
	},
	{
	    PCI_VENDOR_PERICOM, PCI_PRODUCT_PERICOM_PI7C8152,
	    0,
	    "Pericom Semiconductor",
	    "PI7C8152",
	},
	{
	    PCI_VENDOR_NS, PCI_PRODUCT_NS_DP83810,
	    0,
	    "National Semiconductor",
	    "DP83810 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_NS, PCI_PRODUCT_NS_DP83815,
	    0,
	    "National Semiconductor",
	    "DP83815 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_REALTEK, PCI_PRODUCT_REALTEK_RT8139,
	    0,
	    "Realtek Semiconductor",
	    "8139 10/100 Ethernet",
	},
	{
	    PCI_VENDOR_SIBYTE, PCI_PRODUCT_SIBYTE_SB1250_PCI,
	    0,
	    "SiByte, Inc.",
	    "BCM1250 PCI Host Bridge",
	},
	{
	    PCI_VENDOR_SIBYTE, PCI_PRODUCT_SIBYTE_SB1250_LDT,
	    0,
	    "SiByte, Inc.",
	    "BCM1250 HyperTransport Host Bridge",
	},
	{
	    PCI_VENDOR_SIBYTE, PCI_PRODUCT_SIBYTE_SB1480_HTP,
	    0,
	    "SiByte, Inc.",
	    "BCM1480 HyperTransport Bridge (Primary)",
	},
	{
	    PCI_VENDOR_SIBYTE, PCI_PRODUCT_SIBYTE_SB1480_HTS,
	    0,
	    "SiByte, Inc.",
	    "BCM1480 HyperTransport Bridge (Secondary)",
	},
	{
	    PCI_VENDOR_SIBYTE, PCI_PRODUCT_SIBYTE_SB1480_PCIX,
	    0,
	    "SiByte, Inc.",
	    "BCM1480 PCI-X Host Bridge",
	},
	{
	    PCI_VENDOR_SIBYTE, PCI_PRODUCT_SIBYTE_SB1480_LDT,
	    0,
	    "SiByte, Inc.",
	    "BCM1480 HyperTransport Host Bridge",
	},
	{
	    PCI_VENDOR_TUNDRA, PCI_PRODUCT_TUNDRA_TEMPE,
	    0,
	    "Tundra Semiconductor",
	    "Tempe VME Bridge",
	},
	{
	    PCI_VENDOR_NS, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "National Semiconductor",
	    NULL,
	},
	{
	    PCI_VENDOR_DEC, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Digital Equipment",
	    NULL,
	},
	{
	    PCI_VENDOR_AMD, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Advanced Micro Devices",
	    NULL,
	},
	{
	    PCI_VENDOR_OPTI, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Opti",
	    NULL,
	},
	{
	    PCI_VENDOR_TEXASINST, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Texas Instruments",
	    NULL,
	},
	{
	    PCI_VENDOR_TUNDRA, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Tundra Semiconductor",
	    NULL,
	},
	{
	    PCI_VENDOR_REALTEK, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Realtek Semiconductor",
	    NULL,
	},
	{
	    PCI_VENDOR_SERVERWORKS, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "ServerWorks",
	    NULL,
	},
	{
	    PCI_VENDOR_PERICOM, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Pericom Semiconductor",
	    NULL,
	},
	{
	    PCI_VENDOR_ALSC, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Alliance Semiconductor",
	    NULL,
	},
	{
	    PCI_VENDOR_BROADCOM, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Broadcom",
	    NULL,
	},
	{
	    PCI_VENDOR_SIBYTE, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "SiByte, Inc.",
	    NULL,
	},
	{
	    PCI_VENDOR_HINT, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Hint Corp.",
	    NULL,
	},
	{
	    PCI_VENDOR_INTEL, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Intel",
	    NULL,
	},
	{
	    PCI_VENDOR_ADP, 0,
	    PCI_KNOWNDEV_NOPROD,
	    "Adaptec",
	    NULL,
	},
	{ 0, 0, 0, NULL, NULL, }
};
