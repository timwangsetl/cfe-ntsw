/*
 * $Id: factory_config.h,v 1.1.1.1 2007/01/31 00:39:23 sanjayg Exp $
 *
 * $Copyright: (c) 2004 Broadcom Corp.
 * All Rights Reserved.$
 *
 */

#ifndef _FACTORY_CONFIG_H_
#define _FACTORY_CONFIG_H_

/*
 * Handle to access factory configurables
 */
typedef void *FACTORYCFG_H;

/*
 * Functions
 */
extern FACTORYCFG_H factory_config_open(void);
extern bool factory_config_close(FACTORYCFG_H handle, bool commit);
extern unsigned short factory_config_get_size(FACTORYCFG_H handle);
extern const char *factory_config_get(FACTORYCFG_H handle, const char *name);
extern bool factory_config_set(FACTORYCFG_H handle, 
                               const char *name, const char *value);
extern void factory_config_clear(FACTORYCFG_H handle);
extern void factory_config_dump(FACTORYCFG_H handle, 
                                int (*_printf)(const char *, ...));

#endif /* _FACTORY_CONFIG_H_ */
